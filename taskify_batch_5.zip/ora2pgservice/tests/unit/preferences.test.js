'use strict';

// "My preferences": each user's own choices, kept apart per SSO ID, only known options stored.
const fs = require('fs');
const os = require('os');
const path = require('path');

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'dma-prefs-'));
process.env.MIGRATION_STAGING_DIR = dir;
const { DEFAULTS, getPreferences, savePreferences, clean } = require('../../services/preferences');

afterAll(() => fs.rmSync(dir, { recursive: true, force: true }));

test('a new user gets the defaults', async () => {
  expect(await getPreferences({ id: 'NEWUSER' })).toEqual(DEFAULTS);
});

test('each user keeps their own choices (the ID ignores case and the @domain)', async () => {
  await savePreferences({ id: 'abc123@corp' }, { monitor: { phases: false }, projects: { onlyMine: true } });
  await savePreferences({ id: 'XYZ9' }, { migrate: { emailMe: true, email: ' me@corp.com ' } });
  const a = await getPreferences({ id: 'ABC123' });
  expect(a.monitor).toMatchObject({ phases: false, serverUsage: true });
  expect(a.projects.onlyMine).toBe(true);
  const b = await getPreferences({ id: 'xyz9' });
  expect(b.migrate).toEqual({ emailMe: true, email: 'me@corp.com' });
  expect(b.monitor.phases).toBe(true);
});

test('unknown options and wrong types are dropped', () => {
  const c = clean({ monitor: { phases: 'no', hack: true }, admin: { x: 1 }, migrate: { email: 42 } });
  expect(c.monitor.phases).toBe(true);
  expect(c.monitor.hack).toBeUndefined();
  expect(c.admin).toBeUndefined();
  expect(c.migrate.email).toBe('');
});
