'use strict';

const path = require('path');
const { CONSTANTS } = require('../utils/constants');
const store = require('./projectStore');

/**
 * Each user's own display preferences ("My preferences" in the account menu): what they want to see
 * on the screens, remembered on the server, so they follow the user to any browser or PC. They only
 * change what that user sees; admin-only parts stay admin-only whatever a user chooses.
 * One file in the staging folder: { users: { <SSO ID>: prefs } } ("_local" without SSO).
 */
const FILE = () => path.join(CONSTANTS.STAGING_DIR, '.dma_preferences.json');

const DEFAULTS = {
  monitor: { phases: true, serverUsage: true, autoTune: true, timeReport: true, logProblems: true },
  projects: { onlyMine: false },
  migrate: { emailMe: false, email: '' },
};

const keyOf = (user) => (user && user.id ? String(user.id).split('@')[0].toUpperCase() : '_local');

/** Only the known options, with the right types; anything else is dropped. */
function clean(input) {
  const out = {};
  for (const [group, fields] of Object.entries(DEFAULTS)) {
    out[group] = {};
    for (const [k, def] of Object.entries(fields)) {
      const v = input && input[group] ? input[group][k] : undefined;
      if (typeof def === 'boolean') out[group][k] = typeof v === 'boolean' ? v : def;
      else out[group][k] = typeof v === 'string' ? v.trim().slice(0, 200) : def;
    }
  }
  return out;
}

async function readAll() {
  const data = await store.readJson(FILE()).catch(() => null);
  return data && data.users ? data : { users: {} };
}

async function getPreferences(user) {
  return clean((await readAll()).users[keyOf(user)]);
}

async function savePreferences(user, prefs) {
  const all = await readAll();
  const saved = clean(prefs);
  all.users[keyOf(user)] = { ...saved, updatedAt: new Date().toISOString() };
  await store.writeJsonAtomic(FILE(), all);
  return saved;
}

module.exports = { DEFAULTS, getPreferences, savePreferences, clean };
