'use strict';

const oracledb = require('oracledb');
const logger = require('../utils/logger');

/**
 * "Where did the time go?" Every few seconds while tables load, DMA looks at what the sessions
 * of each loading table are doing, on both sides:
 *   Oracle  (v$session): working (CPU, disk reads)      -> "oracle"
 *                        sending rows over the network  -> "network"
 *                        waiting for ora2pg             -> idle
 *   PostgreSQL (pg_stat_activity): writing (COPY busy)  -> "pg"
 *                        waiting for rows               -> idle
 * When both sides wait, ora2pg on this server is converting rows ("ora2pg"). No session seen
 * (starting, between parts) is "other". Each sample's seconds are split between the buckets in
 * proportion, and added up per table in t.timeSplit.
 * Oracle's side needs read access to v$session / v$sqlarea (SELECT_CATALOG_ROLE); without it
 * only PostgreSQL's side is measured, and Oracle, network and ora2pg are one bucket ("source").
 */
const BUCKETS = ['oracle', 'network', 'ora2pg', 'pg', 'source', 'other'];
const esc = (s) => String(s).replace(/[.*+?^${}()|[\]\\$#]/g, '\\$&');

/** What an Oracle session is doing: 'oracle' (working), 'network' (sending rows) or 'idle' (waiting for its client). */
function oracleActivity({ state, event, waitClass }) {
  if (state !== 'WAITING') return 'oracle'; // on CPU
  if (/^SQL\*Net (more data|message) to client/i.test(event || '')) return 'network';
  if (waitClass === 'Idle' || /from client/i.test(event || '')) return 'idle';
  return 'oracle'; // disk reads, undo, latches ...
}

/** What a PostgreSQL session is doing: 'pg' (working) or 'idle' (waiting for its client). */
function pgActivity({ state, waitEvent }) {
  return state === 'active' && waitEvent !== 'ClientRead' ? 'pg' : 'idle';
}

/** The table (Oracle name) an Oracle statement reads: the one after its FROM. */
function oracleTableOf(sql, schema, names) {
  if (!sql) return null;
  for (const n of names) {
    const re = new RegExp(`\\bFROM\\s+(?:"?${esc(schema)}"?\\s*\\.\\s*)?"?${esc(n)}"?(?=[\\s),]|$)`, 'i');
    if (re.test(sql)) return n;
  }
  return null;
}

/** The table (Oracle name) a PostgreSQL statement works on: COPY / INSERT into it, or its schema-qualified name. */
function pgTableOf(sql, pgSchema, pgNames) {
  if (!sql) return null;
  for (const [pgName, name] of pgNames) {
    const t = `"?${esc(pgName)}"?`;
    const sch = `"?${esc(pgSchema)}"?\\s*\\.\\s*`;
    if (new RegExp(`^\\s*(?:COPY|INSERT\\s+INTO)\\s+(?:${sch})?${t}(?=[\\s(]|$)`, 'i').test(sql)) return name;
    if (new RegExp(`${sch}${t}(?=[\\s(),;]|$)`, 'i').test(sql)) return name;
  }
  return null;
}

/**
 * Shares of one sample for one table, from what its sessions do. Working sessions count; when none
 * works but some wait for each other, ora2pg (between them) is the busy one.
 */
function splitSample(acts) {
  const votes = { oracle: 0, network: 0, pg: 0 };
  let idle = 0;
  for (const a of acts) {
    if (a === 'idle') idle += 1;
    else votes[a] += 1;
  }
  const sum = votes.oracle + votes.network + votes.pg;
  if (!sum) return idle ? { ora2pg: 1 } : { other: 1 };
  const out = {};
  for (const [k, v] of Object.entries(votes)) if (v) out[k] = v / sum;
  return out;
}

/** Adds up seconds per bucket; the biggest bucket, and a plain sentence about it. */
function summarize(splits) {
  const total = Object.fromEntries(BUCKETS.map((b) => [b, 0]));
  for (const s of splits) for (const b of BUCKETS) total[b] += (s && s[b]) || 0;
  const measured = BUCKETS.reduce((a, b) => a + total[b], 0);
  const top = BUCKETS.filter((b) => b !== 'other').sort((a, b) => total[b] - total[a])[0];
  return { total, measured, top: measured && total[top] / measured >= 0.4 ? top : null };
}

class TimeSampler {
  /**
   * run: the Run (state, project, pools). intervalMs: how often to look.
   * oracleQuery / pgQuery: (sql, binds) => rows as objects; given by the run, replaced in tests.
   */
  constructor({ run, intervalMs = 5000, oracleQuery, pgQuery }) {
    this.run = run;
    this.intervalMs = intervalMs;
    this.oracleQuery = oracleQuery;
    this.pgQuery = pgQuery;
    this.sqlTables = new Map(); // Oracle sql_id -> table name or null
    this.oracleOk = true;
    this.timer = null;
    this.busy = false;
    this.last = 0;
  }

  start() {
    this.last = Date.now();
    this.timer = setInterval(() => this.tick().catch((err) => logger.error(`Time sampling: ${err.message}`)), this.intervalMs);
    if (this.timer.unref) this.timer.unref();
  }

  stop() {
    clearInterval(this.timer);
    this.timer = null;
  }

  async oracleSessions(names) {
    if (!this.oracleOk) return null;
    try {
      const sessions = await this.oracleQuery(
        `SELECT state AS "state", event AS "event", wait_class AS "waitClass", NVL(sql_id, prev_sql_id) AS "sqlId"
           FROM v$session WHERE username = USER AND type = 'USER' AND sid <> TO_NUMBER(SYS_CONTEXT('USERENV', 'SID'))`, []);
      const unknown = [...new Set(sessions.map((s) => s.sqlId).filter((id) => id && !this.sqlTables.has(id)))].slice(0, 200);
      if (unknown.length) {
        if (this.sqlTables.size > 5000) this.sqlTables.clear();
        const binds = unknown.map((_, i) => `:${i + 1}`).join(',');
        const texts = await this.oracleQuery(`SELECT sql_id AS "sqlId", sql_fulltext AS "text" FROM v$sqlarea WHERE sql_id IN (${binds})`, unknown);
        for (const id of unknown) this.sqlTables.set(id, null);
        for (const t of texts) this.sqlTables.set(t.sqlId, oracleTableOf(t.text, this.run.state.schema, names));
      }
      return sessions.map((s) => ({ table: this.sqlTables.get(s.sqlId) || null, act: oracleActivity(s) }));
    } catch (err) {
      // Usually ORA-00942: no read access to v$session. Measure PostgreSQL's side only.
      this.oracleOk = false;
      this.run.state.timeSplitNote = `Oracle's side is not measured (${String(err.message).split('\n')[0]}). Ask the DBA for SELECT_CATALOG_ROLE to see Oracle reading and network apart.`;
      logger.warn(`Time sampling: Oracle side off: ${err.message}`);
      return null;
    }
  }

  async tick() {
    if (this.busy) return;
    const tables = Object.values(this.run.state.tables).filter((t) => t.status === 'running' && !t.waiting);
    const now = Date.now();
    const seconds = Math.min(30, (now - this.last) / 1000);
    this.last = now;
    if (!tables.length) return;
    this.busy = true;
    try {
      const names = tables.map((t) => t.name);
      const pgNames = tables.map((t) => [this.run.pgName(t.name), t.name]);
      const [ora, pg] = await Promise.all([
        this.oracleSessions(names),
        this.pgQuery(
          `SELECT state, wait_event AS "waitEvent", query FROM pg_stat_activity
            WHERE datname = current_database() AND usename = current_user AND pid <> pg_backend_pid()`, [])
          .then((rows) => rows.map((r) => ({ table: pgTableOf(r.query, this.run.pgSchema, pgNames), act: pgActivity(r) })))
          .catch((err) => { logger.warn(`Time sampling: PostgreSQL side: ${err.message}`); return []; }),
      ]);
      for (const t of tables) {
        const acts = [...(ora || []), ...pg].filter((x) => x.table === t.name).map((x) => x.act);
        // Without Oracle's side, PostgreSQL waiting means "Oracle, network or ora2pg": one bucket, "source".
        const share = ora ? splitSample(acts) : acts.includes('pg') ? { pg: 1 } : acts.length ? { source: 1 } : { other: 1 };
        const split = t.timeSplit || Object.fromEntries(BUCKETS.map((b) => [b, 0]));
        for (const [b, f] of Object.entries(share)) split[b] = Math.round((split[b] + f * seconds) * 10) / 10;
        t.timeSplit = split;
      }
      this.run.save();
    } finally {
      this.busy = false;
    }
  }
}

/** The run's queries for the sampler: Oracle rows as objects (CLOB text as a string), PostgreSQL rows. */
function samplerFor(run, oracleClient, pgClient) {
  return new TimeSampler({
    run,
    oracleQuery: async (sql, binds) => {
      const conn = await oracleClient.getOracleConnection(run.projectName);
      try {
        const r = await conn.execute(sql, binds, { outFormat: oracledb.OUT_FORMAT_OBJECT, fetchInfo: { text: { type: oracledb.STRING } } });
        return r.rows;
      } finally {
        await conn.close().catch(() => {});
      }
    },
    pgQuery: async (sql, params) => (await pgClient.pgQuery(sql, params, run.projectName)).rows,
  });
}

module.exports = { BUCKETS, TimeSampler, samplerFor, oracleActivity, pgActivity, oracleTableOf, pgTableOf, splitSample, summarize };
