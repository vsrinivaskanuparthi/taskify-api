'use strict';

const fs = require('fs');
const os = require('os');

/**
 * How busy this server (the one DMA and ora2pg run on) is: CPU % of all cores and memory in use.
 * Used by auto-tune (never overload the server) and shown on the Live monitor.
 */

/**
 * Memory this server can still give to new processes, in bytes. os.freemem() leaves out the file
 * cache (on Linux with older Node versions, and on macOS), which makes a busy server look full: on
 * Linux MemAvailable is read instead; elsewhere the memory check is skipped (Infinity).
 */
function availableMemory() {
  if (process.platform !== 'linux') return Infinity;
  try {
    const m = /^MemAvailable:\s+(\d+) kB/m.exec(fs.readFileSync('/proc/meminfo', 'utf8'));
    return m ? Number(m[1]) * 1024 : os.freemem();
  } catch {
    return os.freemem();
  }
}

/** CPU time of all cores so far (idle and total), in ms. */
function cpuTimes() {
  let idle = 0;
  let total = 0;
  for (const c of os.cpus()) {
    const t = c.times;
    idle += t.idle;
    total += t.user + t.nice + t.sys + t.idle + t.irq;
  }
  return { idle, total, at: Date.now() };
}

/** CPU % of all cores between two calls of percent() (null on the first call). */
class CpuMeter {
  constructor() {
    this.last = cpuTimes();
  }

  percent() {
    const now = cpuTimes();
    const total = now.total - this.last.total;
    const pct = total > 0 ? Math.max(0, Math.min(100, Math.round((1 - (now.idle - this.last.idle) / total) * 100))) : null;
    this.last = now;
    return pct;
  }
}

const shared = new CpuMeter();

/** CPU % and memory of this server now. The CPU is measured over at least half a second. */
async function serverUsage() {
  const since = Date.now() - shared.last.at;
  if (since < 500) await new Promise((r) => setTimeout(r, 500 - since));
  const cpuPct = shared.percent();
  const total = os.totalmem();
  const avail = availableMemory();
  const free = Number.isFinite(avail) ? avail : os.freemem();
  return {
    cpuPct,
    cores: os.cpus().length,
    memTotalGb: Math.round((total / 1024 ** 3) * 10) / 10,
    memUsedGb: Math.round(((total - free) / 1024 ** 3) * 10) / 10,
    memUsedPct: Math.round(((total - free) / total) * 100),
    at: new Date().toISOString(),
  };
}

module.exports = { availableMemory, CpuMeter, serverUsage };
