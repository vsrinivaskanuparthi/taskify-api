'use strict';

const { availableMemory, CpuMeter } = require('./serverUsage');

/**
 * Auto-tune speed: during the data phase DMA changes how many loads run at once ("readers"),
 * from the speed it measures. Not AI, a measured feedback rule:
 *   - every few minutes (AUTO_TUNE_SECONDS, default 120) it measures MB/s over the last window;
 *   - it adds readers while the speed rises (by 5 % or more), one at a time, or a quarter more when
 *     there are already many;
 *   - when an added reader did not make it faster, it steps back and holds for a few windows, then
 *     tries again (the tables being loaded change during a run);
 *   - when the speed falls hard at the same number of readers, it removes one;
 *   - it never goes above the maximum (the pre-flight checked Oracle sessions and PostgreSQL
 *     connections for it) and never adds readers while this server's CPU or memory is short;
 *   - when this server's CPU is nearly full (CPU_MAX + 10 %, default 95 %) or memory is short, it
 *     removes one, so ora2pg never takes the whole server.
 * Each ora2pg load (a table, or one part of a big table) takes one reader; a big table read with
 * several Oracle readers at once (-J) takes that many.
 */
const GAIN = 0.05; // an added reader must make the run at least 5 % faster
const FALL = 0.25; // at the same readers, 25 % slower is a real drop (not noise)
const HOLD = 3; // windows to wait after a step back before trying again
const BUSY = 0.8; // readers busy at least 80 % of the window, or there is not enough work to judge
// This server's CPU (all cores): no reader is added at CPU_MAX % or more, one is removed at CPU_HIGH %.
const CPU_MAX = Math.min(95, Math.max(50, Number(process.env.AUTO_TUNE_CPU_MAX) || 85));
const CPU_HIGH = Math.min(98, CPU_MAX + 10);

/** Readers to add in one step: one, or a quarter more when there are already many. */
const stepUp = (readers, max) => Math.min(max, readers + Math.max(1, Math.round(readers * 0.25)));

/**
 * Lets at most `limit` loads run at once; the limit can change while loads run (a lower limit
 * only stops new loads from starting). Loads start in the order they asked (first come, first served).
 */
class Gate {
  constructor(limit = Infinity) {
    this.limit = limit;
    this.used = 0;
    this.queue = [];
  }

  /** Waits for `weight` free readers (a load bigger than the limit runs alone); resolves to release(). */
  acquire(weight = 1) {
    const w = Math.max(1, weight);
    return new Promise((resolve) => {
      this.queue.push({ w, resolve });
      this.pump();
    });
  }

  get waiting() {
    return this.queue.length;
  }

  setLimit(limit) {
    this.limit = Math.max(1, limit);
    this.pump();
  }

  pump() {
    while (this.queue.length) {
      const next = this.queue[0];
      if (this.used > 0 && this.used + next.w > this.limit) return;
      this.queue.shift();
      this.used += next.w;
      let released = false;
      next.resolve(() => {
        if (released) return;
        released = true;
        this.used -= next.w;
        this.pump();
      });
    }
  }
}

/**
 * One tuning decision. s: the tuner's memory { readers, ref: {readers, mbps} | null, last: 'up' |
 * null, hold }; w: the window just measured { mbps, busy (0..1), waiting (loads queued), cpuBusy
 * (no more readers), cpuHigh (one reader less), cpuPct, memoryLow }. Returns { readers, ref, last, hold, action: 'up' | 'down' | 'back' | 'keep', why }.
 */
function decide(s, w, { min, max }) {
  const out = { readers: s.readers, ref: s.ref, last: null, hold: Math.max(0, (s.hold || 0) - 1), action: 'keep', why: '' };
  const pct = (a, b) => `${Math.round((a / b - 1) * 100)}%`;
  const canAdd = () => {
    if (out.readers >= max) return `at the maximum (${max})`;
    if (!w.waiting || w.busy < BUSY) return 'all remaining work is already running';
    if (w.memoryLow) return 'this server is short of memory';
    if (w.cpuBusy) return `this server's CPU is busy${w.cpuPct != null ? ` (${w.cpuPct}%)` : ''}`;
    return null;
  };
  const up = (why) => {
    const blocked = canAdd();
    if (blocked) { out.why = `${why ? `${why}; ` : ''}not adding: ${blocked}`; return out; }
    out.readers = stepUp(s.readers, max);
    out.last = 'up';
    out.action = 'up';
    out.why = `${why ? `${why}; ` : ''}trying ${out.readers}`;
    return out;
  };

  // Server short of memory: one reader less, whatever the speed.
  if (w.memoryLow && s.readers > min) {
    Object.assign(out, { readers: s.readers - 1, ref: null, action: 'down', why: 'this server is short of memory' });
    return out;
  }
  // CPU nearly full: one reader less, and wait a few windows before trying more.
  if (w.cpuHigh && s.readers > min) {
    Object.assign(out, { readers: s.readers - 1, ref: null, action: 'down', hold: HOLD, why: `this server's CPU is at ${w.cpuPct != null ? `${w.cpuPct}%` : 'its limit'}` });
    return out;
  }
  if (!(w.mbps > 0)) {
    out.why = 'no data moved in this window (indexes, checks or a table starting)';
    return out;
  }
  // An added reader is judged against the speed before it.
  if (s.last === 'up' && s.ref) {
    if (w.mbps >= s.ref.mbps * (1 + GAIN)) {
      out.ref = { readers: s.readers, mbps: w.mbps };
      return up(`${s.readers} readers: ${pct(w.mbps, s.ref.mbps)} faster`);
    }
    Object.assign(out, { readers: s.ref.readers, ref: { readers: s.ref.readers, mbps: s.ref.mbps }, action: 'back', hold: HOLD,
      why: `${s.readers} readers were not faster (${pct(w.mbps, s.ref.mbps)}): back to ${s.ref.readers}` });
    return out;
  }
  if (out.hold > 0) {
    out.ref = { readers: s.readers, mbps: w.mbps };
    out.why = 'holding after a step back';
    return out;
  }
  // Same readers, much slower: Oracle, the network or PostgreSQL is overloaded.
  if (s.ref && s.ref.readers === s.readers && w.mbps < s.ref.mbps * (1 - FALL) && s.readers > min && w.busy >= BUSY) {
    Object.assign(out, { readers: s.readers - 1, ref: null, action: 'down', hold: HOLD, why: `speed fell ${pct(w.mbps, s.ref.mbps)} at ${s.readers} readers` });
    return out;
  }
  out.ref = { readers: s.readers, mbps: w.mbps };
  return up('');
}

/** What the slow side is, from the time report of the tables loading now (for the status line). */
function slowSide(tables) {
  const total = {};
  for (const t of tables) for (const [k, v] of Object.entries(t.timeSplit || {})) total[k] = (total[k] || 0) + v;
  const sum = Object.entries(total).filter(([k]) => k !== 'other').reduce((a, [, v]) => a + v, 0);
  const [top, secs] = Object.entries(total).filter(([k]) => k !== 'other').sort((a, b) => b[1] - a[1])[0] || [];
  if (!sum || secs / sum < 0.4) return null;
  const what = { oracle: 'Oracle reading', network: 'the network from Oracle', ora2pg: 'ora2pg on this server (CPU)', pg: 'PostgreSQL writing', source: 'Oracle, the network or ora2pg' }[top];
  return what ? `${what} takes most of the time (${Math.round((secs / sum) * 100)}%)` : null;
}

/** Readers to start with and the most allowed, from the run's speed settings. */
function readerRange(opts) {
  const max = Math.max(1, opts.maxReaders > 0 ? Math.min(opts.maxReaders, opts.parallelTables * opts.oracleCopies) : opts.parallelTables * opts.oracleCopies);
  const min = Math.min(2, max);
  return { min, max, start: Math.min(max, Math.max(min, opts.parallelTables)) };
}

class SpeedTuner {
  /**
   * run: the Run (its state.tables and save/event). gate: the Gate it controls.
   * intervalMs: one measuring window. host: { cpuPct, freemem } (replaced in tests).
   */
  constructor({ run, gate, intervalMs, host }) {
    this.run = run;
    this.gate = gate;
    this.intervalMs = intervalMs || Math.max(10, Number(process.env.AUTO_TUNE_SECONDS) || 120) * 1000;
    const cpu = new CpuMeter();
    this.host = host || { cpuPct: () => cpu.percent(), freemem: availableMemory };
    this.range = readerRange(run.state.options);
    this.mem = { readers: this.range.start, ref: null, last: null, hold: 0 };
    this.lastRows = new Map();
    this.busySum = 0;
    this.busyN = 0;
    this.cpuSum = 0;
    this.cpuN = 0;
    this.timers = [];
  }

  start() {
    this.gate.setLimit(this.mem.readers);
    this.mb(); // starting point of the first window
    this.publish({ action: 'start', why: `starting with ${this.mem.readers} readers, at most ${this.range.max}` });
    this.timers.push(setInterval(() => this.sampleBusy(), 5000), setInterval(() => this.tick(), this.intervalMs));
    this.timers.forEach((t) => t.unref && t.unref());
  }

  stop() {
    this.timers.forEach(clearInterval);
    this.timers = [];
    this.gate.setLimit(Infinity);
    const s = this.run.state.speed;
    if (s) {
      s.mbps = 0;
      this.run.save(true);
      if (this.run.emitRun) this.run.emitRun();
    }
  }

  sampleBusy() {
    this.busySum += Math.min(1, this.gate.used / Math.max(1, this.gate.limit));
    this.busyN += 1;
    const cpu = this.host.cpuPct();
    if (cpu != null) { this.cpuSum += cpu; this.cpuN += 1; }
  }

  /** MB moved since the last call: rows loaded since then × MB per row of each table. */
  mb() {
    let mb = 0;
    for (const t of Object.values(this.run.state.tables)) {
      const rows = t.rowsDone || 0;
      const before = this.lastRows.has(t.name) ? this.lastRows.get(t.name) : rows;
      if (rows > before && t.estRows > 0) mb += (rows - before) * (t.sizeMb / t.estRows);
      this.lastRows.set(t.name, rows);
    }
    return mb;
  }

  tick() {
    const secs = this.intervalMs / 1000;
    // CPU: the average of the window's 5-second samples (a short spike does not count).
    const cpuPct = this.cpuN ? Math.round(this.cpuSum / this.cpuN) : this.host.cpuPct();
    const window = {
      mbps: this.mb() / secs,
      busy: this.busyN ? this.busySum / this.busyN : 1,
      waiting: this.gate.waiting,
      cpuPct,
      cpuBusy: cpuPct != null && cpuPct >= CPU_MAX,
      cpuHigh: cpuPct != null && cpuPct >= CPU_HIGH,
      memoryLow: this.host.freemem() < 1024 ** 3,
    };
    this.busySum = 0;
    this.busyN = 0;
    this.cpuSum = 0;
    this.cpuN = 0;
    const before = this.mem.readers;
    const d = decide(this.mem, window, this.range);
    if (this.run.log) this.run.log.info(`Auto-tune window: ${window.mbps.toFixed(1)} MB/s, ${before} readers ${Math.round(window.busy * 100)}% busy, ${window.waiting} waiting${cpuPct != null ? `, CPU ${cpuPct}%` : ''}${window.memoryLow ? ', memory low' : ''} → ${d.action} ${d.readers} (${d.why})`);
    this.mem = { readers: d.readers, ref: d.ref, last: d.last, hold: d.hold };
    if (d.readers !== before) {
      this.gate.setLimit(d.readers);
      this.run.event('info', `Auto-tune: ${before} → ${d.readers} readers (${window.mbps.toFixed(1)} MB/s; ${d.why})`);
    }
    this.publish({ action: d.action, why: d.why, mbps: window.mbps, from: before, cpuPct });
  }

  publish({ action, why, mbps = 0, from, cpuPct = null }) {
    const s = this.run.state.speed || { auto: true, history: [] };
    const running = Object.values(this.run.state.tables).filter((t) => t.status === 'running' && !t.waiting);
    Object.assign(s, {
      auto: true,
      readers: this.mem.readers,
      min: this.range.min,
      max: this.range.max,
      mbps: Math.round(mbps * 10) / 10,
      why,
      cpuPct,
      cpuMax: CPU_MAX,
      slowSide: slowSide(running),
      at: new Date().toISOString(),
    });
    if (action !== 'keep') s.history = [...(s.history || []), { at: s.at, action, from: from ?? null, readers: this.mem.readers, mbps: s.mbps, why }].slice(-30);
    this.run.state.speed = s;
    this.run.save(true);
    if (this.run.emitRun) this.run.emitRun();
  }
}

module.exports = { Gate, SpeedTuner, decide, readerRange, slowSide, stepUp, availableMemory, CPU_MAX, CPU_HIGH };
