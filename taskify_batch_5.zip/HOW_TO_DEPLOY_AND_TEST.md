# DMA v2: feedback batch (CPU safety, server usage, preferences, monitor fixes)

How to deploy it by hand on RHEL, and what to test afterwards. The steps are the same as the last batch.

---

## 1. What this batch fixes (your 6 feedback points)

| # | Feedback | What changed |
|---|---|---|
| 1 | Normal users don't need "Where did the time go?" | Shown to **admins only** (DMA_ADMINS). Admins can also hide it in My preferences. |
| 2 | Preferences: choose what to see, saved and remembered | New **My preferences** in the account menu (top right). Any user can set them, **for themselves only**. Saved on the server, so they follow the user to any PC. Admin-only parts stay admin-only. |
| 3 | Tables show moving progress bars without loading anything | They were waiting for a free load slot (auto-tune). Now they show **Waiting**, with an empty bar and "waiting for a free load slot". Time counts from when they really start. Parts of a big table show "(3 loading, 5 waiting)". |
| 4 | Bell: Notification settings disabled on the home page | It was on purpose (notifications are per project) but confusing. Now it works everywhere: outside a project you **choose the project** first. |
| 5 | Auto-tune must not exhaust the CPU | Auto-tune now measures **real CPU %** of the server: no load added at **85%** or more, **one load removed at 95%**. Averaged over the window, so a short spike doesn't count. Change it with `AUTO_TUNE_CPU_MAX` in `.env` (optional). |
| 6 | Show server RAM and CPU | Live monitor: **Server CPU** and **Server memory** bars, updated every 5 seconds while the run goes (green / orange from 75% / red from 90%). |

**My preferences has:**
- Live monitor: show or hide Server CPU and memory, Auto-tune line, Phases, Errors in the run's log, Where did the time go? (admins).
- Projects: Show only my projects (also a switch on the Projects page, remembered).
- Migrate: tick "Email me when it ends" for me every time, and my email address.

---

## 2. Files in the zip

| File | |
|---|---|
| `ora2pgservice/services/serverUsage.js` | **new**: server CPU % and memory |
| `ora2pgservice/services/preferences.js` | **new**: each user's preferences |
| `ora2pgservice/services/autoTune.js` | CPU step-back |
| `ora2pgservice/services/migrate.js` | waiting tables / waiting parts |
| `ora2pgservice/services/timeSplit.js` | waiting tables not counted as loading |
| `ora2pgservice/routes/projectRoutes.js` | `/api/server-usage`, `/api/preferences` |
| `ora2pgservice/.env.optional` | documents `AUTO_TUNE_CPU_MAX` (nothing to add) |
| `ora2pgservice/tests/unit/autoTune.test.js`, `tests/unit/preferences.test.js`, `tests/e2e/options.e2e.test.js` | tests |
| `ora2pgui/src/prefs.ts`, `src/components/PreferencesDialog.tsx` | **new** |
| `ora2pgui/src/components/UserMenu.tsx`, `Bell.tsx`, `src/pages/RunPage.tsx`, `ProjectsPage.tsx`, `MigratePage.tsx` | changed |

**Not in the zip:** `server.js` (not changed) and `.env`. **No new npm packages.**

Preferences are stored in one file in the staging folder: `<MIGRATION_STAGING_DIR>/.dma_preferences.json`. It's created at the first save. It isn't a project, so the Projects page ignores it.

---

## 3. Deploy

1. Unzip. Copy `ora2pgservice/` over your `ora2pgservice` folder, and `ora2pgui/` over your `ora2pgui` folder.
2. In `ora2pgservice`: `npm test` should end with **Tests: 72 passed**.
3. In `ora2pgui`: `npm run build`.
4. Push `ora2pgservice` to the repository as usual.
5. On RHEL:
   ```bash
   curl -s http://127.0.0.1:5101/health        # "running":0 → no migration runs
   cd /path/to/ora2pgservice && git pull
   ls -l services/serverUsage.js services/preferences.js
   pm2 restart ora2pg-service-prod
   pm2 restart ora2pg-worker-prod              # only when no migration runs
   pm2 save
   ```
   Check:
   - `pm2 logs ora2pg-service-prod --lines 20 --nostream` shows "Connected to the migration worker".
   - `pm2 logs ora2pg-worker-prod --lines 20 --nostream` shows "worker is running".
6. Screens:
   ```bash
   sudo cp -p /usr/share/nginx/html/index.html /usr/share/nginx/html/index.html.previous
   sudo install -m 644 /tmp/dma_index.html /usr/share/nginx/html/index.html
   sudo restorecon /usr/share/nginx/html/index.html
   ```
   Then press **Ctrl+F5** in the browser.

Quick check from the server (needs a signed-in browser for the real screens; from curl it may say unauthorized, which is normal):
```bash
pm2 logs ora2pg-service-prod --lines 50 --nostream | grep -i error
```

---

## 4. What to test

**Test 1: My preferences (any user)**
- [ ] Account icon (top right) → **My preferences**. Switch off "Phases" → Save.
- [ ] Open a Live monitor: Phases is gone. Open the app on another PC or browser with the same login: still gone.
- [ ] A normal user (not in DMA_ADMINS) does **not** see "Where did the time go?", in the monitor or in My preferences.
- [ ] Projects page: switch on **Only my projects** → reload the page: still on.
- [ ] My preferences → tick "Email me when it ends" → the Migrate page has it ticked.

**Test 2: bell**
- [ ] On the Home or Projects page: bell → **Notification settings** works; choose a project, then its settings appear.

**Test 3: medium run with auto-tune (the important one)**
- [ ] Live monitor shows **Server CPU** and **Server memory** bars that move every few seconds.
- [ ] Tables that are started but wait for a slot show **Waiting** and an empty bar, not a moving bar. The "Waiting" tab counts them.
- [ ] The big table shows "parts x/y (n loading, m waiting)".
- [ ] Logs → Master log, search `Auto-tune window`: every line now has `CPU nn%`.
- [ ] If the CPU goes above 85%, the Auto-tune line says *"not adding: this server's CPU is busy (nn%)"*. If it goes above 95%, it removes a load: *"this server's CPU is at nn%"*.

**Going back:** the same as before (index.html.previous, git checkout of the previous commit). Auto-tune can still be switched off in Settings → Run defaults.

---

## 5. What to send me

1. The `Auto-tune window` lines (with CPU %) from a medium run.
2. A screenshot of the Live monitor with the CPU / memory bars and some waiting tables.
3. Anything red or unclear.
