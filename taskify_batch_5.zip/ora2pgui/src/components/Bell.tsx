import { Alert, Badge, Box, Button, Checkbox, CircularProgress, Divider, FormControlLabel, IconButton, Menu, MenuItem, Stack, Tab, Tabs, TextField, Tooltip, Typography } from '@mui/material';
import NotificationsRoundedIcon from '@mui/icons-material/NotificationsRounded';
import { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { api, projectPath } from '../api';
import { timeAgo } from '../format';
import { brand, monoFont } from '../theme';
import { StatusChip } from './ui';

interface Item { projectName: string; runId: string; status: string; startedAt: string | null; finishedAt: string | null; startedBy: string | null; tables: number; done: number; failed: number }
interface Notify { emails: string; webhook: string; onStart: boolean; onAttention: boolean; onFinish: boolean }

const SEEN_KEY = 'dma.bell.seen';
const readSeen = () => { try { return localStorage.getItem(SEEN_KEY) || ''; } catch { return ''; } };
const writeSeen = (v: string) => { try { localStorage.setItem(SEEN_KEY, v); } catch { /* private window */ } };

/** The project's email and Google Chat settings. Any user of the project may change them. */
function NotificationSettings({ project }: { project: string }) {
  const [n, setN] = useState<Notify | null>(null);
  const [smtp, setSmtp] = useState(true);
  const [busy, setBusy] = useState<'' | 'save' | 'test'>('');
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  useEffect(() => {
    api<{ notify: Notify; channels: { email: boolean } }>(`${projectPath(project)}/notifications`)
      .then((r) => { setN(r.notify); setSmtp(!!r.channels?.email); })
      .catch((e) => setMsg({ ok: false, text: e.message }));
  }, [project]);
  if (!n) return msg ? <Alert severity="error" sx={{ m: 2 }}>{msg.text}</Alert> : <Box sx={{ p: 3, display: 'grid', placeItems: 'center' }}><CircularProgress size={22} /></Box>;
  const set = (k: keyof Notify, v: any) => setN({ ...n, [k]: v });

  const save = async () => {
    setBusy('save');
    setMsg(null);
    try {
      const r = await api<{ notify: Notify }>(`${projectPath(project)}/notifications`, { method: 'PUT', body: n });
      setN(r.notify);
      setMsg({ ok: true, text: 'Saved. Every run of this project uses these.' });
    } catch (e: any) {
      setMsg({ ok: false, text: e.message });
    } finally {
      setBusy('');
    }
  };
  const test = async () => {
    setBusy('test');
    setMsg(null);
    try {
      // Each channel answers 'sent', 'off' (not set) or the error text.
      const { result } = await api<{ result: { email: string; webhook: string } }>(`${projectPath(project)}/settings/notifications/test`, { body: n });
      const say = (what: string, v: string) => (v === 'sent' ? `${what}: sent ✓` : v === 'off' ? '' : `${what}: ${v}`);
      const ok = [result.email, result.webhook].every((v) => v === 'sent' || v === 'off');
      setMsg({ ok, text: [say('Email', result.email), say('Google Chat', result.webhook)].filter(Boolean).join(' · ') });
    } catch (e: any) {
      setMsg({ ok: false, text: e.message });
    } finally {
      setBusy('');
    }
  };

  return (
    <Stack spacing={1.75} sx={{ px: 2, py: 1.75 }} onKeyDown={(e) => e.stopPropagation()}>
      <Typography variant="caption" color="text.secondary">For project <b>{project}</b>: who hears about its migrations.</Typography>
      <TextField size="small" label="Email addresses" placeholder="you@company.com, dba-team@company.com" value={n.emails} onChange={(e) => set('emails', e.target.value)}
        helperText={smtp ? 'Separate several with commas.' : 'Email is not set up on this server (SMTP): ask the server team.'} />
      <TextField size="small" label="Google Chat space (webhook link)" placeholder="https://chat.googleapis.com/v1/spaces/…" value={n.webhook} onChange={(e) => set('webhook', e.target.value)}
        InputProps={{ sx: { fontFamily: monoFont, fontSize: 12.5 } }}
        helperText="In Google Chat: open the space → its name → Apps & integrations → Webhooks → Add, then paste the link here." />
      <Box>
        <Typography variant="caption" fontWeight={700} color="text.secondary">Send a message when</Typography>
        <Stack direction="row" flexWrap="wrap" useFlexGap columnGap={1}>
          <FormControlLabel control={<Checkbox size="small" checked={n.onAttention} onChange={(e) => set('onAttention', e.target.checked)} />} label={<Typography variant="body2">a table needs attention</Typography>} />
          <FormControlLabel control={<Checkbox size="small" checked={n.onFinish} onChange={(e) => set('onFinish', e.target.checked)} />} label={<Typography variant="body2">a run ends</Typography>} />
          <FormControlLabel control={<Checkbox size="small" checked={n.onStart} onChange={(e) => set('onStart', e.target.checked)} />} label={<Typography variant="body2">a run starts</Typography>} />
        </Stack>
      </Box>
      {msg && <Alert severity={msg.ok ? 'success' : 'error'} sx={{ py: 0, overflowWrap: 'anywhere' }}>{msg.text}</Alert>}
      <Stack direction="row" spacing={1} justifyContent="flex-end">
        <Button size="small" onClick={test} disabled={!!busy}>{busy === 'test' ? 'Sending…' : 'Send a test'}</Button>
        <Button size="small" variant="contained" onClick={save} disabled={!!busy}>{busy === 'save' ? 'Saving…' : 'Save'}</Button>
      </Stack>
    </Stack>
  );
}

/** Header bell: the migrations (running and ended lately, every project) and, inside a project, its notification settings. */
export default function Bell() {
  const navigate = useNavigate();
  const { pathname } = useLocation();
  const project = (/^\/projects\/([^/]+)/.exec(pathname) || [])[1];
  const [items, setItems] = useState<Item[]>([]);
  const [anchor, setAnchor] = useState<HTMLElement | null>(null);
  const [tab, setTab] = useState<'runs' | 'settings'>('runs');
  const [seen, setSeen] = useState(readSeen);
  // Outside a project (home, projects list) the settings tab asks which project.
  const [picked, setPicked] = useState('');
  const [projects, setProjects] = useState<string[]>([]);
  useEffect(() => {
    if (tab !== 'settings' || project || projects.length) return;
    api<{ projects: { projectName: string }[] }>('/projects').then((r) => setProjects(r.projects.map((p) => p.projectName))).catch(() => {});
  }, [tab, project, projects.length]);
  const settingsFor = project ? decodeURIComponent(project) : picked;

  useEffect(() => {
    let alive = true;
    const load = () => api<{ items: Item[] }>('/notifications').then((r) => alive && setItems(r.items)).catch(() => {});
    load();
    const t = setInterval(load, 60000);
    return () => { alive = false; clearInterval(t); };
  }, []);

  // New = ended since the bell was last opened.
  const unread = items.filter((i) => i.finishedAt && i.finishedAt > seen).length;
  const running = items.filter((i) => !i.finishedAt).length;
  const open = (e: React.MouseEvent<HTMLElement>) => {
    setAnchor(e.currentTarget);
    setTab('runs');
    const latest = items.map((i) => i.finishedAt || '').sort().pop() || seen;
    writeSeen(latest);
    setSeen(latest);
  };

  return (
    <>
      <Tooltip title="Migrations and notifications">
        <IconButton onClick={open} aria-label="Migrations and notifications">
          <Badge badgeContent={unread || (running ? '●' : 0)} color={unread ? 'error' : 'primary'} overlap="circular">
            <NotificationsRoundedIcon sx={{ color: brand.ink }} />
          </Badge>
        </IconButton>
      </Tooltip>
      <Menu anchorEl={anchor} open={!!anchor} onClose={() => setAnchor(null)} anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }} transformOrigin={{ vertical: 'top', horizontal: 'right' }}
        slotProps={{ paper: { sx: { width: 420, maxHeight: 560, mt: 1, borderRadius: 3 } } }} MenuListProps={{ autoFocusItem: false }}>
        <Tabs value={tab} onChange={(_, v) => setTab(v)} variant="fullWidth" sx={{ borderBottom: 1, borderColor: 'divider', minHeight: 44, '& .MuiTab-root': { minHeight: 44, textTransform: 'none', fontWeight: 650 } }}>
          <Tab value="runs" label="Migrations" />
          <Tab value="settings" label="Notification settings" />
        </Tabs>
        {tab === 'settings' && !project && (
          <Box sx={{ px: 2, pt: 1.75 }} onKeyDown={(e) => e.stopPropagation()}>
            <TextField select size="small" fullWidth label="Project" value={picked} onChange={(e) => setPicked(e.target.value)}
              helperText={picked ? '' : 'Notifications are set per project: choose one.'}>
              {projects.map((n) => <MenuItem key={n} value={n}>{n}</MenuItem>)}
            </TextField>
          </Box>
        )}
        {tab === 'settings' ? (settingsFor ? <NotificationSettings key={settingsFor} project={settingsFor} /> : null) : (
          <Box>
            <Typography variant="caption" color="text.secondary" sx={{ display: 'block', px: 2, pt: 1.25, pb: 0.75 }}>Running now, and ended in the last 14 days, in every project.</Typography>
            <Divider />
            {!items.length && <Typography variant="body2" color="text.secondary" sx={{ px: 2, py: 2 }}>Nothing yet.</Typography>}
            {items.map((i) => (
              <MenuItem key={`${i.projectName}/${i.runId}`} onClick={() => { setAnchor(null); navigate(`/projects/${encodeURIComponent(i.projectName)}/runs/${i.runId}`); }}
                sx={{ py: 1.25, alignItems: 'flex-start', whiteSpace: 'normal' }}>
                <Stack spacing={0.5} sx={{ width: '100%', minWidth: 0 }}>
                  <Stack direction="row" spacing={1} alignItems="center">
                    <Typography fontWeight={700} fontSize={14} noWrap sx={{ flex: 1, minWidth: 0 }}>{i.projectName}</Typography>
                    <StatusChip status={i.status} />
                  </Stack>
                  <Typography variant="caption" color="text.secondary">
                    {i.finishedAt ? `Ended ${timeAgo(i.finishedAt)}` : `Started ${timeAgo(i.startedAt)}`}
                    {` · ${i.done} of ${i.tables} tables`}{i.failed ? ` · ${i.failed} failed` : ''}{i.startedBy ? ` · by ${i.startedBy}` : ''}
                  </Typography>
                </Stack>
              </MenuItem>
            ))}
          </Box>
        )}
      </Menu>
    </>
  );
}
