'use strict';

/**
 * End-to-end: real migrations through the running API, on a project that is already connected
 * (Connections and Schema & snapshot done). Slow (several minutes); not part of `npm test`.
 *
 *   DMA_E2E_URL       API, default http://localhost:5055
 *   DMA_E2E_PROJECT   project, default E2E_TEST
 *   DMA_E2E_TABLES    a normal table and a document table, default CALENDAR_EXCEPTION,DOCUMENTS
 *   DMA_E2E_BIG       a big table to split into parts, default AUDIT_TRAIL
 *   DMA_E2E_PG_URL    postgres://user:password@host:port/db of the target, for the "never half a
 *                     table" test (a test CHECK constraint makes one part fail); that test is skipped without it
 *   DMA_E2E_SCHEMA    target schema, default e2e_test
 *
 * dev-tools/run-e2e.sh sets these for the local test databases and runs: npm run test:e2e
 */
const { Client } = require('pg');

const API = process.env.DMA_E2E_URL || 'http://localhost:5055';
const PROJECT = process.env.DMA_E2E_PROJECT || 'E2E_TEST';
const [NORMAL, LOB] = (process.env.DMA_E2E_TABLES || 'CALENDAR_EXCEPTION,DOCUMENTS').split(',');
const BIG = process.env.DMA_E2E_BIG || 'AUDIT_TRAIL';
const SCHEMA = process.env.DMA_E2E_SCHEMA || 'e2e_test';
const P = `${API}/api/projects/${PROJECT}`;

jest.setTimeout(20 * 60 * 1000);

async function call(method, url, body) {
  const res = await fetch(url, { method, headers: body ? { 'Content-Type': 'application/json' } : {}, body: body ? JSON.stringify(body) : undefined });
  const text = await res.text();
  let data = null;
  try { data = text ? JSON.parse(text) : null; } catch { data = text; }
  return { status: res.status, data };
}

// Run options come from the project's Settings (Run defaults), not from the browser: the tests
// change them through the Settings API and put the saved ones back at the end.
let savedSettings = null;
async function setRunDefaults(engine) {
  const { data } = await call('GET', `${P}/settings`);
  const r = await call('PUT', `${P}/settings`, { ...data.settings, engine: { ...data.settings.engine, ...engine } });
  expect(r.status).toBe(200);
}

/** Starts a run with the given Run defaults and waits until it ends; returns its final state. */
async function migrate(tables, engine = {}) {
  await setRunDefaults({ snapshot: 'off', hugeTableRows: 2000000, chunkRows: 5000000, chunkMb: 1024, maxAttempts: 3, ...engine });
  const start = await call('POST', `${P}/runs`, { tables, options: { parallelTables: 99 } }); // ignored by the server
  expect(start.status).toBe(202);
  const id = start.data.runId;
  for (;;) {
    await new Promise((r) => setTimeout(r, 3000));
    const { data } = await call('GET', `${P}/runs/${id}`);
    if (['COMPLETED', 'COMPLETED_WITH_ERRORS', 'FAILED', 'CANCELLED', 'INTERRUPTED'].includes(data.status)) return data;
  }
}

const done = (run, name) => {
  const t = run.tables[name];
  expect(t.status).toBe('done');
  expect(t.pgRows).toBe(t.oracleRows);
  if (t.dataCheck) expect(t.dataCheck.ok).toBe(true);
};

beforeAll(async () => {
  const health = await call('GET', `${API}/api/health`).catch(() => null);
  if (!health || health.status !== 200) throw new Error(`The API is not running at ${API}`);
  savedSettings = (await call('GET', `${P}/settings`)).data.settings;
});

afterAll(async () => {
  if (savedSettings) await call('PUT', `${P}/settings`, savedSettings);
});

test('whoami: without SSO everybody is an admin', async () => {
  const { data } = await call('GET', `${API}/api/whoami`);
  expect(data.admin).toBe(true);
});

test('pre-flight returns the settings DMA chose, with reasons', async () => {
  const { status, data } = await call('POST', `${P}/runs/preflight`, { tables: [NORMAL, LOB], options: { parallelTables: 99 } });
  expect(status).toBe(200);
  expect(data.auto.options.parallelTables).toBeGreaterThanOrEqual(1);
  expect(data.auto.options.parallelTables).toBeLessThan(99); // the browser's numbers are ignored
  expect(data.auto.reasons.length).toBeGreaterThan(0);
});

test('a normal and a document table: loaded, counted and checksummed', async () => {
  const run = await migrate([NORMAL, LOB]);
  expect(run.status).toBe('COMPLETED');
  done(run, NORMAL);
  done(run, LOB);
  expect(run.options.parallelTables).not.toBe(99);
});

test('running it again: existing tables do not stop the rest (re-run)', async () => {
  const run = await migrate([NORMAL, LOB]);
  expect(run.status).toBe('COMPLETED');
  done(run, LOB);
});

test('a big table is split into parts and every part is verified', async () => {
  const run = await migrate([BIG], { hugeTableRows: 100000, chunkRows: 300000, chunkMb: 64 });
  expect(run.status).toBe('COMPLETED');
  done(run, BIG);
  expect(run.tables[BIG].chunkInfo.total).toBeGreaterThan(1);
});

const pgUrl = process.env.DMA_E2E_PG_URL;
(pgUrl ? test : test.skip)('one part fails: the whole table is emptied and the failed part is named', async () => {
  const pg = new Client({ connectionString: pgUrl });
  await pg.connect();
  const table = `${SCHEMA}.${BIG.toLowerCase()}`;
  try {
    // A row PostgreSQL refuses: the part that holds it fails, the other parts load fine. A CHECK
    // constraint, because ora2pg switches triggers off while it loads (DISABLE_TRIGGERS).
    const { rows: pk } = await pg.query(`SELECT a.attname FROM pg_index i JOIN pg_attribute a ON a.attrelid = i.indrelid AND a.attnum = ANY(i.indkey)
      WHERE i.indrelid = $1::regclass AND i.indisprimary LIMIT 1`, [table]);
    const key = pk[0].attname;
    const { rows } = await pg.query(`SELECT "${key}"::text AS v FROM ${table} ORDER BY "${key}" DESC LIMIT 1`);
    await pg.query(`ALTER TABLE ${table} ADD CONSTRAINT e2e_reject CHECK ("${key}"::text <> '${rows[0].v}') NOT VALID`);

    const run = await migrate([BIG], { hugeTableRows: 100000, chunkRows: 300000, chunkMb: 64, maxAttempts: 1 });
    const t = run.tables[BIG];
    expect(t.status).toBe('failed');
    expect(t.error).toMatch(/Part \d+ of \d+ failed/);
    expect(t.error).toMatch(/never left half loaded/);
    expect(t.failedParts.length).toBeGreaterThanOrEqual(1);
    const left = await pg.query(`SELECT count(*)::int AS n FROM ${table}`);
    expect(left.rows[0].n).toBe(0);
  } finally {
    await pg.query(`ALTER TABLE ${table} DROP CONSTRAINT IF EXISTS e2e_reject`).catch(() => {});
    await pg.end();
  }
  // Without the trigger the same table loads completely again.
  const again = await migrate([BIG], { hugeTableRows: 100000, chunkRows: 300000, chunkMb: 64 });
  done(again, BIG);
});

test('validation: table structure is compared column by column, with no false alarms', async () => {
  const { status, data } = await call('GET', `${P}/validation`);
  expect(status).toBe(200);
  expect(data.structureCheck.length).toBeGreaterThan(0);
  const problems = data.structureCheck.filter((r) => r[5] !== 'yes');
  expect(problems).toEqual([]);
});

test('the bell lists the latest run', async () => {
  const { data } = await call('GET', `${API}/api/notifications`);
  const mine = data.items.filter((i) => i.projectName === PROJECT);
  expect(mine.length).toBeGreaterThan(0);
  expect(mine[0].status).toBe('COMPLETED');
});

test('notifications (the bell): saved for the project, and not overwritten by a Settings save', async () => {
  const before = (await call('GET', `${P}/notifications`)).data.notify;
  const staleSettings = (await call('GET', `${P}/settings`)).data.settings; // a Settings page opened earlier
  try {
    const saved = await call('PUT', `${P}/notifications`, { ...before, emails: 'e2e@example.com', onStart: true });
    expect(saved.status).toBe(200);
    expect(saved.data.notify.emails).toBe('e2e@example.com');
    const bad = await call('PUT', `${P}/notifications`, { ...before, emails: 'not-an-email' });
    expect(bad.status).toBe(400);
    // An admin saves Settings from the page opened before: the notifications stay.
    expect((await call('PUT', `${P}/settings`, staleSettings)).status).toBe(200);
    expect((await call('GET', `${P}/notifications`)).data.notify.emails).toBe('e2e@example.com');
  } finally {
    await call('PUT', `${P}/notifications`, before);
  }
});

test('rename the project and back', async () => {
  const to = `${PROJECT}_RN`;
  const r1 = await call('POST', `${P}/rename`, { newName: to });
  expect(r1.status).toBe(200);
  expect(r1.data.project.projectName).toBe(to);
  const r2 = await call('POST', `${API}/api/projects/${to}/rename`, { newName: PROJECT });
  expect(r2.status).toBe(200);
  const list = await call('GET', `${API}/api/projects`);
  expect(list.data.projects.map((p) => p.projectName)).toContain(PROJECT);
});
