'use strict';

const fs = require('fs').promises;
const os = require('os');
const path = require('path');
const settingsSvc = require('../services/settings');
const store = require('../services/projectStore');
const { buildConfig } = require('../services/config_modify');
const notify = require('../services/notify');

/** Settings as sent to the browser: the Google Chat webhook URL is masked. */
function forBrowser(settings) {
  return { ...settings, notify: notify.publicView(notify.resolve({ settings })) };
}

/** Settings with the option catalogue the Settings page is built from. */
async function getSettings(req, res) {
  res.json({
    settings: forBrowser(settingsSvc.resolve(req.project)),
    defaults: settingsSvc.defaults(),
    options: settingsSvc.ORA2PG_OPTIONS,
    notifyChannels: notify.channels(),
  });
}

async function saveSettings(req, res) {
  const { settings, error } = settingsSvc.validate(req.body || {}, (req.project && req.project.settings) || {});
  if (error) return res.status(400).json({ message: error });
  // Notifications are saved from the bell (any user): keep the stored ones, never the copy the page loaded.
  const meta = await store.updateMeta(req.projectName, (m) => ({ ...m, settings: { ...settings, notify: (m.settings && m.settings.notify) || settings.notify } }));
  res.json({ settings: forBrowser(meta.settings), message: 'Settings saved. They apply to the next export and migration run.' });
}

/** Notifications (the bell, top right): every user of the project may see and change them. */
async function getNotifications(req, res) {
  res.json({ notify: notify.publicView(notify.resolve(req.project)), channels: notify.channels() });
}

async function saveNotifications(req, res) {
  const r = notify.validate(req.body || {}, notify.resolve(req.project));
  if (r.error) return res.status(400).json({ message: r.error });
  const meta = await store.updateMeta(req.projectName, (m) => ({ ...m, settings: { ...(m.settings || {}), notify: r.notify } }));
  res.json({ notify: notify.publicView(notify.resolve(meta)), message: 'Notifications saved.' });
}

/** Sends a test message with the notification settings on screen (saved or not). */
async function testNotification(req, res) {
  const r = await notify.test(req.projectName, req.body || {});
  if (r.error) return res.status(400).json({ message: r.error });
  res.json(r);
}

/** The ora2pg.conf the next run will use, with passwords masked. */
async function previewConfig(req, res) {
  const meta = req.project;
  const settings = settingsSvc.resolve(meta);
  const oracle = store.oracleCredentials(meta) || { userUrl: 'host:1521/SERVICE', userUsername: 'user', userPassword: '' };
  const pg = store.postgresCredentials(meta);
  const schema = meta.selectedSchema || 'SCHEMA';
  const tmp = path.join(os.tmpdir(), `dma_preview_${process.pid}_${Date.now()}.conf`);
  try {
    await buildConfig({
      outFile: tmp,
      outputDir: path.join(store.projectDir(req.projectName), 'runs', '<run>', 'data'),
      oracle,
      schema,
      postgres: pg,
      options: { pgSchema: settings.targetSchema || schema.toLowerCase(), directives: settingsSvc.ora2pgDirectives(settings), forData: true },
    });
    const text = (await fs.readFile(tmp, 'utf8'))
      .replace(/^(ORACLE_PWD|PG_PWD)\s.*$/gm, '$1\t********')
      .split('\n')
      .filter((l) => l.trim() && !l.trim().startsWith('#'))
      .join('\n');
    res.type('text/plain').send(text);
  } catch (err) {
    res.status(400).json({ message: err.message });
  } finally {
    await fs.unlink(tmp).catch(() => {});
  }
}

module.exports = { getSettings, saveSettings, previewConfig, testNotification, getNotifications, saveNotifications };
