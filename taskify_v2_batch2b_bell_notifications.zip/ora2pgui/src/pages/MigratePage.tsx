import { Alert, Box, Button, Checkbox, Chip, CircularProgress, Dialog, DialogActions, DialogContent, DialogTitle, FormControlLabel, MenuItem, Radio, RadioGroup, Stack, TextField, Tooltip, Typography } from '@mui/material';
import AutoAwesomeRoundedIcon from '@mui/icons-material/AutoAwesomeRounded';
import RocketLaunchRoundedIcon from '@mui/icons-material/RocketLaunchRounded';
import PlaylistAddCheckRoundedIcon from '@mui/icons-material/PlaylistAddCheckRounded';
import MonitorHeartRoundedIcon from '@mui/icons-material/MonitorHeartRounded';
import { useEffect, useMemo, useRef, useState } from 'react';
import { Link as RouterLink, useLocation, useNavigate } from 'react-router-dom';
import { api, projectPath } from '../api';
import { useProject } from '../context/ProjectContext';
import DataTable from '../components/DataTable';
import { CheckIcon, EmptyState, PageHeader, SectionCard, Tag } from '../components/ui';
import { fmtDate, fmtInt, fmtMb } from '../format';
import { brand } from '../theme';
import { useIsAdmin, useMe } from '../role';

type Check = { check: string; response: boolean | string; description: string; level?: 'ok' | 'warn' | 'block' };
type Estimate = { selectedGb: number; gbPerHour: number; loadHours: number; runHours: number; measured: boolean };
type AutoInfo = { options: { parallelTables: number; oracleCopies: number; pgJobs: number }; reasons: string[] };
const KIND_LABEL: Record<string, { label: string; color: string }> = {
  normal: { label: 'Normal', color: brand.muted },
  huge: { label: 'Huge · chunked & parallel', color: brand.blue },
  lob: { label: 'LOB · small batches', color: brand.warning },
  object: { label: 'Object table', color: brand.violet },
};
type PackageM = { id: string; fileName: string; uploadedAt: string; fileCount: number; lastApply: any };

/** Folded pre-flight card: counts per state, as chips. */
function PreflightSummary({ list, isOk, isWarn, stale, noTables }: { list: Check[]; isOk: (c: Check) => boolean; isWarn: (c: Check) => boolean; stale: boolean; noTables: boolean }) {
  const ok = list.filter(isOk).length;
  const warn = list.filter((c) => !isOk(c) && isWarn(c)).length;
  const bad = list.length - ok - warn;
  return (
    <Stack direction="row" spacing={1} alignItems="center" flexWrap="wrap" useFlexGap sx={{ mt: 0.5 }}>
      <Chip size="small" icon={<CheckIcon ok />} label={`${ok} OK`} sx={{ bgcolor: '#ECFDF3' }} />
      {warn > 0 && <Chip size="small" icon={<CheckIcon ok={false} warn />} label={`${warn} warning${warn === 1 ? '' : 's'}`} sx={{ bgcolor: '#FFFAEB' }} />}
      {bad > 0 && <Chip size="small" icon={<CheckIcon ok={false} />} label={`${bad} to fix`} sx={{ bgcolor: '#FEF3F2' }} />}
      {noTables && <Typography variant="caption" color="text.secondary">capacity: select tables</Typography>}
      {!noTables && stale && <Typography variant="caption" color="text.secondary">checking the new selection…</Typography>}
    </Stack>
  );
}

function StepNo({ n }: { n: number }) {
  return <Box sx={{ width: 28, height: 28, borderRadius: 2, flexShrink: 0, display: 'grid', placeItems: 'center', background: brand.accentGradient, color: '#fff', fontWeight: 800, fontSize: 14 }}>{n}</Box>;
}

export default function MigratePage() {
  const { name, project, snapshot, activeRunId } = useProject();
  const navigate = useNavigate();
  const [checks, setChecks] = useState<Check[] | null>(null);
  const [checking, setChecking] = useState(false);
  const [checkError, setCheckError] = useState<string | null>(null);
  const [estimate, setEstimate] = useState<Estimate | null>(null);
  const [checkedKey, setCheckedKey] = useState('');
  const [preOpen, setPreOpen] = useState(true);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [kindFilter, setKindFilter] = useState('all');
  const [starting, setStarting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [opts, setOpts] = useState<any>({
    auto: true, loadMode: 'direct', parallelTables: 4, hugeTableRows: 2000000, oracleCopies: 4, pgJobs: 4, chunkRows: 5000000, chunkMb: 4096, stallMinutes: 20, maxAttempts: 3, verifyRowCounts: true, verifyData: 'all', maintenanceWorkMem: '1GB', snapshot: 'on', bulkLoad: 'standard',
  });
  const admin = useIsAdmin();
  const me = useMe();
  // "Notify me when it ends": the signed-in user's email, editable; Google Chat comes from Settings.
  const [notifyMe, setNotifyMe] = useState(false);
  const [notifyEmail, setNotifyEmail] = useState('');
  const [channels, setChannels] = useState<{ email: boolean; chat: boolean }>({ email: false, chat: false });
  useEffect(() => { if (me?.email && !notifyEmail) setNotifyEmail(me.email); }, [me]); // eslint-disable-line react-hooks/exhaustive-deps
  // Tables at a time and parts at a time, chosen by DMA for the selected tables (from the pre-flight).
  const [autoInfo, setAutoInfo] = useState<AutoInfo | null>(null);
  const [packages, setPackages] = useState<PackageM[]>([]);
  const [askCode, setAskCode] = useState(false);
  const [codeChoice, setCodeChoice] = useState<string>('later');

  // Defaults come from the project's Settings page.
  useEffect(() => {
    api<{ settings: any; notifyChannels?: { email: boolean } }>(`${projectPath(name)}/settings`).then((r) => {
      setOpts((o: any) => ({ ...o, ...r.settings.engine }));
      setChannels({ email: !!r.notifyChannels?.email, chat: !!r.settings.notify?.webhook });
    }).catch(() => {});
    api<{ packages: PackageM[] }>(`${projectPath(name)}/code`).then((r) => {
      setPackages(r.packages);
      if (r.packages[0]) setCodeChoice(r.packages[0].id);
    }).catch(() => {});
  }, [name]);

  const lob = useMemo(() => new Set<string>(snapshot?.lobTables || []), [snapshot]);
  const objectTables = useMemo(() => new Set<string>((snapshot?.objectTables || []).map((o: any) => o.tableName || o)), [snapshot]);
  const tables = useMemo(() => (snapshot?.tableMetadata || []).map((t: any) => {
    const rows = Number(t.rowCount) || 0;
    const kind = objectTables.has(t.name) ? 'object' : lob.has(t.name) ? 'lob' : rows >= opts.hugeTableRows ? 'huge' : 'normal';
    return { name: t.name as string, sizeMb: Number(t.sizeMb) || 0, rows, kind };
  }), [snapshot, lob, objectTables, opts.hugeTableRows]);

  // "Migrate all tables" on the Assessment page: arrive with every table selected (once).
  const location = useLocation();
  const preselected = useRef(false);
  useEffect(() => {
    if (preselected.current || !(location.state as any)?.selectAll || !tables.length) return;
    preselected.current = true;
    setSelected(new Set(tables.map((t: any) => t.name)));
    navigate('.', { replace: true, state: null });
  }, [tables, location.state]); // eslint-disable-line react-hooks/exhaustive-deps

  const visible = kindFilter === 'all' ? tables : tables.filter((t: any) => t.kind === kindFilter);
  const sel = tables.filter((t: any) => selected.has(t.name));
  const selMb = sel.reduce((s: number, t: any) => s + t.sizeMb, 0);
  const selRows = sel.reduce((s: number, t: any) => s + t.rows, 0);

  // Two kinds of checks: the environment (Oracle, PostgreSQL, tools: once, when the page opens) and the
  // capacity of the planned run (disk, connections, undo, estimate), which depends on the selected tables
  // and the options. The capacity checks re-run by themselves shortly after the selection or an option changes.
  const planKey = JSON.stringify({ t: sel.map((t: any) => t.name).sort(), opts });
  const latestKey = useRef(planKey);
  latestKey.current = planKey;
  const [capChecking, setCapChecking] = useState(false);
  const REPLACED = ['staging disk space', 'connection capacity']; // the capacity checks have newer versions of these
  const isOk = (c: Check) => (c.level ? c.level === 'ok' : c.response === true || c.response === 'true');
  const isWarnOnly = (c: Check) => (c.level ? c.level === 'warn' : ['analyze', 'connection capacity', 'staging disk space', 'snapshot', 'status', 'object types'].includes(c.check.toLowerCase()));
  const openIfNeeded = (list: Check[]) => setPreOpen(list.some((c) => !isOk(c)));

  const runCapacity = async (key: string, tableNames: string[], options: any) => {
    setCapChecking(true);
    try {
      const cap = await api<{ checks: Check[]; estimate: Estimate; auto: AutoInfo | null }>(`${projectPath(name)}/runs/preflight`, { body: { tables: tableNames, options } });
      if (latestKey.current !== key) return; // the selection changed meanwhile: a newer check follows
      setAutoInfo(cap.auto);
      setChecks((prev) => {
        const env = (prev || []).filter((c) => !c.level);
        openIfNeeded([...env.filter((c) => !REPLACED.includes(c.check)), ...cap.checks]);
        return [...env, ...cap.checks];
      });
      setEstimate(cap.estimate);
      setCheckedKey(key);
    } catch (e: any) {
      if (latestKey.current === key) setCheckError(e.message);
    } finally {
      if (latestKey.current === key) setCapChecking(false);
    }
  };

  /** "Run checks again" (and on page open): environment, plus capacity when tables are selected. */
  const runChecks = async () => {
    setChecking(true);
    setCheckError(null);
    try {
      const [ora, pg] = await Promise.all([
        api<Check[]>(`${projectPath(name)}/prerequisites`).catch((e) => [{ check: 'oracle analysis', response: false, description: e.message }]),
        api<Check[]>(`${projectPath(name)}/postgres/checks`),
      ]);
      const env: Check[] = [...ora, ...pg];
      setChecks((prev) => [...env, ...(prev || []).filter((c) => c.level)]);
      if (sel.length) await runCapacity(planKey, sel.map((t: any) => t.name), opts);
      else openIfNeeded(env);
    } catch (e: any) {
      setCheckError(e.message);
    } finally {
      setChecking(false);
    }
  };
  useEffect(() => { if (snapshot && !checks && !checking) runChecks(); }, [snapshot]); // eslint-disable-line react-hooks/exhaustive-deps
  // New selection or options: check the capacity again after a short pause (no button to press).
  useEffect(() => {
    if (!checks || checking || !sel.length || planKey === checkedKey) return undefined;
    const names = sel.map((t: any) => t.name);
    const t = setTimeout(() => runCapacity(planKey, names, opts), 900);
    return () => clearTimeout(t);
  }, [planKey, !!checks, checking]); // eslint-disable-line react-hooks/exhaustive-deps

  const stale = sel.length > 0 && checkedKey !== planKey; // results not yet for this selection (a check is pending or running)
  const envChecks = (checks || []).filter((c) => !c.level && !(sel.length && REPLACED.includes(c.check)));
  const capChecks = sel.length ? (checks || []).filter((c) => c.level) : [];
  const blocking = [...envChecks, ...(stale ? [] : capChecks)].filter((c) => !isOk(c) && !isWarnOnly(c));
  const checksOk = !!checks && blocking.length === 0 && !stale && !capChecking;
  const fmtH = (h: number) => (h >= 1 ? `${h.toFixed(1)} h` : `${Math.max(1, Math.round(h * 60))} min`);

  const start = async () => {
    setStarting(true);
    setError(null);
    try {
      const run = await api<{ runId: string }>(`${projectPath(name)}/runs`, {
        body: { tables: sel.map((t: any) => t.name), notifyEmail: notifyMe ? notifyEmail.trim() : null, codePackageId: codeChoice !== 'later' ? codeChoice : null },
      });
      navigate(`../runs/${run.runId}`);
    } catch (e: any) {
      setError(e.message);
      setStarting(false);
    }
  };

  if (!snapshot) {
    return <SectionCard><EmptyState icon={<RocketLaunchRoundedIcon />} title="No snapshot yet" text="Take a schema snapshot before planning the migration." action={<Button variant="contained" onClick={() => navigate('../schema')}>Go to schema & snapshot</Button>} /></SectionCard>;
  }

  const toggle = (n: string) => setSelected((prev) => { const s = new Set(prev); if (s.has(n)) s.delete(n); else s.add(n); return s; });
  const allVisibleSelected = visible.length > 0 && visible.every((t: any) => selected.has(t.name));
  const someVisibleSelected = visible.some((t: any) => selected.has(t.name));
  const toggleAll = () => setSelected((prev) => { const s = new Set(prev); visible.forEach((t: any) => (allVisibleSelected ? s.delete(t.name) : s.add(t.name))); return s; });

  return (
    <>
      <PageHeader overline="Step 6" title={`Migrate ${snapshot.schemaName}`} icon={<RocketLaunchRoundedIcon />}
        subtitle={<>Target schema <b className="mono">{snapshot.schemaName.toLowerCase()}</b> in <b>{project?.postgres?.dbname || '—'}</b>. Data streams straight from Oracle into PostgreSQL; each table is verified and retried on its own.</>} />

      {activeRunId && (
        <Alert severity="info" sx={{ mb: 3 }} action={<Button color="inherit" startIcon={<MonitorHeartRoundedIcon />} onClick={() => navigate(`../runs/${activeRunId}`)}>Open live monitor</Button>}>
          A migration is running for this project now. Only one run per project at a time.
        </Alert>
      )}

      {/* 1. Pre-flight checks: environment first (no tables needed), capacity once tables are selected. */}
      <SectionCard collapsible open={preOpen} onOpenChange={setPreOpen} title={<Stack direction="row" spacing={1.25} alignItems="center"><StepNo n={1} /><span>Pre-flight checks</span></Stack>}
        summary={checking ? 'Checking…' : !checks ? 'Not run yet' : <PreflightSummary list={[...envChecks, ...(stale ? [] : capChecks)]} isOk={isOk} isWarn={isWarnOnly} stale={stale || capChecking} noTables={!sel.length} />}
        subtitle={<>Oracle, PostgreSQL and the tools are checked right away. Disk, connections, undo and the time estimate are checked for the tables you select. <Box component={RouterLink} to="/guide#preflight" sx={{ fontWeight: 700 }}>What the checks mean →</Box></>}
        action={<Button variant="outlined" onClick={runChecks} disabled={checking} startIcon={checking ? <CircularProgress size={16} /> : <PlaylistAddCheckRoundedIcon />}>{checks ? 'Run checks again' : 'Run checks'}</Button>}>
        {checkError && <Alert severity="error" sx={{ mb: 2 }}>{checkError}</Alert>}
        {!checks && checking && <Typography variant="body2" color="text.secondary">Checking Oracle, PostgreSQL, ora2pg and psql…</Typography>}
        {checks && (
          <Box sx={{ display: 'grid', gap: 3, gridTemplateColumns: { xs: '1fr', lg: '1fr 1fr' }, alignItems: 'start' }}>
            {[
              ['Environment', envChecks, null],
              ['Capacity for the selected tables', capChecks, !sel.length ? 'Select tables in step 2: disk, connections, undo and the time estimate are then checked for them automatically.' : stale || capChecking ? 'Checking the new selection…' : null],
            ].map(([title, list, note]: any) => (
              <Box key={title}>
                <Typography variant="overline" color="text.secondary">{title}</Typography>
                {note && <Alert severity="info" sx={{ my: 1, py: 0 }}>{note}</Alert>}
                <Box sx={{ display: 'grid', gap: 1.25, gridTemplateColumns: { xs: '1fr', md: '1fr 1fr' }, mt: 0.5 }}>
                  {(list as Check[]).map((c) => (
                    <Stack key={c.check} direction="row" spacing={1.25} alignItems="flex-start" sx={{ p: 1.25, borderRadius: 2.5, border: `1px solid ${brand.border}`, bgcolor: isOk(c) ? '#fff' : isWarnOnly(c) ? '#FFFAEB' : '#FEF3F2', opacity: stale && title !== 'Environment' ? 0.6 : 1 }}>
                      <Box sx={{ mt: 0.2 }}><CheckIcon ok={isOk(c)} warn={isWarnOnly(c)} /></Box>
                      <Box sx={{ minWidth: 0 }}>
                        <Typography fontWeight={650} fontSize={14} sx={{ textTransform: c.level ? 'none' : 'capitalize' }}>{c.check}</Typography>
                        <Typography variant="caption" color="text.secondary" sx={{ display: 'block', overflowWrap: 'anywhere' }}>{c.description}</Typography>
                      </Box>
                    </Stack>
                  ))}
                </Box>
              </Box>
            ))}
          </Box>
        )}
      </SectionCard>

      {/* 2. Tables */}
      <Box sx={{ mt: 3 }}>
        <SectionCard dense title={<Stack direction="row" spacing={1.25} alignItems="center"><StepNo n={2} /><span>Tables</span></Stack>}
          subtitle="Tick the box in the header to select every table. Biggest tables are loaded first; LOB tables use small batches; huge tables use several readers and writers.">
          <DataTable rows={visible} rowKey={(r: any) => r.name} searchKeys={['name']} initialSort={{ key: 'sizeMb', dir: 'desc' }} pageSize={10}
            toolbar={
              <Stack direction="row" spacing={1} alignItems="center" flexWrap="wrap" useFlexGap>
                <TextField select size="small" value={kindFilter} onChange={(e) => setKindFilter(e.target.value)} sx={{ minWidth: 170 }}>
                  <MenuItem value="all">All kinds ({tables.length})</MenuItem>
                  {Object.entries(KIND_LABEL).map(([k, v]) => <MenuItem key={k} value={k}>{v.label} ({tables.filter((t: any) => t.kind === k).length})</MenuItem>)}
                </TextField>
                <Typography variant="body2" color="text.secondary">{sel.length} of {tables.length} selected</Typography>
                {selected.size > 0 && <Button size="small" color="inherit" onClick={() => setSelected(new Set())}>Clear</Button>}
              </Stack>
            }
            columns={[
              {
                key: 'sel', width: 48, sortValue: (r: any) => (selected.has(r.name) ? 1 : 0),
                label: (
                  <Tooltip title={allVisibleSelected ? 'Unselect all' : `Select all ${visible.length}${kindFilter === 'all' ? '' : ' shown'} tables`}>
                    <Checkbox size="small" checked={allVisibleSelected} indeterminate={someVisibleSelected && !allVisibleSelected}
                      onClick={(e) => e.stopPropagation()} onChange={toggleAll} inputProps={{ 'aria-label': 'Select all tables' }} sx={{ p: 0.5 }} />
                  </Tooltip>
                ),
                render: (r: any) => <Checkbox size="small" checked={selected.has(r.name)} onChange={() => toggle(r.name)} inputProps={{ 'aria-label': `Select ${r.name}` }} />,
              },
              { key: 'name', label: 'Table', render: (r: any) => <span className="mono">{r.name}</span> },
              { key: 'kind', label: 'Load as', render: (r: any) => <Tag label={KIND_LABEL[r.kind].label} color={KIND_LABEL[r.kind].color} /> },
              { key: 'sizeMb', label: 'Size', align: 'right', render: (r: any) => fmtMb(r.sizeMb) },
              { key: 'rows', label: 'Rows (stats)', align: 'right', render: (r: any) => fmtInt(r.rows) },
            ]} />
        </SectionCard>
      </Box>

      {/* 3. Settings: chosen by DMA; admins can open the options and choose themselves */}
      {sel.length > 0 && autoInfo && opts.auto !== false && (
        <Box sx={{ mt: 3, p: { xs: 2, md: 2.5 }, borderRadius: 4, border: `1px solid ${brand.border}`, bgcolor: '#F7FAFF', display: 'flex', gap: 2, alignItems: 'flex-start' }}>
          <AutoAwesomeRoundedIcon sx={{ color: brand.blue, mt: 0.25 }} />
          <Box sx={{ minWidth: 0 }}>
            <Typography fontWeight={750}>Speed settings chosen by DMA</Typography>
            {autoInfo.reasons.map((r) => <Typography key={r} variant="body2" color="text.secondary">{r}</Typography>)}
          </Box>
        </Box>
      )}

      {/* The run's options live in Settings (admins). Here: what the run will do, in one line. */}
      <Stack direction="row" spacing={1} alignItems="center" flexWrap="wrap" useFlexGap sx={{ mt: 1.5, px: 0.5 }}>
        <Typography variant="body2" color="text.secondary">
          {({ direct: 'Direct load', file: 'Through files', export: 'Export only' } as any)[opts.loadMode]}
          {' · '}{opts.snapshot === 'off' ? 'snapshot off (keep the application stopped)' : 'consistent snapshot'}
          {' · '}{opts.verifyRowCounts ? (opts.verifyData === 'all' ? 'rows and checksums verified' : 'rows verified') : 'no verification'}
          {' · '}{opts.maxAttempts} tries per table
          {opts.auto === false ? ` · speed set in Settings: ${opts.parallelTables} tables, ${opts.oracleCopies} parts at a time` : ''}
        </Typography>
        {admin && <Box component={RouterLink} to="../settings?tab=run" sx={{ fontSize: 14, fontWeight: 700 }}>Change in Settings →</Box>}
      </Stack>

      {/* Notifications for this run */}
      <Stack direction={{ xs: 'column', md: 'row' }} spacing={{ xs: 1, md: 2 }} alignItems={{ md: 'center' }} sx={{ mt: 2, p: 1.75, borderRadius: 3, border: `1px solid ${brand.border}`, bgcolor: '#fff' }}>
        <FormControlLabel sx={{ m: 0 }} control={<Checkbox checked={notifyMe} disabled={!channels.email} onChange={(e) => setNotifyMe(e.target.checked)} />}
          label={<Typography fontWeight={650} fontSize={14}>Email me when it ends</Typography>} />
        <TextField size="small" placeholder="you@company.com" value={notifyEmail} disabled={!notifyMe} onChange={(e) => setNotifyEmail(e.target.value)} sx={{ width: { xs: '100%', md: 280 } }} />
        <Typography variant="caption" color="text.secondary" sx={{ flex: 1 }}>
          {channels.email ? 'Also when a table needs attention.' : 'Email is not set up on this server (SMTP).'}
          {' '}Google Chat: {channels.chat ? 'on for this project' : 'off'} (set it with the bell 🔔 at the top right).
        </Typography>
      </Stack>

      {/* 4. Start: always in view at the bottom of the window, on a laptop or a wide monitor. */}
      <Box sx={{ position: 'sticky', bottom: 12, zIndex: 6, mt: 3 }}>
        <Box sx={{ p: { xs: 1.75, md: 2 }, borderRadius: 4, bgcolor: '#fff', border: `1px solid ${brand.border}`, boxShadow: '0 18px 40px -16px rgba(16,24,40,.35)',
          display: 'flex', flexWrap: 'wrap', gap: { xs: 1.5, md: 3 }, alignItems: 'center' }}>
          <StepNo n={4} />
          <Box sx={{ display: 'flex', gap: { xs: 2, md: 4 }, flexWrap: 'wrap', alignItems: 'center', flex: 1, minWidth: 0 }}>
            <Box><Typography variant="caption" color="text.secondary">Tables</Typography><Typography fontWeight={800} fontSize={18}>{sel.length} / {tables.length}</Typography></Box>
            <Box><Typography variant="caption" color="text.secondary">Data</Typography><Typography fontWeight={800} fontSize={18}>{fmtMb(selMb)}</Typography></Box>
            <Box><Typography variant="caption" color="text.secondary">Rows (stats)</Typography><Typography fontWeight={800} fontSize={18}>{fmtInt(selRows)}</Typography></Box>
            {estimate && !stale && sel.length > 0 && (
              <Tooltip title={`at ${estimate.gbPerHour.toFixed(0)} GB/h (${estimate.measured ? 'measured on this project' : 'v1 reference speed'}), checksums included; indexes and keys come after`}>
                <Box><Typography variant="caption" color="text.secondary">Estimate (data)</Typography><Typography fontWeight={800} fontSize={18}>≈ {fmtH(estimate.runHours)}</Typography></Box>
              </Tooltip>
            )}
            <Box sx={{ minWidth: 0 }}>
              <Typography variant="caption" color="text.secondary">Checks</Typography>
              <Stack direction="row" spacing={0.75} alignItems="center">
                {checking || capChecking || stale ? <CircularProgress size={16} /> : <CheckIcon ok={checksOk} warn={!checksOk && !blocking.length} />}
                <Typography fontWeight={650} fontSize={14} noWrap>
                  {checking && !checks ? 'checking…' : !checks ? 'not run yet' : blocking.length ? `${blocking.length} to fix: ${blocking.map((c) => c.check).join(', ')}` : !sel.length ? 'select tables' : stale || capChecking ? 'checking this selection…' : capChecks.some((c) => !isOk(c)) ? 'passed, with warnings' : 'passed'}
                </Typography>
              </Stack>
            </Box>
          </Box>
          {error && <Alert severity="error" sx={{ flexBasis: '100%', order: 3 }}>{error}</Alert>}
          <Tooltip title={!sel.length ? 'Select at least one table' : !checks || stale || capChecking ? 'Waiting for the checks of this selection' : blocking.length ? 'Fix the red checks first' : ''}>
            <span>
              <Button size="large" variant="contained" startIcon={starting ? <CircularProgress size={18} color="inherit" /> : <RocketLaunchRoundedIcon />}
                disabled={!checksOk || !sel.length || starting || !!activeRunId} onClick={() => setAskCode(true)} sx={{ py: 1.3, px: 3 }}>
                {starting ? 'Starting…' : `Start migration${sel.length ? ` (${sel.length})` : ''}`}
              </Button>
            </span>
          </Tooltip>
        </Box>
      </Box>
      <Dialog open={askCode} onClose={() => setAskCode(false)} fullWidth maxWidth="sm">
        <DialogTitle sx={{ display: 'flex', alignItems: 'center', gap: 1.5, fontWeight: 800 }}>
          <AutoAwesomeRoundedIcon color="primary" /> Are your GenAI-converted code objects ready?
        </DialogTitle>
        <DialogContent>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
            Views, functions, procedures, packages and triggers are applied after the data, indexes and keys are in place.
            If the conversion is not ready yet, migrate the data now and apply the code later from Code objects.
          </Typography>
          <RadioGroup value={codeChoice} onChange={(e) => setCodeChoice(e.target.value)}>
            {packages.slice(0, 4).map((p) => (
              <Box key={p.id} sx={{ p: 1.5, mb: 1, borderRadius: 2.5, border: `1px solid ${codeChoice === p.id ? brand.blue : brand.border}`, bgcolor: codeChoice === p.id ? '#F5F9FF' : '#fff' }}>
                <FormControlLabel value={p.id} control={<Radio />} sx={{ m: 0, width: '100%' }}
                  label={<Box><Typography fontWeight={650} className="mono" fontSize={14}>Yes, apply {p.fileName}</Typography><Typography variant="caption" color="text.secondary">uploaded {fmtDate(p.uploadedAt)} · {p.fileCount} files{p.lastApply ? ` · last applied: ${p.lastApply.applied} ok, ${p.lastApply.failed} failed` : ''}</Typography></Box>} />
              </Box>
            ))}
            <Box sx={{ p: 1.5, borderRadius: 2.5, border: `1px solid ${codeChoice === 'later' ? brand.blue : brand.border}`, bgcolor: codeChoice === 'later' ? '#F5F9FF' : '#fff' }}>
              <FormControlLabel value="later" control={<Radio />} sx={{ m: 0 }}
                label={<Box><Typography fontWeight={650} fontSize={14}>Not yet: migrate the data only</Typography><Typography variant="caption" color="text.secondary">Upload the converted zip on the Code objects page and apply it later.</Typography></Box>} />
            </Box>
          </RadioGroup>
          {packages.length === 0 && (
            <Alert severity="info" sx={{ mt: 2 }} action={<Button color="inherit" size="small" onClick={() => navigate('../code')}>Code objects</Button>}>
              No converted package uploaded yet. Export the GenAI candidates zip and upload the converted one there.
            </Alert>
          )}
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2.5 }}>
          <Button onClick={() => setAskCode(false)}>Back</Button>
          <Button variant="contained" startIcon={starting ? <CircularProgress size={16} color="inherit" /> : <RocketLaunchRoundedIcon />} disabled={starting} onClick={start}>Start migration ({sel.length} tables)</Button>
        </DialogActions>
      </Dialog>
    </>
  );
}
