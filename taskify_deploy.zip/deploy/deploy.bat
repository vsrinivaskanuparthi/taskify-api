@echo off
REM DMA one-command deploy from Windows to the RHEL server.
REM This file lives in the backend folder: ora2pgservice\deploy\deploy.bat
REM The frontend folder ora2pgui is expected next to ora2pgservice (same parent folder).
REM
REM   deploy\deploy.bat          API and screens
REM   deploy\deploy.bat api      API only   (git push, then on the server: pull + pm2 restart)
REM   deploy\deploy.bat ui       screens only (npm run build, copy index.html into nginx)
REM   deploy\deploy.bat api force    restart the API even while a migration runs (it is interrupted, resumable)
REM
REM Needs: git, npm, and the OpenSSH client of Windows 10/11 (ssh, scp).

REM ---------- edit these lines once ----------
REM Your login on the RHEL server
set SERVER=youruser@your-rhel-server
REM The backend folder ON THE SERVER (where you run git pull today)
set APP_DIR=/path/to/ora2pgservice/on/the/server
REM The frontend folder on THIS Windows PC (default: next to the backend folder)
set UI_DIR=%~dp0..\..\ora2pgui
REM --------------------------------------------

setlocal
set MODE=%~1
if "%MODE%"=="" set MODE=all
set FORCE=
if /i "%~2"=="force" set FORCE=--force
set API_DIR=%~dp0..
set ARGS=

if /i "%MODE%"=="api" goto api
if /i "%MODE%"=="ui" goto ui
if /i "%MODE%"=="all" goto api
echo Unknown option "%MODE%". Use: api, ui, or nothing for both.
exit /b 1

:api
cd /d "%API_DIR%"
for /f %%i in ('git status --porcelain -- .') do (
  echo The backend has changes that are not committed. Commit them first ^(git add / git commit^), then run this again.
  exit /b 1
)
echo.
echo ==^> Pushing the backend branch
git push || (echo git push failed. & exit /b 1)
set ARGS=--api %FORCE%
if /i "%MODE%"=="api" goto remote

:ui
if not exist "%UI_DIR%\package.json" (echo Frontend folder not found: %UI_DIR% ^(edit UI_DIR in this file^) & exit /b 1)
cd /d "%UI_DIR%"
echo.
echo ==^> Building the screens
call npm run build || (echo Build failed. & exit /b 1)
echo.
echo ==^> Copying index.html to the server
scp dist\index.html %SERVER%:/tmp/dma_index.html || (echo Copy failed. & exit /b 1)
set ARGS=%ARGS% --ui /tmp/dma_index.html

:remote
echo.
echo ==^> Deploying on %SERVER%
ssh -t %SERVER% "bash %APP_DIR%/deploy/server-deploy.sh %ARGS%"
if errorlevel 2 (echo. & echo Not restarted: a migration is running. & exit /b 2)
if errorlevel 1 (echo. & echo Deploy FAILED: see the messages above. & exit /b 1)
echo.
echo All done. Open the app and press Ctrl+F5.
endlocal
