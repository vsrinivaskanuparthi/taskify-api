#!/bin/bash
# DMA deploy on the RHEL server (no internet needed). Lives in the backend folder (ora2pgservice/deploy/).
# Called by deploy.bat from Windows, or by hand from the backend folder:
#
#   bash deploy/server-deploy.sh --api                      pull the branch, restart the API
#   bash deploy/server-deploy.sh --ui /tmp/dma_index.html   put a new index.html in nginx
#   bash deploy/server-deploy.sh --api --ui /tmp/dma_index.html
#   add --force to restart the API even while a migration is running (it is interrupted, resumable)
#
# Settings below can be overridden with environment variables.
set -euo pipefail

# The backend folder (the one with server.js), one level above this script.
APP_DIR="$(cd "$(dirname "$0")/.." && pwd)"
NGINX_HTML="${NGINX_HTML:-/usr/share/nginx/html}"
PM2_NAME="${PM2_NAME:-ora2pg-service-prod}"
PORT="${PORT:-5000}"

API=0; UI=""; FORCE=0
while [ $# -gt 0 ]; do
  case "$1" in
    --api) API=1 ;;
    --ui) UI="$2"; shift ;;
    --force) FORCE=1 ;;
    *) echo "Unknown option: $1"; exit 1 ;;
  esac
  shift
done
[ "$API" = 1 ] || [ -n "$UI" ] || { echo "Nothing to do: give --api and/or --ui <file>"; exit 1; }

step() { echo; echo "==> $*"; }
# sudo only when the nginx folder is not writable by this user (asks for the password once).
SUDO=""; [ -w "$NGINX_HTML" ] || SUDO="sudo"

# ---------------------------------------------------------------- API
if [ "$API" = 1 ]; then
  # A restart interrupts running migrations (they can be resumed), so it is refused unless --force.
  STAGING="$(grep -E '^\s*MIGRATION_STAGING_DIR\s*=' "$APP_DIR/.env" 2>/dev/null | tail -1 | cut -d= -f2- | tr -d '"'"'"' ' || true)"
  STAGING="${STAGING:-/migration_staging}"
  RUNNING="$(grep -lE '"migrationStatus": *"(RUNNING|IN_PROGRESS|QUEUED)"' "$STAGING"/*/project_meta.json 2>/dev/null || true)"
  if [ -n "$RUNNING" ] && [ "$FORCE" != 1 ]; then
    echo "A migration is running in: $(echo "$RUNNING" | xargs -n1 dirname | xargs -n1 basename | tr '\n' ' ')"
    echo "The API was NOT restarted. Deploy after it finishes, or add --force (the run is interrupted and can be resumed)."
    exit 2
  fi

  step "Pulling the latest code"
  cd "$APP_DIR"
  OLD="$(git rev-parse HEAD)"
  git pull --ff-only
  NEW="$(git rev-parse HEAD)"
  echo "$OLD -> $NEW"

  if [ -n "$(git diff --name-only "$OLD" "$NEW" -- package.json package-lock.json)" ]; then
    step "Backend packages changed: npm ci"
    npm ci --omit=dev || {
      echo "npm ci failed (no internet / registry on this server?). Copy node_modules from a machine"
      echo "with the same Node version, then run this script again."
      exit 1
    }
  fi

  step "Restarting the API ($PM2_NAME)"
  if pm2 describe "$PM2_NAME" >/dev/null 2>&1; then
    pm2 restart "$PM2_NAME"
  else
    npm run start:prod
  fi
  pm2 save >/dev/null

  step "Waiting for the API"
  for i in $(seq 1 30); do
    if curl -sf "http://127.0.0.1:$PORT/api/health" >/dev/null; then echo "API is up"; break; fi
    [ "$i" = 30 ] && { echo "API did not answer on port $PORT. See: pm2 logs $PM2_NAME --lines 50"; exit 1; }
    sleep 1
  done
fi

# ---------------------------------------------------------------- UI
if [ -n "$UI" ]; then
  step "Installing the new screens (index.html)"
  [ -s "$UI" ] || { echo "File not found or empty: $UI"; exit 1; }
  grep -q '<div id="root"' "$UI" || { echo "$UI does not look like the DMA index.html"; exit 1; }
  # Previous version kept for a quick rollback: cp index.html.previous index.html
  [ -f "$NGINX_HTML/index.html" ] && $SUDO cp -p "$NGINX_HTML/index.html" "$NGINX_HTML/index.html.previous"
  $SUDO install -m 644 "$UI" "$NGINX_HTML/index.html"
  # SELinux (RHEL): files copied in keep the label of /tmp, which nginx may not read.
  command -v restorecon >/dev/null && $SUDO restorecon "$NGINX_HTML/index.html" || true
  rm -f "$UI"
  echo "Done: nginx serves the new file right away (no restart needed). Press Ctrl+F5 in the browser."
fi

echo
echo "Deploy finished."
