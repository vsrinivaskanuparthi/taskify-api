'use strict';

// Error handling hardening (DMA-073): every API failure gets an answer (never an endless spinner),
// with a DMA error code and a log reference; and the input bugs found while checking it.
const fs = require('fs');
const os = require('os');
const path = require('path');
const express = require('express');
const request = require('supertest');

const staging = fs.mkdtempSync(path.join(os.tmpdir(), 'dma-errors-'));
process.env.MIGRATION_STAGING_DIR = staging;
const { safeRouter, errorResponder, wrapHandler } = require('../../utils/asyncRoute');
const { CODES, codeForStatus } = require('../../utils/errorCodes');

afterAll(() => {
  try { fs.chmodSync(path.join(staging, 'RO_PROJ'), 0o755); } catch { /* not created */ }
  fs.rmSync(staging, { recursive: true, force: true });
});

function app(build) {
  const a = express();
  a.use(express.json());
  const r = safeRouter(express.Router());
  build(r);
  r.use(errorResponder);
  a.use('/api', r);
  return a;
}

describe('every API failure gets an answer', () => {
  test('an async handler that fails answers 500 with a code and a reference (Express 4 alone would hang)', async () => {
    const a = app((r) => r.get('/boom', async () => { await Promise.resolve(); throw new Error('disk read failed at /secret/path'); }));
    const res = await request(a).get('/api/boom').timeout(3000);
    expect(res.status).toBe(500);
    expect(res.body).toMatchObject({ code: 'DMA-SYS-500' });
    expect(res.body.ref).toMatch(/^R-[0-9A-F]{6}$/);
    expect(res.body.message).toContain(res.body.ref);
    expect(res.body.message).not.toContain('/secret/path'); // no internals in the browser
  });

  test('a handler that throws straight away is answered too', async () => {
    const a = app((r) => r.get('/sync', () => { throw new Error('x'); }));
    expect((await request(a).get('/api/sync').timeout(3000)).status).toBe(500);
  });

  test('a failing middleware (like loading the project) is answered too', async () => {
    const a = app((r) => r.use('/p', async () => { throw new Error('meta unreadable'); }, (req, res) => res.json({})));
    expect((await request(a).get('/api/p').timeout(3000)).body.code).toBe('DMA-SYS-500');
  });

  test('an error with its own status and code keeps them, and its message is shown', async () => {
    const a = app((r) => {
      r.get('/busy', async () => { throw Object.assign(new Error('A migration is already running for this project.'), { status: 409 }); });
      r.get('/disk', async () => { throw Object.assign(new Error('Disk almost full'), { status: 507, code: 'DMA-SYS-202' }); });
    });
    const busy = await request(a).get('/api/busy');
    expect(busy.status).toBe(409);
    expect(busy.body).toMatchObject({ code: 'DMA-SYS-409', message: 'A migration is already running for this project.' });
    expect((await request(a).get('/api/disk')).body.code).toBe('DMA-SYS-202');
  });

  test('normal answers and error handlers are not changed', async () => {
    const a = app((r) => r.get('/ok', async (req, res) => res.json({ ok: true })));
    expect((await request(a).get('/api/ok')).body).toEqual({ ok: true });
    const fourArgs = (err, req, res, next) => next(err);
    expect(wrapHandler(fourArgs)).toBe(fourArgs);
  });

  test('a stream already started is closed instead of answered twice', async () => {
    const a = app((r) => r.get('/stream', async (req, res) => { res.write('partial'); throw new Error('broke mid-stream'); }));
    const res = await request(a).get('/api/stream').timeout(3000);
    expect(res.text).toBe('partial');
  });
});

describe('DMA error codes', () => {
  const FORMAT = /^DMA-(ORA|PG|NET|ENG|SYS)-\d{3}$/;
  test('server codes have the right format and a description', () => {
    Object.entries(CODES).forEach(([code, text]) => {
      expect(code).toMatch(FORMAT);
      expect(text.length).toBeGreaterThan(5);
    });
    expect(codeForStatus(404)).toBe('DMA-SYS-404');
    expect(codeForStatus(502)).toBe('DMA-SYS-500');
    expect(codeForStatus(422)).toBe('DMA-SYS-400');
  });

  // The UI folder is "frontend" in the dev repo and "ora2pgui" on the servers; skip if neither is next to us.
  const uiFile = ['frontend', 'ora2pgui']
    .map((dir) => path.join(__dirname, '../../..', dir, 'src/errorHelp.ts'))
    .find((f) => fs.existsSync(f));
  (uiFile ? test : test.skip)('no code is used twice, across the server list and the UI explanations', () => {
    const ui = fs.readFileSync(uiFile, 'utf8');
    const uiCodes = [...ui.matchAll(/code: '(DMA-[A-Z]+-\d{3})'/g)].map((m) => m[1]);
    expect(uiCodes.length).toBeGreaterThan(30);
    uiCodes.forEach((c) => expect(c).toMatch(FORMAT));
    // Server codes that the UI explains appear in both lists (same meaning); every other code is unique.
    const explainedByUi = new Set(['DMA-SYS-500', 'DMA-SYS-201', 'DMA-SYS-202', 'DMA-ENG-201', 'DMA-ENG-202']);
    expect(new Set(uiCodes).size).toBe(uiCodes.length);
    Object.keys(CODES).filter((c) => !explainedByUi.has(c)).forEach((c) => expect(uiCodes).not.toContain(c));
    explainedByUi.forEach((c) => { expect(uiCodes).toContain(c); expect(CODES[c]).toBeDefined(); });
  });
});

describe('the real API routes', () => {
  const routes = require('../../routes/projectRoutes');
  const api = express();
  api.use(express.json({ limit: '5mb' }));
  api.use('/api', routes);
  const store = require('../../services/projectStore');

  beforeAll(async () => {
    for (const name of ['RO_PROJ', 'OK_PROJ']) {
      fs.mkdirSync(path.join(staging, name), { recursive: true });
      await store.writeJsonAtomic(path.join(staging, name, 'project_meta.json'), { projectName: name, appName: 'App', appCode: 'A', createdAt: '2026-11-16T00:00:00Z' });
    }
  });

  test('saving settings when the project folder cannot be written: a clear answer, not a hang', async () => {
    // Windows does not enforce read-only folders, and root ignores them: nothing to prove there.
    if (process.platform === 'win32' || (process.getuid && process.getuid() === 0)) return;
    fs.chmodSync(path.join(staging, 'RO_PROJ'), 0o555);
    try {
      const res = await request(api).put('/api/projects/RO_PROJ/settings').send({ targetSchema: 'x' }).timeout(5000);
      expect(res.status).toBe(500);
      expect(res.body.code).toBe('DMA-SYS-500');
      expect(res.body.ref).toMatch(/^R-/);
    } finally {
      fs.chmodSync(path.join(staging, 'RO_PROJ'), 0o755);
    }
  });

  test('project fields must be text (an object was saved as is before)', async () => {
    const bad = await request(api).patch('/api/projects/OK_PROJ').send({ appName: { x: 1 } });
    expect(bad.status).toBe(400);
    expect(bad.body).toMatchObject({ code: 'DMA-SYS-400', message: 'appName must be text.' });
    expect((await store.readMeta('OK_PROJ')).appName).toBe('App');
    const ok = await request(api).patch('/api/projects/OK_PROJ').send({ appName: 'Billing' });
    expect(ok.body.project.appName).toBe('Billing');
  });

  test('deleting a package that does not exist says so (it said "Deleted")', async () => {
    const res = await request(api).delete('/api/projects/OK_PROJ/code/packages/20260101-000000');
    expect(res.status).toBe(404);
    expect(res.body.code).toBe('DMA-SYS-404');
  });

  test('downloading an export with a wrong id explains why (the answer was empty)', async () => {
    const res = await request(api).get('/api/projects/OK_PROJ/code/exports/not-an-id/download');
    expect(res.status).toBe(400);
    expect(res.body).toMatchObject({ code: 'DMA-SYS-400', message: 'Invalid export id.' });
  });

  test('admin-only answers carry their code', async () => {
    const roles = require('../../utils/roles');
    const prev = process.env.DMA_ADMINS;
    process.env.DMA_ADMINS = 'SOMEONE_ELSE';
    const res = { status: jest.fn().mockReturnThis(), json: jest.fn() };
    roles.requireAdmin({ user: { id: 'me' } }, res, () => {});
    expect(res.json).toHaveBeenCalledWith(expect.objectContaining({ code: 'DMA-SYS-403' }));
    process.env.DMA_ADMINS = prev;
  });
});
