'use strict';

// DB link errors in plain words: what went wrong and what to do (oracle_fdw / postgres_fdw).
const { dbLinkError } = require('../../services/code');

test.each([
  ['psql:/srv/p/.dblinks_1.sql:9: ERROR:  cannot authenticate connection to foreign Oracle server', /^cannot authenticate connection to foreign Oracle server\. Wrong user or password/],
  ['psql:/srv/p/.dblinks_1.sql:3: ERROR:  permission denied for foreign-data wrapper oracle_fdw', /GRANT USAGE ON FOREIGN DATA WRAPPER oracle_fdw TO <DMA user>/],
  ['ERROR:  permission denied to create extension "oracle_fdw"', /The extension is not installed in this PostgreSQL/],
  ['ERROR:  extension "oracle_fdw" is not available', /The DBA installs it on the PostgreSQL server/],
  ['ERROR:  cannot connect to foreign Oracle server', /cannot reach the remote database: check Host, Port and Service name/],
])('%s', (raw, expected) => {
  const msg = dbLinkError(raw);
  expect(msg).toMatch(expected);
  expect(msg).not.toMatch(/psql:|ERROR:/);
  expect(msg).toMatch(/previous DB link setup is kept unchanged\.$/);
});

// DMA-079: DB links created on their own (no converted package).
describe('updating a link that views use', () => {
  const { dbLinkUpdateSql, dbLinkSql } = require('../../services/code');
  const pgLink = { mode: 'postgres_fdw', host: 'pg-remote', port: '', dbname: 'sales', user: "o'neil", localSchema: 'link_sales', remoteSchema: 'public' };
  const oraLink = { mode: 'oracle_fdw', host: 'ora1', port: '1522', dbname: 'ORCL', user: 'APP', localSchema: 'link_ora', remoteSchema: 'APP' };

  test('never drops anything (the views that use the link stay)', () => {
    const sql = dbLinkUpdateSql('SALES.EXAMPLE.COM', pgLink, ['app_read'], 'pw').join('\n');
    expect(sql).not.toMatch(/DROP/i);
    expect(sql).toMatch(/^ALTER SERVER "fdw_sales_example_com" OPTIONS \(SET host 'pg-remote', SET port '5432', SET dbname 'sales'\);/);
    expect(sql).toContain('CREATE SCHEMA IF NOT EXISTS "link_sales";');
  });

  test('sets the new user and password for DMA and for every application role, quoted safely', () => {
    const sql = dbLinkUpdateSql('SALES', pgLink, ['app_read', 'app_rw'], "p'w");
    for (const who of ['CURRENT_USER', 'app_read', 'app_rw']) {
      expect(sql).toContain(`CREATE USER MAPPING IF NOT EXISTS FOR ${who} SERVER "fdw_sales" OPTIONS (user 'o''neil', password 'p''w');`);
      expect(sql).toContain(`ALTER USER MAPPING FOR ${who} SERVER "fdw_sales" OPTIONS (SET user 'o''neil', SET password 'p''w');`);
    }
    expect(sql).toContain('GRANT USAGE ON FOREIGN SERVER "fdw_sales" TO app_rw;');
  });

  test('oracle_fdw: the address becomes dbserver, a full description is kept as it is', () => {
    expect(dbLinkUpdateSql('ORA', oraLink, [], 'x')[0]).toBe(`ALTER SERVER "fdw_ora" OPTIONS (SET dbserver '//ora1:1522/ORCL');`);
    const desc = '(DESCRIPTION=(ADDRESS=(HOST=a)(PORT=1)))';
    expect(dbLinkUpdateSql('ORA', { ...oraLink, host: ` ${desc}` }, [], 'x')[0]).toBe(`ALTER SERVER "fdw_ora" OPTIONS (SET dbserver '${desc}');`);
  });

  test('a fresh link is built with the same server name, so create, update and remove agree', () => {
    expect(dbLinkSql({ dbLinkMappings: { 'SALES.EXAMPLE.COM': pgLink } })).toContain('CREATE SERVER "fdw_sales_example_com"');
    expect(dbLinkSql({ dbLinkMappings: { X: { ...pgLink, mode: 'skip' } } })).toBe('');
  });
});

test('a remote PostgreSQL that does not ask for the password is explained', () => {
  expect(dbLinkError('ERROR:  password or GSSAPI delegated credentials required')).toMatch(/without asking for its password.*instead of localhost/);
  expect(dbLinkError('ERROR:  password is required')).toMatch(/scram-sha-256/);
});

test('postgres_fdw: the reason on the DETAIL line is shown and decides the advice', () => {
  const pgErr = 'could not connect to server "fdw_sales"\nconnection to server at "pg1" (10.0.0.5), port 5432 failed: FATAL:  password authentication failed for user "reader"';
  const msg = dbLinkError(pgErr);
  expect(msg).toMatch(/^could not connect to server "fdw_sales": password authentication failed for user "reader"\. Wrong user or password/);
  expect(msg).not.toMatch(/cannot reach/);
  const psqlTail = 'psql:/x/.dblinks_1.sql:5: ERROR:  could not connect to server "fdw_sales"\nDETAIL:  connection to server at "pg1" (10.0.0.5), port 5432 failed: Connection refused';
  expect(dbLinkError(psqlTail)).toMatch(/: Connection refused\. The PostgreSQL server cannot reach the remote database/);
});
