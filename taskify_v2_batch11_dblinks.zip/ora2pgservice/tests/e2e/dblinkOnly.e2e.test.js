'use strict';

/**
 * End-to-end (DMA-079): DB links created on their own, without a converted GenAI package.
 * A link of project E2E_TEST is mapped to postgres_fdw and points at the test database acmm_remote
 * on the same PostgreSQL server. Checks: "Create now", the status shown on Code objects, creating
 * again while a view uses the link (kept, new remote tables added), Remove (asks first when views use
 * it), a wrong password, and a migration run that creates the links with "migrate the data only".
 * The project's own DB link settings are put back at the end.
 *
 * Needs (dev-tools/run-e2e.sh sets them): PG_REMOTE_PW, DMA_E2E_STAGING, DMA_E2E_PG_URL.
 *   DMA_E2E_PGFDW_HOST  the remote PostgreSQL as the PostgreSQL server reaches it (default ora2pg-postgres:
 *                       its network name, because localhost logins there need no password).
 */
const fs = require('fs');
const path = require('path');
const { Client } = require('pg');
const { P, call, apiUp, waitRun } = require('./helpers');

const LINK = 'ACMM_LINK';
const LOCAL = 'link_acmm_link';
const SCRATCH = 'dblink_e2e';
const ready = process.env.PG_REMOTE_PW && process.env.DMA_E2E_STAGING && process.env.DMA_E2E_PG_URL;
const maybe = ready ? describe : describe.skip;
const metaFile = () => path.join(process.env.DMA_E2E_STAGING, process.env.DMA_E2E_PROJECT || 'E2E_TEST', 'project_meta.json');

jest.setTimeout(300000);

const mapping = (password) => ({ mappings: { [LINK]: {
  mode: 'postgres_fdw', host: process.env.DMA_E2E_PGFDW_HOST || 'ora2pg-postgres', port: '5432', dbname: 'acmm_remote',
  remoteSchema: 'acmm_remote', user: 'acmm_reader', password, localSchema: LOCAL } } });
const create = async (body = {}) => (await call('POST', `${P}/code/dblinks/create`, body)).data;
const remove = (force) => call('POST', `${P}/code/dblinks/${LINK}/remove`, { force });

maybe('DB links without a converted package (postgres_fdw)', () => {
  let pg; // the migration target database (DMA_E2E_PG_URL), as DMA's user
  let remote; // the remote database, as the link's user
  let saved; // the project's DB link settings before the test
  const exists = async (schema) => (await pg.query('SELECT 1 FROM pg_namespace WHERE nspname = $1', [schema])).rowCount === 1;
  const count = async (c, q) => Number((await c.query(q)).rows[0].n);

  beforeAll(async () => {
    await apiUp();
    const meta = JSON.parse(fs.readFileSync(metaFile(), 'utf8'));
    saved = { dbLinkMappings: meta.dbLinkMappings, dbLinkStatus: meta.dbLinkStatus };
    pg = new Client({ connectionString: process.env.DMA_E2E_PG_URL });
    await pg.connect();
    const u = new URL(process.env.DMA_E2E_PG_URL);
    remote = new Client({ host: u.hostname, port: Number(u.port || 5432), database: 'acmm_remote', user: 'acmm_reader', password: process.env.PG_REMOTE_PW });
    await remote.connect();
    await remote.query('DROP TABLE IF EXISTS acmm_remote.dblink_e2e_new');
    expect((await call('PUT', `${P}/code/dblinks`, mapping(process.env.PG_REMOTE_PW))).status).toBe(200);
    await remove(true);
    await pg.query(`DROP SCHEMA IF EXISTS ${SCRATCH} CASCADE`);
  });

  afterAll(async () => {
    if (!pg) return;
    await pg.query(`DROP SCHEMA IF EXISTS ${SCRATCH} CASCADE`).catch(() => {});
    await remove(true).catch(() => {});
    await remote.query('DROP TABLE IF EXISTS acmm_remote.dblink_e2e_new').catch(() => {});
    await Promise.all([pg.end(), remote.end()]);
    // The project's own DB link settings, as they were.
    const meta = JSON.parse(fs.readFileSync(metaFile(), 'utf8'));
    fs.writeFileSync(metaFile(), JSON.stringify({ ...meta, ...saved }, null, 2));
  });

  test('"Create now": the remote tables and views can be read in PostgreSQL, same rows as the remote database', async () => {
    const r = await create();
    expect(r).toMatchObject({ ok: true, created: 1, failed: 0 });
    expect(r.links[0]).toMatchObject({ name: LINK, ok: true, action: 'created', tables: 4 });
    for (const t of ['operator_src', 'customer_src', 'ss10_view_third']) {
      expect(await count(pg, `SELECT count(*) AS n FROM ${LOCAL}.${t}`)).toBe(await count(remote, `SELECT count(*) AS n FROM acmm_remote.${t}`));
    }
  });

  test('the Code objects page shows that the link is in PostgreSQL', async () => {
    const { data } = await call('GET', `${P}/code`);
    expect(data.dbLinkStatus[LINK]).toMatchObject({ ok: true, action: 'created', tables: 4 });
    expect(data.dbLinkMappings[LINK].password).toBeUndefined(); // never sent to the browser
  });

  test('creating again while a view uses the link keeps the view and adds new remote tables', async () => {
    await pg.query(`CREATE SCHEMA ${SCRATCH}`);
    await pg.query(`CREATE VIEW ${SCRATCH}.operators AS SELECT * FROM ${LOCAL}.operator_src`);
    await remote.query('CREATE TABLE acmm_remote.dblink_e2e_new (id int)');
    await remote.query('INSERT INTO acmm_remote.dblink_e2e_new VALUES (1), (2)');
    const r = (await create({ names: [LINK] })).links[0];
    expect(r).toMatchObject({ ok: true, action: 'updated', kept: 1, added: 1, tables: 5 });
    expect(await count(pg, `SELECT count(*) AS n FROM ${SCRATCH}.operators`)).toBeGreaterThan(0);
    expect(await count(pg, `SELECT count(*) AS n FROM ${LOCAL}.dblink_e2e_new`)).toBe(2);
  });

  test('a wrong password is explained and the working link is kept', async () => {
    await call('PUT', `${P}/code/dblinks`, mapping('wrong-password'));
    try {
      const r = (await create()).links[0];
      expect(r.ok).toBe(false);
      expect(r.message).toMatch(/password authentication failed.*Wrong user or password.*previous DB link setup is kept unchanged/);
      expect(r.message).not.toMatch(/cannot reach/);
      expect(await count(pg, `SELECT count(*) AS n FROM ${SCRATCH}.operators`)).toBeGreaterThan(0);
    } finally {
      await call('PUT', `${P}/code/dblinks`, mapping(process.env.PG_REMOTE_PW));
    }
  });

  test('Remove asks first when views use the link, and removes both only when confirmed', async () => {
    const first = await remove(false);
    expect(first.status).toBe(409);
    expect(first.data.dependents).toEqual([{ name: `${SCRATCH}.operators`, kind: 'view' }]);
    expect(await exists(LOCAL)).toBe(true);
    const forced = await remove(true);
    expect(forced.status).toBe(200);
    expect(forced.data.removed).toBe(true);
    expect(await exists(LOCAL)).toBe(false);
    expect((await pg.query(`SELECT 1 FROM pg_views WHERE schemaname = '${SCRATCH}'`)).rowCount).toBe(0);
    expect((await call('GET', `${P}/code`)).data.dbLinkStatus[LINK]).toBeUndefined();
  });

  test('unknown links and bad input are refused', async () => {
    expect((await call('POST', `${P}/code/dblinks/create`, { names: ['NO_SUCH_LINK'] })).status).toBe(400);
    expect((await call('POST', `${P}/code/dblinks/create`, { names: 'x' })).status).toBe(400);
    expect((await call('POST', `${P}/code/dblinks/NO_SUCH_LINK/remove`, {})).status).toBe(404);
  });

  test('a migration run without a package creates the links only when asked', async () => {
    const plain = await call('POST', `${P}/runs`, { tables: ['PLANT'] });
    expect(plain.status).toBe(202);
    const run1 = await waitRun(plain.data.runId);
    expect(run1.status).toBe('COMPLETED');
    expect(run1.phases.find((p) => p.key === 'code').status).not.toBe('failed');
    expect(await exists(LOCAL)).toBe(false);

    const withLinks = await call('POST', `${P}/runs`, { tables: ['PLANT'], createDbLinks: true });
    expect(withLinks.status).toBe(202);
    const run2 = await waitRun(withLinks.data.runId);
    expect(run2.status).toBe('COMPLETED');
    expect(run2.codeResult).toMatchObject({ packageId: null, dbLinks: 'ok' });
    expect(run2.codeResult.links).toEqual([expect.objectContaining({ name: LINK, ok: true, action: 'created' })]);
    expect(run2.events.some((e) => /DB links: 1 created/.test(e.message || e.text || ''))).toBe(true);
    expect(await count(pg, `SELECT count(*) AS n FROM ${LOCAL}.operator_src`)).toBeGreaterThan(0);
  });
});
