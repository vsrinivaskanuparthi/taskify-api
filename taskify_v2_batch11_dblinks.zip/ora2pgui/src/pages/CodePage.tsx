import { prefillFromOracle } from '../logic/dbLink';
import { Alert, Box, Button, Card, Chip, CircularProgress, Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle, IconButton, LinearProgress, MenuItem, Stack, Table, TableBody, TableCell, TableHead, TableRow, TextField, Tooltip, Typography } from '@mui/material';
import AutoAwesomeRoundedIcon from '@mui/icons-material/AutoAwesomeRounded';
import CloudDownloadRoundedIcon from '@mui/icons-material/CloudDownloadRounded';
import CloudUploadRoundedIcon from '@mui/icons-material/CloudUploadRounded';
import PsychologyRoundedIcon from '@mui/icons-material/PsychologyRounded';
import PlayArrowRoundedIcon from '@mui/icons-material/PlayArrowRounded';
import DeleteOutlineRoundedIcon from '@mui/icons-material/DeleteOutlineRounded';
import ListAltRoundedIcon from '@mui/icons-material/ListAltRounded';
import LinkRoundedIcon from '@mui/icons-material/LinkRounded';
import CloseRoundedIcon from '@mui/icons-material/CloseRounded';
import FolderZipRoundedIcon from '@mui/icons-material/FolderZipRounded';
import { useCallback, useEffect, useRef, useState } from 'react';
import { api, ApiError, apiUrl, projectPath } from '../api';
import { useProject } from '../context/ProjectContext';
import { CheckIcon, EmptyState, PageHeader, SectionCard, StatusChip, Tag } from '../components/ui';
import { fmtBytes, fmtDate } from '../format';
import { brand, headingFont, monoFont } from '../theme';

type Folder = { folder: string; label: string; files: number; objects?: number; status?: string; error?: string };
type ExportM = { id: string; zipName: string; createdAt: string; bytes?: number; folders: Folder[] };
type PackageM = { id: string; fileName: string; uploadedAt: string; folders: Folder[]; warnings: string[]; notice?: string | null; fileCount: number; lastApply: null | { at: string; applied: number; existing?: number; failed: number; dbLinks: string | null; runId: string | null } };
type DbLink = { owner: string; name: string; username: string; host: string; usedBy: number; usedByNames?: string[]; synonyms?: string[] };

type Mapping = { mode: 'postgres_fdw' | 'oracle_fdw' | 'skip'; host: string; port: string; dbname: string; remoteSchema: string; user: string; password?: string; localSchema: string; hasPassword?: boolean };
/** What happened the last time a link was created in PostgreSQL (DMA-079). */
export type LinkStatus = { ok: boolean; action: string; tables: number | null; message: string; at: string };
type Overview = {
  exports: ExportM[]; exportJob: any; packages: PackageM[]; applyJob: any;
  objectCounts: [string, number][]; dbLinks: DbLink[]; dbLinkMappings: Record<string, Mapping>; dbLinkStatus?: Record<string, LinkStatus>;
};
type CreateResult = { links: { name: string; ok: boolean; action: string; tables: number; message: string }[]; ok: boolean; created: number; failed: number };

const CODE_TYPES: [string, string][] = [
  ['VIEW', 'Views'], ['MATERIALIZED VIEW', 'Materialized views'], ['FUNCTION', 'Functions'], ['PROCEDURE', 'Procedures'],
  ['PACKAGE', 'Packages'], ['TRIGGER', 'Triggers'], ['TYPE', 'Types'], ['SYNONYM', 'Synonyms'], ['DATABASE LINK', 'DB links'],
];

function StepBadge({ n }: { n: number }) {
  return <Box sx={{ width: 30, height: 30, borderRadius: '50%', background: brand.accentGradient, color: '#fff', display: 'grid', placeItems: 'center', fontWeight: 800, fontFamily: headingFont, flexShrink: 0 }}>{n}</Box>;
}

/** Package files grouped by their folder (procedures/, functions/, views/, ...): one box per object type. */
const FOLDER_ORDER = ['packages', 'procedures', 'functions', 'views', 'mviews', 'materialized_views', 'triggers', 'types', 'synonyms', 'sequences'];
function groupFiles(files: any[]) {
  const groups = new Map<string, any[]>();
  for (const f of files) {
    const parts = String(f.path).split('/');
    const key = parts.length > 1 ? parts[parts.length - 2].toLowerCase() : 'other';
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key)!.push(f);
  }
  const rank = (k: string) => { const i = FOLDER_ORDER.indexOf(k); return i < 0 ? 99 : i; };
  return [...groups.entries()]
    .sort(([a], [b]) => rank(a) - rank(b) || a.localeCompare(b))
    .map(([key, list]) => ({
      key,
      title: key === 'other' ? 'Other files' : key.replace(/_/g, ' ').replace(/^./, (c) => c.toUpperCase()),
      files: list,
      failed: list.filter((f) => f.status === 'failed').length,
    }));
}

function FilesDialog({ pkgId, onClose }: { pkgId: string | null; onClose: () => void }) {
  const { name } = useProject();
  const [m, setM] = useState<any>(null);
  useEffect(() => { if (pkgId) api(`${projectPath(name)}/code/packages/${pkgId}`).then(setM); else setM(null); }, [pkgId, name]);
  return (
    <Dialog open={!!pkgId} onClose={onClose} fullWidth maxWidth="lg">
      <DialogTitle sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
        <ListAltRoundedIcon color="primary" /> Files in {m?.fileName}
        <Box sx={{ flex: 1 }} /><IconButton onClick={onClose}><CloseRoundedIcon /></IconButton>
      </DialogTitle>
      <DialogContent>
        {!m ? <LinearProgress /> : (
          <>
            {m.warnings?.length > 0 && <Alert severity="warning" sx={{ mb: 2 }}>{m.warnings.length} entries were ignored: {m.warnings.slice(0, 3).join('; ')}{m.warnings.length > 3 ? '…' : ''}</Alert>}
            <Box sx={{ display: 'grid', gap: 2, gridTemplateColumns: { xs: '1fr', md: '1fr 1fr' }, alignItems: 'start' }}>
              {groupFiles(m.files).map((g) => (
                <Box key={g.key} sx={{ border: `1px solid ${brand.border}`, borderRadius: 3, overflow: 'hidden' }}>
                  <Stack direction="row" alignItems="center" spacing={1} sx={{ px: 1.75, py: 1.25, bgcolor: '#F7F9FC', borderBottom: `1px solid ${brand.border}` }}>
                    <CheckIcon ok={g.failed === 0} warn={g.failed > 0} />
                    <Typography fontWeight={700} fontSize={14} sx={{ flex: 1 }}>{g.title}</Typography>
                    <Typography variant="caption" color="text.secondary">{g.files.length} file{g.files.length === 1 ? '' : 's'}{g.failed ? ` · ${g.failed} failed` : ''}</Typography>
                  </Stack>
                  <Table size="small">
                    <TableBody>
                      {g.files.map((f: any) => (
                        <TableRow key={f.path}>
                          <TableCell sx={{ maxWidth: 360 }}>
                            <span className="mono">{f.path.split('/').pop()}</span>
                            {f.error && <Typography variant="caption" color={f.status === 'failed' ? 'error.main' : 'text.secondary'} sx={{ display: 'block', overflowWrap: 'anywhere' }}>{f.error.replace(/^psql:[^:]+:\d+:\s*/, '')}</Typography>}
                          </TableCell>
                          <TableCell sx={{ width: 110 }}><StatusChip status={f.status === 'pending' ? 'pending' : f.status} /></TableCell>
                          <TableCell sx={{ width: 80, color: 'text.secondary' }}>{fmtBytes(f.bytes)}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </Box>
              ))}
            </Box>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}

export function DbLinkMapping({ links, initial, status = {}, onSaved }: { links: DbLink[]; initial: Record<string, Mapping>; status?: Record<string, LinkStatus>; onSaved: () => void }) {
  const { name } = useProject();
  const blank = (l: DbLink): Mapping => ({ mode: 'skip', host: '', port: '', dbname: '', remoteSchema: (l.username || '').toLowerCase(), user: '', localSchema: `link_${l.name.toLowerCase().split('.')[0].replace(/[^a-z0-9_]/g, '_')}` });
  const [maps, setMaps] = useState<Record<string, Mapping>>(() => Object.fromEntries(links.map((l) => [l.name, { ...blank(l), ...(initial[l.name] || {}) }])));
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const [tests, setTests] = useState<Record<string, { busy?: boolean; ok?: boolean; text?: string }>>({});
  const [creating, setCreating] = useState<string | null>(null); // a link name, or '*' for all
  const [remove, setRemove] = useState<{ link: string; busy?: boolean; dependents?: string; error?: string } | null>(null);
  const set = (link: string, k: keyof Mapping, v: string) => setMaps({ ...maps, [link]: { ...maps[link], [k]: v } });
  // Choosing oracle_fdw fills the empty fields from Oracle's own link definition (a starting point:
  // the host must be reachable from the PostgreSQL server).
  const setMode = (l: DbLink, mode: string) => {
    const m = maps[l.name];
    const fromOracle = prefillFromOracle(mode, l.host);
    setMaps({ ...maps, [l.name]: { ...m, mode: mode as any,
      host: m.host || fromOracle.host, port: m.port || fromOracle.port, dbname: m.dbname || fromOracle.dbname,
      user: m.user || (mode === 'oracle_fdw' ? l.username : ''), remoteSchema: mode === 'oracle_fdw' && (!m.remoteSchema || m.remoteSchema === (l.username || '').toLowerCase()) ? l.username : m.remoteSchema } });
  };
  const persist = () => api(`${projectPath(name)}/code/dblinks`, { method: 'PUT', body: { mappings: maps } });
  const save = async () => {
    try {
      await persist();
      setMsg({ ok: true, text: 'Saved. Press "Create now" to create the links in PostgreSQL, or tick "Create the saved DB links" on the Migrate page.' });
      onSaved();
    } catch (e: any) { setMsg({ ok: false, text: e.message }); }
  };
  /** Saves, then tries the link on the PostgreSQL server without keeping anything. */
  const test = async (link: string) => {
    setTests({ ...tests, [link]: { busy: true } });
    try {
      await persist();
      const r = await api<{ ok: boolean; message: string }>(`${projectPath(name)}/code/dblinks/test`, { body: { name: link } });
      setTests((t) => ({ ...t, [link]: { ok: r.ok, text: r.message } }));
    } catch (e: any) { setTests((t) => ({ ...t, [link]: { ok: false, text: e.message } })); }
  };
  /** Saves, then creates the link(s) in PostgreSQL now: no converted package needed (DMA-079). */
  const create = async (link?: string) => {
    setCreating(link || '*');
    setMsg(null);
    try {
      await persist();
      const r = await api<CreateResult>(`${projectPath(name)}/code/dblinks/create`, { body: link ? { names: [link] } : {} });
      if (link) {
        const one = r.links[0];
        setTests((t) => ({ ...t, [link]: { ok: !!one?.ok, text: one?.message || 'Nothing to create.' } }));
      } else {
        setMsg(r.links.length
          ? { ok: r.ok, text: `${r.created} DB link(s) created${r.failed ? `, ${r.failed} failed: ${r.links.filter((x) => !x.ok).map((x) => `${x.name}: ${x.message}`).join(' ')}` : '.'}` }
          : { ok: false, text: 'No link to create: choose postgres_fdw or oracle_fdw for a link first.' });
      }
      onSaved();
    } catch (e: any) {
      if (link) setTests((t) => ({ ...t, [link]: { ok: false, text: e.message } }));
      else setMsg({ ok: false, text: e.message });
    } finally { setCreating(null); }
  };
  /** Removes a link from PostgreSQL; when views use it, asks again before dropping them too. */
  const doRemove = async (force: boolean) => {
    if (!remove) return;
    setRemove({ ...remove, busy: true, error: undefined });
    try {
      const r = await api<{ message: string }>(`${projectPath(name)}/code/dblinks/${encodeURIComponent(remove.link)}/remove`, { body: { force } });
      setTests((t) => ({ ...t, [remove.link]: { ok: true, text: r.message } }));
      setRemove(null);
      onSaved();
    } catch (e: any) {
      if (e instanceof ApiError && e.status === 409) setRemove({ link: remove.link, dependents: e.message });
      else setRemove({ link: remove.link, error: e.message });
    }
  };
  const busy = creating !== null;
  const active = links.filter((l) => maps[l.name]?.mode !== 'skip').length;
  if (!links.length) return <Typography color="text.secondary" variant="body2">No DB links in this schema (from the snapshot).</Typography>;
  return (
    <Stack spacing={2}>
      {links.map((l) => {
        const m = maps[l.name];
        return (
          <Box key={l.name} sx={{ p: 2, borderRadius: 3, border: `1px solid ${brand.border}`, bgcolor: m.mode === 'skip' ? '#FAFBFD' : '#fff' }}>
            <Stack direction={{ xs: 'column', md: 'row' }} spacing={2} alignItems={{ md: 'center' }} justifyContent="space-between" sx={{ mb: m.mode === 'skip' ? 0 : 2 }}>
              <Box sx={{ minWidth: 0 }}>
                <Stack direction="row" spacing={1} alignItems="center"><LinkRoundedIcon fontSize="small" color="primary" /><Typography fontWeight={700} className="mono">{l.name}</Typography>{l.owner === 'PUBLIC' && <Tag label="public" color={brand.muted} />}</Stack>
                <Typography variant="caption" color="text.secondary">Oracle: {l.username}@{l.host} · used by {l.usedBy} object{l.usedBy === 1 ? '' : 's'}{l.usedByNames?.length ? ` (${l.usedByNames.map((n) => n.toLowerCase()).join(', ')}${(l.synonyms || []).length ? ', synonyms below' : ''})` : ''}</Typography>
                {status[l.name] && (
                  <Stack direction="row" spacing={0.75} alignItems="center" sx={{ mt: 0.5 }} data-testid={`link-status-${l.name}`}>
                    <CheckIcon ok={status[l.name].ok} warn={!status[l.name].ok} />
                    <Typography variant="caption" color={status[l.name].ok ? 'success.dark' : 'error.main'}>
                      {status[l.name].ok ? `In PostgreSQL${status[l.name].tables != null ? `: ${status[l.name].tables} remote tables and views` : ''}` : 'Last create failed'} · {fmtDate(status[l.name].at)}
                    </Typography>
                  </Stack>
                )}
                {(l.synonyms || []).length > 0 && <Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>Synonyms over this link: {(l.synonyms || []).join(', ')}. They are not in the export: once the link is mapped, code reads the remote table as link_{l.name.split('.')[0].toLowerCase()}.&lt;table&gt;.</Typography>}
              </Box>
              <TextField select size="small" value={m.mode} onChange={(e) => setMode(l, e.target.value)} sx={{ minWidth: 300 }}>
                <MenuItem value="postgres_fdw">Remote database is on PostgreSQL (postgres_fdw)</MenuItem>
                <MenuItem value="oracle_fdw">Remote database stays on Oracle (oracle_fdw)</MenuItem>
                <MenuItem value="skip">Do not create (handle manually)</MenuItem>
              </TextField>
            </Stack>
            {m.mode !== 'skip' && (
              <Box sx={{ display: 'grid', gap: 1.5, gridTemplateColumns: { xs: '1fr 1fr', lg: 'repeat(4, 1fr)' } }}>
                <TextField size="small" label="Host" value={m.host} onChange={(e) => set(l.name, 'host', e.target.value)} />
                <TextField size="small" label="Port" value={m.port} placeholder={m.mode === 'postgres_fdw' ? '5432' : '1521'} onChange={(e) => set(l.name, 'port', e.target.value)} />
                <TextField size="small" label={m.mode === 'postgres_fdw' ? 'Database' : 'Service name'} value={m.dbname} onChange={(e) => set(l.name, 'dbname', e.target.value)} />
                <TextField size="small" label="Remote schema" value={m.remoteSchema} onChange={(e) => set(l.name, 'remoteSchema', e.target.value)} />
                <TextField size="small" label="User" value={m.user} onChange={(e) => set(l.name, 'user', e.target.value)} />
                <TextField size="small" label="Password" type="password" value={m.password || ''} helperText={m.hasPassword ? 'Saved (leave empty to keep it)' : undefined} onChange={(e) => set(l.name, 'password', e.target.value)} />
                <TextField size="small" label="Local schema for remote tables" value={m.localSchema} onChange={(e) => set(l.name, 'localSchema', e.target.value.toLowerCase())} sx={{ gridColumn: { lg: 'span 2' } }}
                  helperText={<>Converted code uses <span className="mono">{m.localSchema}.table</span> instead of <span className="mono">table@{l.name}</span></>} />
                <Box sx={{ gridColumn: '1 / -1', display: 'flex', alignItems: 'center', gap: 1.5 }}>
                  <Button variant="outlined" onClick={() => test(l.name)} disabled={tests[l.name]?.busy} sx={{ whiteSpace: 'nowrap', flexShrink: 0, minWidth: 140 }}
                    startIcon={tests[l.name]?.busy ? <CircularProgress size={14} /> : undefined}>{tests[l.name]?.busy ? 'Testing…' : 'Save and test'}</Button>
                  <Tooltip title="Creates this link in PostgreSQL now (server, user mapping, local schema with the remote tables and views). No converted package needed.">
                    <span><Button variant="contained" onClick={() => create(l.name)} disabled={busy || tests[l.name]?.busy} sx={{ whiteSpace: 'nowrap', minWidth: 130 }}
                      startIcon={creating === l.name ? <CircularProgress size={14} color="inherit" /> : undefined}>{creating === l.name ? 'Creating…' : status[l.name]?.ok ? 'Create again' : 'Create now'}</Button></span>
                  </Tooltip>
                  {status[l.name] && <Button color="error" onClick={() => setRemove({ link: l.name })} disabled={busy} sx={{ whiteSpace: 'nowrap' }}>Remove</Button>}
                  <Typography variant="caption" color="text.secondary">
                    Host, port and service as the <b>PostgreSQL server</b> reaches them.{m.mode === 'oracle_fdw' ? ' The DBA installs oracle_fdw on the PostgreSQL server and grants its use to DMA\'s user.' : ''}
                  </Typography>
                </Box>
                {tests[l.name]?.text && <Alert severity={tests[l.name]?.ok ? 'success' : 'error'} sx={{ gridColumn: '1 / -1', overflowWrap: 'anywhere' }}>{tests[l.name]?.text}</Alert>}
              </Box>
            )}
          </Box>
        );
      })}
      {msg && <Alert severity={msg.ok ? 'success' : 'error'}>{msg.text}</Alert>}
      <Stack direction="row" spacing={1.5} alignItems="center" useFlexGap flexWrap="wrap">
        <Button variant="outlined" onClick={save} disabled={busy}>Save DB link mapping</Button>
        <Button variant="contained" onClick={() => create()} disabled={busy || !active}
          startIcon={creating === '*' ? <CircularProgress size={14} color="inherit" /> : <LinkRoundedIcon />}>{creating === '*' ? 'Creating…' : `Save and create ${active > 1 ? `all ${active} links` : 'the link'} now`}</Button>
        <Typography variant="caption" color="text.secondary">No converted package needed. Your own views with <span className="mono">table@LINK</span> still come from the converted package.</Typography>
      </Stack>
      <Dialog open={!!remove} onClose={() => !remove?.busy && setRemove(null)} maxWidth="sm" fullWidth>
        <DialogTitle>Remove DB link {remove?.link} from PostgreSQL?</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Drops the schema <span className="mono">{remove ? maps[remove.link]?.localSchema : ''}</span> with its foreign tables, and the foreign server. The saved details stay, so you can create it again.
          </DialogContentText>
          {remove?.dependents && <Alert severity="warning" sx={{ mt: 2 }}>{remove.dependents} Remove them too, or keep the link.</Alert>}
          {remove?.error && <Alert severity="error" sx={{ mt: 2 }}>{remove.error}</Alert>}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setRemove(null)} disabled={remove?.busy}>Keep it</Button>
          {remove?.dependents
            ? <Button color="error" variant="contained" onClick={() => doRemove(true)} disabled={remove?.busy}>Remove with these objects</Button>
            : <Button color="error" variant="contained" onClick={() => doRemove(false)} disabled={remove?.busy}>Remove</Button>}
        </DialogActions>
      </Dialog>
    </Stack>
  );
}

export default function CodePage() {
  const { name, project, subscribe, connectedAt } = useProject();
  const [ov, setOv] = useState<Overview | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [exportJob, setExportJob] = useState<any>(null);
  const [applyJob, setApplyJob] = useState<any>(null);
  const [uploading, setUploading] = useState(false);
  const [uploadMsg, setUploadMsg] = useState<{ ok: boolean; text: string; id?: string } | null>(null);
  const [drag, setDrag] = useState(false);
  const [filesOf, setFilesOf] = useState<string | null>(null);
  const fileInput = useRef<HTMLInputElement>(null);

  const load = useCallback(async () => {
    try {
      const r = await api<Overview>(`${projectPath(name)}/code`);
      setOv(r);
      setExportJob(r.exportJob);
      setApplyJob(r.applyJob);
    } catch (e: any) { setError(e.message); }
  }, [name]);
  useEffect(() => { load(); }, [load, connectedAt]);
  // The zip downloads by itself when an export this page started is finished.
  const autoDownload = useRef<string | null>(null);
  useEffect(() => subscribe((e) => {
    if (e.type === 'codeExport') {
      setExportJob(e.data);
      if (e.data.status !== 'RUNNING') {
        load();
        if (autoDownload.current === e.data.id && e.data.status !== 'FAILED') {
          autoDownload.current = null;
          const a = document.createElement('a');
          a.href = apiUrl(`${projectPath(name)}/code/exports/${e.data.id}/download`);
          a.download = e.data.zipName || '';
          document.body.appendChild(a);
          a.click();
          a.remove();
        }
      }
    }
    if (e.type === 'codeApply') { setApplyJob(e.data); if (e.data.status !== 'RUNNING') load(); }
  }), [subscribe, load]);

  const startExport = async () => {
    setError(null);
    try {
      const job = await api<any>(`${projectPath(name)}/code/exports`, { body: {} });
      autoDownload.current = job.id;
      setExportJob(job);
    } catch (e: any) { setError(e.message); }
  };
  const upload = async (file: File) => {
    setUploading(true);
    setUploadMsg(null);
    try {
      // Sent in pieces of 768 KB: proxies with default upload limits (nginx: 1 MB) need no change.
      const PART = 768 * 1024;
      const id = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
      const parts = Math.max(1, Math.ceil(file.size / PART));
      let data: any = null;
      for (let i = 0; i < parts; i += 1) {
        const last = i === parts - 1;
        const q = `upload=${id}&index=${i}${last ? `&last=1&name=${encodeURIComponent(file.name)}` : ''}`;
        const res = await fetch(apiUrl(`${projectPath(name)}/code/packages/part?${q}`), {
          method: 'POST', headers: { 'Content-Type': 'application/octet-stream' }, body: file.slice(i * PART, (i + 1) * PART), credentials: 'include',
        });
        data = await res.json().catch(() => ({ message: `Upload failed (${res.status})` }));
        if (!res.ok) throw new Error(data.message);
        if (!last) setUploadMsg({ ok: true, text: `Uploading ${file.name}: ${Math.round(((i + 1) / parts) * 100)}%` });
      }
      setUploadMsg({ ok: !data.notice, id: data.id, text: `${file.name}: ${data.files.length} files accepted${data.warnings.length ? `, ${data.warnings.length} ignored` : ''}.${data.notice ? ` ${data.notice}` : ''}` });
      await load();
    } catch (e: any) {
      setUploadMsg({ ok: false, text: e.message });
    } finally {
      setUploading(false);
    }
  };
  const applyNow = async (id: string) => {
    setError(null);
    try { setApplyJob(await api(`${projectPath(name)}/code/packages/${id}/apply`, { body: {} })); } catch (e: any) { setError(e.message); }
  };
  // Deleting a package asks first (it cannot be undone) and shows why when it fails.
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);
  const [deleting, setDeleting] = useState(false);
  const remove = async (id: string) => {
    setDeleting(true);
    setError(null);
    try {
      await api(`${projectPath(name)}/code/packages/${id}`, { method: 'DELETE' });
      setConfirmDelete(null);
      load();
    } catch (e: any) {
      setConfirmDelete(null);
      setError(`The package could not be deleted: ${e.message}`);
    } finally {
      setDeleting(false);
    }
  };

  if (!ov) return error ? <Alert severity="error">{error}</Alert> : <LinearProgress />;
  const counts = new Map(ov.objectCounts.map(([t, n]) => [t, Number(n)]));
  const exporting = exportJob?.status === 'RUNNING';
  const applying = applyJob?.status === 'RUNNING';

  return (
    <>
      <PageHeader overline="Step 5 · optional" title="Code objects & GenAI conversion" icon={<AutoAwesomeRoundedIcon />}
        subtitle={<>Views, PL/SQL, triggers and DB links of <b>{project?.selectedSchema || 'the schema'}</b> are converted outside this tool with your GenAI assistant. Export them as one zip, convert, upload the result, and it is applied after the data load (or now).</>} />
      {error && <Alert severity="error" sx={{ mb: 3 }}>{error}</Alert>}

      <Card sx={{ p: 2.5, mb: 3 }}>
        <Box sx={{ display: 'grid', gap: 1.5, gridTemplateColumns: { xs: 'repeat(3, 1fr)', md: 'repeat(5, 1fr)', xl: 'repeat(9, 1fr)' } }}>
          {CODE_TYPES.map(([t, label]) => (
            <Box key={t} sx={{ p: 1.5, borderRadius: 2.5, bgcolor: counts.get(t) ? '#F5F9FF' : '#FAFBFD', border: `1px solid ${brand.border}` }}>
              <Typography sx={{ fontFamily: headingFont, fontWeight: 800, fontSize: 22, color: counts.get(t) ? brand.ink : 'text.disabled' }}>{counts.get(t) || 0}</Typography>
              <Typography variant="caption" color="text.secondary" noWrap>{label}</Typography>
            </Box>
          ))}
        </Box>
      </Card>

      <Box sx={{ display: 'grid', gap: 3, gridTemplateColumns: { xs: 'minmax(0, 1fr)', lg: 'repeat(3, minmax(0, 1fr))' }, alignItems: 'stretch', mb: 3 }}>
        {/* 1 export */}
        <SectionCard fill title={<Stack direction="row" spacing={1.25} alignItems="center"><StepBadge n={1} /><span>Export for GenAI</span></Stack>}
          subtitle="ora2pg exports every code object, one file per object, as a zip.">
          <Button fullWidth variant="contained" size="large" startIcon={exporting ? <CircularProgress size={18} color="inherit" /> : <FolderZipRoundedIcon />} disabled={exporting || !project?.oracle} onClick={startExport}>
            {exporting ? 'Exporting…' : 'Export & build zip'}
          </Button>
          {exportJob && (
            <Stack spacing={0.75} sx={{ mt: 2 }}>
              {exportJob.steps.map((s: any) => (
                <Stack key={s.folder} direction="row" spacing={1} alignItems="center">
                  {s.status === 'running' ? <CircularProgress size={16} /> : <CheckIcon ok={s.status === 'done'} pending={s.status === 'pending'} />}
                  <Typography variant="body2" sx={{ flex: 1 }}>{s.label}</Typography>
                  <Typography variant="caption" color="text.secondary">{s.status === 'done' ? `${s.objects} objects` : ''}</Typography>
                </Stack>
              ))}
            </Stack>
          )}
          <Typography variant="overline" color="text.secondary" sx={{ display: 'block', mt: 2.5, mb: 1 }}>Exports</Typography>
          {ov.exports.length === 0 && <Typography variant="body2" color="text.secondary">No export yet.</Typography>}
          <Stack spacing={1}>
            {ov.exports.slice(0, 5).map((e) => (
              <Stack key={e.id} direction="row" spacing={1.5} alignItems="center" sx={{ p: 1.25, borderRadius: 2.5, border: `1px solid ${brand.border}` }}>
                <FolderZipRoundedIcon sx={{ color: brand.blue }} />
                <Box sx={{ minWidth: 0, flex: 1 }}>
                  <Typography variant="body2" fontWeight={650} noWrap title={e.zipName} className="mono">{e.zipName}</Typography>
                  <Typography variant="caption" color="text.secondary">{fmtDate(e.createdAt)} · {fmtBytes(e.bytes || 0)} · {e.folders.reduce((s, f) => s + (f.objects || 0), 0)} objects in files (each package routine counted)</Typography>
                </Box>
                <Tooltip title="Download zip"><IconButton component="a" href={apiUrl(`${projectPath(name)}/code/exports/${e.id}/download`)} color="primary"><CloudDownloadRoundedIcon /></IconButton></Tooltip>
              </Stack>
            ))}
          </Stack>
        </SectionCard>

        {/* 2 convert */}
        <SectionCard fill title={<Stack direction="row" spacing={1.25} alignItems="center"><StepBadge n={2} /><span>Convert with GenAI</span></Stack>}
          subtitle="Outside this tool. Keep the folder structure; the zip's CONVERSION_GUIDE.md has the rules.">
          <Box sx={{ p: 2, borderRadius: 3, bgcolor: '#0B1730', color: '#D6E4FF', fontFamily: monoFont, fontSize: 12.5, lineHeight: 1.75 }}>
            <Box component="span" sx={{ color: '#7FB2FF' }}>converted.zip</Box><br />
            {['types/', 'dblinks/   (optional)', 'functions/', 'procedures/', 'packages/', 'views/', 'mviews/', 'triggers/', 'synonyms/', 'grants/'].map((f, i, a) => (
              <span key={f}>{i === a.length - 1 ? '└── ' : '├── '}{f}<Box component="span" sx={{ color: '#7C8BA6' }}>{f.endsWith('/') ? '  *.sql' : ''}</Box><br /></span>
            ))}
          </Box>
          <Stack spacing={1} sx={{ mt: 2 }}>
            {[
              'One object per file is best; file names do not matter.',
              'Order does not matter: files that need another object are retried after it exists.',
              'table@LINK → link_<link>.table (see DB link mapping below).',
              'Each file runs in its own transaction; a failing file never leaves half an object.',
            ].map((t) => (
              <Stack key={t} direction="row" spacing={1} alignItems="flex-start"><PsychologyRoundedIcon fontSize="small" sx={{ color: brand.violet, mt: 0.2 }} /><Typography variant="body2">{t}</Typography></Stack>
            ))}
          </Stack>
        </SectionCard>

        {/* 3 upload */}
        <SectionCard fill title={<Stack direction="row" spacing={1.25} alignItems="center"><StepBadge n={3} /><span>Upload converted zip</span></Stack>}
          subtitle="Apply only the code objects now (no data is touched), or pick the package when you start a migration.">
          <Box onDragOver={(e) => { e.preventDefault(); setDrag(true); }} onDragLeave={() => setDrag(false)}
            onDrop={(e) => { e.preventDefault(); setDrag(false); const f = e.dataTransfer.files[0]; if (f) upload(f); }}
            onClick={() => fileInput.current?.click()}
            sx={{ cursor: 'pointer', p: 3, borderRadius: 3, textAlign: 'center', border: `2px dashed ${drag ? brand.blue : '#C9D4E5'}`, bgcolor: drag ? '#EEF4FE' : '#FAFBFD', transition: 'all .15s' }}>
            {uploading ? <CircularProgress size={28} /> : <CloudUploadRoundedIcon sx={{ fontSize: 34, color: brand.blue }} />}
            <Typography fontWeight={700} sx={{ mt: 1 }}>Drop the zip here or click to choose</Typography>
            <Typography variant="caption" color="text.secondary">.zip with the folders shown in step 2 · up to 500 MB</Typography>
            <input ref={fileInput} type="file" accept=".zip,application/zip" hidden onChange={(e) => { const f = e.target.files?.[0]; if (f) upload(f); e.target.value = ''; }} />
          </Box>
          {uploadMsg && (
            <Alert severity={uploadMsg.ok ? 'success' : 'error'} sx={{ mt: 2 }}>
              {uploadMsg.text}
              {uploadMsg.ok && uploadMsg.id && (
                <Stack direction="row" spacing={1} alignItems="center" flexWrap="wrap" useFlexGap sx={{ mt: 1 }}>
                  <Button size="small" variant="contained" startIcon={<PlayArrowRoundedIcon />} disabled={applying || !project?.postgres} onClick={() => applyNow(uploadMsg.id!)}>
                    Apply to PostgreSQL now
                  </Button>
                  <Typography variant="caption" color="text.secondary">or choose it when you start a migration</Typography>
                </Stack>
              )}
            </Alert>
          )}
          {applying && (
            <Box sx={{ mt: 2 }}>
              <Typography variant="body2" fontWeight={650}>Applying… {applyJob.applied}/{applyJob.total || '?'} files (pass {applyJob.pass})</Typography>
              <LinearProgress variant={applyJob.total ? 'determinate' : 'indeterminate'} value={applyJob.total ? (applyJob.applied / applyJob.total) * 100 : 0} sx={{ mt: 1 }} />
            </Box>
          )}
        </SectionCard>
      </Box>

      <SectionCard collapsible storeKey="code.packages" title="Converted packages" subtitle="Uploaded GenAI results. The latest is offered when a migration starts." summary={`${ov.packages.length} package${ov.packages.length === 1 ? '' : 's'} uploaded`} icon={<FolderZipRoundedIcon />} dense>
        {ov.packages.length === 0 ? (
          <EmptyState icon={<CloudUploadRoundedIcon />} title="No converted package yet" text="Upload the zip from step 3 when your GenAI conversion is ready. You can migrate the data before that and apply the code later." />
        ) : (
          <Table>
            <TableHead><TableRow><TableCell>Package</TableCell><TableCell>Folders</TableCell><TableCell>Last apply</TableCell><TableCell align="right">Actions</TableCell></TableRow></TableHead>
            <TableBody>
              {ov.packages.map((p) => (
                <TableRow key={p.id} hover>
                  <TableCell>
                    <Typography fontWeight={650} className="mono">{p.fileName}</Typography>
                    <Typography variant="caption" color="text.secondary">uploaded {fmtDate(p.uploadedAt)} · {p.fileCount} files{p.warnings.length ? ` · ${p.warnings.length} ignored` : ''}</Typography>
                    {p.notice && <Typography variant="caption" color="warning.main" sx={{ display: 'block', maxWidth: 360 }}>⚠ {p.notice}</Typography>}
                  </TableCell>
                  <TableCell><Stack direction="row" spacing={0.5} flexWrap="wrap" useFlexGap>{p.folders.map((f) => <Chip key={f.folder} size="small" variant="outlined" label={`${f.folder} · ${f.files}`} sx={{ bgcolor: '#fff' }} />)}</Stack></TableCell>
                  <TableCell>
                    {p.lastApply ? (
                      <Stack direction="row" spacing={1} alignItems="center">
                        <CheckIcon ok={!p.lastApply.failed && (!p.lastApply.dbLinks || p.lastApply.dbLinks === 'ok')} warn={!!p.lastApply.failed || (!!p.lastApply.dbLinks && p.lastApply.dbLinks !== 'ok')} />
                        <Box>
                          <Typography variant="body2" fontWeight={600}>{p.lastApply.applied} applied{p.lastApply.existing ? `, ${p.lastApply.existing} already present` : ''}{p.lastApply.failed ? `, ${p.lastApply.failed} failed` : ''}{p.lastApply.dbLinks && p.lastApply.dbLinks !== 'ok' ? ' · DB link failed' : ''}</Typography>
                          <Typography variant="caption" color="text.secondary">{fmtDate(p.lastApply.at)}{p.lastApply.runId ? ` · run ${p.lastApply.runId}` : ''}{p.lastApply.dbLinks === 'ok' ? ' · DB links created' : ''}</Typography>
                          {p.lastApply.dbLinks && p.lastApply.dbLinks !== 'ok' && <Typography variant="caption" color="error.main" sx={{ display: 'block', maxWidth: 420 }}>DB link: {p.lastApply.dbLinks}</Typography>}
                        </Box>
                      </Stack>
                    ) : <Typography variant="body2" color="text.secondary">Not applied yet</Typography>}
                  </TableCell>
                  <TableCell align="right" sx={{ whiteSpace: 'nowrap' }}>
                    <Tooltip title="Files and errors"><IconButton onClick={() => setFilesOf(p.id)}><ListAltRoundedIcon /></IconButton></Tooltip>
                    <Button size="small" variant="outlined" startIcon={<PlayArrowRoundedIcon />} disabled={applying || !project?.postgres} onClick={() => applyNow(p.id)} sx={{ mx: 1 }}>Apply now</Button>
                    <Tooltip title="Delete"><IconButton aria-label={`Delete package ${p.id}`} onClick={() => setConfirmDelete(p.id)}><DeleteOutlineRoundedIcon /></IconButton></Tooltip>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </SectionCard>

      <Box sx={{ mt: 3 }}>
        <SectionCard collapsible storeKey="code.dblinks" summary={`${ov.dbLinks.length} DB link${ov.dbLinks.length === 1 ? '' : 's'} in the schema`} title="DB link mapping" icon={<LinkRoundedIcon />}
          subtitle="PostgreSQL has no DB links. Each Oracle link becomes a foreign server (postgres_fdw or oracle_fdw) with the remote tables and views imported into a local schema. Create them now, with a migration run, or when converted code is applied.">
          <DbLinkMapping key={JSON.stringify(ov.dbLinks)} links={ov.dbLinks} initial={ov.dbLinkMappings} status={ov.dbLinkStatus} onSaved={load} />
        </SectionCard>
      </Box>
      <FilesDialog pkgId={filesOf} onClose={() => { setFilesOf(null); load(); }} />
      <Dialog open={!!confirmDelete} onClose={() => !deleting && setConfirmDelete(null)} maxWidth="xs" fullWidth>
        <DialogTitle>Delete this converted package?</DialogTitle>
        <DialogContent>
          <DialogContentText>Package {confirmDelete} and its files are removed from DMA. This cannot be undone. Objects already applied to PostgreSQL stay there.</DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setConfirmDelete(null)} disabled={deleting}>Keep it</Button>
          <Button color="error" variant="contained" onClick={() => confirmDelete && remove(confirmDelete)} disabled={deleting}>Delete</Button>
        </DialogActions>
      </Dialog>
    </>
  );
}
