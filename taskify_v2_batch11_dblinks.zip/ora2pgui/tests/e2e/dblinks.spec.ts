import { expect, test } from '@playwright/test';
import { P, pageIsFine, watchErrors } from './helpers';

// DMA-079: DB links created on their own, without a converted GenAI package. Against the real API.
// Project E2E_TEST has DB link ACMM_LINK saved as oracle_fdw, and its PostgreSQL has no oracle_fdw:
// so "Create now" really runs and fails in plain words, without changing anything.

test('Code objects: "Create now" runs without a package and explains a failure in plain words', async ({ page }) => {
  const errors = watchErrors(page);
  await page.goto(`${P}/code`);
  test.skip((await page.getByText('No DB links in this schema').count()) > 0, 'no DB link in this schema');
  const createNow = page.getByRole('button', { name: /^(Create now|Create again)$/ }).first();
  test.skip((await createNow.count()) === 0, 'no DB link mapped in this project');
  await expect(page.getByRole('button', { name: /Save and create (the link|all \d+ links) now/ })).toBeEnabled();
  await expect(page.getByText(/No converted package needed/)).toBeVisible();
  await createNow.click();
  await expect(page.getByRole('alert').filter({ hasText: /extension is not installed|Created:|Updated:|Wrong user|cannot reach/ }).first()).toBeVisible({ timeout: 60000 });
  await pageIsFine(page);
  expect(errors).toEqual([]);
});

test('Migrate: the start dialog offers to create the saved DB links with "migrate the data only"', async ({ page }) => {
  const errors = watchErrors(page);
  await page.goto(`${P}/migrate`);
  await page.getByPlaceholder('Search').fill('PLANT');
  await page.getByRole('checkbox', { name: 'Select PLANT', exact: true }).check();
  await page.getByRole('button', { name: /^Start migration \(1\)$/ }).click();
  const dialog = page.getByRole('dialog');
  const links = dialog.getByRole('checkbox', { name: /Create the saved DB links/ });
  test.skip((await links.count()) === 0, 'no DB link mapped in this project');
  await dialog.getByRole('radio', { name: /Not yet: migrate the data only/ }).check();
  await expect(links).toBeChecked();
  await expect(links).toBeEnabled();
  await expect(dialog.getByText(/No converted package needed/)).toBeVisible();
  await links.uncheck();
  await expect(links).not.toBeChecked();
  await page.keyboard.press('Escape'); // nothing is started
  await expect(dialog).toHaveCount(0);
  await pageIsFine(page);
  expect(errors).toEqual([]);
});
