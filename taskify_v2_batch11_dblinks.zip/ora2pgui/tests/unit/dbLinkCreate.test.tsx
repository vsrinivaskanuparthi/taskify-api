import { fireEvent, render, screen, waitFor, within } from '@testing-library/react';
import { beforeEach, describe, expect, test, vi } from 'vitest';
import { ApiError } from '../../src/api';
import { DbLinkMapping, type LinkStatus } from '../../src/pages/CodePage';

// DMA-079: DB links created on their own (no converted package), from the Code objects page.
// The API is replaced: every call is recorded, answers come from `server`.
const server = vi.hoisted(() => ({ calls: [] as { path: string; init: any }[], create: null as any, remove: [] as any[] }));
vi.mock('../../src/context/ProjectContext', () => ({ useProject: () => ({ name: 'P1' }) }));
vi.mock('../../src/api', async (orig) => {
  const real = await orig<typeof import('../../src/api')>();
  return {
    ...real,
    api: vi.fn(async (path: string, init: any = {}) => {
      server.calls.push({ path, init });
      if (path.endsWith('/code/dblinks') && init.method === 'PUT') return { message: 'saved' };
      if (path.endsWith('/code/dblinks/create')) return server.create;
      if (path.includes('/remove')) { const r = server.remove.shift(); if (r instanceof Error) throw r; return r; }
      throw new Error(`unexpected ${path}`);
    }),
  };
});

const LINK = { owner: 'APP', name: 'SALES.CORP', username: 'SALES', host: '//orahost:1521/SALES', usedBy: 2 };
const mapped = { 'SALES.CORP': { mode: 'postgres_fdw' as const, host: 'pg1', port: '5432', dbname: 'sales', remoteSchema: 'public', user: 'reader', localSchema: 'link_sales', hasPassword: true } };
const created: LinkStatus = { ok: true, action: 'created', tables: 4, message: 'Created: 4 remote tables and views in link_sales.', at: '2026-11-24T10:00:00Z' };

beforeEach(() => { server.calls = []; server.remove = []; server.create = { links: [{ name: 'SALES.CORP', ok: true, action: 'created', tables: 4, message: created.message }], ok: true, created: 1, failed: 0 }; });

describe('DB links without a converted package', () => {
  test('"Create now" saves the form first, then creates only this link and shows what happened', async () => {
    const onSaved = vi.fn();
    render(<DbLinkMapping links={[LINK]} initial={mapped} onSaved={onSaved} />);
    fireEvent.click(screen.getByRole('button', { name: 'Create now' }));
    expect(await screen.findByText(created.message)).toBeInTheDocument();
    expect(server.calls.map((c) => c.path)).toEqual(['/projects/P1/code/dblinks', '/projects/P1/code/dblinks/create']);
    expect(server.calls[1].init.body).toEqual({ names: ['SALES.CORP'] });
    expect(onSaved).toHaveBeenCalled();
  });

  test('"Create all" reports a failed link with its reason', async () => {
    server.create = { links: [{ name: 'SALES.CORP', ok: false, action: 'failed', tables: 0, message: 'Wrong user or password.' }], ok: false, created: 0, failed: 1 };
    render(<DbLinkMapping links={[LINK]} initial={mapped} onSaved={() => {}} />);
    fireEvent.click(screen.getByRole('button', { name: /Save and create the link now/ }));
    expect(await screen.findByText(/0 DB link\(s\) created, 1 failed: SALES.CORP: Wrong user or password\./)).toBeInTheDocument();
    expect(server.calls[1].init.body).toEqual({});
  });

  test('nothing to create while every link is "Do not create"', () => {
    render(<DbLinkMapping links={[LINK]} initial={{}} onSaved={() => {}} />);
    expect(screen.getByRole('button', { name: /Save and create the link now/ })).toBeDisabled();
    expect(screen.queryByRole('button', { name: 'Create now' })).not.toBeInTheDocument();
  });

  test('a link already in PostgreSQL shows it, offers "Create again" and Remove', () => {
    render(<DbLinkMapping links={[LINK]} initial={mapped} status={{ 'SALES.CORP': created }} onSaved={() => {}} />);
    expect(screen.getByTestId('link-status-SALES.CORP')).toHaveTextContent('In PostgreSQL: 4 remote tables and views');
    expect(screen.getByRole('button', { name: 'Create again' })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Remove' })).toBeInTheDocument();
  });

  test('a link never created has no Remove button', () => {
    render(<DbLinkMapping links={[LINK]} initial={mapped} onSaved={() => {}} />);
    expect(screen.queryByRole('button', { name: 'Remove' })).not.toBeInTheDocument();
  });

  test('Remove asks again when views use the link, and only then drops them too', async () => {
    server.remove = [new ApiError('2 object(s) use this link and would be dropped with it: app.v1, app.v2.', 409, null, null), { ok: true, message: 'Removed link_sales and its server, and 2 object(s) that used it.' }];
    const onSaved = vi.fn();
    render(<DbLinkMapping links={[LINK]} initial={mapped} status={{ 'SALES.CORP': created }} onSaved={onSaved} />);
    fireEvent.click(screen.getByRole('button', { name: 'Remove' }));
    const dialog = within(await screen.findByRole('dialog'));
    fireEvent.click(dialog.getByRole('button', { name: 'Remove' }));
    expect(await dialog.findByText(/would be dropped with it: app.v1, app.v2/)).toBeInTheDocument();
    expect(server.calls[0].init.body).toEqual({ force: false });
    fireEvent.click(dialog.getByRole('button', { name: 'Remove with these objects' }));
    await waitFor(() => expect(screen.queryByRole('dialog')).not.toBeInTheDocument());
    expect(server.calls[1].init.body).toEqual({ force: true });
    expect(server.calls[1].path).toBe('/projects/P1/code/dblinks/SALES.CORP/remove');
    expect(onSaved).toHaveBeenCalled();
  });

  test('"Keep it" removes nothing', async () => {
    render(<DbLinkMapping links={[LINK]} initial={mapped} status={{ 'SALES.CORP': created }} onSaved={() => {}} />);
    fireEvent.click(screen.getByRole('button', { name: 'Remove' }));
    fireEvent.click(within(await screen.findByRole('dialog')).getByRole('button', { name: 'Keep it' }));
    await waitFor(() => expect(screen.queryByRole('dialog')).not.toBeInTheDocument());
    expect(server.calls).toEqual([]);
  });
});
