# DMA v2: batch 11, DB links without GenAI (DMA-079)

**No `.env` change needed. No new npm package. `server.js` is not changed.**

## What's new

Before, DB links were created **only** while applying a converted GenAI package. With no code to convert, the links could not be created at all.

Now:

| Where | What |
|---|---|
| **Code objects → DB link mapping**, per link | **Create now**: creates this link in PostgreSQL right away: foreign server, user mapping (also for the application roles), schema `link_<name>` with the remote tables and views. No converted package needed |
| Same, per link | A status line: **"In PostgreSQL: N remote tables and views · date"** (or "Last create failed") |
| Same, per link | **Remove**: drops the link from PostgreSQL; the saved details stay. If views or materialized views use the link, DMA lists them and asks again: **"Remove with these objects"** or **"Keep it"** |
| Same, at the bottom | **Save and create all links now** |
| **Migrate → start dialog** | Checkbox **"Create the saved DB links"** (on by default when links are saved). Works with **"Not yet: migrate the data only"**: the links are created after the data load |
| **Live monitor** | A **DB links** card shows each link: created / failed, number of tables |

**Safe by design:**
- Each link is created in its own transaction. A failing link doesn't stop the others and leaves the previous setup as it was.
- **Create again** while your views use the link: nothing is dropped. The address, user and password are updated, and remote tables that are new since last time are added. Your views keep working.
- Changing a used link from postgres_fdw to oracle_fdw (or back) is refused with a clear message, because it would drop the views.

**Still needs the converted package:** your own Oracle views, procedures and so on that contain `table@LINK`. PostgreSQL has no `@LINK`, so that code must be rewritten to `link_<name>.table`.

**Also fixed:**
- postgres_fdw: a wrong password showed as "cannot reach the remote database". Now it says "password authentication failed … Wrong user or password".
- New plain-words message when the remote PostgreSQL lets the user in without a password (trust login): postgres_fdw refuses that for normal users. Use the server's network name instead of `localhost`, or ask the DBA to require a password.
- Windows: the unit test `errorHandling.test.js` looked for the UI in a folder named `frontend`. It now also finds `ora2pgui`.

## Files

| | Files |
|---|---|
| `ora2pgservice/` changed | `services/code.js`, `services/migrate.js`, `controllers/codeController.js`, `controllers/runController.js`, `routes/projectRoutes.js` |
| `ora2pgservice/` tests | new `tests/e2e/dblinkOnly.e2e.test.js`; changed `tests/e2e/dblink.e2e.test.js`, `tests/unit/dbLinks.test.js`, `tests/unit/errorHandling.test.js` |
| `ora2pgui/` changed | `src/pages/CodePage.tsx`, `src/pages/MigratePage.tsx`, `src/pages/RunPage.tsx` |
| `ora2pgui/` tests | new `tests/unit/dbLinkCreate.test.tsx`, `tests/e2e/dblinks.spec.ts` |

## Deploy

1. Copy `ora2pgservice/` and `ora2pgui/` over your folders.
2. In `ora2pgservice`, run `npm test`. It should end with **Tests: 114 passed** (on Windows a few file-permission tests are skipped).
3. In `ora2pgui`, run `npm test` (should end with **52 passed**), then `npm run build`, then copy `index.html` to nginx.
4. On RHEL, **when no migration runs**:
   ```bash
   pm2 restart ora2pg-service-prod
   ```
   ```bash
   pm2 restart ora2pg-worker-prod
   ```
5. Press Ctrl+F5 in the browser.

## Before testing on RHEL (DBA, on the PostgreSQL server)

- The extension is installed in the target database: `CREATE EXTENSION postgres_fdw;` (and/or `oracle_fdw`, which also needs the Oracle Instant Client on the PostgreSQL server).
- DMA's PostgreSQL user may use it: `GRANT USAGE ON FOREIGN DATA WRAPPER postgres_fdw TO <DMA user>;` (same for oracle_fdw).
- The **PostgreSQL server** (not the DMA server) can reach the remote database through the firewall.

## Test on RHEL

- [ ] **Code objects → DB link mapping**: choose postgres_fdw or oracle_fdw for a link, fill in host, port, service/database, remote schema, user, password → **Save and test**: "Connected: N remote tables…".
- [ ] Press **Create now**: "Created: N remote tables and views in link_<name>". The status line shows "In PostgreSQL".
- [ ] **SQL Workbench** (PostgreSQL): `SELECT count(*) FROM link_<name>.<table>;` gives the same count as Oracle.
- [ ] Wrong password → **Create now**: a red message "Wrong user or password", and the link that worked still works.
- [ ] **Migrate**: select a small table → Start migration → choose **"Not yet: migrate the data only"**: the checkbox **"Create the saved DB links"** is ticked → start. On the Live monitor the **DB links** card shows the link as created.
- [ ] **Remove** on a link that a view uses: DMA lists the view and asks again; **Keep it** keeps everything.

## Tested on the Mac (real databases)

| Proof | Result |
|---|---|
| postgres_fdw link to another PostgreSQL database, **Create now** | 4 remote tables and views, same row counts as the remote database |
| Create again while a view uses the link, with a new remote table | View kept, new table added (5 tables) |
| Wrong password | "password authentication failed … Wrong user or password", working link kept |
| Remove while a view uses it | Refused with the view's name; removed together only when confirmed |
| Migration run, "data only", without / with "Create the saved DB links" | Without: no link. With: link created, run COMPLETED |
| oracle_fdw link (remote stays on Oracle), **Create now** after converted views were applied | Views kept, same results as Oracle; Remove lists them |

Tests on the final code:
- API unit **114** passed.
- API e2e full suite **54** passed, 0 failed (3 skipped: they need test setups not used here). Includes the new DB link tests: postgres_fdw 7, oracle_fdw 6.
- UI Vitest **52** passed.
- UI Playwright **28** passed.
