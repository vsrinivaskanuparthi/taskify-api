'use strict';

/**
 * End-to-end: Oracle object tables (CREATE TABLE x OF type_t) and columns of an object type.
 * ora2pg cannot create or copy an object table, so DMA does it itself (as v1 did): a table with one
 * TEXT column per attribute, rows read from Oracle by the engine. A normal table with an object-type
 * column gets a PostgreSQL composite type.
 *
 * Test data (dev-tools/testdb/06_object_tables.sql): SITE_OBJ (object table of ADDRESS_T, 202 rows),
 * CONTACT_OBJ (object table of CONTACT_T with a key, a date, decimals, a nested ADDRESS_T and a
 * VARRAY, 302 rows, including quotes, commas, a backslash, a line break and NULLs); PLANT has an
 * ADDRESS_T column. Migrates into a scratch target schema (DMA_E2E_OBJECTS_SCHEMA, default
 * e2e_objects); the project's settings are put back at the end. Needs DMA_E2E_PG_URL.
 */
const { Client } = require('pg');
const { P, call, apiUp, getSettings, saveSettings, migrate, types, one, loaded } = require('./helpers');

const TARGET = process.env.DMA_E2E_OBJECTS_SCHEMA || 'e2e_objects';
const maybe = process.env.DMA_E2E_PG_URL ? describe : describe.skip;
jest.setTimeout(20 * 60 * 1000);

maybe('Oracle object tables', () => {
  let pg;
  let saved;
  let run;

  beforeAll(async () => {
    await apiUp();
    saved = await getSettings();
    pg = new Client({ connectionString: process.env.DMA_E2E_PG_URL });
    await pg.connect();
  });

  afterAll(async () => {
    if (saved) await saveSettings(saved);
    if (pg) {
      await pg.query(`DROP SCHEMA IF EXISTS "${TARGET}" CASCADE`).catch(() => {});
      await pg.end();
    }
  });

  test('the snapshot lists the object tables with the other tables, so they can be selected', async () => {
    const { data } = await call('GET', `${P}/snapshot`);
    const names = data.tableMetadata.map((t) => t.name);
    expect(names).toEqual(expect.arrayContaining(['SITE_OBJ', 'CONTACT_OBJ']));
    expect(data.objectTables.map((o) => o.tableName || o)).toEqual(expect.arrayContaining(['SITE_OBJ', 'CONTACT_OBJ']));
    expect(data.tableMetadata.find((t) => t.name === 'CONTACT_OBJ')).toMatchObject({ rowCount: 302 });
  });

  test('a run loads both object tables and a table with an object-type column, row counts equal', async () => {
    await saveSettings({ ...saved, targetSchema: TARGET, engine: { ...saved.engine, snapshot: 'off' } });
    run = await migrate(pg, TARGET, ['SITE_OBJ', 'CONTACT_OBJ', 'PLANT']);
    expect(run.status).toBe('COMPLETED');
    for (const t of ['SITE_OBJ', 'CONTACT_OBJ', 'PLANT']) loaded(run, t);
    expect(run.tables.SITE_OBJ).toMatchObject({ kind: 'object', oracleRows: 202 });
    expect(run.tables.CONTACT_OBJ).toMatchObject({ kind: 'object', oracleRows: 302 });
    const said = run.events.map((e) => e.message).join('\n');
    expect(said).toMatch(/TEXT fallback table for Oracle object table SITE_OBJ/);
    expect(said).toMatch(/TEXT fallback table for Oracle object table CONTACT_OBJ/);
  });

  test('an object table becomes one TEXT column per attribute, in the same order', async () => {
    expect(await types(pg, TARGET, 'site_obj')).toEqual({ street: 'text', city: 'text', zip: 'text', country: 'text' });
    expect(Object.keys(await types(pg, TARGET, 'contact_obj'))).toEqual(['contact_id', 'full_name', 'email', 'born', 'credit', 'address', 'phones']);
  });

  test('values arrive exactly: quotes, commas, line break, backslash, NULLs, dates, decimals, nested object, VARRAY', async () => {
    const row = async (id) => (await pg.query(`SELECT * FROM "${TARGET}".contact_obj WHERE contact_id = $1`, [id])).rows[0];
    expect(await row('1')).toMatchObject({
      full_name: 'Contact 1', email: 'c1@example.test', born: '1980-01-02 00:00:00.000', credit: '1.25',
      address: '("Street 1","City 1","00001","FR")',
    });
    expect((await row('1')).phones).toMatch(/\+33 1 000001.*\+33 6 000001/);
    const tricky = await row('9001');
    expect(tricky).toMatchObject({ full_name: 'O\'Brien, "Jr"', email: null, born: '2024-02-29 23:59:58.000', credit: '-0.01' });
    // The nested object is kept as a PostgreSQL composite literal "(street,city,zip,country)".
    expect(tricky.address).toMatch(/^\("Line 1\nLine 2",.*,,"IE"\)$/s);
    expect(tricky.address).toContain('IE');
    expect(await row('9002')).toMatchObject({ full_name: null, born: null, credit: null, address: null, phones: null });

    expect((await pg.query(`SELECT * FROM "${TARGET}".site_obj WHERE country = 'DE'`)).rows).toEqual([{ street: '1, "Quoted" Rd', city: null, zip: null, country: 'DE' }]);
    expect(Number(await one(pg, `SELECT count(*) FROM "${TARGET}".site_obj WHERE street IS NULL AND city IS NULL AND zip IS NULL AND country IS NULL`))).toBe(1);
  });

  test('a column of an object type becomes a composite type whose attributes can be queried', async () => {
    expect(await types(pg, TARGET, 'plant')).toMatchObject({ address: `${TARGET}.address_t` });
    const r = (await pg.query(`SELECT (address).street, (address).city, (address).country FROM "${TARGET}".plant WHERE plant_id = 1`)).rows[0];
    expect(r).toEqual({ street: 'Street 1', city: 'City 1', country: 'FR' });
  });

  test('Validation counts the object tables on both sides', async () => {
    const v = await call('GET', `${P}/validation`);
    expect(v.status).toBe(200);
    for (const [t, n] of [['site_obj', 202], ['contact_obj', 302]]) {
      const row = v.data.rowCountCheck.find((r) => r[1] === t);
      expect(row.slice(2, 5)).toEqual([n, n, 'yes']);
    }
  });
});
