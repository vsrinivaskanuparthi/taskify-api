# DMA v2: batch 12, object tables (DMA-080)

**No `.env` change needed. No new npm package. `server.js` is not changed. No screen changed.**

## What was wrong

Oracle **object tables** are tables built on a type (`CREATE TABLE contacts OF contact_t`).

v1 migrated them. v2 has the same loading code, but it read the table list from Oracle's `dba_tables` view, and that view **leaves object tables out**. So in v2:
- they were not shown on **Migrate**, so nobody could select them;
- the API refused them ("Unknown tables");
- **Validation** did not count them.

They were silently left behind.

## What is fixed

The table list now comes from `dba_all_tables`, which has the normal tables **and** the object tables. Nothing else changed: the same tables as before stay out (recycle bin, temporary tables, materialized view logs and storage tables).

Now:

| Where | What |
|---|---|
| **Migrate** | Object tables are listed with a purple **"Object table"** label and can be selected |
| Migration run | As in v1: DMA creates the table in PostgreSQL with one `TEXT` column per attribute, reads the rows from Oracle itself and loads them. Row counts are verified |
| Nested object or collection inside an object table | Kept as text: an object as `("street","city",…)`, a VARRAY as a list |
| Normal table with a column of an object type (e.g. `ADDRESS_T`) | Unchanged: becomes a PostgreSQL composite type, `(address).street` can be queried |
| **Validation** | Row counts of object tables on both sides |

**Important:** press **Refresh snapshot** once on each project after the deploy. The table list is read when the snapshot is taken.

## Files

| | Files |
|---|---|
| `ora2pgservice/` changed | `queries/oracle/getTableMetadata.js` |
| `ora2pgservice/` tests | new `tests/unit/objectTables.test.js`, `tests/e2e/objectTables.e2e.test.js` |
| `ora2pgui/` tests | new `tests/e2e/objectTables.spec.ts` (no screen code changed) |

## Deploy

0. Batch 11 (DB links) is deployed first. This batch builds on it.
1. Copy `ora2pgservice/` and `ora2pgui/` over your folders.
2. In `ora2pgservice`, run `npm test`. It should end with **Tests: 116 passed**.
3. No UI build needed (only a test file was added to `ora2pgui`).
4. On RHEL, **when no migration runs**:
   ```bash
   pm2 restart ora2pg-service-prod
   ```
5. On every project: **Schema & snapshot → Refresh snapshot**.

## Test on RHEL

- [ ] Ask the DBA (or check in SQL Workbench, Oracle side) whether the schema has object tables: `SELECT table_name FROM all_object_tables WHERE owner = '<SCHEMA>';`
- [ ] **Refresh snapshot**. On **Migrate**, search the table name: it shows **"Object table"**.
- [ ] Migrate it (with a small normal table). The Live monitor shows "Created TEXT fallback table for Oracle object table …" and the table **done**, same row count.
- [ ] **SQL Workbench** (PostgreSQL): `SELECT * FROM <schema>.<table> LIMIT 10;` shows the values.
- [ ] **Validation**: the table is in the row counts with "yes".

## Tested on the Mac (real databases)

Test data: two object tables in the test Oracle (one with a key, a date, decimals, a nested object and a VARRAY; values with quotes, commas, a backslash, a line break and NULLs) and a normal table with an object-type column.

| Proof | Result |
|---|---|
| Before the fix | Object tables missing from Migrate; a run with them was refused ("Unknown tables") |
| After the fix, snapshot | 18 tables instead of 16; both object tables listed and marked "Object table" |
| Migration run | Both object tables done, 202 and 302 rows, same as Oracle; quotes, commas, line break, backslash, NULLs, dates and decimals exact |
| Table with an object-type column | Composite type, `(address).street` gives the Oracle value |
| Validation | Object tables counted on both sides: equal |

Tests on the final code:
- API unit **116** passed (114 + 2 new).
- API e2e full suite **60** passed, 0 failed (3 skipped: they need test setups not used here). Includes the 6 new object table tests and the DB link tests.
- UI Vitest **52** passed.
- UI Playwright **29** passed (28 + 1 new).
