import { expect, test } from '@playwright/test';
import { P, pageIsFine, watchErrors } from './helpers';

// Oracle object tables (CREATE TABLE x OF type_t) appear on Migrate like any table, marked "Object table",
// and can be selected. Against the real API; test data: dev-tools/testdb/06_object_tables.sql.

test('Migrate: object tables are listed, marked "Object table", and can be selected', async ({ page }) => {
  const errors = watchErrors(page);
  await page.goto(`${P}/migrate`);
  await page.getByPlaceholder('Search').fill('_OBJ');
  test.skip((await page.getByRole('checkbox', { name: 'Select CONTACT_OBJ', exact: true }).count()) === 0, 'no object tables in this schema');
  for (const name of ['CONTACT_OBJ', 'SITE_OBJ']) {
    const row = page.getByRole('row').filter({ hasText: name });
    await expect(row.getByText('Object table')).toBeVisible();
  }
  await page.getByRole('checkbox', { name: 'Select CONTACT_OBJ', exact: true }).check();
  await expect(page.getByRole('button', { name: /^Start migration \(1\)$/ })).toBeVisible();
  await pageIsFine(page);
  expect(errors).toEqual([]);
});
