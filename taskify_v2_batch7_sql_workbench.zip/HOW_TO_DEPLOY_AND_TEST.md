# DMA v2: batch 7, SQL Workbench

Deploy **batch 6 (BA fixes) first**, then this batch.

## What's new

A new page in every project: **SQL Workbench** (project menu, under Validation).

- **PostgreSQL:** any query on the migrated schema.
  - Everyone: read-only (PostgreSQL itself blocks changes).
  - Admins: ALTER / INSERT / UPDATE / DELETE work after a **"Run and commit"** confirmation.
  - A script runs as one transaction: if one statement fails, nothing is kept.
- **Oracle:** SELECT only, on the migrated schema. Nothing is ever changed in Oracle.
- **Results:** a table with sorting, search, column types, and CSV / Excel export.
- **Safety:**
  - shows at most 100 / 500 / 1000 rows (the rest is not read);
  - time limit of 30 s / 1 min / 5 min.
- **Editor:**
  - SQL colours and auto-complete of table and column names;
  - Ctrl+Enter runs the query (or only the selected text);
  - your text is remembered.
- **Errors:** the message, the statement, and where in the statement it failed.
- **History:** every query is kept per project (who, when, result).
  - Admins see everyone's queries, users see their own.
  - The file is `sql_history.jsonl` in the project folder.

## Files

| | Files |
|---|---|
| `ora2pgservice/` | `services/sqlWorkbench.js` (new), `routes/projectRoutes.js`, `tests/unit/sqlWorkbench.test.js` (new), `tests/e2e/sql.e2e.test.js` (new) |
| `ora2pgui/` | `src/pages/SqlPage.tsx` (new), `src/App.tsx`, `src/components/ProjectLayout.tsx`, `package.json`, `package-lock.json` |

No `.env` change. `server.js` is not changed.

## Deploy

1. Copy `ora2pgservice/` and `ora2pgui/` over your folders.
2. In `ora2pgui`, **install the 2 new packages once**:
   ```
   npm install
   ```
   This installs the packages listed in the new `package.json`:
   - `@uiw/react-codemirror` 4.25.12 (the editor)
   - `@codemirror/lang-sql` 6.10.0 (SQL colours and auto-complete)

   If you keep your own `package.json`, run this instead:
   ```
   npm install @uiw/react-codemirror@4.25.12 @codemirror/lang-sql@6.10.0
   ```
3. In `ora2pgui`: `npm run build`.
4. In `ora2pgservice`: `npm test`. It should end with **Tests: 76 passed**.
5. On RHEL:
   - `git pull`
   - `pm2 restart ora2pg-service-prod` (the worker doesn't need a restart for this batch)
   - copy `index.html` to nginx as usual, then press Ctrl+F5.

## Test

- [ ] Open a project → **SQL Workbench**. Click a table on the left: its first 100 rows show.
- [ ] As a normal user, run `UPDATE …`: it's refused ("read-only").
- [ ] As an admin, run `UPDATE …`: a confirmation appears; after "Run and commit" the result shows "UPDATE n".
- [ ] Switch to **Oracle**: a SELECT works; a DELETE is refused.
- [ ] Wrong column name: a red message shows the statement and where it failed.
- [ ] History icon: your queries are listed; click one to load it again.
