'use strict';

const fs = require('fs');
const fsp = require('fs').promises;
const path = require('path');
const oracledb = require('oracledb');
const pgTypes = require('pg').types;
const store = require('./projectStore');
const settingsSvc = require('./settings');
const { ensurePostgresPool, getPostgresConnection } = require('../utils/postgreClient');
const { ensureOraclePool, getOracleConnection } = require('../utils/oracleClient');
const logger = require('../utils/logger');

/**
 * SQL Workbench: queries typed by a user on the project's own connections.
 *   PostgreSQL  every query runs in a READ ONLY transaction (PostgreSQL itself refuses changes).
 *               A statement that changes something is answered with needsWrite; an admin confirms
 *               and it runs again in a normal transaction that is committed. Normal users stay read-only.
 *   Oracle      the migration's source (production): SELECT / WITH only, in a READ ONLY transaction.
 * Rows come back as a table (at most maxRows, the rest is not read), with a time limit, and every
 * query is written to the project's SQL history (who, when, what, result).
 */
const MAX_ROWS = 1000;
const MAX_CELL = 4000; // characters of one value sent to the browser
const HISTORY = (projectName) => path.join(store.projectDir(projectName), 'sql_history.jsonl');

/**
 * Splits a script into statements at the semicolons outside quotes, quoted names, dollar quotes
 * ($$ … $$, $tag$ … $tag$) and comments. Empty statements are dropped.
 */
function splitStatements(sql) {
  const out = [];
  let cur = '';
  let i = 0;
  const s = String(sql || '');
  while (i < s.length) {
    const ch = s[i];
    const two = s.slice(i, i + 2);
    if (two === '--') { const end = s.indexOf('\n', i); const j = end === -1 ? s.length : end; cur += s.slice(i, j); i = j; continue; }
    if (two === '/*') { const end = s.indexOf('*/', i + 2); const j = end === -1 ? s.length : end + 2; cur += s.slice(i, j); i = j; continue; }
    if (ch === "'" || ch === '"') {
      let j = i + 1;
      while (j < s.length) { if (s[j] === ch) { if (s[j + 1] === ch) { j += 2; continue; } break; } j += 1; }
      cur += s.slice(i, j + 1); i = j + 1; continue;
    }
    if (ch === '$') {
      const m = /^\$[A-Za-z_]*\$/.exec(s.slice(i));
      if (m) { const end = s.indexOf(m[0], i + m[0].length); const j = end === -1 ? s.length : end + m[0].length; cur += s.slice(i, j); i = j; continue; }
    }
    if (ch === ';') { out.push(cur); cur = ''; i += 1; continue; }
    cur += ch; i += 1;
  }
  out.push(cur);
  return out.map((x) => x.trim()).filter((x) => x && stripComments(x));
}

function stripComments(sql) {
  return String(sql).replace(/--[^\n]*/g, ' ').replace(/\/\*[\s\S]*?\*\//g, ' ').trim();
}

/** First keyword of a statement, upper case (comments skipped): SELECT, WITH, INSERT … */
function firstWord(sql) {
  const m = /^\(*\s*([A-Za-z]+)/.exec(stripComments(sql));
  return m ? m[1].toUpperCase() : '';
}

/** A value as the browser shows it: text, numbers as text, binary as a size, long text shortened. */
function cell(v) {
  if (v === null || v === undefined) return null;
  if (Buffer.isBuffer(v)) return `<binary, ${v.length.toLocaleString()} bytes>`;
  if (v instanceof Date) {
    const p = (n, l = 2) => String(n).padStart(l, '0');
    return `${v.getFullYear()}-${p(v.getMonth() + 1)}-${p(v.getDate())} ${p(v.getHours())}:${p(v.getMinutes())}:${p(v.getSeconds())}`;
  }
  let s = typeof v === 'object' ? JSON.stringify(v) : String(v);
  if (s.length > MAX_CELL) s = `${s.slice(0, MAX_CELL)}… (${s.length.toLocaleString()} characters)`;
  return s;
}

// PostgreSQL dates and times as the database prints them (no time zone shifts in the browser).
const RAW = new Set([1082, 1083, 1114, 1184, 1266]);
const pgTypeParser = { getTypeParser: (oid, format) => (RAW.has(oid) ? (v) => v : pgTypes.getTypeParser(oid, format)) };

/** Statement → result set: { statement, command, rowCount, fields, rows, more }. */
async function runPgStatement(client, statement, maxRows, n) {
  const word = firstWord(statement);
  if (['SELECT', 'WITH', 'VALUES', 'TABLE'].includes(word)) {
    // A cursor reads only the rows shown, however big the result is.
    await client.query('SAVEPOINT dma_ws');
    const prefix = `DECLARE dma_ws_${n} NO SCROLL CURSOR FOR `;
    try {
      await client.query(prefix + statement);
      const r = await client.query({ text: `FETCH ${maxRows + 1} FROM dma_ws_${n}`, rowMode: 'array', types: pgTypeParser });
      await client.query(`CLOSE dma_ws_${n}`);
      await client.query('RELEASE SAVEPOINT dma_ws');
      return { command: 'SELECT', fields: r.fields, rows: r.rows.slice(0, maxRows), more: r.rows.length > maxRows, rowCount: Math.min(r.rows.length, maxRows) };
    } catch (err) {
      await client.query('ROLLBACK TO SAVEPOINT dma_ws');
      // Data-changing WITH, SELECT … INTO: not allowed in a cursor, run as it is below.
      if (!/cannot be used in|DECLARE CURSOR|INTO/i.test(err.message)) {
        if (err.position) err.position = String(Math.max(1, Number(err.position) - prefix.length)); // position in the user's text
        throw err;
      }
    }
  }
  const r = await client.query({ text: statement, rowMode: 'array', types: pgTypeParser });
  const res = Array.isArray(r) ? r[r.length - 1] : r;
  const fields = res.fields || [];
  const rows = res.rows || [];
  return { command: res.command || word, fields, rows: rows.slice(0, maxRows), more: rows.length > maxRows, rowCount: res.rowCount ?? rows.length };
}

async function pgTypeNames(client, fields) {
  const ids = [...new Set(fields.map((f) => f.dataTypeID))];
  if (!ids.length) return new Map();
  const { rows } = await client.query('SELECT oid, format_type(oid, NULL) AS name FROM pg_type WHERE oid = ANY($1)', [ids]);
  return new Map(rows.map((r) => [r.oid, r.name]));
}

async function runPostgres(project, projectName, { sql, allowWrite, maxRows, timeoutSec }) {
  const statements = splitStatements(sql);
  if (!statements.length) throw Object.assign(new Error('Nothing to run.'), { status: 400 });
  const settings = settingsSvc.resolve(project);
  const schema = settings.targetSchema || String(project.selectedSchema || '').toLowerCase() || 'public';
  await ensurePostgresPool(store.postgresCredentials(project), projectName);
  const client = await getPostgresConnection(projectName);
  const results = [];
  try {
    await client.query(allowWrite ? 'BEGIN' : 'BEGIN READ ONLY');
    await client.query(`SET LOCAL statement_timeout = ${Math.round(timeoutSec * 1000)}`);
    await client.query(`SET LOCAL search_path = "${schema.replace(/"/g, '""')}", public`);
    for (const [n, statement] of statements.entries()) {
      const t0 = Date.now();
      const r = await runPgStatement(client, statement, maxRows, n);
      const types = await pgTypeNames(client, r.fields);
      results.push({
        statement, command: r.command, rowCount: r.rowCount, more: r.more, ms: Date.now() - t0,
        columns: r.fields.map((f) => ({ name: f.name, type: types.get(f.dataTypeID) || '' })),
        rows: r.rows.map((row) => row.map(cell)),
      });
    }
    await client.query(allowWrite ? 'COMMIT' : 'ROLLBACK');
    return { schema, results };
  } catch (err) {
    await client.query('ROLLBACK').catch(() => {});
    // 25006: a change inside the read-only transaction.
    if (err.code === '25006') return { schema, needsWrite: true, statement: statements[results.length], message: err.message };
    throw Object.assign(err, { statement: statements[results.length], done: results.length, status: 400 });
  } finally {
    // The session settings went with the transaction; the connection goes back to the pool.
    client.release();
  }
}

async function runOracle(project, projectName, { sql, maxRows, timeoutSec }) {
  const statements = splitStatements(String(sql).replace(/^\s*\/\s*$/gm, ''));
  if (!statements.length) throw Object.assign(new Error('Nothing to run.'), { status: 400 });
  const bad = statements.find((s) => !['SELECT', 'WITH'].includes(firstWord(s)));
  if (bad) throw Object.assign(new Error('Oracle is the source of the migration: only SELECT queries run here. Changes are made in PostgreSQL.'), { status: 400, statement: bad });
  await ensureOraclePool(store.oracleCredentials(project), projectName);
  const conn = await getOracleConnection(projectName);
  const results = [];
  let sessionUser = null;
  try {
    conn.callTimeout = Math.round(timeoutSec * 1000);
    // Names without a schema are the migrated schema's (as in PostgreSQL), not the login user's.
    sessionUser = (await conn.execute("SELECT SYS_CONTEXT('USERENV', 'SESSION_USER') FROM dual")).rows[0][0];
    await conn.execute(`ALTER SESSION SET CURRENT_SCHEMA = "${String(project.selectedSchema).replace(/"/g, '')}"`);
    await conn.execute('SET TRANSACTION READ ONLY');
    for (const statement of statements) {
      const t0 = Date.now();
      const r = await conn.execute(statement, [], {
        maxRows: maxRows + 1,
        outFormat: oracledb.OUT_FORMAT_ARRAY,
        // Text and binary LOBs as values (not LOB objects), so they can be shown.
        fetchTypeHandler: (meta) => (meta.dbType === oracledb.DB_TYPE_CLOB || meta.dbType === oracledb.DB_TYPE_NCLOB ? { type: oracledb.STRING }
          : meta.dbType === oracledb.DB_TYPE_BLOB ? { type: oracledb.BUFFER } : undefined),
      });
      const rows = r.rows || [];
      results.push({
        statement, command: 'SELECT', rowCount: Math.min(rows.length, maxRows), more: rows.length > maxRows, ms: Date.now() - t0,
        columns: (r.metaData || []).map((m) => ({ name: m.name, type: m.dbTypeName || '' })),
        rows: rows.slice(0, maxRows).map((row) => row.map(cell)),
      });
    }
    return { schema: project.selectedSchema, results };
  } catch (err) {
    throw Object.assign(err, { statement: statements[results.length], done: results.length, status: 400 });
  } finally {
    await conn.rollback().catch(() => {});
    conn.callTimeout = 0;
    // The pooled connection goes back as it was.
    if (sessionUser) await conn.execute(`ALTER SESSION SET CURRENT_SCHEMA = "${String(sessionUser).replace(/"/g, '')}"`).catch(() => {});
    await conn.close().catch(() => {});
  }
}

/**
 * Runs the SQL. user: { id } or null; admin: may change data in PostgreSQL after confirming.
 * Returns { schema, results } or { needsWrite, statement, message }.
 */
async function run(projectName, project, { target, sql, allowWrite = false, maxRows = MAX_ROWS, timeoutSec = 60 }, { user, admin }) {
  const rows = Math.max(1, Math.min(MAX_ROWS, Number(maxRows) || MAX_ROWS));
  const timeout = Math.max(5, Math.min(600, Number(timeoutSec) || 60));
  if (String(sql || '').length > 200000) throw Object.assign(new Error('The SQL is too long (200,000 characters at most).'), { status: 400 });
  if (allowWrite && !admin) throw Object.assign(new Error('Only DMA administrators can change data here. Your queries run read-only.'), { status: 403 });
  const t0 = Date.now();
  let out;
  let error = null;
  try {
    out = target === 'oracle'
      ? await runOracle(project, projectName, { sql, maxRows: rows, timeoutSec: timeout })
      : await runPostgres(project, projectName, { sql, allowWrite: !!allowWrite, maxRows: rows, timeoutSec: timeout });
    if (out.needsWrite && !admin) {
      out = { ...out, message: `${out.message}. Only DMA administrators can change data here; your queries run read-only.` };
    }
    return { ...out, admin: !!admin, ms: Date.now() - t0 };
  } catch (err) {
    error = err.message;
    throw err;
  } finally {
    await record(projectName, {
      at: new Date().toISOString(), user: user ? user.id : null, target: target === 'oracle' ? 'oracle' : 'postgres',
      sql: String(sql || '').slice(0, 20000), write: !!allowWrite, ms: Date.now() - t0,
      result: error ? null : out && out.needsWrite ? 'needs confirmation' : out ? out.results.map((r) => `${r.command} ${r.rowCount}`).join(', ') : null,
      error,
    });
  }
}

async function record(projectName, entry) {
  try {
    await fsp.appendFile(HISTORY(projectName), `${JSON.stringify(entry)}\n`, { mode: 0o600 });
  } catch (err) {
    logger.error(`SQL history: ${err.message}`);
  }
  if (entry.write) logger.info(`SQL Workbench change on ${projectName} by ${entry.user || 'local user'}: ${entry.sql.slice(0, 300)}`);
}

/** The newest queries of this project: everyone's for an admin, one's own otherwise. */
async function history(projectName, { user, admin, limit = 100 }) {
  const file = HISTORY(projectName);
  if (!fs.existsSync(file)) return [];
  const lines = (await fsp.readFile(file, 'utf8')).trim().split('\n').filter(Boolean);
  const items = [];
  for (let i = lines.length - 1; i >= 0 && items.length < limit; i -= 1) {
    try {
      const e = JSON.parse(lines[i]);
      if (admin || !user || e.user === user.id) items.push(e);
    } catch { /* a broken line is skipped */ }
  }
  return items;
}

/** Tables and their columns, for the side list and the editor's completion. */
async function objects(projectName, project, target) {
  if (target === 'oracle') {
    await ensureOraclePool(store.oracleCredentials(project), projectName);
    const conn = await getOracleConnection(projectName);
    try {
      const r = await conn.execute(
        `SELECT table_name, column_name FROM all_tab_columns WHERE owner = :o AND table_name NOT LIKE 'BIN$%' AND table_name NOT LIKE 'DR$%' AND table_name NOT LIKE 'MLOG$%' AND table_name NOT LIKE 'RUPD$%' ORDER BY table_name, column_id`,
        { o: project.selectedSchema }, { maxRows: 50000 });
      return { schema: project.selectedSchema, tables: group(r.rows) };
    } finally {
      await conn.close().catch(() => {});
    }
  }
  const settings = settingsSvc.resolve(project);
  const schema = settings.targetSchema || String(project.selectedSchema || '').toLowerCase() || 'public';
  await ensurePostgresPool(store.postgresCredentials(project), projectName);
  const client = await getPostgresConnection(projectName);
  try {
    const { rows } = await client.query(
      `SELECT c.relname, a.attname FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
         JOIN pg_attribute a ON a.attrelid = c.oid AND a.attnum > 0 AND NOT a.attisdropped
        WHERE n.nspname = $1 AND c.relkind IN ('r', 'p', 'v', 'm', 'f') AND NOT c.relispartition
        ORDER BY c.relname, a.attnum LIMIT 50000`, [schema]);
    return { schema, tables: group(rows.map((r) => [r.relname, r.attname])) };
  } finally {
    client.release();
  }
}

function group(rows) {
  const t = {};
  for (const [table, column] of rows) (t[table] = t[table] || []).push(column);
  return t;
}

module.exports = { run, history, objects, splitStatements, firstWord, cell, MAX_ROWS };
