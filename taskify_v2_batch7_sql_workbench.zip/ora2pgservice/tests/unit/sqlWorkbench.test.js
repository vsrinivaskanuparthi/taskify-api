'use strict';

// SQL Workbench helpers: splitting a script into statements, the first keyword, and how values are shown.
const { splitStatements, firstWord, cell } = require('../../services/sqlWorkbench');

test('a script is split at semicolons outside quotes, quoted names, dollar quotes and comments', () => {
  const sql = `select 'a;b' as "x;y"; -- note; here
    insert into t values (1); /* a; b */
    create function f() returns int as $$ begin return 1; end; $$ language plpgsql;
    select $tag$ ; $tag$;;`;
  expect(splitStatements(sql)).toEqual([
    `select 'a;b' as "x;y"`,
    '-- note; here\n    insert into t values (1)',
    '/* a; b */\n    create function f() returns int as $$ begin return 1; end; $$ language plpgsql',
    'select $tag$ ; $tag$',
  ]);
  expect(splitStatements('  ;; -- only a comment\n')).toEqual([]);
  expect(splitStatements("select 'it''s; fine'")).toEqual(["select 'it''s; fine'"]);
});

test('the first keyword decides what a statement is (comments and brackets skipped)', () => {
  expect(firstWord('  -- hi\n /* x */ with a as (select 1) select * from a')).toBe('WITH');
  expect(firstWord('(select 1) union (select 2)')).toBe('SELECT');
  expect(firstWord('delete from t')).toBe('DELETE');
  expect(firstWord('')).toBe('');
});

test('values are shown as text: NULL kept, binary as a size, long text shortened, dates without time zone shift', () => {
  expect(cell(null)).toBeNull();
  expect(cell(Buffer.alloc(16000))).toBe('<binary, 16,000 bytes>');
  expect(cell('x'.repeat(5000))).toMatch(/^x{4000}… \(5,000 characters\)$/);
  expect(cell(new Date(2024, 0, 2, 3, 4, 5))).toBe('2024-01-02 03:04:05');
  expect(cell({ a: 1 })).toBe('{"a":1}');
  expect(cell(42)).toBe('42');
});
