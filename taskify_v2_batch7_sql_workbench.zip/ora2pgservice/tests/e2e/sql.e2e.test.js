'use strict';

/**
 * End-to-end: SQL Workbench on the project's real databases. PostgreSQL is read-only until a change
 * is confirmed; a confirmed script is one transaction; Oracle answers SELECT only; every query is in
 * the history. Uses a scratch table in the project's target schema, dropped at the end.
 * Needs DMA_E2E_PG_URL (skipped without it). dev-tools/run-e2e.sh sets everything.
 */
const API = process.env.DMA_E2E_URL || 'http://localhost:5055';
const PROJECT = process.env.DMA_E2E_PROJECT || 'E2E_TEST';
const P = `${API}/api/projects/${PROJECT}`;
const maybe = process.env.DMA_E2E_PG_URL ? describe : describe.skip;

jest.setTimeout(120000);

async function sql(body) {
  const res = await fetch(`${P}/sql`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
  return { status: res.status, data: await res.json() };
}

maybe('SQL Workbench', () => {
  afterAll(async () => {
    await sql({ target: 'postgres', sql: 'DROP TABLE IF EXISTS dma_ws_e2e', allowWrite: true });
  });

  test('PostgreSQL: a change is refused until confirmed, then committed as one transaction', async () => {
    await sql({ target: 'postgres', sql: 'DROP TABLE IF EXISTS dma_ws_e2e', allowWrite: true });
    const ask = await sql({ target: 'postgres', sql: 'CREATE TABLE dma_ws_e2e (id int, txt text)' });
    expect(ask.status).toBe(200);
    expect(ask.data).toMatchObject({ needsWrite: true });

    const done = await sql({ target: 'postgres', sql: "CREATE TABLE dma_ws_e2e (id int, txt text); INSERT INTO dma_ws_e2e SELECT g, 'row ' || g FROM generate_series(1, 2500) g", allowWrite: true });
    expect(done.status).toBe(200);
    expect(done.data.results.map((r) => r.command)).toEqual(['CREATE', 'INSERT']);
    expect(done.data.results[1].rowCount).toBe(2500);

    // A failing script keeps nothing: the insert before the error is rolled back.
    const bad = await sql({ target: 'postgres', sql: 'INSERT INTO dma_ws_e2e VALUES (9999, NULL); SELECT nope FROM dma_ws_e2e', allowWrite: true });
    expect(bad.status).toBe(400);
    expect(bad.data).toMatchObject({ done: 1, statement: 'SELECT nope FROM dma_ws_e2e' });
    expect(Number(bad.data.position)).toBe(8);
    const count = await sql({ target: 'postgres', sql: 'SELECT count(*) FROM dma_ws_e2e' });
    expect(count.data.results[0].rows).toEqual([['2500']]);
  });

  test('PostgreSQL: only the rows asked for are read, the rest is reported as more', async () => {
    const r = await sql({ target: 'postgres', sql: 'SELECT * FROM dma_ws_e2e ORDER BY id', maxRows: 100 });
    expect(r.data.results[0]).toMatchObject({ command: 'SELECT', rowCount: 100, more: true });
    expect(r.data.results[0].columns).toEqual([{ name: 'id', type: 'integer' }, { name: 'txt', type: 'text' }]);
    expect(r.data.results[0].rows[0]).toEqual(['1', 'row 1']);
  });

  test('PostgreSQL: a query longer than the time limit is stopped', async () => {
    const r = await sql({ target: 'postgres', sql: 'SELECT pg_sleep(8)', timeoutSec: 5 });
    expect(r.status).toBe(400);
    expect(r.data.message).toMatch(/statement timeout/);
  });

  test('Oracle: SELECT in the migrated schema works, anything else is refused', async () => {
    const ok = await sql({ target: 'oracle', sql: 'SELECT COUNT(*) AS n FROM plant;' });
    expect(ok.status).toBe(200);
    expect(Number(ok.data.results[0].rows[0][0])).toBeGreaterThan(0);
    const no = await sql({ target: 'oracle', sql: 'DELETE FROM plant' });
    expect(no.status).toBe(400);
    expect(no.data.message).toMatch(/only SELECT/);
  });

  test('every query is in the history, changes marked', async () => {
    const res = await fetch(`${P}/sql/history`);
    const { items } = await res.json();
    expect(items.length).toBeGreaterThan(5);
    expect(items.some((i) => i.write && /INSERT INTO dma_ws_e2e SELECT/.test(i.sql) && i.result === 'CREATE 0, INSERT 2500')).toBe(true);
    expect(items.some((i) => i.target === 'oracle' && /only SELECT/.test(i.error || ''))).toBe(true);
  });
});
