import react from '@vitejs/plugin-react-swc';
import { defineConfig } from 'vitest/config';

// Screen tests: logic and components in a simulated browser (jsdom). Browser flows: tests/e2e (Playwright).
export default defineConfig({
  plugins: [react()],
  test: {
    environment: 'jsdom',
    include: ['tests/unit/**/*.test.{ts,tsx}'],
    setupFiles: ['tests/unit/setup.ts'],
    css: false,
  },
});
