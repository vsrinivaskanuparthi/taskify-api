import { expect, test } from '@playwright/test';
import { P, pageIsFine, watchErrors } from './helpers';

// Every page opens without errors, with the heading a user expects.
const PAGES: [string, RegExp][] = [
  ['/', /Database Migration Accelerator/],
  ['/projects', /Migration projects/],
  ['/guide', /Guide/],
  [`${P}/connect`, /Connections/],
  [`${P}/schema`, /Schema & snapshot/],
  [`${P}/assessment`, /Assessment/],
  [`${P}/settings`, /Settings/],
  [`${P}/code`, /Code objects & GenAI conversion/],
  [`${P}/migrate`, /Migrate /],
  [`${P}/runs`, /Live monitor & history/],
  [`${P}/validation`, /Validation/],
  [`${P}/sql`, /SQL Workbench/],
  [`${P}/analysis`, /Detailed report/],
];

for (const [path, heading] of PAGES) {
  test(`page ${path} opens without errors`, async ({ page }) => {
    const errors = watchErrors(page);
    await page.goto(path);
    await expect(page.getByRole('heading', { name: heading }).first()).toBeVisible();
    await page.waitForLoadState('networkidle');
    await pageIsFine(page);
    expect(errors).toEqual([]);
  });
}

test('an unknown page goes back to Home; an unknown project says so', async ({ page }) => {
  await page.goto('/no/such/page');
  await expect(page).toHaveURL(/\/$/);
  await page.goto('/projects/NO_SUCH_PROJECT_X/assessment');
  await expect(page.getByText('Project NO_SUCH_PROJECT_X not found.')).toBeVisible();
});
