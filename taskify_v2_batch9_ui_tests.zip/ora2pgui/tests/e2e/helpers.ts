import { expect, Page } from '@playwright/test';

export const PROJECT = process.env.DMA_E2E_PROJECT || 'E2E_TEST';
export const P = `/projects/${PROJECT}`;

/** Fails the test on any error the page throws or logs (white screens, broken scripts, failed API calls). */
export function watchErrors(page: Page) {
  const errors: string[] = [];
  page.on('pageerror', (e) => errors.push(`page error: ${e.message}`));
  // "Failed to load resource" repeats a failed request: those are judged below, by address.
  page.on('console', (m) => { if (m.type() === 'error' && !/favicon|DevTools|Failed to load resource/.test(m.text())) errors.push(`console: ${m.text()}`); });
  page.on('response', (r) => {
    const url = r.url();
    if (!url.includes('/api/')) return;
    // /api/auth/me answers 404 when sign-in (SSO) is off, as on a developer's PC: the app expects that.
    if (r.status() >= 500 || (r.status() === 404 && !/\/api\/auth\/me$/.test(url))) errors.push(`API ${r.status()}: ${url}`);
  });
  return errors;
}

/** The page shows its content, not the safety-net message. */
export async function pageIsFine(page: Page) {
  await expect(page.getByText('This page could not be shown')).toHaveCount(0);
}
