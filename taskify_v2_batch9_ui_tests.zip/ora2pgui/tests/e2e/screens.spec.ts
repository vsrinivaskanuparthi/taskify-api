import { expect, test } from '@playwright/test';
import { P } from './helpers';

test('the bell lists recent migrations and opens notification settings outside a project', async ({ page }) => {
  await page.goto('/projects');
  await page.getByRole('button', { name: 'Migrations and notifications' }).click();
  await expect(page.getByText('Running now, and ended in the last 14 days, in every project.')).toBeVisible();
  await page.getByRole('tab', { name: 'Notification settings' }).click();
  await expect(page.getByText('Notifications are set per project: choose one.')).toBeVisible();
});

test('My preferences: a hidden section stays hidden after a reload, then is shown again', async ({ page }) => {
  await page.goto(`${P}/runs`);
  const firstRun = page.locator('tbody tr').first();
  test.skip((await firstRun.count()) === 0, 'no run in this project yet');
  await firstRun.getByRole('button').first().click();
  const phases = page.getByText(/^\d+ of \d+ complete$/); // the Phases card's subtitle
  await expect(phases).toBeVisible();
  const toggle = async () => {
    await page.getByRole('button', { name: 'Account' }).click();
    await page.getByRole('button', { name: 'My preferences' }).click();
    await page.getByRole('dialog').getByText('Phases', { exact: true }).click();
    await page.getByRole('button', { name: 'Save' }).click();
  };
  await toggle();
  await expect(phases).toHaveCount(0);
  await page.reload();
  await expect(page.getByText(/^Run \d{8}-\d{6}/)).toBeVisible();
  await expect(phases).toHaveCount(0);
  await toggle(); // back as it was
  await expect(phases).toBeVisible();
});

test('DB link mapping: the "Save and test" button stays on one line', async ({ page }) => {
  await page.goto(`${P}/code`);
  const button = page.getByRole('button', { name: 'Save and test' });
  test.skip((await page.getByText('No DB links in this schema').count()) > 0, 'no DB link in this schema');
  if ((await button.count()) === 0) {
    await page.getByRole('combobox').filter({ hasText: /Do not create|stays on Oracle|PostgreSQL/ }).first().click();
    await page.getByRole('option', { name: 'Remote database stays on Oracle (oracle_fdw)' }).click();
  }
  const box = await button.first().boundingBox();
  expect(box!.height).toBeLessThan(45);
});

test('Settings: a saved decision is kept after a reload', async ({ page }) => {
  await page.goto(`${P}/settings`);
  const field = page.getByLabel('Agreed with (team / person)');
  const stamp = `UI test ${Date.now()}`;
  await field.fill(stamp);
  await page.getByRole('button', { name: 'Save settings' }).first().click();
  await expect(page.getByText(/Settings saved/)).toBeVisible();
  await page.reload();
  await expect(page.getByText(`Agreed with ${stamp}`)).toBeVisible();
});
