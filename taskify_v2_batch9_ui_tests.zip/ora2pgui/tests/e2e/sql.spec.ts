import { expect, test } from '@playwright/test';
import { P, pageIsFine, watchErrors } from './helpers';

test.describe('SQL Workbench', () => {
  test('a query shows its rows; a change asks for confirmation; Cancel changes nothing', async ({ page }) => {
    const errors = watchErrors(page);
    await page.goto(`${P}/sql`);
    const editor = page.locator('.cm-content');
    await editor.click();
    await page.keyboard.press('ControlOrMeta+a');
    await page.keyboard.type('SELECT 1 AS one, \'two\' AS two');
    await page.keyboard.press('Escape'); // closes the completion list
    await page.keyboard.press('ControlOrMeta+Enter');
    await expect(page.getByRole('tab', { name: /SELECT · 1 row/ })).toBeVisible();
    await expect(page.locator('tbody').getByText('two', { exact: true })).toBeVisible();

    await editor.click();
    await page.keyboard.press('ControlOrMeta+a');
    await page.keyboard.type('CREATE TABLE dma_ui_e2e_never (x int)');
    await page.keyboard.press('Escape');
    await page.getByRole('button', { name: 'Run', exact: true }).click();
    await expect(page.getByRole('heading', { name: 'Change data in PostgreSQL?' })).toBeVisible();
    await page.getByRole('button', { name: 'Cancel' }).click();

    // Nothing was created.
    await editor.click();
    await page.keyboard.press('ControlOrMeta+a');
    await page.keyboard.type("SELECT count(*) AS n FROM pg_class WHERE relname = 'dma_ui_e2e_never'");
    await page.keyboard.press('Escape');
    await page.keyboard.press('ControlOrMeta+Enter');
    await expect(page.locator('tbody td').first()).toHaveText('0');
    await pageIsFine(page);
    expect(errors).toEqual([]);
  });

  test('an error names the statement and where it failed', async ({ page }) => {
    await page.goto(`${P}/sql`);
    await page.locator('.cm-content').click();
    await page.keyboard.press('ControlOrMeta+a');
    await page.keyboard.type('SELECT nope FROM pg_class');
    await page.keyboard.press('Escape');
    await page.keyboard.press('ControlOrMeta+Enter');
    await expect(page.getByText('column "nope" does not exist')).toBeVisible();
    await expect(page.getByText(/Near character 8/)).toBeVisible();
  });

  test('Oracle is read-only', async ({ page }) => {
    await page.goto(`${P}/sql`);
    await page.getByRole('button', { name: 'Oracle', exact: true }).click();
    await expect(page.getByText('Oracle source · SELECT only')).toBeVisible();
    await page.locator('.cm-content').click();
    await page.keyboard.press('ControlOrMeta+a');
    await page.keyboard.type('DELETE FROM plant');
    await page.keyboard.press('Escape');
    await page.keyboard.press('ControlOrMeta+Enter');
    await expect(page.getByText(/only SELECT queries run here/)).toBeVisible();
  });

  test('the table list is hidden until asked for', async ({ page }) => {
    await page.goto(`${P}/sql`);
    await page.evaluate(() => localStorage.removeItem('dma.sql.tables'));
    await page.reload();
    await expect(page.getByPlaceholder('Search tables')).toHaveCount(0);
    await page.getByRole('button', { name: /^Tables/ }).click();
    await expect(page.getByPlaceholder('Search tables')).toBeVisible();
    await page.getByRole('button', { name: 'Hide tables' }).click();
  });
});
