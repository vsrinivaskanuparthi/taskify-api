import { expect, test } from '@playwright/test';
import { P, pageIsFine, watchErrors } from './helpers';

// The main user path for one small table: Migrate → Live monitor → Validation.
test('migrate one table from the screens and see it verified', async ({ page }) => {
  const errors = watchErrors(page);
  await page.goto(`${P}/migrate`);
  await page.getByPlaceholder('Search').fill('PLANT');
  await page.getByRole('checkbox', { name: 'Select PLANT', exact: true }).check();
  await page.getByRole('button', { name: /^Start migration \(1\)$/ }).click();
  await page.getByRole('button', { name: /^Start migration \(1 table\)$/ }).click();

  await expect(page).toHaveURL(/\/runs\/\d{8}-\d{6}$/);
  await expect(page.getByText(/^Completed$/).first()).toBeVisible({ timeout: 4 * 60 * 1000 });
  await expect(page.locator('tbody').getByText('PLANT')).toBeVisible();

  await page.goto(`${P}/validation`);
  const row = page.locator('tbody tr', { hasText: /^plant/ }).first();
  await expect(row).toContainText('verified at load');
  await pageIsFine(page);
  expect(errors).toEqual([]);
});
