import { fireEvent, render, screen, within } from '@testing-library/react';
import { describe, expect, test } from 'vitest';
import DataTable from '../../src/components/DataTable';

type Row = { name: string; rows: number };
const make = (n: number): Row[] => Array.from({ length: n }, (_, i) => ({ name: `T${String(i + 1).padStart(2, '0')}`, rows: (i * 37) % 100 }));
const cols = [{ key: 'name', label: 'Table' }, { key: 'rows', label: 'Rows', sortValue: (r: Row) => r.rows }];
const bodyNames = () => within(document.querySelector('tbody')!).queryAllByRole('row').map((r) => r.querySelector('td')?.textContent);

describe('DataTable', () => {
  test('search filters rows; nothing found shows the empty text', () => {
    render(<DataTable rows={make(5)} columns={cols} rowKey={(r) => r.name} searchKeys={['name']} empty="No tables" />);
    fireEvent.change(screen.getByPlaceholderText('Search'), { target: { value: 't03' } });
    expect(bodyNames()).toEqual(['T03']);
    fireEvent.change(screen.getByPlaceholderText('Search'), { target: { value: 'zzz' } });
    expect(screen.getByText('No tables')).toBeInTheDocument();
  });

  test('sorting by a column, numbers as numbers, click again reverses', () => {
    render(<DataTable rows={[{ name: 'A', rows: 10 }, { name: 'B', rows: 9 }, { name: 'C', rows: 100 }]} columns={cols} rowKey={(r) => r.name} />);
    fireEvent.click(screen.getByText('Rows'));
    expect(bodyNames()).toEqual(['B', 'A', 'C']); // 9, 10, 100 (not "10" < "100" < "9")
    fireEvent.click(screen.getByText('Rows'));
    expect(bodyNames()).toEqual(['C', 'A', 'B']);
  });

  test('paging: 10 per page', () => {
    render(<DataTable rows={make(23)} columns={cols} rowKey={(r) => r.name} />);
    expect(bodyNames()).toHaveLength(10);
    fireEvent.click(screen.getByRole('button', { name: /next page/i }));
    expect(bodyNames()[0]).toBe('T11');
  });

  test('when the rows shrink while on a later page, the rows still show (no empty page)', () => {
    const { rerender } = render(<DataTable rows={make(30)} columns={cols} rowKey={(r) => r.name} />);
    fireEvent.click(screen.getByRole('button', { name: /next page/i }));
    fireEvent.click(screen.getByRole('button', { name: /next page/i }));
    expect(bodyNames()[0]).toBe('T21');
    rerender(<DataTable rows={make(4)} columns={cols} rowKey={(r) => r.name} />); // e.g. a new query with fewer rows
    expect(bodyNames()).toEqual(['T01', 'T02', 'T03', 'T04']);
  });

  test('missing values show a dash', () => {
    render(<DataTable rows={[{ name: 'A' } as Row]} columns={cols} rowKey={(r) => r.name} />);
    expect(bodyNames()).toEqual(['A']);
    expect(screen.getByText('—')).toBeInTheDocument();
  });
});
