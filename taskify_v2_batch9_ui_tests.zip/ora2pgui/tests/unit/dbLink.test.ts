import { describe, expect, test } from 'vitest';
import { hasSeveralAddresses, parseLinkHost, prefillFromOracle } from '../../src/logic/dbLink';

// Real link definitions seen in Oracle (anonymised hosts): EZConnect and TNS descriptions.
const ONE = '//orahost.corp:1521/SALES.corp';
const TNS = '(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=db1.corp)(PORT=1522))(CONNECT_DATA=(SERVICE_NAME=SVC1)))';
const TWO = '(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=APP-PRO-PRIM)(PORT=1521))(ADDRESS=(PROTOCOL=TCP)(HOST=APP-PRO-SEC)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=APP_HADG.corp)))';
const LIST = '(DESCRIPTION=(ADDRESS_LIST=(ADDRESS=(PROTOCOL=TCP)(HOST=a-p59.corp)(PORT=1521))(ADDRESS=(PROTOCOL=TCP)(HOST=a-p60.corp)(PORT=1521)))(CONNECT_DATA=(SERVICE_NAME=X_HADG.corp)))';

describe('Oracle link address', () => {
  test('EZConnect forms', () => {
    expect(parseLinkHost(ONE)).toEqual({ host: 'orahost.corp', port: '1521', dbname: 'SALES.corp' });
    expect(parseLinkHost('orahost:1600/S')).toEqual({ host: 'orahost', port: '1600', dbname: 'S' });
    expect(parseLinkHost('orahost')).toEqual({ host: 'orahost', port: '1521', dbname: '' });
  });

  test('TNS description with one address', () => {
    expect(parseLinkHost(TNS)).toEqual({ host: 'db1.corp', port: '1522', dbname: 'SVC1' });
    expect(parseLinkHost(TNS.replace('SERVICE_NAME', 'SID'))).toEqual({ host: 'db1.corp', port: '1522', dbname: 'SVC1' });
  });

  test('empty or odd input never throws', () => {
    expect(parseLinkHost('')).toEqual({ host: '', port: '', dbname: '' });
    expect(parseLinkHost(undefined as unknown as string)).toEqual({ host: '', port: '', dbname: '' });
  });

  test('a link with a primary and a standby is kept whole for oracle_fdw', () => {
    expect(hasSeveralAddresses(TWO)).toBe(true);
    expect(hasSeveralAddresses(LIST)).toBe(true);
    expect(hasSeveralAddresses(TNS)).toBe(false);
    expect(prefillFromOracle('oracle_fdw', `  ${TWO}  `)).toEqual({ host: TWO, port: '', dbname: '' });
    expect(prefillFromOracle('oracle_fdw', TNS)).toEqual({ host: 'db1.corp', port: '1522', dbname: 'SVC1' });
  });

  test('other modes start empty', () => {
    expect(prefillFromOracle('postgres_fdw', ONE)).toEqual({ host: '', port: '', dbname: '' });
    expect(prefillFromOracle('skip', ONE)).toEqual({ host: '', port: '', dbname: '' });
  });
});
