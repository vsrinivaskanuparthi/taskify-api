import { describe, expect, test } from 'vitest';
import { ERROR_HELP, explainError, IMPACT_TEXT } from '../../src/errorHelp';

describe('"What does this mean?" catalogue', () => {
  test('every entry is complete and has a unique id', () => {
    const ids = new Set<string>();
    for (const e of ERROR_HELP) {
      expect(e.id, JSON.stringify(e.title)).toBeTruthy();
      expect(ids.has(e.id), `duplicate id ${e.id}`).toBe(false);
      ids.add(e.id);
      expect(e.title.length).toBeGreaterThan(5);
      expect(e.meaning.length).toBeGreaterThan(10);
      expect(e.action.length).toBeGreaterThan(5);
      expect(Object.keys(IMPACT_TEXT)).toContain(e.impact);
      expect(e.match.test(''), `${e.id} matches an empty text`).toBe(false);
    }
  });

  test('common errors from real migrations are explained', () => {
    for (const text of [
      'ORA-01017: invalid credential or not authorized; logon denied',
      'ERROR:  relation "orders" already exists',
      'ORA-01555: snapshot too old: rollback segment number 9 with name "_SYSSMU9$" too small',
      'ERROR:  permission denied for schema app',
      'FATAL:  password authentication failed for user "dma"',
      'ERROR:  value too long for type character varying(20)',
      'ERROR:  invalid input syntax for type boolean: "2"',
      'ERROR:  deadlock detected',
    ]) {
      expect(explainError(text), text).not.toBeNull();
    }
  });

  test('unknown or empty text has no explanation (nothing made up)', () => {
    expect(explainError('')).toBeNull();
    expect(explainError(null)).toBeNull();
    expect(explainError('everything is fine')).toBeNull();
  });
});
