import { describe, expect, test } from 'vitest';
import { estimateText, REFERENCE_MBPS, shortOf, Sizing } from '../../src/logic/estimate';

describe('time estimate', () => {
  test('at the v1 reference speed (30 GB/h), plus a third for indexes and keys', () => {
    expect(REFERENCE_MBPS).toBeCloseTo(8.53, 2);
    // 2.57 GB of the test schema: about 7 min (a real run took 5–7 min)
    expect(estimateText(2631.5, REFERENCE_MBPS)).toBe('about 7 min');
    // 450 GB: about 20 h
    expect(estimateText(450 * 1024, REFERENCE_MBPS)).toBe('about 20 h');
  });

  test('never zero, never "Infinity", also with no speed or no data', () => {
    expect(estimateText(0, REFERENCE_MBPS)).toBe('about 1 min');
    expect(estimateText(1000, 0)).toMatch(/^about \d+(\.\d)? h$/);
    expect(estimateText(NaN, NaN)).toBe('about 1 min');
  });
});

describe('server shortfall', () => {
  const sz = (server: Partial<Sizing['server']>, need: Partial<Sizing['need']> = {}): Sizing => ({
    speed: { mbps: 8, measured: false },
    server: { cpus: 8, ramGb: 64, stagingDir: '/x', disk: { freeGb: 100, totalGb: 200 }, ...server },
    need: { parallelTables: 2, loadMode: 'direct', cpus: 6, ramGb: 8, stagingGb: { direct: 10, file: 20, export: 30 }, ...need },
  });
  test('names what is short', () => {
    expect(shortOf(sz({}))).toEqual([]);
    expect(shortOf(sz({ cpus: 4 }))).toEqual(['CPU cores']);
    expect(shortOf(sz({ ramGb: 7 }))).toEqual(['RAM']);
    expect(shortOf(sz({ disk: { freeGb: 11, totalGb: 50 } }))).toEqual(['disk space']); // needs 10 GB + 20 % margin
    expect(shortOf(sz({ disk: null }))).toEqual([]); // unknown disk is not reported as short
    expect(shortOf(null)).toEqual([]);
  });
});
