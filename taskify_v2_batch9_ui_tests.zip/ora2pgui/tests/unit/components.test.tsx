import { fireEvent, render, screen, waitFor } from '@testing-library/react';
import { beforeEach, describe, expect, test, vi } from 'vitest';

// The API is replaced: /whoami says admin or not, /preferences is kept in memory.
const server = vi.hoisted(() => ({ admin: true, prefs: null as any, saved: [] as any[] }));
vi.mock('../../src/api', async (orig) => ({
  ...(await orig<typeof import('../../src/api')>()),
  api: vi.fn(async (path: string, init: any = {}) => {
    if (path === '/whoami') return { admin: server.admin, user: { id: 'U1', email: 'u1@corp' } };
    if (path === '/preferences' && init.method === 'PUT') { server.saved.push(init.body.preferences); return { preferences: init.body.preferences }; }
    if (path === '/preferences') return { preferences: server.prefs };
    throw new Error(`unexpected ${path}`);
  }),
}));

beforeEach(() => { vi.resetModules(); server.saved = []; });

async function renderPrefs(admin: boolean) {
  server.admin = admin;
  const { DEFAULT_PREFS } = await import('../../src/prefs');
  server.prefs = structuredClone(DEFAULT_PREFS);
  const { default: PreferencesDialog } = await import('../../src/components/PreferencesDialog');
  const onClose = vi.fn();
  render(<PreferencesDialog open onClose={onClose} />);
  return onClose;
}

describe('My preferences', () => {
  test('a normal user does not see the admin-only "Where did the time go?"', async () => {
    await renderPrefs(false);
    await screen.findByText('Server CPU and memory');
    await waitFor(() => expect(screen.queryByText('Where did the time go?')).not.toBeInTheDocument());
  });

  test('an admin sees it; a change is saved for this user and the dialog closes', async () => {
    const onClose = await renderPrefs(true);
    await screen.findByText('Where did the time go?');
    fireEvent.click(screen.getByText('Phases'));
    fireEvent.click(screen.getByRole('button', { name: 'Save' }));
    await waitFor(() => expect(onClose).toHaveBeenCalled());
    expect(server.saved[0].monitor.phases).toBe(false);
    expect(server.saved[0].monitor.serverUsage).toBe(true);
  });
});

describe('"What does this mean?"', () => {
  test('a known error opens its explanation; an unknown one says how to find the cause', async () => {
    const { default: ErrorHelp } = await import('../../src/components/ErrorHelp');
    const { rerender } = render(<ErrorHelp text="ERROR:  deadlock detected" />);
    fireEvent.click(screen.getByText('What does this mean?'));
    expect(screen.getByText('Two steps waited for each other')).toBeInTheDocument();
    rerender(<ErrorHelp text="something never seen" defaultOpen key="x" />);
    expect(screen.getByText(/Not in DMA’s list of known errors yet/)).toBeInTheDocument();
    rerender(<ErrorHelp text="" key="y" />);
    expect(screen.queryByText('What does this mean?')).not.toBeInTheDocument();
  });
});

describe('status chips', () => {
  test('every run and table status has a readable label', async () => {
    const { StatusChip } = await import('../../src/components/ui');
    for (const [status, label] of [['running', 'Loading'], ['pending', 'Waiting'], ['COMPLETED_WITH_ERRORS', 'Completed with errors']]) {
      const { unmount } = render(<StatusChip status={status} />);
      expect(screen.getByText(label)).toBeInTheDocument();
      unmount();
    }
    // An unknown status still shows something readable, never an empty chip.
    render(<StatusChip status="SOMETHING_NEW" />);
    expect(screen.getByText('SOMETHING_NEW')).toBeInTheDocument();
  });
});
