import { afterEach, describe, expect, test, vi } from 'vitest';
import { api, ApiError, projectPath } from '../../src/api';

const reply = (status: number, body: unknown, ok = status < 400) => vi.fn().mockResolvedValue({ ok, status, text: () => Promise.resolve(typeof body === 'string' ? body : JSON.stringify(body)) });

afterEach(() => vi.unstubAllGlobals());

describe('API helper', () => {
  test('JSON answer; POST when there is a body; cookies sent (SSO)', async () => {
    const f = reply(200, { a: 1 });
    vi.stubGlobal('fetch', f);
    expect(await api('/x', { body: { q: 1 } })).toEqual({ a: 1 });
    expect(f.mock.calls[0][1]).toMatchObject({ method: 'POST', credentials: 'include' });
  });

  test('the server\'s message becomes the error, with the status', async () => {
    vi.stubGlobal('fetch', reply(409, { message: 'A migration of this project is already running' }));
    const err = await api('/x').catch((e) => e);
    expect(err).toBeInstanceOf(ApiError);
    expect(err.message).toBe('A migration of this project is already running');
    expect(err.status).toBe(409);
  });

  test('an answer that is not JSON (e.g. a proxy error page) still gives a readable error', async () => {
    vi.stubGlobal('fetch', reply(502, '<html>Bad Gateway</html>'));
    const err = await api('/x').catch((e) => e);
    expect(err.message).toBe('Request failed (502)');
  });

  test('server down: a plain message, not "Failed to fetch"', async () => {
    vi.stubGlobal('fetch', vi.fn().mockRejectedValue(new TypeError('Failed to fetch')));
    const err = await api('/x').catch((e) => e);
    expect(err.message).toMatch(/Cannot reach the migration server/);
    expect(err.status).toBe(0);
  });

  test('project names are encoded in URLs', () => {
    expect(projectPath('A B/C')).toBe('/projects/A%20B%2FC');
  });
});
