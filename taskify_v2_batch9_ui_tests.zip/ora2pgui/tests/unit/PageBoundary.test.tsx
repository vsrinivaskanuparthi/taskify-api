import { fireEvent, render, screen } from '@testing-library/react';
import { afterAll, beforeAll, describe, expect, test, vi } from 'vitest';
import PageBoundary from '../../src/components/PageBoundary';

let broken = true;
function Page() {
  if (broken) throw new Error('Cannot read properties of null (reading "tables")');
  return <p>Page content</p>;
}

// React and the boundary log the error on purpose: kept quiet here.
beforeAll(() => { vi.spyOn(console, 'error').mockImplementation(() => {}); });
afterAll(() => vi.restoreAllMocks());

describe('page safety net', () => {
  test('an error while showing a page gives a message, not a white screen', () => {
    render(<PageBoundary resetKey="/a"><Page /></PageBoundary>);
    expect(screen.getByText('This page could not be shown')).toBeInTheDocument();
    fireEvent.click(screen.getByText('Details for the DMA team'));
    expect(screen.getByText(/reading "tables"/)).toBeInTheDocument();
  });

  test('"Try again" shows the page once it works', () => {
    broken = true;
    render(<PageBoundary resetKey="/a"><Page /></PageBoundary>);
    broken = false;
    fireEvent.click(screen.getByText('Try again'));
    expect(screen.getByText('Page content')).toBeInTheDocument();
  });

  test('going to another page clears the message', () => {
    broken = true;
    const { rerender } = render(<PageBoundary resetKey="/a"><Page /></PageBoundary>);
    broken = false;
    rerender(<PageBoundary resetKey="/b"><Page /></PageBoundary>);
    expect(screen.getByText('Page content')).toBeInTheDocument();
  });
});
