import { describe, expect, test, vi } from 'vitest';
import { fmtBytes, fmtDuration, fmtInt, fmtMb, shortDb, timeAgo } from '../../src/format';

describe('numbers and sizes', () => {
  test('sizes from MB', () => {
    expect(fmtMb(0.5)).toBe('512 KB');
    expect(fmtMb(12.34)).toBe('12.3 MB');
    expect(fmtMb(2631.5)).toBe('2.57 GB');
    expect(fmtMb(500 * 1024 * 1024)).toBe('500.00 TB');
    expect(fmtMb('abc')).toBe('—');
    expect(fmtMb(null)).toBe('—');
  });
  test('bytes', () => {
    expect(fmtBytes(512)).toBe('512 B');
    expect(fmtBytes(16 * 1048576)).toBe('16.0 MB');
    expect(fmtBytes(NaN)).toBe('—');
  });
  test('integers: blanks and text are a dash, never "NaN"', () => {
    expect(fmtInt(null)).toBe('—');
    expect(fmtInt('')).toBe('—');
    expect(fmtInt('x')).toBe('—');
    expect(fmtInt(0)).toBe('0');
  });
});

describe('durations and times', () => {
  test('durations', () => {
    expect(fmtDuration(45_000)).toBe('45s');
    expect(fmtDuration(320_000)).toBe('5m 20s');
    expect(fmtDuration(2 * 3600_000 + 5 * 60_000)).toBe('2h 5m');
    expect(fmtDuration(26 * 3600_000)).toBe('1d 2h 0m');
    expect(fmtDuration(-1)).toBe('—');
    expect(fmtDuration(Infinity)).toBe('—');
  });
  test('time ago', () => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date('2026-11-09T12:00:00Z'));
    expect(timeAgo('2026-11-09T11:59:30Z')).toBe('just now');
    expect(timeAgo('2026-11-09T11:30:00Z')).toBe('30 min ago');
    expect(timeAgo('2026-11-09T07:00:00Z')).toBe('5 h ago');
    expect(timeAgo('2026-11-06T12:00:00Z')).toBe('3 d ago');
    expect(timeAgo(null)).toBe('—');
    vi.useRealTimers();
  });
});

describe('database address for display', () => {
  test('TNS description shortened, EZConnect unchanged', () => {
    expect(shortDb('(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=db1)(PORT=1521))(CONNECT_DATA=(SERVICE_NAME=S1)))')).toBe('db1:1521/S1');
    expect(shortDb('localhost:1522/FREEPDB1')).toBe('localhost:1522/FREEPDB1');
    expect(shortDb(null)).toBe('');
  });
});
