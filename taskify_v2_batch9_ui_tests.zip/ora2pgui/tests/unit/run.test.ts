import { describe, expect, test } from 'vitest';
import { overallProgress, shownStatus, waitingSlot } from '../../src/logic/run';

const t = (over: Record<string, any> = {}) => ({ status: 'running', sizeMb: 100, estRows: 1000, rowsDone: 0, ...over });

describe('table status on the Live monitor', () => {
  test('a table waiting for a load slot shows as waiting', () => {
    expect(waitingSlot(t({ waiting: true }))).toBe(true);
    expect(shownStatus(t({ waiting: true }))).toBe('pending');
  });

  test('a table in parts waits while none of its parts loads', () => {
    expect(shownStatus(t({ chunkInfo: { total: 4, done: 0, running: 0, queued: 4, failed: 0 } }))).toBe('pending');
    expect(shownStatus(t({ chunkInfo: { total: 4, done: 0, running: 1, queued: 3, failed: 0 } }))).toBe('running');
    expect(shownStatus(t({ chunkInfo: { total: 4, done: 4, running: 0, queued: 0, failed: 0 } }))).toBe('running');
  });

  test('other statuses are shown as they are', () => {
    for (const s of ['pending', 'done', 'failed', 'exported']) expect(shownStatus(t({ status: s, waiting: true }))).toBe(s);
  });
});

describe('overall progress', () => {
  test('weighted by size: a big table counts more', () => {
    const run = { phases: [{ status: 'done' }, { status: 'running' }], tables: { BIG: t({ sizeMb: 900, rowsDone: 500 }), SMALL: t({ sizeMb: 100, status: 'done' }) } };
    // data: (900 * 0.5 + 100) / 1000 = 0.55 → 44 %; phases 1/2 → 10 %
    expect(overallProgress(run)).toBeCloseTo(54, 5);
  });

  test('stays between 0 and 100 with odd data (no phases, no tables, rows above the estimate, missing numbers)', () => {
    expect(overallProgress({ phases: [], tables: {} })).toBe(0);
    expect(overallProgress({ phases: [{ status: 'done' }], tables: { X: t({ rowsDone: 5000 }) } })).toBeLessThanOrEqual(100);
    const odd = overallProgress({ phases: [{ status: 'done' }], tables: { X: t({ sizeMb: undefined, estRows: 0, rowsDone: undefined }) } });
    expect(Number.isFinite(odd)).toBe(true);
    expect(overallProgress({ phases: [{ status: 'done' }, { status: 'done' }], tables: { A: t({ status: 'done' }), B: t({ status: 'failed' }) } })).toBe(100);
  });
});
