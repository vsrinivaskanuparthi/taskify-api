import { Button, LinearProgress, Stack, Typography } from '@mui/material';
import HistoryRoundedIcon from '@mui/icons-material/HistoryRounded';
import MonitorHeartRoundedIcon from '@mui/icons-material/MonitorHeartRounded';
import { useCallback, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api, projectPath } from '../api';
import { useProject } from '../context/ProjectContext';
import DataTable from '../components/DataTable';
import { EmptyState, PageHeader, SectionCard, StatusChip } from '../components/ui';
import { fmtCompact, fmtDate, fmtDuration } from '../format';

type RunSummary = { runId: string; schema: string; status: string; attempt: number; startedAt: string | null; finishedAt: string | null; createdAt: string; startedBy?: { id: string; email: string | null } | null; totals: { tables: number; done: number; failed: number; rowsDone: number; sizeMb: number } };

export default function RunsPage() {
  const { name, subscribe, activeRunId } = useProject();
  const navigate = useNavigate();
  const [runs, setRuns] = useState<RunSummary[] | null>(null);
  const load = useCallback(() => api<{ runs: RunSummary[] }>(`${projectPath(name)}/runs`).then((r) => setRuns(r.runs)), [name]);
  useEffect(() => { load(); }, [load]);
  // Keep the list current from the live stream (status changes of the running run).
  useEffect(() => subscribe((e) => {
    if (e.type === 'run') setRuns((rs) => (rs ? rs.map((r) => (r.runId === e.data.runId ? { ...r, ...e.data } : r)) : rs));
  }), [subscribe]);
  useEffect(() => { if (activeRunId && runs && !runs.some((r) => r.runId === activeRunId)) load(); }, [activeRunId, runs, load]);

  return (
    <>
      <PageHeader overline="Step 7" title="Live monitor & history" icon={<MonitorHeartRoundedIcon />} subtitle="Every migration run, its result and its logs. Open a run to watch it live or resume it."
        actions={activeRunId ? <Button variant="contained" onClick={() => navigate(activeRunId)}>Open running migration</Button> : <Button variant="outlined" onClick={() => navigate('../migrate')}>New run</Button>} />
      <SectionCard dense>
        {!runs && <LinearProgress />}
        {runs && runs.length === 0 && <EmptyState icon={<HistoryRoundedIcon />} title="No runs yet" text="Start a migration from the Migrate step." action={<Button variant="contained" onClick={() => navigate('../migrate')}>Plan migration</Button>} />}
        {runs && runs.length > 0 && (
          <DataTable rows={runs} rowKey={(r) => r.runId} initialSort={{ key: 'runId', dir: 'desc' }}
            columns={[
              { key: 'runId', label: 'Run', render: (r) => <Button size="small" onClick={() => navigate(r.runId)} className="mono" sx={{ fontFamily: 'inherit', whiteSpace: 'nowrap' }}>{r.runId}</Button> },
              // Names are never broken in the middle (JAGUAR_AP / P).
              { key: 'schema', label: 'Schema', render: (r) => <Typography className="mono" fontSize={13} sx={{ whiteSpace: 'nowrap' }}>{r.schema}</Typography> },
              { key: 'status', label: 'Status', render: (r) => <Stack direction="row" spacing={1} alignItems="center"><StatusChip status={r.status} />{r.attempt > 1 && <Typography variant="caption" color="text.secondary">resumed {r.attempt - 1}×</Typography>}</Stack> },
              { key: 'tables', label: 'Tables', sortValue: (r) => r.totals.done, render: (r) => `${r.totals.done} / ${r.totals.tables}${r.totals.failed ? ` (${r.totals.failed} failed)` : ''}` },
              { key: 'rows', label: 'Rows', align: 'right', sortValue: (r) => r.totals.rowsDone, render: (r) => fmtCompact(r.totals.rowsDone) },
              { key: 'startedAt', label: 'Started', render: (r) => fmtDate(r.startedAt || r.createdAt) },
              { key: 'startedBy', label: 'Started by', sortValue: (r) => r.startedBy?.id || '', render: (r) => r.startedBy?.id || '—' },
              { key: 'dur', label: 'Duration', align: 'right', sortValue: (r) => (r.startedAt ? new Date(r.finishedAt || Date.now()).getTime() - new Date(r.startedAt).getTime() : 0), render: (r) => (r.startedAt ? fmtDuration(new Date(r.finishedAt || Date.now()).getTime() - new Date(r.startedAt).getTime()) : '—') },
            ]} />
        )}
      </SectionCard>
    </>
  );
}
