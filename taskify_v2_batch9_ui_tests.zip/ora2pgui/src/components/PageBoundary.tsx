import { Alert, Box, Button, Collapse, Stack, Typography } from '@mui/material';
import { Component, ErrorInfo, ReactNode } from 'react';

type Props = { children: ReactNode; resetKey?: string };
type State = { error: Error | null; details: boolean };

/**
 * Safety net: an unexpected error while showing a page (e.g. data the page did not expect) shows a
 * message with "Try again" instead of a white screen, and the menu around it keeps working.
 * Going to another page (resetKey) clears it.
 */
export default class PageBoundary extends Component<Props, State> {
  state: State = { error: null, details: false };

  static getDerivedStateFromError(error: Error): Partial<State> {
    return { error };
  }

  componentDidCatch(error: Error, info: ErrorInfo) {
    // Kept in the browser console for the DMA team (F12 → Console).
    console.error('DMA page error:', error, info.componentStack);
  }

  componentDidUpdate(prev: Props) {
    if (this.state.error && prev.resetKey !== this.props.resetKey) this.setState({ error: null, details: false });
  }

  render() {
    const { error, details } = this.state;
    if (!error) return this.props.children;
    return (
      <Box sx={{ p: { xs: 2, md: 4 } }}>
        <Alert severity="error" sx={{ borderRadius: 3 }}>
          <Typography fontWeight={750}>This page could not be shown</Typography>
          <Typography variant="body2" sx={{ mt: 0.5 }}>
            Something unexpected happened while showing it. Your migrations and data are not affected. Try again, or use the menu to open another page.
          </Typography>
          <Stack direction="row" spacing={1} sx={{ mt: 1.5 }}>
            <Button size="small" variant="contained" color="error" onClick={() => this.setState({ error: null, details: false })}>Try again</Button>
            <Button size="small" onClick={() => window.location.reload()}>Reload the page</Button>
            <Button size="small" onClick={() => this.setState({ details: !details })}>{details ? 'Hide details' : 'Details for the DMA team'}</Button>
          </Stack>
          <Collapse in={details}>
            <Box component="pre" className="mono" sx={{ mt: 1.5, p: 1.5, bgcolor: '#fff', borderRadius: 2, fontSize: 12, whiteSpace: 'pre-wrap', overflowWrap: 'anywhere', maxHeight: 220, overflow: 'auto' }}>
              {`${error.name}: ${error.message}\n${window.location.pathname}`}
            </Box>
          </Collapse>
        </Alert>
      </Box>
    );
  }
}
