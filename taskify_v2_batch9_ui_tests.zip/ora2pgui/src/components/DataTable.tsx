import { Box, InputAdornment, Stack, Table, TableBody, TableCell, TableContainer, TableHead, TablePagination, TableRow, TableSortLabel, TextField, Typography } from '@mui/material';
import SearchRoundedIcon from '@mui/icons-material/SearchRounded';
import { ReactNode, useMemo, useState } from 'react';

export interface Column<T> {
  key: string;
  label: ReactNode;
  align?: 'left' | 'right' | 'center';
  width?: number | string;
  sortValue?: (row: T) => number | string;
  render?: (row: T) => ReactNode;
}

/**
 * Table with search, sorting and paging (client side; fine for thousands of rows).
 * Cells never overflow their box: long names wrap or are cut with a tooltip.
 */
export default function DataTable<T extends Record<string, any>>({
  rows, columns, searchKeys, initialSort, toolbar, rowKey, pageSize = 10, empty = 'No rows', dense, maxHeight,
}: {
  rows: T[];
  columns: Column<T>[];
  searchKeys?: (keyof T)[];
  initialSort?: { key: string; dir: 'asc' | 'desc' };
  toolbar?: ReactNode;
  rowKey: (row: T) => string;
  pageSize?: number;
  empty?: string;
  dense?: boolean;
  maxHeight?: number;
}) {
  const [q, setQ] = useState('');
  const [sort, setSort] = useState(initialSort || { key: columns[0].key, dir: 'asc' as const });
  const [page, setPage] = useState(0);
  const [perPage, setPerPage] = useState(pageSize);

  const filtered = useMemo(() => {
    let r = rows;
    if (q && searchKeys) {
      const s = q.toLowerCase();
      r = r.filter((row) => searchKeys.some((k) => String(row[k] ?? '').toLowerCase().includes(s)));
    }
    const col = columns.find((c) => c.key === sort.key);
    const val = col?.sortValue || ((row: T) => row[sort.key]);
    return [...r].sort((a, b) => {
      const x = val(a);
      const y = val(b);
      const cmp = typeof x === 'number' && typeof y === 'number' ? x - y : String(x ?? '').localeCompare(String(y ?? ''));
      return sort.dir === 'asc' ? cmp : -cmp;
    });
  }, [rows, q, sort, columns, searchKeys]);

  // Fewer rows than before (new data, a filter): never stay on a page past the end.
  const lastPage = Math.max(0, Math.ceil(filtered.length / perPage) - 1);
  const current = Math.min(page, lastPage);
  const pageRows = filtered.slice(current * perPage, current * perPage + perPage);

  return (
    <Box>
      {(searchKeys || toolbar) && (
        <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.5} alignItems={{ sm: 'center' }} justifyContent="space-between" sx={{ px: 2.5, py: 1.5 }}>
          {searchKeys ? (
            <TextField size="small" placeholder="Search" value={q} onChange={(e) => { setQ(e.target.value); setPage(0); }} sx={{ width: { sm: 300 } }}
              InputProps={{ startAdornment: <InputAdornment position="start"><SearchRoundedIcon fontSize="small" /></InputAdornment> }} />
          ) : <span />}
          {toolbar}
        </Stack>
      )}
      <TableContainer sx={{ maxHeight }}>
        <Table size={dense ? 'small' : 'medium'} stickyHeader={!!maxHeight} sx={{ tableLayout: 'auto' }}>
          <TableHead>
            <TableRow>
              {columns.map((c) => (
                <TableCell key={c.key} align={c.align} sx={{ width: c.width, whiteSpace: 'nowrap' }}>
                  <TableSortLabel active={sort.key === c.key} direction={sort.key === c.key ? sort.dir : 'asc'}
                    onClick={() => setSort({ key: c.key, dir: sort.key === c.key && sort.dir === 'asc' ? 'desc' : 'asc' })}>
                    {c.label}
                  </TableSortLabel>
                </TableCell>
              ))}
            </TableRow>
          </TableHead>
          <TableBody>
            {pageRows.map((row) => (
              <TableRow key={rowKey(row)} hover>
                {columns.map((c) => (
                  <TableCell key={c.key} align={c.align} sx={{ maxWidth: 420, overflowWrap: 'anywhere' }}>
                    {c.render ? c.render(row) : String(row[c.key] ?? '—')}
                  </TableCell>
                ))}
              </TableRow>
            ))}
            {pageRows.length === 0 && (
              <TableRow><TableCell colSpan={columns.length}><Typography color="text.secondary" sx={{ py: 3, textAlign: 'center' }}>{empty}</Typography></TableCell></TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>
      {filtered.length > perPage && (
        <TablePagination component="div" count={filtered.length} page={current} onPageChange={(_, p) => setPage(p)} rowsPerPage={perPage}
          onRowsPerPageChange={(e) => { setPerPage(Number(e.target.value)); setPage(0); }} rowsPerPageOptions={[10, 25, 50, 100]} />
      )}
    </Box>
  );
}
