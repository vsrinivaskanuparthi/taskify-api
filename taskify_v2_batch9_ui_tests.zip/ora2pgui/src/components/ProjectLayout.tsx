import PageBoundary from './PageBoundary';
import TerminalRoundedIcon from '@mui/icons-material/TerminalRounded';
import { Alert, Box, Chip, Stack, Typography } from '@mui/material';
import FolderCopyRoundedIcon from '@mui/icons-material/FolderCopyRounded';
import MenuBookRoundedIcon from '@mui/icons-material/MenuBookRounded';
import CableRoundedIcon from '@mui/icons-material/CableRounded';
import AccountTreeRoundedIcon from '@mui/icons-material/AccountTreeRounded';
import InsightsRoundedIcon from '@mui/icons-material/InsightsRounded';
import AutoAwesomeRoundedIcon from '@mui/icons-material/AutoAwesomeRounded';
import RocketLaunchRoundedIcon from '@mui/icons-material/RocketLaunchRounded';
import MonitorHeartRoundedIcon from '@mui/icons-material/MonitorHeartRounded';
import FactCheckRoundedIcon from '@mui/icons-material/FactCheckRounded';
import TuneRoundedIcon from '@mui/icons-material/TuneRounded';
import HomeRoundedIcon from '@mui/icons-material/HomeRounded';
import AssessmentRoundedIcon from '@mui/icons-material/AssessmentRounded';
import { Outlet, useLocation, useParams } from 'react-router-dom';
import Shell, { NavSection } from './Shell';
import { ProjectProvider, useProject } from '../context/ProjectContext';
import { StatusChip } from './ui';
import { WizardBar, WizardFooter, WizardStep } from './Wizard';
import { useIsAdmin } from '../role';

const PAGE_TITLES: Record<string, string> = {
  connect: 'Connections', schema: 'Schema & snapshot', assessment: 'Assessment', analysis: 'Detailed report', code: 'Code objects (GenAI)',
  migrate: 'Migrate', runs: 'Live monitor', validation: 'Validation', settings: 'Settings', sql: 'SQL Workbench',
};

function Body() {
  const { error, name, project, snapshot, activeRunId, live } = useProject();
  const { pathname } = useLocation();
  const admin = useIsAdmin();
  const base = `/projects/${name}`;
  const page = pathname.slice(base.length + 1).split('/')[0];
  const connected = !!(project?.oracle && project?.postgres);
  const p = project as any;

  // The project's path, in order. Live monitor belongs to the Migrate step.
  const steps: WizardStep[] = [
    { key: 'connect', route: 'connect', label: 'Connect', done: connected },
    { key: 'schema', route: 'schema', label: 'Snapshot', done: !!snapshot },
    { key: 'assessment', route: 'assessment', label: 'Assess', done: !!snapshot },
    ...(admin ? [{ key: 'settings', route: 'settings', label: 'Settings', optional: true, done: !!p?.settings?.decisions?.agreedBy }] : []),
    { key: 'code', route: 'code', label: 'Code (GenAI)', optional: true, done: !!(p?.codeExportAt || p?.codeAppliedAt) },
    { key: 'migrate', route: 'migrate', label: 'Migrate', also: ['runs'], done: ['COMPLETED', 'COMPLETED_WITH_ERRORS'].includes(project?.migrationStatus || '') },
    { key: 'validation', route: 'validation', label: 'Validate' },
  ];
  const current = steps.findIndex((s) => s.route === page || (s.also || []).includes(page));

  const sections: NavSection[] = [
    { title: 'Workspace', items: [{ to: '/', label: 'Home', icon: <HomeRoundedIcon />, end: true }, { to: '/projects', label: 'All projects', icon: <FolderCopyRoundedIcon />, end: true }, { to: '/guide', label: 'Guide', icon: <MenuBookRoundedIcon />, end: true }] },
    {
      title: 'Project',
      header: (
        <Box sx={{ mx: 0.5, mb: 1.5, p: 1.5, borderRadius: 3, bgcolor: 'rgba(255,255,255,.06)', border: '1px solid rgba(255,255,255,.08)' }}>
          <Typography sx={{ fontWeight: 800, fontSize: 15, color: '#fff' }} noWrap title={name}>{name}</Typography>
          <Typography sx={{ fontSize: 12, color: 'rgba(255,255,255,.6)' }} noWrap>{project ? `${project.appName} · ${project.appCode}` : '…'}</Typography>
          <Stack direction="row" spacing={0.75} sx={{ mt: 1 }}>
            <Chip size="small" label={project?.selectedSchema || 'No schema'} sx={{ bgcolor: 'rgba(255,255,255,.12)', color: '#fff', height: 22, fontSize: 11.5 }} />
            <Chip size="small" label={live ? 'Live' : 'Offline'} sx={{ bgcolor: live ? 'rgba(14,159,110,.3)' : 'rgba(255,255,255,.08)', color: live ? '#7CF0C3' : 'rgba(255,255,255,.6)', height: 22, fontSize: 11.5 }} />
          </Stack>
        </Box>
      ),
      items: [
        { to: `${base}/connect`, label: 'Connections', icon: <CableRoundedIcon />, badge: connected ? 'done' : null },
        { to: `${base}/schema`, label: 'Schema & snapshot', icon: <AccountTreeRoundedIcon />, badge: snapshot ? 'done' : null },
        { to: `${base}/assessment`, label: 'Assessment', icon: <InsightsRoundedIcon /> },
        { to: `${base}/code`, label: 'Code objects (GenAI)', icon: <AutoAwesomeRoundedIcon />, badge: p?.codeExportAt || p?.codeAppliedAt ? 'done' : null },
        { to: `${base}/migrate`, label: 'Migrate', icon: <RocketLaunchRoundedIcon /> },
        { to: `${base}/runs`, label: 'Live monitor', icon: <MonitorHeartRoundedIcon />, badge: activeRunId ? 'live' : null },
        { to: `${base}/validation`, label: 'Validation', icon: <FactCheckRoundedIcon /> },
        { to: `${base}/sql`, label: 'SQL Workbench', icon: <TerminalRoundedIcon /> },
        // Optional, for the DBA or architect: not part of the step bar.
        { to: `${base}/analysis`, label: admin === false ? 'ora2pg report' : 'Detailed report', icon: <AssessmentRoundedIcon />, badge: p?.analysisAt ? 'done' : null },
        // Last in the menu, admins only: decisions, notifications and engine defaults for the whole project.
        ...(admin ? [{ to: `${base}/settings`, label: 'Settings', icon: <TuneRoundedIcon />, badge: p?.settings?.decisions?.agreedBy ? 'done' as const : null }] : []),
      ],
    },
  ];

  return (
    <Shell sections={sections}
      crumbs={[{ label: 'Projects', to: '/projects' }, { label: name, to: `${base}/connect` }, { label: page === 'analysis' && admin === false ? 'ora2pg report' : PAGE_TITLES[page] || '' }]}
      topRight={<StatusChip status={activeRunId ? 'RUNNING' : project?.migrationStatus} />}>
      {error ? <Alert severity="error">{error}</Alert> : (
        <>
          <WizardBar steps={steps} current={current} base={base} />
          <PageBoundary resetKey={pathname}><Outlet /></PageBoundary>
          <WizardFooter steps={steps} current={current} base={base} />
        </>
      )}
    </Shell>
  );
}

export default function ProjectLayout() {
  const { name = '' } = useParams();
  return (
    <ProjectProvider key={name} name={name}>
      <Body />
    </ProjectProvider>
  );
}
