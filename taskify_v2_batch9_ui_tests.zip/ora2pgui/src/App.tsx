import SqlPage from './pages/SqlPage';
import { Navigate, Route, Routes, useLocation } from 'react-router-dom';
import PageBoundary from './components/PageBoundary';
import ProjectLayout from './components/ProjectLayout';
import ProjectsPage from './pages/ProjectsPage';
import GuidePage from './pages/GuidePage';
import HomePage from './pages/HomePage';
import ConnectPage from './pages/ConnectPage';
import SchemaPage from './pages/SchemaPage';
import AssessmentPage from './pages/AssessmentPage';
import MigratePage from './pages/MigratePage';
import RunsPage from './pages/RunsPage';
import RunPage from './pages/RunPage';
import ValidationPage from './pages/ValidationPage';
import CodePage from './pages/CodePage';
import SettingsPage from './pages/SettingsPage';
import AnalysisPage from './pages/AnalysisPage';

function App() {
  const { pathname } = useLocation();
  return (
    <PageBoundary resetKey={pathname}>
    <Routes>
      <Route path="/" element={<HomePage />} />
      <Route path="/projects" element={<ProjectsPage />} />
      <Route path="/guide" element={<GuidePage />} />
      <Route path="/projects/:name" element={<ProjectLayout />}>
        <Route index element={<Navigate to="connect" replace />} />
        <Route path="connect" element={<ConnectPage />} />
        <Route path="schema" element={<SchemaPage />} />
        <Route path="assessment" element={<AssessmentPage />} />
        <Route path="migrate" element={<MigratePage />} />
        <Route path="runs" element={<RunsPage />} />
        <Route path="runs/:runId" element={<RunPage />} />
        <Route path="validation" element={<ValidationPage />} />
        <Route path="sql" element={<SqlPage />} />
        <Route path="analysis" element={<AnalysisPage />} />
        <Route path="code" element={<CodePage />} />
        <Route path="settings" element={<SettingsPage />} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
    </PageBoundary>
  );
}

export default App;
