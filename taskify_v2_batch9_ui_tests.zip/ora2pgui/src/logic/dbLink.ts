/**
 * Oracle DB link addresses for the DB link mapping (Code objects page).
 */
export type LinkAddress = { host: string; port: string; dbname: string };

/** Oracle's link address (//host:port/service, host:port/service or a TNS description) → host, port, service. */
export function parseLinkHost(h: string): LinkAddress {
  const tns = /HOST\s*=\s*([^)\s]+)[\s\S]*?PORT\s*=\s*(\d+)[\s\S]*?(?:SERVICE_NAME|SID)\s*=\s*([^)\s]+)/i.exec(h || '');
  if (tns) return { host: tns[1], port: tns[2], dbname: tns[3] };
  const m = /^\/*([^:/]+)(?::(\d+))?(?:\/([^\s]+))?/.exec((h || '').trim());
  return m ? { host: m[1], port: m[2] || '1521', dbname: m[3] || '' } : { host: '', port: '', dbname: '' };
}

/** A description with several addresses (primary + standby): kept whole, oracle_fdw uses it as it is. */
export const hasSeveralAddresses = (h: string) => /\(ADDRESS\s*=[\s\S]*\(ADDRESS\s*=/i.test(h || '');

/** What the mapping form starts with when a mode is chosen, from Oracle's own link definition. */
export function prefillFromOracle(mode: string, oracleHost: string): LinkAddress {
  if (mode !== 'oracle_fdw') return { host: '', port: '', dbname: '' };
  if (hasSeveralAddresses(oracleHost)) return { host: oracleHost.trim(), port: '', dbname: '' };
  return parseLinkHost(oracleHost);
}
