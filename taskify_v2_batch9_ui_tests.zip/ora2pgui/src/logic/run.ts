/**
 * Live monitor logic: what a table shows, and the run's overall progress.
 */
export type RunTable = {
  status: string; sizeMb: number; estRows: number; rowsDone: number; waiting?: boolean;
  chunkInfo?: { total: number; done: number; running: number; queued?: number; failed: number };
};
export type RunPhase = { status: string };

/** Started, but waiting for a free load slot (auto-tune): shown as waiting, not loading. A table in
 * parts waits while none of its parts loads and some are queued. */
export const waitingSlot = (t: RunTable) => t.status === 'running' && (!!t.waiting || (!!t.chunkInfo && !t.chunkInfo.running && !!t.chunkInfo.queued));
export const shownStatus = (t: RunTable) => (waitingSlot(t) ? 'pending' : t.status);

/** Share of the work done (0–100), weighted by table size (a 500 GB table counts more than a 1 MB one). */
export function overallProgress(run: { tables: Record<string, RunTable>; phases: RunPhase[] }) {
  const tables = Object.values(run.tables || {});
  const phases = run.phases || [];
  const phaseShare = phases.length ? phases.filter((p) => ['done', 'warning', 'skipped'].includes(p.status)).length / phases.length : 0;
  const total = tables.reduce((s, t) => s + Math.max(Number(t.sizeMb) || 0, 0.01), 0);
  const loaded = tables.reduce((s, t) => {
    const w = Math.max(Number(t.sizeMb) || 0, 0.01);
    if (t.status === 'done' || t.status === 'failed') return s + w;
    if (t.status === 'running' && t.estRows > 0) return s + w * Math.min((t.rowsDone || 0) / t.estRows, 0.99);
    return s;
  }, 0);
  const dataShare = total ? loaded / total : 0;
  // Data loading is the bulk of a run: 80% of the bar, the other phases 20%.
  return Math.max(0, Math.min(100, (dataShare * 0.8 + phaseShare * 0.2) * 100));
}
