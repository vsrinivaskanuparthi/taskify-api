/**
 * Assessment estimates: time from the measured (or v1 reference) speed, and server shortfalls.
 */
export const REFERENCE_MBPS = (30 * 1024) / 3600; // v1: 450 GB in 15 h

/** Data load at the given MB/s plus ~35% for indexes and keys, in words. */
export function estimateText(totalMb: number, mbps: number) {
  const minutes = Math.max(1, Math.round((((Number(totalMb) || 0) / Math.max(Number(mbps) || 0, 0.1)) * 1.35) / 60));
  return minutes < 60 ? `about ${minutes} min` : `about ${(minutes / 60).toFixed(minutes < 600 ? 1 : 0)} h`;
}

export type Sizing = {
  speed: { mbps: number; measured: boolean };
  server: { cpus: number; ramGb: number; stagingDir: string; disk: { freeGb: number; totalGb: number } | null };
  need: { parallelTables: number; loadMode: 'direct' | 'file' | 'export'; cpus: number; ramGb: number; stagingGb: { direct: number; file: number; export: number } };
};

/** What this server has less of than the run needs (CPU cores, RAM, disk space). */
export const shortOf = (sz: Sizing | null) => (sz ? [
  sz.server.cpus < sz.need.cpus && 'CPU cores',
  sz.server.ramGb < sz.need.ramGb - 0.5 && 'RAM',
  sz.server.disk && sz.server.disk.freeGb < sz.need.stagingGb[sz.need.loadMode] * 1.2 && 'disk space',
].filter(Boolean) as string[] : []);
