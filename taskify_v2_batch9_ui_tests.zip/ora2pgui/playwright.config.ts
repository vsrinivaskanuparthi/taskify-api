import { defineConfig } from '@playwright/test';

/**
 * Browser tests: a real browser clicks through DMA like a user. They need the app running
 * (UI and backend, with test databases) and a connected, snapshotted project:
 *   DMA_UI_URL       the UI, default http://localhost:5175 (npm run dev)
 *   DMA_E2E_PROJECT  the project to use, default E2E_TEST
 *   PW_CHANNEL       the installed browser to drive, default chrome ("msedge" on Windows also works)
 */
export default defineConfig({
  testDir: 'tests/e2e',
  timeout: 5 * 60 * 1000,
  expect: { timeout: 15000 },
  fullyParallel: false,
  workers: 1,
  reporter: [['list']],
  use: {
    baseURL: process.env.DMA_UI_URL || 'http://localhost:5175',
    channel: process.env.PW_CHANNEL || 'chrome',
    viewport: { width: 1440, height: 900 },
    screenshot: 'only-on-failure',
    trace: 'retain-on-failure',
  },
});
