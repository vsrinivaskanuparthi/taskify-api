# DMA v2: batch 9, screen tests + robustness

Only the UI (`ora2pgui`) changes. No backend change, no `.env` change.

## What's new

**1. Automatic tests for the screens (first time)**

| Kind | Tool | Tests | What it checks |
|---|---|---|---|
| Logic + components | Vitest | 39 | Sizes, times, estimates, DB link addresses, waiting status, tables, preferences, error help, API errors |
| Real browser | Playwright | 23 | Every page opens without errors; SQL Workbench; migrate a table → Live monitor → Validation; bell; preferences; settings; DB link button |

**2. Robustness fixes the tests found**

| Problem | Now |
|---|---|
| A page error showed a **white screen** | "This page could not be shown" with **Try again**; the menu keeps working |
| A table on page 3 of results showed "No rows" (stuck) when new data had fewer rows | Jumps back to a page that has rows |
| An unknown size showed "0 KB" | Shows "—" |
| Live monitor list: names broke in the middle ("JAGUAR_AP / P") | Kept on one line |
| Progress could become "NaN %" with odd data | Always 0–100 |

**3. Code moved, behaviour unchanged:** screen logic is now in `src/logic/` (`dbLink.ts`, `run.ts`, `estimate.ts`), so it can be tested.

## Files (ora2pgui)

| What | Files |
|---|---|
| New | `src/logic/*.ts`, `src/components/PageBoundary.tsx`, `tests/unit/*`, `tests/e2e/*`, `vitest.config.ts`, `playwright.config.ts` |
| Changed | `package.json`, `package-lock.json`, `.gitignore`, `src/App.tsx`, `src/format.ts`, `src/components/DataTable.tsx`, `src/components/ProjectLayout.tsx`, `src/pages/AssessmentPage.tsx`, `src/pages/CodePage.tsx`, `src/pages/RunPage.tsx`, `src/pages/RunsPage.tsx` |

The test tools are **dev-only**: nothing from them goes into `dist/index.html`.

## Deploy

1. Copy `ora2pgui/` over your folder.
2. `npm install` (adds the dev test tools: Vitest, Testing Library, Playwright).
3. `npm test`: should end with **39 passed**.
4. `npm run build`, then copy `index.html` to nginx as usual and press Ctrl+F5.

## Run the browser tests (optional, on a PC with Chrome or Edge)

They need the app running (UI and backend) and a connected, snapshotted project:
```
set DMA_UI_URL=http://localhost:5175
set DMA_E2E_PROJECT=E2E_TEST
npm run test:e2e
```
- On Windows with Edge instead of Chrome: `set PW_CHANNEL=msedge`.
- One test migrates the table PLANT into the project's target schema: use a **test project**, never a real one.
