# DMA v2: final batch (Settings tests + 4 fixes + auto-tune speed)

How to deploy it by hand on RHEL (without deploy.bat), and what to test afterwards.

---

## 1. What is in this zip

| Folder | Files | What changed |
|---|---|---|
| `ora2pgservice/services/autoTune.js` | **new** | Auto-tune speed: measures MB/s and changes how many loads run at once |
| `ora2pgservice/services/migrate.js` | changed | Auto-tune wired in; 3 bug fixes (calculated columns checked, preserve case loads data, skip constraint types done by DMA) |
| `ora2pgservice/services/config_modify.js` | changed | Fix: preserve case / reserved-word table names load data (`ON_ERROR_STOP 1`) |
| `ora2pgservice/services/settings.js` | changed | New Run defaults: auto-tune on/off, most loads at once; clearer help texts; `SKIP` no longer passed to ora2pg (it crashed) |
| `ora2pgservice/services/sqlRunner.js` | changed | Lets DMA leave out skipped constraints |
| `ora2pgservice/controllers/runController.js` | changed | Migrate page explains auto-tune |
| `ora2pgservice/utils/constants.js` | changed | `AUTO_TUNE` default |
| `ora2pgservice/.env.optional` | changed | Documents `AUTO_TUNE`, `AUTO_TUNE_SECONDS` (nothing to add to your .env) |
| `ora2pgservice/tests/...` | new / changed | Automatic tests (66 unit tests, 29 real-migration tests) |
| `ora2pgui/src/pages/SettingsPage.tsx` | changed | Auto-tune switch in Settings → Run defaults |
| `ora2pgui/src/pages/RunPage.tsx` | changed | Auto-tune line on the Live monitor |

**Not in the zip:** `server.js` (not changed; yours keeps the SSO setup and certificate) and `.env`.
**No new npm packages:** no `npm install` needed.

---

## 2. Copy the files (Windows Workspace)

1. Unzip.
2. Copy the contents of `ora2pgservice/` over your `ora2pgservice` folder (same sub-folders).
3. Copy the contents of `ora2pgui/` over your `ora2pgui` folder.
4. Optional but recommended, in `ora2pgservice`:
   ```
   npm test
   ```
   It should end with **Tests: 66 passed**. If something fails, stop and send me the output.
5. Build the screens, in `ora2pgui`:
   ```
   npm run build
   ```
   This gives `ora2pgui/dist/index.html`.
6. Push the `ora2pgservice` code to your repository as usual.

---

## 3. Deploy on RHEL by hand

Log in as the user that runs pm2 (the API and the worker must run as the **same** user).

### 3a. Is a migration running right now?

```bash
curl -s http://127.0.0.1:5101/health
```

- `"running":0` → nothing runs, go on.
- Any other number → a migration runs. You can still restart the **API** (step 3c), but restart the **worker** (step 3d) only after it ends. Otherwise it is interrupted (resumable, but it stops).

### 3b. Get the new code

```bash
cd /path/to/ora2pgservice
git pull
```

Check that the new file is there:

```bash
ls -l services/autoTune.js
```

### 3c. Restart the API

```bash
pm2 restart ora2pg-service-prod
```

Check:

```bash
curl -s http://127.0.0.1:5000/api/health
pm2 logs ora2pg-service-prod --lines 30 --nostream
```

- Health answers `{"status":"ok",...}`.
- The log shows **"Connected to the migration worker"**.
- No `EADDRINUSE`. If you see it, an old API copy still runs: `pm2 list`, then `pm2 delete` the duplicate.

### 3d. Restart the worker (only when no migration runs)

```bash
pm2 restart ora2pg-worker-prod
curl -s http://127.0.0.1:5101/health
pm2 logs ora2pg-worker-prod --lines 30 --nostream
```

- Health answers with `"running":0`.
- The log shows **"DMA migration worker is running on 127.0.0.1:5101"**.

The migration engine (`services/...`) runs in the **worker**. Until the worker is restarted, migrations still use the old engine.

### 3e. Save the pm2 list (so both come back after a server reboot)

```bash
pm2 save
pm2 list
```

Both `ora2pg-service-prod` and `ora2pg-worker-prod` should be **online**.

### 3f. Put in the new screens

Copy `ora2pgui/dist/index.html` from Windows to the server (e.g. to `/tmp/dma_index.html`), then:

```bash
sudo cp -p /usr/share/nginx/html/index.html /usr/share/nginx/html/index.html.previous
sudo install -m 644 /tmp/dma_index.html /usr/share/nginx/html/index.html
sudo restorecon /usr/share/nginx/html/index.html
```

(Use your nginx folder if it is not `/usr/share/nginx/html`.) No nginx restart is needed. In the browser press **Ctrl+F5**.

### Going back (rollback)

- **Auto-tune only:** Settings → Run defaults → switch **Auto-tune speed** off. DMA then runs exactly as before; no redeploy needed.
- **Screens:**
  ```bash
  sudo cp -p /usr/share/nginx/html/index.html.previous /usr/share/nginx/html/index.html
  ```
- **Code:**
  ```bash
  git checkout <previous commit>
  pm2 restart ora2pg-service-prod ora2pg-worker-prod
  ```

---

## 4. What to test and observe

### Test 1: everything is up (5 minutes)

- [ ] `pm2 list`: both apps online, restarts not climbing.
- [ ] The app opens after Ctrl+F5.
- [ ] **Settings → Run defaults** shows **"Auto-tune speed during the run (recommended)"**, switched on, and **"Most loads at once"** (0). Saving works.
- [ ] **Migrate** page: select a few tables. The "Speed settings chosen by DMA" box has a new last line: *"Auto-tune: starts with X loads at once … up to Y."*

### Test 2: a small run (2–3 small tables)

- [ ] It completes; row counts and data check green.
- [ ] The Live monitor shows a line under the numbers: *"Auto-tune: 2 loads at once (2–8) · …"*.
- [ ] After the run the line says *"Auto-tune ended at …"*.

### Test 3: a medium or big run (several GB, many tables; this is the real test)

Pick tables you migrated before, so you can compare the speed.

While it runs, every few minutes:
- [ ] Look at the **Auto-tune** line. Over time it should either **add loads** (the number goes up) or say why not:
  - *"all remaining work is already running"*: fine, nothing is waiting;
  - *"this server's CPU is busy"* or *"short of memory"*: the RHEL server is the limit;
  - *"N readers were not faster: back to M"*: the right number was found.
- [ ] **Hover** over the line: the history of changes and what takes most of the time (Oracle, network, ora2pg or PostgreSQL).
- [ ] Keep an eye on Oracle and PostgreSQL. If the DBA sees too many sessions, lower **Most loads at once** in Settings (e.g. 4).

After it ends:
- [ ] Status COMPLETED, all tables verified.
- [ ] Compare **total time / MB/s** with the earlier run of the same tables. It should be **the same or faster**.
- [ ] **Where did the time go?** card on the run page: note the biggest part.
- [ ] Logs → **Master log**, search for `Auto-tune window`. One line per window: speed, loads at once, how busy, how many waiting, and the decision.

### Test 4: the bug fixes (only if you use these options)

- [ ] A project with **Keep Oracle upper case (PRESERVE_CASE)** on: the data really loads (rows > 0), and calculated columns are created.
- [ ] **Settings → Advanced → Skip constraint types** = `indexes`: the run does **not** crash, indexes are not created, and primary keys are still there.
- [ ] A table with a calculated NUMBER column (like `QTY*PRICE`): its data check is green.

### Test 5: deploy during a migration (the batch 3 promise)

- [ ] Start a migration, then run `pm2 restart ora2pg-service-prod`. The migration **keeps running**, and the Live monitor reconnects by itself.

---

## 5. What to send me

1. The `Auto-tune window` lines from the master log of the big run (Test 3).
2. A screenshot of the Live monitor with the Auto-tune line, and of the **Where did the time go?** card.
3. The speed (MB/s) and total time, old run vs new run of the same tables.
4. Anything red, or any message you do not understand.
