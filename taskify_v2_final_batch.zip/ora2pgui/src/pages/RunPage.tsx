import { Alert, Box, Button, Chip, CircularProgress, Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle, IconButton, LinearProgress, Menu, MenuItem, Stack, Tab, Tabs, Tooltip, Typography } from '@mui/material';
import StopCircleRoundedIcon from '@mui/icons-material/StopCircleRounded';
import ReplayRoundedIcon from '@mui/icons-material/ReplayRounded';
import DownloadRoundedIcon from '@mui/icons-material/DownloadRounded';
import FactCheckRoundedIcon from '@mui/icons-material/FactCheckRounded';
import ArticleRoundedIcon from '@mui/icons-material/ArticleRounded';
import RefreshRoundedIcon from '@mui/icons-material/RefreshRounded';
import CloseRoundedIcon from '@mui/icons-material/CloseRounded';
import VerifiedRoundedIcon from '@mui/icons-material/VerifiedRounded';
import ArrowBackRoundedIcon from '@mui/icons-material/ArrowBackRounded';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { api, apiUrl, projectPath } from '../api';
import { useProject } from '../context/ProjectContext';
import { Ring } from '../components/charts';
import DataTable from '../components/DataTable';
import { CheckIcon, SectionCard, StatusChip } from '../components/ui';
import { fmtCompact, fmtDate, fmtDuration, fmtInt, fmtMb } from '../format';
import { brand } from '../theme';
import ActivityPanel, { RunEvent } from '../components/ActivityPanel';
import ErrorHelp from '../components/ErrorHelp';
import { explainError } from '../errorHelp';
import TimeReport from '../components/TimeReport';

/**
 * Errors from the run's error log (types, sequences, indexes… that do not belong to one table),
 * each once, with its plain-words explanation. Refreshed when the run's status or counts change.
 */
function LogProblems({ name, runId, refreshKey }: { name: string; runId: string; refreshKey: string }) {
  const [items, setItems] = useState<{ text: string; count: number }[]>([]);
  useEffect(() => {
    fetch(apiUrl(`${projectPath(name)}/runs/${runId}/logs/error?tail=64`), { credentials: 'include' })
      .then((r) => (r.ok ? r.text() : ''))
      .then((text) => {
        const seen = new Map<string, number>();
        for (const line of text.split('\n')) {
          const m = /^\[[^\]]+\] !!! (.*)$/.exec(line);
          if (!m || /FAILED \(exit|^Run |attempt \d+/i.test(m[1])) continue;
          const msg = m[1].replace(/psql:[^\s]+:\d+:\s*/, '').trim();
          seen.set(msg, (seen.get(msg) || 0) + 1);
        }
        // Real problems first; harmless ones ("already exists" on a re-run) last.
        const harmless = (t: string) => explainError(t)?.impact === 'none';
        setItems([...seen].map(([t, count]) => ({ text: t, count })).sort((a, b) => Number(harmless(a.text)) - Number(harmless(b.text))).slice(0, 30));
      })
      .catch(() => setItems([]));
  }, [name, runId, refreshKey]);
  if (!items.length) return null;
  const harmless = items.filter((it) => explainError(it.text)?.impact === 'none').length;
  return (
    <SectionCard collapsible storeKey="run.logProblems" title={`${items.length} error${items.length === 1 ? '' : 's'} in this run’s log${harmless ? ` (${harmless === items.length ? 'all' : harmless} harmless)` : ''}`}
      subtitle="Each error once, with what it means. The run’s error log (Logs → Errors) has the full lines.">
      <Stack spacing={1.25} sx={{ maxHeight: 420, overflow: 'auto' }}>
        {items.map((it) => (
          <Box key={it.text} sx={{ p: 1.5, border: 1, borderColor: 'divider', borderRadius: 2 }}>
            <Typography variant="body2" color={explainError(it.text)?.impact === 'none' ? 'text.secondary' : 'error.main'} sx={{ overflowWrap: 'anywhere' }}>{it.text}{it.count > 1 ? ` (×${it.count})` : ''}</Typography>
            <ErrorHelp text={it.text} />
          </Box>
        ))}
      </Stack>
    </SectionCard>
  );
}

type TableState = { name: string; kind: string; estRows: number; sizeMb: number; status: string; attempts: number; rowsDone: number; rate: number; startedAt?: string; finishedAt?: string; error?: string | null; pgRows?: number; oracleRows?: number; chunkInfo?: { total: number; done: number; running: number; failed: number }; dataCheck?: { columns: number; ok: boolean; diffs: { column: string; oracle: string; postgres: string }[] }; timeSplit?: Record<string, number>; waiting?: boolean };
type Phase = { key: string; label: string; status: string; progress?: number; detail?: string | null; startedAt?: string; finishedAt?: string; warnings?: number };
type RunState = { runId: string; schema: string; targetSchema: string; status: string; attempt: number; createdAt: string; startedAt: string | null; finishedAt: string | null; error?: string | null; options: any; phases: Phase[]; tables: Record<string, TableState>; events: RunEvent[]; ddlFailures?: { step: string; statement: string; error: string }[]; codePackageId?: string | null; codeResult?: { packageId: string; applied: number; existing?: number; failed: { path: string; error: string }[]; dbLinks: string | null }; timeSplitNote?: string | null; speed?: Speed | null };
type Speed = { auto: boolean; readers: number; min: number; max: number; mbps: number; why: string; slowSide?: string | null; history?: { at: string; action: string; from: number | null; readers: number; mbps: number; why: string }[] };

const RUNNING = ['RUNNING', 'QUEUED'];

const TUNE_ACTION: Record<string, string> = { start: 'Started', up: 'Added', back: 'Stepped back', down: 'Removed' };

/** Auto-tune status in the hero: loads at once now, the last decision, and its history on hover. */
function SpeedLine({ speed, running }: { speed: Speed; running: boolean }) {
  const changes = (speed.history || []).filter((h) => h.action !== 'start');
  const best = Math.max(0, ...(speed.history || []).map((h) => h.readers));
  const text = running
    ? `Auto-tune: ${speed.readers} loads at once (${speed.min}–${speed.max})${speed.mbps ? ` · ${speed.mbps} MB/s last window` : ''}${speed.why ? ` · ${speed.why}` : ''}`
    : `Auto-tune ended at ${speed.readers} loads at once (most used: ${best}, allowed ${speed.max})${changes.length ? `, ${changes.length} change${changes.length === 1 ? '' : 's'}` : ''}`;
  const history = (
    <Box sx={{ p: 0.5 }}>
      {(speed.history || []).slice(-12).map((h) => (
        <Typography key={h.at} fontSize={12}>{fmtDate(h.at)} · {TUNE_ACTION[h.action] || h.action}: {h.from != null && h.from !== h.readers ? `${h.from} → ` : ''}{h.readers}{h.mbps ? ` · ${h.mbps} MB/s` : ''}</Typography>
      ))}
      {speed.slowSide && <Typography fontSize={12} sx={{ mt: 0.5, fontWeight: 700 }}>{speed.slowSide}.</Typography>}
    </Box>
  );
  return (
    <Tooltip title={history} placement="bottom-start">
      <Typography sx={{ mt: 2, fontSize: 13, opacity: 0.9, cursor: 'help', overflowWrap: 'anywhere' }}>
        {text}{running && speed.slowSide ? ` · ${speed.slowSide}` : ''}
      </Typography>
    </Tooltip>
  );
}

/** Share of the work done, weighted by table size (a 500 GB table counts more than a 1 MB one). */
function overallProgress(run: RunState) {
  const tables = Object.values(run.tables);
  const phaseShare = run.phases.filter((p) => ['done', 'warning', 'skipped'].includes(p.status)).length / run.phases.length;
  const total = tables.reduce((s, t) => s + Math.max(t.sizeMb, 0.01), 0);
  const loaded = tables.reduce((s, t) => {
    const w = Math.max(t.sizeMb, 0.01);
    if (t.status === 'done' || t.status === 'failed') return s + w;
    if (t.status === 'running' && t.estRows > 0) return s + w * Math.min(t.rowsDone / t.estRows, 0.99);
    return s;
  }, 0);
  const dataShare = total ? loaded / total : 0;
  // Data loading is the bulk of a run: 80% of the bar, the other phases 20%.
  return Math.min(100, (dataShare * 0.8 + phaseShare * 0.2) * 100);
}

function LogDialog({ run, table, onClose }: { run: RunState; table: string | null; onClose: () => void }) {
  const { name } = useProject();
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(false);
  const load = useCallback(async () => {
    if (!table) return;
    setLoading(true);
    try {
      const res = await fetch(apiUrl(`${projectPath(name)}/runs/${run.runId}/logs/table?table=${encodeURIComponent(table)}&tail=96`));
      setText(res.ok ? await res.text() : 'No log yet for this table.');
    } finally {
      setLoading(false);
    }
  }, [name, run.runId, table]);
  useEffect(() => { load(); }, [load]);
  return (
    <Dialog open={!!table} onClose={onClose} fullWidth maxWidth="lg">
      <DialogTitle sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
        <ArticleRoundedIcon color="primary" /> <span className="mono">{table}</span>
        <Box sx={{ flex: 1 }} />
        <Tooltip title="Reload"><IconButton onClick={load}>{loading ? <CircularProgress size={18} /> : <RefreshRoundedIcon />}</IconButton></Tooltip>
        <Button size="small" startIcon={<DownloadRoundedIcon />} href={apiUrl(`${projectPath(name)}/runs/${run.runId}/logs/table?table=${encodeURIComponent(table || '')}`)}>Full log</Button>
        <IconButton onClick={onClose}><CloseRoundedIcon /></IconButton>
      </DialogTitle>
      <DialogContent>
        <Box component="pre" className="mono" sx={{ m: 0, p: 2, bgcolor: '#0B1730', color: '#D6E4FF', borderRadius: 2, fontSize: 12.5, maxHeight: '65vh', overflow: 'auto', whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>
          {text || 'Loading…'}
        </Box>
      </DialogContent>
    </Dialog>
  );
}

export default function RunPage() {
  const { runId = '' } = useParams();
  const { name, subscribe, live } = useProject();
  const navigate = useNavigate();
  const [run, setRun] = useState<RunState | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [tab, setTab] = useState('all');
  const [now, setNow] = useState(Date.now());
  const [busy, setBusy] = useState(false);
  const [logTable, setLogTable] = useState<string | null>(null);
  const [menu, setMenu] = useState<HTMLElement | null>(null);
  const [confirmCancel, setConfirmCancel] = useState(false);

  const load = useCallback(async () => {
    try {
      setRun(await api<RunState>(`${projectPath(name)}/runs/${runId}`));
    } catch (e: any) {
      setError(e.message);
    }
  }, [name, runId]);
  useEffect(() => { load(); }, [load]);

  // Live updates pushed by the server.
  useEffect(() => subscribe((e) => {
    if (!e.data || e.data.runId !== runId) return;
    if (e.type === 'runFull') setRun(e.data);
    if (e.type === 'run') setRun((r) => (r ? { ...r, ...e.data, tables: r.tables } : r));
    if (e.type === 'table') setRun((r) => (r ? { ...r, tables: { ...r.tables, [e.data.table.name]: e.data.table } } : r));
    if (e.type === 'log') setRun((r) => (r ? { ...r, events: [...r.events.slice(-299), { at: e.data.at, level: e.data.level, message: e.data.message, ref: e.data.ref }] } : r));
  }), [subscribe, runId]);

  // When the live stream reconnects (e.g. after a network blip) the full state is reloaded once.
  useEffect(() => { if (live) load(); }, [live, load]);

  const isRunning = !!run && RUNNING.includes(run.status);
  // Clock for the elapsed time display only.
  useEffect(() => {
    if (!isRunning) return undefined;
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, [isRunning]);

  const tables = useMemo(() => (run ? Object.values(run.tables) : []), [run]);
  const counts = useMemo(() => {
    const c: Record<string, number> = { all: tables.length, running: 0, pending: 0, done: 0, failed: 0 };
    tables.forEach((t) => { c[t.status] = (c[t.status] || 0) + 1; });
    return c;
  }, [tables]);

  if (error) return <Alert severity="error">{error}</Alert>;
  if (!run) return <LinearProgress />;

  const pct = overallProgress(run);
  const rowsDone = tables.reduce((s, t) => s + (t.status === 'done' ? Math.max(t.rowsDone, t.pgRows || 0) : t.rowsDone || 0), 0);
  const estRows = tables.reduce((s, t) => s + (t.estRows || 0), 0);
  const rate = tables.filter((t) => t.status === 'running').reduce((s, t) => s + (t.rate || 0), 0);
  const end = run.finishedAt ? new Date(run.finishedAt).getTime() : now;
  const elapsed = run.startedAt ? end - new Date(run.startedAt).getTime() : 0;
  const remainingRows = Math.max(estRows - rowsDone, 0);
  // By size, not rows: a LOB table has few rows but many GB, so rows/s says little there.
  // MB per row comes from Oracle's size and row estimate of each table.
  const mbPerRow = (t: TableState) => (t.estRows > 0 ? t.sizeMb / t.estRows : 0);
  const mbOf = (t: TableState) => (t.status === 'done' ? t.sizeMb : Math.min(t.sizeMb, (t.rowsDone || 0) * mbPerRow(t)));
  const totalMb = tables.reduce((s, t) => s + (t.sizeMb || 0), 0);
  const loadedMb = tables.reduce((s, t) => s + mbOf(t), 0);
  const mbRate = tables.filter((t) => t.status === 'running').reduce((s, t) => s + (t.rate || 0) * mbPerRow(t), 0);
  const eta = !isRunning ? NaN
    : mbRate > 0 && totalMb > 0 ? (Math.max(totalMb - loadedMb, 0) / mbRate) * 1000
      : rate > 0 ? (remainingRows / rate) * 1000 : NaN;
  const doneMb = tables.filter((t) => t.status === 'done').reduce((s, t) => s + t.sizeMb, 0);
  const canResume = ['FAILED', 'COMPLETED_WITH_ERRORS', 'CANCELLED', 'INTERRUPTED'].includes(run.status);
  // An export-only run continues as an import: same run, same snapshot, the files are loaded.
  // Oracle's undo no longer reaches the run's SCN: resuming with the same snapshot would fail again.
  const undoLost = canResume && run.options?.snapshot !== 'off' && tables.some((t: any) => /undo no longer reaches/.test(t.error || ''));
  const canImport = run.status === 'EXPORTED' || (canResume && run.options?.loadMode === 'export' && !counts.failed && !counts.pending);

  const act = async (path: string, body: any = {}) => {
    setBusy(true);
    try {
      await api(`${projectPath(name)}/runs/${runId}/${path}`, { body });
      await load();
    } catch (e: any) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  };

  const visible = tab === 'all' ? tables : tables.filter((t) => t.status === tab);
  const activePhase = run.phases.find((p) => p.status === 'running');

  return (
    <>
      <Button size="small" startIcon={<ArrowBackRoundedIcon />} onClick={() => navigate('..', { relative: 'path' })} sx={{ mb: 1 }}>All runs</Button>

      <ActivityPanel events={run.events} phases={run.phases} tables={run.tables} runActive={isRunning} now={now} live={live} onOpenTable={setLogTable}>
        <Stack spacing={3} sx={{ minWidth: 0 }}>
          {/* Hero */}
          <Box sx={{ background: brand.gradient, color: '#fff', borderRadius: 4, p: { xs: 2.5, md: 3.5 }, position: 'relative', overflow: 'clip' }}>
            <Box sx={{ position: 'absolute', right: -60, bottom: -140, width: 380, height: 380, borderRadius: '50%', background: 'radial-gradient(circle, rgba(255,255,255,.12), transparent 70%)' }} />
            <Stack direction={{ xs: 'column', md: 'row' }} spacing={4} alignItems={{ md: 'center' }} sx={{ position: 'relative' }}>
              <Ring value={run.status === 'COMPLETED' ? 100 : pct} label={isRunning ? 'complete' : run.status === 'COMPLETED' ? 'done' : 'progress'} color={run.status === 'FAILED' ? '#FF8A80' : '#7FB2FF'} />
              <Box sx={{ flex: 1, minWidth: 0 }}>
                <Stack direction="row" spacing={1.5} alignItems="center" flexWrap="wrap" useFlexGap>
                  <Typography variant="h5" sx={{ fontSize: { xs: 20, md: 24 }, overflowWrap: 'anywhere' }}>{run.schema} → {run.targetSchema}</Typography>
                  <StatusChip status={run.status} />
                  {isRunning && <Chip size="small" label={live ? 'LIVE' : 'reconnecting…'} sx={{ bgcolor: live ? 'rgba(18,200,120,.25)' : 'rgba(255,255,255,.15)', color: '#fff', fontWeight: 800 }} />}
                </Stack>
                <Typography sx={{ opacity: 0.85, mt: 0.5 }} className="mono" fontSize={13}>
                  Run {run.runId}{run.attempt > 1 ? ` · resumed ${run.attempt - 1}×` : ''} · started {fmtDate(run.startedAt)}
                </Typography>
                {activePhase && <Typography sx={{ mt: 1.5, fontWeight: 600 }}>{activePhase.label}{activePhase.detail ? ` — ${activePhase.detail}` : ''}</Typography>}
                <Box sx={{ display: 'grid', gap: 2, gridTemplateColumns: 'repeat(auto-fill, minmax(118px, 1fr))', mt: 2.5 }}>
                  {[
                    ['Elapsed', fmtDuration(elapsed)],
                    ['Time left', isRunning ? (Number.isFinite(eta) ? `~${fmtDuration(eta)}` : 'calculating…') : '—'],
                    ['Tables', `${counts.done} / ${counts.all}${counts.failed ? ` · ${counts.failed} failed` : ''}`],
                    ['Rows loaded', `${fmtCompact(rowsDone)} / ${fmtCompact(estRows)}`],
                    ['Data loaded', `${fmtMb(isRunning ? loadedMb : doneMb)} / ${fmtMb(totalMb)}`],
                    ...(isRunning ? [['Speed', mbRate > 0 ? `${fmtMb(mbRate)}/s · ${fmtCompact(rate)} rows/s` : `${fmtCompact(rate)} rows/s`]] : []),
                  ].map(([k, v]) => (
                    <Box key={k} sx={{ minWidth: 0 }}>
                      <Typography sx={{ fontSize: 12, opacity: 0.75, textTransform: 'uppercase', letterSpacing: '.06em' }}>{k}</Typography>
                      <Typography sx={{ fontWeight: 800, fontSize: 18 }} noWrap title={v}>{v}</Typography>
                    </Box>
                  ))}
                </Box>
                {run.speed && <SpeedLine speed={run.speed} running={isRunning} />}
              </Box>
              <Stack spacing={1} sx={{ flexShrink: 0 }}>
                {isRunning && <Button variant="contained" color="error" startIcon={<StopCircleRoundedIcon />} disabled={busy} onClick={() => setConfirmCancel(true)}>Cancel run</Button>}
                {canImport && <Button variant="contained" sx={{ bgcolor: '#fff', backgroundImage: 'none', color: brand.navy, '&:hover': { bgcolor: brand.sky } }} startIcon={<ReplayRoundedIcon />} disabled={busy} onClick={() => act('resume', { options: { loadMode: 'file' } })}>Import exported files</Button>}
                {undoLost && <Tooltip title="Reads the remaining tables as they are now (no snapshot). Keep the application stopped."><Button variant="contained" sx={{ bgcolor: '#fff', color: brand.navy, '&:hover': { bgcolor: brand.sky } }} startIcon={<ReplayRoundedIcon />} disabled={busy} onClick={() => act('resume', { options: { snapshot: 'off' } })}>Resume without snapshot</Button></Tooltip>}
                {canResume && !canImport && <Button variant="contained" sx={{ bgcolor: '#fff', color: brand.navy, '&:hover': { bgcolor: brand.sky } }} startIcon={<ReplayRoundedIcon />} disabled={busy} onClick={() => act('resume')}>{counts.failed ? `Retry ${counts.failed} failed & resume` : 'Resume'}</Button>}
                <Button variant="outlined" sx={{ color: '#fff', borderColor: 'rgba(255,255,255,.45)', bgcolor: 'rgba(255,255,255,.06)', '&:hover': { bgcolor: 'rgba(255,255,255,.14)', borderColor: '#fff' } }} startIcon={<DownloadRoundedIcon />} onClick={(e) => setMenu(e.currentTarget)}>Logs</Button>
                {!isRunning && <Button variant="outlined" sx={{ color: '#fff', borderColor: 'rgba(255,255,255,.45)', bgcolor: 'rgba(255,255,255,.06)', '&:hover': { bgcolor: 'rgba(255,255,255,.14)', borderColor: '#fff' } }} startIcon={<FactCheckRoundedIcon />} onClick={() => navigate('../../validation', { relative: 'path' })}>Validate</Button>}
              </Stack>
            </Stack>
          </Box>
          <Menu anchorEl={menu} open={!!menu} onClose={() => setMenu(null)}>
            {[['master', 'Master log (everything)'], ['error', 'Errors only'], ['success', 'Completed steps']].map(([k, label]) => (
              <MenuItem key={k} component="a" href={apiUrl(`${projectPath(name)}/runs/${runId}/logs/${k}`)} onClick={() => setMenu(null)}>{label}</MenuItem>
            ))}
          </Menu>

          {run.error && <Alert severity={run.status === 'COMPLETED_WITH_ERRORS' || run.status === 'INTERRUPTED' ? 'warning' : 'error'} sx={{ overflowWrap: 'anywhere' }}>{run.error}<ErrorHelp text={run.error} /></Alert>}

          <SectionCard collapsible storeKey="run.phases" title="Phases" subtitle={`${run.phases.filter((p) => ['done', 'warning', 'skipped'].includes(p.status)).length} of ${run.phases.length} complete`}>
            <Box sx={{ display: 'grid', gap: 1.25, gridTemplateColumns: 'repeat(auto-fill, minmax(210px, 1fr))' }}>
              {run.phases.map((p, i) => {
                const dur = p.startedAt ? (p.finishedAt ? new Date(p.finishedAt).getTime() : now) - new Date(p.startedAt).getTime() : null;
                const active = p.status === 'running';
                return (
                  <Tooltip key={p.key} title={p.detail || ''} disableHoverListener={!p.detail}>
                    <Box sx={{
                      p: 1.5, borderRadius: 3, border: 1, minWidth: 0,
                      borderColor: active ? '#B2CCFA' : p.status === 'failed' ? '#FDA29B' : 'divider',
                      bgcolor: active ? '#F3F7FF' : p.status === 'pending' ? 'transparent' : '#FAFBFD',
                      boxShadow: active ? '0 0 0 3px rgba(11,87,208,.08)' : 'none',
                    }}>
                      <Stack direction="row" spacing={1} alignItems="center">
                        <Box sx={{ width: 22, height: 22, display: 'grid', placeItems: 'center', flexShrink: 0 }}>
                          {active ? <CircularProgress size={18} thickness={5} /> : <CheckIcon ok={p.status === 'done'} warn={p.status === 'warning'} pending={p.status === 'pending'} skipped={p.status === 'skipped'} />}
                        </Box>
                        <Typography fontSize={11} fontWeight={700} color="text.secondary" sx={{ letterSpacing: '.04em' }}>STEP {i + 1}</Typography>
                        <Box sx={{ flex: 1 }} />
                        <Typography fontSize={11.5} color="text.secondary">{dur !== null && p.status !== 'pending' ? fmtDuration(dur) : ''}</Typography>
                      </Stack>
                      <Typography fontWeight={active ? 750 : 600} fontSize={13.5} sx={{ mt: 0.75, lineHeight: 1.3 }} color={p.status === 'pending' ? 'text.secondary' : 'text.primary'}>{p.label}</Typography>
                      {active && <LinearProgress variant={p.progress ? 'determinate' : 'indeterminate'} value={p.progress || 0} sx={{ mt: 1, height: 5 }} />}
                      {(p.warnings || p.status === 'failed') ? (
                        <Typography variant="caption" color={p.status === 'failed' ? 'error.main' : 'warning.main'} noWrap sx={{ display: 'block', mt: 0.5 }}>
                          {p.warnings ? `${p.warnings} warnings` : p.detail}
                        </Typography>
                      ) : null}
                    </Box>
                  </Tooltip>
                );
              })}
            </Box>
          </SectionCard>

          <TimeReport phases={run.phases} tables={run.tables} note={run.timeSplitNote} now={now} />

          <SectionCard dense>
            <Tabs value={tab} onChange={(_, v) => setTab(v)} variant="scrollable" sx={{ px: 2, borderBottom: 1, borderColor: 'divider' }}>
              {[['all', 'All'], ['running', 'Loading'], ['pending', 'Waiting'], ['done', 'Done'], ...(counts.exported ? [['exported', 'Exported']] : []), ['failed', 'Failed']].map(([k, label]) => (
                <Tab key={k} value={k} label={<Stack direction="row" spacing={1} alignItems="center"><span>{label}</span><Chip size="small" label={counts[k] || 0} color={k === 'failed' && counts.failed ? 'error' : k === 'running' && counts.running ? 'primary' : 'default'} /></Stack>} />
              ))}
            </Tabs>
            <DataTable rows={visible} rowKey={(r) => r.name} searchKeys={['name']} pageSize={25} dense
              initialSort={{ key: 'status', dir: 'asc' }}
              columns={[
                { key: 'name', label: 'Table', render: (t) => <Box sx={{ minWidth: 140 }}><Typography className="mono" fontSize={13} fontWeight={600} sx={{ wordBreak: 'keep-all', overflowWrap: 'normal' }}>{t.name}</Typography><Typography variant="caption" color="text.secondary" sx={{ display: 'block', whiteSpace: 'nowrap' }}>{t.kind} · {fmtMb(t.sizeMb)}</Typography></Box> },
                { key: 'status', label: 'Status', sortValue: (t) => ({ running: 0, failed: 1, pending: 2, done: 3 } as any)[t.status] ?? 4, render: (t) => <StatusChip status={t.status} /> },
                { key: 'progress', label: 'Progress', sortValue: (t) => (t.estRows ? t.rowsDone / t.estRows : 0), render: (t) => {
                  const p = t.status === 'done' ? 100 : t.estRows ? Math.min((t.rowsDone / t.estRows) * 100, 99) : 0;
                  return (
                    <Box sx={{ minWidth: 140 }}>
                      <LinearProgress variant={t.status === 'running' && !t.rowsDone ? 'indeterminate' : 'determinate'} value={p} color={t.status === 'failed' ? 'error' : t.status === 'done' ? 'success' : 'primary'} />
                      <Typography variant="caption" color="text.secondary">{fmtInt(t.status === 'done' ? (t.pgRows ?? t.rowsDone) : t.rowsDone)} / {fmtInt(t.estRows)} rows{t.status === 'running' && t.rate ? ` · ${fmtCompact(t.rate)}/s${mbPerRow(t) ? ` · ${fmtMb(t.rate * mbPerRow(t))}/s` : ''}` : ''}{t.status === 'running' && t.waiting ? ' · waiting for a free load slot' : ''}{t.chunkInfo ? ` · parts ${t.chunkInfo.done}/${t.chunkInfo.total}${t.chunkInfo.running ? ` (${t.chunkInfo.running} loading)` : ''}${t.chunkInfo.failed ? ` · ${t.chunkInfo.failed} failed` : ''}` : ''}</Typography>
                    </Box>
                  );
                } },
                { key: 'verify', label: 'Verified', align: 'center', sortValue: (t) => (t.oracleRows !== undefined && t.oracleRows === t.pgRows ? 1 : 0), render: (t) => (t.oracleRows !== undefined && t.pgRows !== undefined ? (
                  <Tooltip title={`Oracle ${fmtInt(t.oracleRows)} · PostgreSQL ${fmtInt(t.pgRows)} rows${t.dataCheck ? (t.dataCheck.ok ? ` · ${t.dataCheck.columns} column checksums match` : ` · checksum differs: ${t.dataCheck.diffs.map((d) => `${d.column} (Oracle ${d.oracle}, PG ${d.postgres})`).join('; ')}`) : ''}`}>
                    {t.oracleRows === t.pgRows && (!t.dataCheck || t.dataCheck.ok) ? <VerifiedRoundedIcon color="success" fontSize="small" /> : <CheckIcon />}
                  </Tooltip>
                ) : '—') },
                { key: 'attempts', label: 'Tries', align: 'center', render: (t) => (t.attempts > 1 ? <Chip size="small" color="warning" label={t.attempts} /> : t.attempts || '—') },
                { key: 'time', label: 'Time', align: 'right', sortValue: (t) => (t.startedAt ? (t.finishedAt ? new Date(t.finishedAt).getTime() : now) - new Date(t.startedAt).getTime() : 0), render: (t) => (t.startedAt && t.status !== 'pending' ? fmtDuration((t.finishedAt ? new Date(t.finishedAt).getTime() : now) - new Date(t.startedAt).getTime()) : '—') },
                { key: 'log', label: '', align: 'right', render: (t) => (
                  <Stack direction="row" alignItems="center" justifyContent="flex-end" spacing={0.5}>
                    {t.error && t.status !== 'done' && <Tooltip title={t.error}><Typography variant="caption" color="error.main" noWrap sx={{ maxWidth: 220 }}>{t.error}</Typography></Tooltip>}
                    {t.error && t.status !== 'done' && <ErrorHelp text={t.error} />}
                    <Tooltip title="Table log"><IconButton size="small" onClick={() => setLogTable(t.name)}><ArticleRoundedIcon fontSize="small" /></IconButton></Tooltip>
                  </Stack>
                ) },
              ]} />
          </SectionCard>

          {(run.ddlFailures?.length || 0) > 0 && (
            <SectionCard collapsible title={`${run.ddlFailures!.length} DDL statements failed`} subtitle="Indexes, constraints, foreign keys or sequences PostgreSQL rejected. The data is loaded; fix these and press Resume to apply them again.">
              <Stack spacing={1.5} sx={{ maxHeight: 360, overflow: 'auto' }}>
                {run.ddlFailures!.map((f, i) => (
                  <Box key={i} sx={{ p: 1.5, border: 1, borderColor: 'divider', borderRadius: 2 }}>
                    <Typography variant="caption" color="text.secondary">{f.step}</Typography>
                    <Typography variant="body2" color="error.main" sx={{ overflowWrap: 'anywhere' }}>{f.error}</Typography>
                    <Typography variant="caption" className="mono" sx={{ display: 'block', mt: 0.5, overflowWrap: 'anywhere' }}>{f.statement}</Typography>
                    <ErrorHelp text={f.error} />
                  </Box>
                ))}
              </Stack>
            </SectionCard>
          )}

          <LogProblems name={name} runId={run.runId} refreshKey={`${run.status}:${counts.done}:${counts.failed}:${run.phases.filter((p) => p.status === 'done').length}`} />

          {run.codeResult && (
            <SectionCard collapsible storeKey="run.code" title="Converted code objects" subtitle={`Package ${run.codeResult.packageId}${run.codeResult.dbLinks ? ` · DB links: ${run.codeResult.dbLinks}` : ''}`}>
              <Stack direction="row" spacing={1} sx={{ mb: run.codeResult.failed.length ? 2 : 0 }}>
                <Chip color="success" label={`${run.codeResult.applied} applied`} />
                {!!run.codeResult.existing && <Chip variant="outlined" label={`${run.codeResult.existing} already present`} />}
                {run.codeResult.failed.length > 0 && <Chip color="error" label={`${run.codeResult.failed.length} failed`} />}
              </Stack>
              <Stack spacing={1} sx={{ maxHeight: 300, overflow: 'auto' }}>
                {run.codeResult.failed.map((f) => (
                  <Box key={f.path} sx={{ p: 1.25, border: 1, borderColor: 'divider', borderRadius: 2 }}>
                    <Typography variant="body2" className="mono">{f.path}</Typography>
                    <Typography variant="caption" color="error.main" sx={{ overflowWrap: 'anywhere' }}>{(f.error || '').replace(/^psql:[^:]+:\d+:\s*/, '')}</Typography>
                    <ErrorHelp text={f.error} />
                  </Box>
                ))}
              </Stack>
              {run.codeResult.failed.length > 0 && <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 1.5 }}>Fix these files, upload the corrected zip on Code objects and press Apply now.</Typography>}
            </SectionCard>
          )}
        </Stack>
      </ActivityPanel>
      <LogDialog run={run} table={logTable} onClose={() => setLogTable(null)} />
      <Dialog open={confirmCancel} onClose={() => setConfirmCancel(false)} maxWidth="xs" fullWidth>
        <DialogTitle>Cancel this migration?</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Tables being loaded are stopped. Finished tables and chunks are kept, so Resume continues from where it stopped.
          </DialogContentText>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2.5 }}>
          <Button onClick={() => setConfirmCancel(false)}>Keep running</Button>
          <Button variant="contained" color="error" startIcon={<StopCircleRoundedIcon />} onClick={() => { setConfirmCancel(false); act('cancel'); }}>Cancel run</Button>
        </DialogActions>
      </Dialog>
    </>
  );
}
