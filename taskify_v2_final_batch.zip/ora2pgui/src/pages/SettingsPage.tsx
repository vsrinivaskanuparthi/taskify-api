import { Alert, Box, Button, Chip, CircularProgress, Dialog, DialogContent, DialogTitle, FormControlLabel, IconButton, LinearProgress, MenuItem, Snackbar, Stack, Switch, Tab, Tabs, TextField, Tooltip, Typography } from '@mui/material';
import TuneRoundedIcon from '@mui/icons-material/TuneRounded';
import DescriptionRoundedIcon from '@mui/icons-material/DescriptionRounded';
import SaveRoundedIcon from '@mui/icons-material/SaveRounded';
import CloseRoundedIcon from '@mui/icons-material/CloseRounded';
import HandshakeRoundedIcon from '@mui/icons-material/HandshakeRounded';
import LightbulbRoundedIcon from '@mui/icons-material/LightbulbRounded';
import CheckCircleRoundedIcon from '@mui/icons-material/CheckCircleRounded';
import AddRoundedIcon from '@mui/icons-material/AddRounded';
import DeleteForeverRoundedIcon from '@mui/icons-material/DeleteForeverRounded';
import { ReactNode, useEffect, useMemo, useState } from 'react';
import { Link as RouterLink, useNavigate } from 'react-router-dom';
import { api, apiUrl, projectPath } from '../api';
import { useProject } from '../context/ProjectContext';
import { PageHeader, SectionCard } from '../components/ui';
import DeleteProjectDialog from '../components/DeleteProjectDialog';
import { fmtDate } from '../format';
import { brand, headingFont, monoFont } from '../theme';
import { useIsAdmin } from '../role';

type Option = { key: string; type: 'bool' | 'select' | 'text' | 'fixed'; default: any; group: string; label: string; help?: string; placeholder?: string; options?: string[] };
type Settings = {
  targetSchema: string; ora2pg: Record<string, any>; extraDirectives: string; lob: { blobAs: 'bytea' | 'oid' }; engine: Record<string, any>;
  access: { readRoles: string; writeRoles: string; dualView: boolean }; decisions: { agreedBy: string; agreedAt: string | null };
  notify: { emails: string; webhook: string; onStart: boolean; onAttention: boolean; onFinish: boolean };
};

// Shown as decisions; everything else from the ora2pg catalogue goes under Advanced.
const DECISION_KEYS = ['PRESERVE_CASE', 'USE_RESERVED_WORDS', 'PG_NUMERIC_TYPE', 'PG_INTEGER_TYPE', 'DEFAULT_NUMERIC', 'REPLACE_AS_BOOLEAN'];

function Choice({ selected, onClick, title, text, recommended }: { selected: boolean; onClick: () => void; title: string; text: string; recommended?: boolean }) {
  return (
    <Box onClick={onClick} sx={{
      p: 1.5, borderRadius: 2.5, cursor: 'pointer', border: `1.5px solid ${selected ? brand.blue : brand.border}`, bgcolor: selected ? '#F3F7FF' : '#fff',
      transition: 'border-color .15s, background-color .15s', '&:hover': { borderColor: selected ? brand.blue : '#B2CCFA' }, display: 'flex', gap: 1.25,
    }}>
      <Box sx={{ width: 18, height: 18, mt: 0.25, borderRadius: '50%', flexShrink: 0, border: `2px solid ${selected ? brand.blue : '#B8C2D3'}`, display: 'grid', placeItems: 'center' }}>
        {selected && <Box sx={{ width: 8, height: 8, borderRadius: '50%', bgcolor: brand.blue }} />}
      </Box>
      <Box sx={{ minWidth: 0 }}>
        <Stack direction="row" spacing={1} alignItems="center" flexWrap="wrap" useFlexGap>
          <Typography fontWeight={700} fontSize={14}>{title}</Typography>
          {recommended && <Chip size="small" label="Recommended" sx={{ height: 20, fontSize: 11, fontWeight: 700, bgcolor: '#ECFDF3', color: brand.success }} />}
        </Stack>
        <Typography variant="body2" color="text.secondary" sx={{ mt: 0.25 }}>{text}</Typography>
      </Box>
    </Box>
  );
}

function Decision({ n, title, question, lesson, children }: { n: number; title: string; question: string; lesson?: string; children: ReactNode }) {
  return (
    <SectionCard fill title={<Stack direction="row" spacing={1.25} alignItems="center">
      <Box sx={{ width: 28, height: 28, borderRadius: 2, display: 'grid', placeItems: 'center', background: brand.accentGradient, color: '#fff', fontFamily: headingFont, fontWeight: 800, fontSize: 14 }}>{n}</Box>
      <span>{title}</span>
    </Stack>} subtitle={question}>
      <Stack spacing={1.25}>{children}</Stack>
      {lesson && (
        <Tooltip title={lesson} placement="top-start">
          <Stack direction="row" spacing={0.75} alignItems="center" sx={{ mt: 1.5, width: 'fit-content', cursor: 'help' }}>
            <LightbulbRoundedIcon sx={{ fontSize: 16, color: brand.warning }} />
            <Typography variant="caption" sx={{ color: '#7A4B05', fontWeight: 600 }}>Learned from a past migration</Typography>
          </Stack>
        </Tooltip>
      )}
    </SectionCard>
  );
}

export default function SettingsPage() {
  const admin = useIsAdmin();
  // One part of the settings at a time (Migrate → "Change in Settings" opens Run defaults).
  const [tab, setTab] = useState(() => new URLSearchParams(window.location.search).get('tab') || 'decisions');
  const { name, project } = useProject();
  const navigate = useNavigate();
  const [del, setDel] = useState(false);
  const [settings, setSettings] = useState<Settings | null>(null);
  const [defaults, setDefaults] = useState<Settings | null>(null);
  const [options, setOptions] = useState<Option[]>([]);
  const [saved, setSaved] = useState<string>('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [toast, setToast] = useState<string | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [candidates, setCandidates] = useState<{ key: string; type: string }[] | null>(null);
  const [newBool, setNewBool] = useState('');

  useEffect(() => {
    api<{ settings: Settings; defaults: Settings; options: Option[]; notifyChannels: { email: boolean; from: string } }>(`${projectPath(name)}/settings`).then((r) => {
      setSettings(r.settings);
      setDefaults(r.defaults);
      setOptions(r.options);
      setSaved(JSON.stringify(r.settings));
    }).catch((e) => setError(e.message));
    api<any>(`${projectPath(name)}/analysis`).then((r) => setCandidates(r.latest?.booleanCandidates ?? null)).catch(() => setCandidates(null));
  }, [name]);

  const savedSettings: Settings | null = useMemo(() => (saved ? JSON.parse(saved) : null), [saved]);
  const dirty = settings && JSON.stringify(settings) !== saved;
  const advanced = useMemo(() => options.filter((o) => !DECISION_KEYS.includes(o.key) && o.type !== 'fixed'), [options]);
  const advGroups = useMemo(() => [...new Set(advanced.map((o) => o.group))], [advanced]);

  if (!settings) return error ? <Alert severity="error">{error}</Alert> : <LinearProgress />;

  const set = (patch: Partial<Settings>) => setSettings({ ...settings, ...patch });
  const setOra = (k: string, v: any) => setSettings({ ...settings, ora2pg: { ...settings.ora2pg, [k]: v } });
  const setEng = (k: string, v: any) => setSettings({ ...settings, engine: { ...settings.engine, [k]: v } });
  const setAccess = (k: keyof Settings['access'], v: any) => setSettings({ ...settings, access: { ...settings.access, [k]: v } });
  const booleans: string[] = String(settings.ora2pg.REPLACE_AS_BOOLEAN || '').split(/\s+/).filter(Boolean);
  const setBooleans = (list: string[]) => setOra('REPLACE_AS_BOOLEAN', [...new Set(list)].join(' '));
  const renames = project?.columnRenames || [];
  const migrated = !!project?.lastMigrationDate;
  // Changing these after a load means rebuilding the target (a past migration ended up with two databases).
  const structural = savedSettings && (
    settings.ora2pg.PRESERVE_CASE !== savedSettings.ora2pg.PRESERVE_CASE || settings.ora2pg.USE_RESERVED_WORDS !== savedSettings.ora2pg.USE_RESERVED_WORDS
    || settings.ora2pg.PG_NUMERIC_TYPE !== savedSettings.ora2pg.PG_NUMERIC_TYPE || settings.ora2pg.DEFAULT_NUMERIC !== savedSettings.ora2pg.DEFAULT_NUMERIC
    || settings.ora2pg.REPLACE_AS_BOOLEAN !== savedSettings.ora2pg.REPLACE_AS_BOOLEAN || settings.lob.blobAs !== savedSettings.lob.blobAs
    || settings.targetSchema !== savedSettings.targetSchema);

  const save = async () => {
    setBusy(true);
    setError(null);
    try {
      const r = await api<{ settings: Settings; message: string }>(`${projectPath(name)}/settings`, { method: 'PUT', body: settings });
      setSettings(r.settings);
      setSaved(JSON.stringify(r.settings));
      setToast(r.message);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  };
  const openPreview = async () => {
    setPreview('');
    const res = await fetch(apiUrl(`${projectPath(name)}/settings/preview`));
    setPreview(await res.text());
  };
  const engineField = (k: string, label: string, help?: string, min = 1, max = 1e12) => (
    <TextField label={label} type="number" size="small" value={settings.engine[k]} helperText={help}
      onChange={(e) => setEng(k, Math.max(min, Math.min(max, Number(e.target.value) || 0)))} />
  );
  const addBool = () => {
    const v = newBool.trim().toUpperCase().replace('.', ':');
    if (/^[A-Z0-9_$#]+:[A-Z0-9_$#]+$/.test(v)) { setBooleans([...booleans, v]); setNewBool(''); }
  };

  if (admin === false) {
    return (
      <>
        <PageHeader overline="Managed by the DBA team" title="Settings" icon={<TuneRoundedIcon />} />
        <Alert severity="info">The DBA team chooses these settings. DMA uses the recommended ones, so you don’t need to change anything: go straight to Migrate.</Alert>
      </>
    );
  }

  return (
    <>
      <PageHeader overline="Step 4 · recommended" title="Settings" icon={<TuneRoundedIcon />}
        subtitle={<>The choices to agree with the application team <b>before the first migration</b>. They shape the tables, the GenAI conversion guide and the analysis report.</>}
        actions={<>
          <Button variant="text" component={RouterLink} to="/guide#options">What do these mean?</Button>
          <Button variant="outlined" startIcon={<DescriptionRoundedIcon />} onClick={openPreview}>Preview ora2pg.conf</Button>
          <Button variant="contained" startIcon={busy ? <CircularProgress size={16} color="inherit" /> : <SaveRoundedIcon />} disabled={!dirty || busy} onClick={save}>Save settings</Button>
        </>} />
      {error && <Alert severity="error" sx={{ mb: 3 }}>{error}</Alert>}
      {migrated && structural && (
        <Alert severity="warning" sx={{ mb: 3 }}>
          This project has already been migrated. Changing names, number or boolean mapping, LOB storage or the target schema means rebuilding the target:
          run a fresh migration and re-apply the code objects and DB links, so you never end up with two half-different databases.
        </Alert>
      )}

      <Tabs value={tab} onChange={(_, v) => setTab(v)} sx={{ mb: 3, borderBottom: 1, borderColor: 'divider' }}>
        <Tab value="decisions" label="Migration decisions" />
        <Tab value="run" label="Run defaults" />
        <Tab value="advanced" label="Advanced" />
      </Tabs>

      {tab === 'decisions' && (<>
      {/* Agreement */}
      <Box sx={{ mb: 3, p: { xs: 2, md: 2.5 }, borderRadius: 4, border: `1px solid ${settings.decisions.agreedBy ? '#ABEFC6' : '#FEDF89'}`, bgcolor: settings.decisions.agreedBy ? '#F6FEF9' : '#FFFCF5', display: 'flex', gap: 2, alignItems: 'center', flexWrap: 'wrap' }}>
        <Box sx={{ width: 44, height: 44, borderRadius: 3, display: 'grid', placeItems: 'center', bgcolor: settings.decisions.agreedBy ? '#DCFAE6' : '#FEF0C7', color: settings.decisions.agreedBy ? brand.success : brand.warning }}>
          {settings.decisions.agreedBy ? <CheckCircleRoundedIcon /> : <HandshakeRoundedIcon />}
        </Box>
        <Box sx={{ flex: 1, minWidth: 240 }}>
          <Typography fontWeight={750}>{savedSettings?.decisions.agreedBy ? `Agreed with ${savedSettings.decisions.agreedBy}` : 'Not agreed yet'}</Typography>
          <Typography variant="body2" color="text.secondary">
            {savedSettings?.decisions.agreedAt ? `Recorded ${fmtDate(savedSettings.decisions.agreedAt)}. ` : ''}
            Review these with the application team (names, booleans, numbers, LOBs) and record who agreed. It is printed in the GenAI guide and in analysis reports generated after you save it.
          </Typography>
        </Box>
        <TextField size="small" label="Agreed with (team / person)" value={settings.decisions.agreedBy} sx={{ width: { xs: '100%', sm: 300 }, bgcolor: '#fff' }}
          onChange={(e) => set({ decisions: { agreedBy: e.target.value, agreedAt: null } })} />
      </Box>

      <Box sx={{ display: 'grid', gap: 3, gridTemplateColumns: { xs: 'minmax(0, 1fr)', lg: 'repeat(2, minmax(0, 1fr))' }, alignItems: 'stretch' }}>
        <Decision n={1} title="Object names" question="How should table, column and code names look in PostgreSQL?"
          lesson="From a past migration: switching from UPPER to lower case midway left two databases, and the DB links and GenAI code were only set up on one of them.">
          <Choice selected={!settings.ora2pg.PRESERVE_CASE} onClick={() => setOra('PRESERVE_CASE', false)} recommended
            title="lower case" text="employees, order_id. No quotes needed in SQL; what PostgreSQL tools and ORMs expect." />
          <Choice selected={!!settings.ora2pg.PRESERVE_CASE} onClick={() => setOra('PRESERVE_CASE', true)}
            title="Keep Oracle UPPER case" text={'"EMPLOYEES", "ORDER_ID". Every query must quote every name. Only if the application already does.'} />
        </Decision>

        <Decision n={2} title="Reserved-word columns" question="Columns named OFFSET, TYPE, VALUE, USER… are reserved words in PostgreSQL."
          lesson="Renaming (offset_value, type_val, variable_table) broke the Java application, which uses the legacy names. Keeping and quoting them worked.">
          <Choice selected={!!settings.ora2pg.USE_RESERVED_WORDS} onClick={() => setOra('USE_RESERVED_WORDS', true)} recommended
            title="Keep the original names, quoted" text={'Column stays offset; SQL writes "offset". No application change.'} />
          <Choice selected={!settings.ora2pg.USE_RESERVED_WORDS} onClick={() => setOra('USE_RESERVED_WORDS', false)}
            title="Rename them" text="Only if the application changes too. Renames are chosen on the Assessment page and passed to the GenAI guide." />
          {renames.length > 0 && <Alert severity={settings.ora2pg.USE_RESERVED_WORDS ? 'warning' : 'info'} variant="outlined">
            {renames.length} column rename{renames.length > 1 ? 's are' : ' is'} saved on the Assessment page ({renames.slice(0, 3).map((r) => `${r.tableName}.${r.oldName} → ${r.name}`).join(', ')}{renames.length > 3 ? '…' : ''}). They are applied in the next run.
          </Alert>}
        </Decision>

        <Decision n={3} title="Numbers" question="How is Oracle NUMBER mapped? Must match the application's Java / .NET types."
          lesson="NUMERIC everywhere broke function calls from Java (numeric vs int8). Changing to BIGINT after the load ran out of disk and was rolled back.">
          <Choice selected={!!settings.ora2pg.PG_NUMERIC_TYPE} onClick={() => setSettings({ ...settings, ora2pg: { ...settings.ora2pg, PG_NUMERIC_TYPE: true, PG_INTEGER_TYPE: true } })} recommended
            title="Whole numbers as integers" text="NUMBER(p,0) → smallint / integer / bigint by precision; decimals stay numeric. Fast, and matches Long / Integer in Java." />
          <Choice selected={!settings.ora2pg.PG_NUMERIC_TYPE} onClick={() => setSettings({ ...settings, ora2pg: { ...settings.ora2pg, PG_NUMERIC_TYPE: false, PG_INTEGER_TYPE: false } })}
            title="Always numeric" text="Exact for everything, slower, and the application must use BigDecimal." />
          {settings.ora2pg.PG_NUMERIC_TYPE && (
            <TextField select size="small" label="NUMBER without precision (IDs, counters…)" value={settings.ora2pg.DEFAULT_NUMERIC} onChange={(e) => setOra('DEFAULT_NUMERIC', e.target.value)}
              helperText="Also used for PL/SQL parameters declared as NUMBER. The analysis lists such columns that might hold decimals." sx={{ mt: 0.5 }}>
              <MenuItem value="bigint">bigint (Java Long): recommended</MenuItem>
              <MenuItem value="integer">integer (Java Integer, values below 2.1 billion)</MenuItem>
              <MenuItem value="numeric">numeric (exact decimals)</MenuItem>
              <MenuItem value="double precision">double precision</MenuItem>
            </TextField>
          )}
        </Decision>

        <Decision n={4} title="Boolean columns" question="Which NUMBER(1) / CHAR(1) flags are booleans in the application? Only these are converted."
          lesson="From a past migration: converting 102 columns after the load meant rebuilding 99 views and fixing functions (boolean = integer), and one column turned out not to be a flag.">
          <Stack direction="row" flexWrap="wrap" useFlexGap spacing={0.75}>
            {booleans.length === 0 && <Typography variant="body2" color="text.secondary">No boolean columns: NUMBER(1) flags stay numbers.</Typography>}
            {booleans.map((b) => <Chip key={b} label={b} onDelete={() => setBooleans(booleans.filter((x) => x !== b))} sx={{ fontFamily: monoFont, fontSize: 12, bgcolor: '#EEF4FF' }} />)}
          </Stack>
          <Stack direction="row" spacing={1}>
            <TextField size="small" fullWidth placeholder="TABLE:COLUMN" value={newBool} onChange={(e) => setNewBool(e.target.value)} onKeyDown={(e) => { if (e.key === 'Enter') addBool(); }}
              InputProps={{ sx: { fontFamily: monoFont, fontSize: 13 } }} />
            <Button variant="outlined" startIcon={<AddRoundedIcon />} onClick={addBool}>Add</Button>
          </Stack>
          {candidates && candidates.filter((c) => !booleans.includes(c.key)).length > 0 && (
            <Box>
              <Typography variant="caption" color="text.secondary" fontWeight={700}>CANDIDATES FROM THE ANALYSIS: CLICK TO ADD</Typography>
              <Stack direction="row" flexWrap="wrap" useFlexGap spacing={0.75} sx={{ mt: 0.75, maxHeight: 160, overflow: 'auto' }}>
                {candidates.filter((c) => !booleans.includes(c.key)).map((c) => (
                  <Chip key={c.key} variant="outlined" size="small" icon={<AddRoundedIcon />} label={`${c.key} · ${c.type}`} onClick={() => setBooleans([...booleans, c.key])} sx={{ fontFamily: monoFont, fontSize: 11.5 }} />
                ))}
              </Stack>
            </Box>
          )}
          {candidates === null && <Typography variant="caption" color="text.secondary">Run the Analysis report to list candidate columns.</Typography>}
        </Decision>

        <Decision n={5} title="LOB storage" question="CLOB and NCLOB always become text. Where do BLOBs go?"
          lesson="The OID mapping done on the first (UPPER case) database was marked completed, but the database in use had bytea: decide once.">
          <Choice selected={settings.lob.blobAs === 'bytea'} onClick={() => set({ lob: { blobAs: 'bytea' } })} recommended
            title="BLOB → bytea" text="Binary column in the row. Works with every driver, tool and backup." />
          <Choice selected={settings.lob.blobAs === 'oid'} onClick={() => set({ lob: { blobAs: 'oid' } })}
            title="BLOB → large object (oid)" text="Only if the application uses the large-object API (lo_*) or values above ~500 MB." />
        </Decision>

        <Decision n={6} title="Target schema & application access" question="Where the data goes, and which database roles the application uses."
          lesson="The application's read-only user hit permission errors one object type at a time: schema, sequences, functions, the foreign server, then write access.">
          <TextField label="Target schema" size="small" value={settings.targetSchema} placeholder={(project?.selectedSchema || 'schema').toLowerCase()}
            onChange={(e) => set({ targetSchema: e.target.value.toLowerCase() })} helperText="Empty = the Oracle schema name in lower case." />
          <TextField label="Read-only roles" size="small" value={settings.access.readRoles} placeholder="app_read" onChange={(e) => setAccess('readRoles', e.target.value)}
            helperText="Comma separated. Get schema usage, SELECT on tables, views and sequences, EXECUTE on functions, foreign servers of DB links." />
          <TextField label="Read-write roles" size="small" value={settings.access.writeRoles} placeholder="app_user" onChange={(e) => setAccess('writeRoles', e.target.value)}
            helperText="Also INSERT / UPDATE / DELETE and sequence USAGE. Default privileges cover objects created later." />
          <FormControlLabel sx={{ m: 0 }} control={<Switch checked={settings.access.dualView} onChange={(e) => setAccess('dualView', e.target.checked)} />}
            label={<Box><Typography fontWeight={650} fontSize={14}>Create a DUAL compatibility view</Typography><Typography variant="caption" color="text.secondary">For application SQL that still says FROM dual.</Typography></Box>} />
        </Decision>
      </Box>
      </>)}


      {tab === 'run' && (
        <SectionCard title="Run defaults" subtitle="How every migration of this project runs. The Migrate page only shows a one-line summary, so nobody changes these by accident.">
          <Stack spacing={2.5} sx={{ maxWidth: 820 }}>
            <FormControlLabel sx={{ m: 0, alignItems: 'flex-start' }} control={<Switch checked={settings.engine.auto !== false} onChange={(e) => setEng('auto', e.target.checked)} />}
              label={<Box sx={{ pt: 0.75 }}><Typography fontWeight={650} fontSize={14}>Let DMA choose the speed (recommended)</Typography><Typography variant="caption" color="text.secondary">Tables at a time and parts at a time, from the selected tables and this server. Off: use the three numbers below.</Typography></Box>} />
            {settings.engine.auto === false && (
              <Box sx={{ display: 'grid', gap: 2, gridTemplateColumns: { xs: 'minmax(0, 1fr)', md: 'repeat(3, minmax(0, 1fr))' } }}>
                {engineField('parallelTables', 'Tables at a time', 'How many tables copy together', 1, 32)}
                {engineField('oracleCopies', 'Parts at a time', 'Of one big table', 1, 32)}
                {engineField('pgJobs', 'PostgreSQL writers', 'For a big table that cannot be cut', 1, 32)}
              </Box>
            )}
            <FormControlLabel sx={{ m: 0, alignItems: 'flex-start' }} control={<Switch checked={settings.engine.autoTune !== 'off'} onChange={(e) => setEng('autoTune', e.target.checked ? 'on' : 'off')} />}
              label={<Box sx={{ pt: 0.75 }}><Typography fontWeight={650} fontSize={14}>Auto-tune speed during the run (recommended)</Typography><Typography variant="caption" color="text.secondary">Every few minutes DMA measures the MB/s and adds a load at once while the speed rises; it steps back when more loads are not faster. Never above tables × parts at a time, which the pre-flight checks.</Typography></Box>} />
            {settings.engine.autoTune !== 'off' && (
              <Box sx={{ display: 'grid', gap: 2, gridTemplateColumns: { xs: 'minmax(0, 1fr)', md: 'repeat(3, minmax(0, 1fr))' } }}>
                {engineField('maxReaders', 'Most loads at once', '0 = tables × parts at a time. Lower it to protect a busy Oracle.', 0, 64)}
              </Box>
            )}
            <Box sx={{ display: 'grid', gap: 2, gridTemplateColumns: { xs: 'minmax(0, 1fr)', md: 'repeat(2, minmax(0, 1fr))' } }}>
              <TextField select size="small" label="Load mode" value={settings.engine.loadMode} onChange={(e) => setEng('loadMode', e.target.value)}
                helperText="Direct: straight into PostgreSQL. Through files: like v1. Export only: files to import later.">
                <MenuItem value="direct">Direct load (recommended)</MenuItem>
                <MenuItem value="file">Through files</MenuItem>
                <MenuItem value="export">Export only</MenuItem>
              </TextField>
              <TextField select size="small" label="Consistent snapshot" value={settings.engine.snapshot || 'on'} onChange={(e) => setEng('snapshot', e.target.value)}
                helperText="On: all tables as of the run's start. Off only when the application is stopped.">
                <MenuItem value="on">On (recommended)</MenuItem>
                <MenuItem value="off">Off (application stopped)</MenuItem>
              </TextField>
              {engineField('maxAttempts', 'Tries per table', 'Automatic retries before a table fails', 1, 10)}
              {engineField('stallMinutes', 'Stop a hung load after (min)', 'No progress this long: stop and retry. 0 = off', 0, 1440)}
              <TextField select size="small" label="Bulk load" value={settings.engine.bulkLoad || 'standard'} onChange={(e) => setEng('bulkLoad', e.target.value)}
                helperText="Unlogged: faster, tables made permanent after their checks pass.">
                <MenuItem value="standard">Standard</MenuItem>
                <MenuItem value="unlogged">Unlogged (faster)</MenuItem>
              </TextField>
            </Box>
            <FormControlLabel control={<Switch checked={!!settings.engine.verifyRowCounts} onChange={(e) => setEng('verifyRowCounts', e.target.checked)} />} label="Count every table in Oracle and PostgreSQL (recommended)" />
            <FormControlLabel control={<Switch checked={settings.engine.verifyData !== 'off'} onChange={(e) => setEng('verifyData', e.target.checked ? 'all' : 'off')} />} label="Compare column totals too: catches cut decimals and shortened text (recommended)" />
          </Stack>
        </SectionCard>
      )}

      {tab === 'advanced' && (<>
      {/* Advanced */}
      <SectionCard title="Advanced" subtitle="Other ora2pg options, extra directives and batch sizes. Most projects never change these.">
          <Box sx={{ display: 'grid', gap: 3, gridTemplateColumns: { xs: '1fr', xl: '3fr 2fr' }, alignItems: 'start' }}>
            <Stack spacing={2.5}>
              {advGroups.map((g) => (
                <Box key={g}>
                  <Typography variant="overline" color="text.secondary">{g}</Typography>
                  <Box sx={{ display: 'grid', gap: 1.5, gridTemplateColumns: { xs: '1fr', md: '1fr 1fr' }, mt: 0.5 }}>
                    {advanced.filter((o) => o.group === g).map((o) => (o.type === 'bool' ? (
                      <FormControlLabel key={o.key} sx={{ m: 0, alignItems: 'flex-start' }} control={<Switch checked={!!settings.ora2pg[o.key]} onChange={(e) => setOra(o.key, e.target.checked)} />}
                        label={<Box sx={{ pt: 0.75 }}><Typography fontWeight={600} fontSize={14}>{o.label}</Typography>{o.help && <Typography variant="caption" color="text.secondary">{o.help}</Typography>}</Box>} />
                    ) : o.type === 'select' ? (
                      <TextField key={o.key} select size="small" label={o.label} value={settings.ora2pg[o.key]} onChange={(e) => setOra(o.key, e.target.value)} helperText={<span className="mono">{o.key}</span>}>
                        {o.options!.map((v) => <MenuItem key={v} value={v}>{v}</MenuItem>)}
                      </TextField>
                    ) : (
                      <TextField key={o.key} size="small" label={o.label} value={settings.ora2pg[o.key]} placeholder={o.placeholder} onChange={(e) => setOra(o.key, e.target.value)}
                        InputProps={{ sx: { fontFamily: monoFont, fontSize: 13 } }} helperText={<><span className="mono">{o.key}</span>{o.help ? ` · ${o.help}` : ''}</>} sx={{ gridColumn: { md: 'span 2' } }} />
                    )))}
                  </Box>
                </Box>
              ))}
              <Box>
                <Typography variant="overline" color="text.secondary">Extra ora2pg directives</Typography>
                <TextField multiline minRows={3} fullWidth value={settings.extraDirectives} onChange={(e) => set({ extraDirectives: e.target.value })}
                  placeholder={'DISABLE_PARTITION 1\nPG_SUPPORTS_IDENTITY 1'} InputProps={{ sx: { fontFamily: monoFont, fontSize: 13 } }}
                  helperText="One per line (KEY value). Connection, output and parallelism directives are managed by the engine and rejected." />
              </Box>
            </Stack>
            <Box>
              <Typography variant="overline" color="text.secondary">Batch sizes and parts</Typography>
              <Stack spacing={2} sx={{ mt: 0.5 }}>
                <Box sx={{ display: 'grid', gap: 2, gridTemplateColumns: '1fr 1fr' }}>
                  {engineField('hugeTableRows', 'Big table from (rows)', undefined, 1000)}
                  {engineField('chunkRows', 'Rows per part', '0 = no parts', 0)}
                  {engineField('chunkMb', 'Cut tables bigger than (MB)', 'Document tables too', 64)}
                  {engineField('dataLimit', 'Batch size (rows)', 'Normal tables', 100)}
                  {engineField('blobLimit', 'Batch size, document tables', 'Keeps memory low', 1)}
                </Box>
                <TextField size="small" label="Index build memory" value={settings.engine.maintenanceWorkMem} onChange={(e) => setEng('maintenanceWorkMem', e.target.value)} helperText="maintenance_work_mem, e.g. 1GB" />
                <Button variant="text" onClick={() => defaults && set({ engine: defaults.engine, extraDirectives: defaults.extraDirectives, ora2pg: { ...settings.ora2pg, ...Object.fromEntries(advanced.map((o) => [o.key, defaults.ora2pg[o.key]])) } })} sx={{ alignSelf: 'flex-start' }}>
                  Reset advanced to defaults
                </Button>
              </Stack>
            </Box>
          </Box>
      </SectionCard>

      <Box sx={{ mt: 3 }}>
        <SectionCard collapsible defaultOpen={false} summary="Delete this project" title="Danger zone" icon={<DeleteForeverRoundedIcon />}
          subtitle="Removes this project's folder on the migration server (ora2pg files, snapshots, runs, logs, exports). Oracle and PostgreSQL are not touched.">
          <Stack direction={{ xs: 'column', sm: 'row' }} spacing={2} alignItems={{ sm: 'center' }} justifyContent="space-between"
            sx={{ p: 2, borderRadius: 3, border: '1px solid #FECDCA', bgcolor: '#FFFBFA' }}>
            <Box>
              <Typography fontWeight={700}>Delete project {name}</Typography>
              <Typography variant="body2" color="text.secondary">Cannot be undone. Refused while a migration, snapshot, export or analysis is running.</Typography>
            </Box>
            <Button variant="outlined" color="error" startIcon={<DeleteForeverRoundedIcon />} onClick={() => setDel(true)} sx={{ flexShrink: 0 }}>Delete project</Button>
          </Stack>
        </SectionCard>
      </Box>
      </>)}
      <DeleteProjectDialog name={name} open={del} onClose={() => setDel(false)} onDeleted={() => navigate('/projects', { replace: true })} />

      <Dialog open={preview !== null} onClose={() => setPreview(null)} fullWidth maxWidth="md">
        <DialogTitle sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
          <DescriptionRoundedIcon color="primary" /> ora2pg.conf for the next run (saved settings, passwords hidden)
          <Box sx={{ flex: 1 }} />
          <IconButton onClick={() => setPreview(null)}><CloseRoundedIcon /></IconButton>
        </DialogTitle>
        <DialogContent>
          {dirty && <Alert severity="warning" sx={{ mb: 2 }}>Save first to see your latest changes here.</Alert>}
          <Box component="pre" sx={{ m: 0, p: 2, bgcolor: '#0B1730', color: '#D6E4FF', borderRadius: 2.5, fontFamily: monoFont, fontSize: 12.5, maxHeight: '65vh', overflow: 'auto' }}>
            {preview || 'Loading…'}
          </Box>
        </DialogContent>
      </Dialog>
      <Snackbar open={!!toast} autoHideDuration={4000} onClose={() => setToast(null)} message={toast} anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }} />
      {dirty && (
        <Box sx={{ position: 'sticky', bottom: 16, mt: 3, display: 'flex', justifyContent: 'center', zIndex: 5 }}>
          <Stack direction="row" spacing={2} alignItems="center" sx={{ px: 2.5, py: 1.25, borderRadius: 99, bgcolor: brand.ink, color: '#fff', boxShadow: '0 16px 40px -12px rgba(0,0,0,.45)' }}>
            <Typography fontSize={14} fontWeight={600}>Unsaved changes</Typography>
            <Button size="small" sx={{ color: '#fff' }} onClick={() => savedSettings && setSettings(savedSettings)}>Discard</Button>
            <Button size="small" variant="contained" onClick={save} disabled={busy}>Save settings</Button>
          </Stack>
        </Box>
      )}
    </>
  );
}
