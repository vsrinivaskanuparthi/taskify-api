'use strict';

// Auto-tune speed: the gate that limits loads at once, the tuning rule, and a simulated run.
const { Gate, SpeedTuner, decide, readerRange, availableMemory } = require('../../services/autoTune');

const tick = () => new Promise((r) => setImmediate(r));

test('gate: at most `limit` loads at once, first come first served, the limit can change while loads run', async () => {
  const g = new Gate(2);
  const started = [];
  const releases = {};
  for (const id of ['a', 'b', 'c', 'd']) g.acquire().then((rel) => { started.push(id); releases[id] = rel; });
  await tick();
  expect(started).toEqual(['a', 'b']);
  expect(g.waiting).toBe(2);
  g.setLimit(3);
  await tick();
  expect(started).toEqual(['a', 'b', 'c']);
  g.setLimit(1); // lower: running loads go on, no new one starts
  releases.a();
  await tick();
  expect(started).toEqual(['a', 'b', 'c']);
  releases.b();
  releases.c();
  releases.c(); // a second release changes nothing
  await tick();
  expect(started).toEqual(['a', 'b', 'c', 'd']);
  expect(g.used).toBe(1);
});

test('gate: a load bigger than the limit (a -J table) runs alone instead of waiting forever', async () => {
  const g = new Gate(2);
  const rel = await g.acquire(4);
  expect(g.used).toBe(4);
  let second = false;
  g.acquire().then(() => { second = true; });
  await tick();
  expect(second).toBe(false);
  rel();
  await tick();
  expect(second).toBe(true);
});

test('reader range: never above tables × parts (what the pre-flight checked), or the admin maximum', () => {
  expect(readerRange({ parallelTables: 2, oracleCopies: 8 })).toEqual({ min: 2, max: 16, start: 2 });
  expect(readerRange({ parallelTables: 4, oracleCopies: 4, maxReaders: 6 })).toEqual({ min: 2, max: 6, start: 4 });
  expect(readerRange({ parallelTables: 4, oracleCopies: 4, maxReaders: 99 }).max).toBe(16);
  expect(readerRange({ parallelTables: 1, oracleCopies: 1 })).toEqual({ min: 1, max: 1, start: 1 });
});

describe('the tuning rule', () => {
  const range = { min: 2, max: 16 };
  const busy = { busy: 1, waiting: 3, cpuBusy: false, memoryLow: false };

  test('adds readers while the speed rises', () => {
    let s = { readers: 4, ref: null, last: null, hold: 0 };
    s = decide(s, { ...busy, mbps: 40 }, range);
    expect([s.action, s.readers]).toEqual(['up', 5]);
    s = decide(s, { ...busy, mbps: 48 }, range);
    expect([s.action, s.readers]).toEqual(['up', 6]);
  });

  test('steps back when an added reader was not faster, then holds before trying again', () => {
    let s = decide({ readers: 6, ref: { readers: 5, mbps: 50 }, last: 'up', hold: 0 }, { ...busy, mbps: 51 }, range);
    expect([s.action, s.readers, s.hold]).toEqual(['back', 5, 3]);
    for (let i = 0; i < 2; i += 1) {
      s = decide(s, { ...busy, mbps: 50 }, range);
      expect([s.action, s.readers]).toEqual(['keep', 5]);
    }
    s = decide(s, { ...busy, mbps: 50 }, range);
    expect([s.action, s.readers]).toEqual(['up', 6]);
  });

  test('removes a reader when the speed falls hard at the same readers', () => {
    const s = decide({ readers: 8, ref: { readers: 8, mbps: 80 }, last: null, hold: 0 }, { ...busy, mbps: 50 }, range);
    expect([s.action, s.readers]).toEqual(['down', 7]);
  });

  test('does not add readers at the maximum, without queued work, or when the server is busy', () => {
    const s0 = { readers: 16, ref: null, last: null, hold: 0 };
    expect(decide(s0, { ...busy, mbps: 40 }, range)).toMatchObject({ action: 'keep', readers: 16, why: expect.stringMatching(/maximum/) });
    const s1 = { readers: 4, ref: null, last: null, hold: 0 };
    expect(decide(s1, { ...busy, waiting: 0, mbps: 40 }, range)).toMatchObject({ action: 'keep', why: expect.stringMatching(/already running/) });
    expect(decide(s1, { ...busy, busy: 0.5, mbps: 40 }, range)).toMatchObject({ action: 'keep' });
    expect(decide(s1, { ...busy, cpuBusy: true, mbps: 40 }, range)).toMatchObject({ action: 'keep', why: expect.stringMatching(/CPU/) });
    expect(decide(s1, { ...busy, memoryLow: true, mbps: 40 }, range)).toMatchObject({ action: 'down', readers: 3 });
  });

  test('a window without data moved changes nothing', () => {
    expect(decide({ readers: 4, ref: null, last: 'up', hold: 0 }, { ...busy, mbps: 0 }, range)).toMatchObject({ action: 'keep', readers: 4 });
  });
});

test('simulated run: the tuner settles where more readers stop helping (Oracle saturates at ~8)', () => {
  jest.useFakeTimers();
  // MB/s for n readers: grows ~10 MB/s per reader up to 8, then flat and a little worse.
  const speed = (n) => (n <= 8 ? n * 10 : 80 - (n - 8) * 2);
  const table = { name: 'BIG', status: 'running', estRows: 1e9, sizeMb: 1e6, rowsDone: 0 }; // 1 MB per 1000 rows
  const state = { options: { parallelTables: 2, oracleCopies: 8, maxReaders: 0 }, tables: { BIG: table } };
  const run = { state, save: () => {}, event: () => {} };
  const gate = new Gate(1);
  for (let i = 0; i < 50; i += 1) gate.acquire(); // plenty of parts waiting
  const tuner = new SpeedTuner({ run, gate, intervalMs: 60000, host: { cpus: () => 32, loadavg: () => 1, freemem: () => 8 * 1024 ** 3 } });
  tuner.start();
  expect(gate.limit).toBe(2);
  const seen = [];
  for (let w = 0; w < 30; w += 1) {
    table.rowsDone += speed(gate.limit) * 60 * 1000; // rows moved in one 60 s window
    gate.used = gate.limit;
    jest.advanceTimersByTime(60000);
    seen.push(gate.limit);
  }
  tuner.stop();
  jest.useRealTimers();
  // It climbed, then stayed around the best point (8), never above the maximum (16).
  expect(Math.max(...seen)).toBeLessThanOrEqual(16);
  const late = seen.slice(-12);
  expect(Math.min(...late)).toBeGreaterThanOrEqual(7);
  expect(Math.max(...late)).toBeLessThanOrEqual(10);
  expect(state.speed).toMatchObject({ auto: true, min: 2, max: 16 });
  expect(state.speed.history.some((h) => h.action === 'back')).toBe(true);
  expect(gate.limit).toBe(Infinity); // stopped: no limit left behind
});

test('available memory counts the file cache as free (MemAvailable on Linux), so a busy server does not look full', () => {
  const free = availableMemory();
  expect(free === Infinity || free > 0).toBe(true);
  if (process.platform === 'linux') expect(free).toBeGreaterThanOrEqual(require('os').freemem());
});
