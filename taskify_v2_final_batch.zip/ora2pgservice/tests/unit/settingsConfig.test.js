'use strict';

// Every Settings option reaches the ora2pg config file of a run, and the options that must not be
// overridden are refused. (What each option then does in PostgreSQL: tests/e2e.)
const fs = require('fs');
const os = require('os');
const path = require('path');

const staging = fs.mkdtempSync(path.join(os.tmpdir(), 'dma-conf-'));
process.env.MIGRATION_STAGING_DIR = staging;
const settings = require('../../services/settings');
const { buildConfig } = require('../../services/config_modify');

afterAll(() => fs.rmSync(staging, { recursive: true, force: true }));

const oracle = { userUrl: 'oracle-host:1521/ORCLPDB', userUsername: 'migrator', userPassword: 'x' };
/** The value of one directive in a generated config ("" when commented out or missing). */
const directive = (conf, key) => ((new RegExp(`^${key}[ \\t]+(.*)$`, 'm').exec(conf) || [])[1] || '').trim();

async function confFor(input, options = {}) {
  const { settings: s, error } = settings.validate(input, settings.defaults());
  if (error) throw new Error(error);
  const outFile = path.join(staging, `t${Date.now()}${Math.random()}.conf`);
  await buildConfig({ outFile, outputDir: staging, oracle, schema: 'APP', options: { ...options, directives: settings.ora2pgDirectives(s) } });
  return fs.readFileSync(outFile, 'utf8');
}

test('each option on the Settings page is written into the run config', async () => {
  const conf = await confFor({
    ora2pg: {
      PRESERVE_CASE: true, USE_RESERVED_WORDS: false, PG_NUMERIC_TYPE: false, PG_INTEGER_TYPE: true, DEFAULT_NUMERIC: 'numeric',
      ENABLE_MICROSECOND: false, DATA_TYPE: 'DATE:date', MODIFY_TYPE: 'T:C:varchar(5)', REPLACE_AS_BOOLEAN: 'T:FLAG',
      NULL_EQUAL_EMPTY: true, DISABLE_COMMENT: true, EXPORT_INVALID: true, SKIP: 'indexes checks',
      PG_VERSION: '15', CLIENT_ENCODING: 'LATIN1', NLS_LANG: 'GERMAN_GERMANY.WE8ISO8859P1',
    },
    extraDirectives: 'DEFAULT_PARALLELISM_DEGREE 4\n# a comment line is ignored',
  }, { dataLimit: 25000 });
  expect({
    PRESERVE_CASE: directive(conf, 'PRESERVE_CASE'),
    USE_RESERVED_WORDS: directive(conf, 'USE_RESERVED_WORDS'),
    PG_NUMERIC_TYPE: directive(conf, 'PG_NUMERIC_TYPE'),
    PG_INTEGER_TYPE: directive(conf, 'PG_INTEGER_TYPE'),
    DEFAULT_NUMERIC: directive(conf, 'DEFAULT_NUMERIC'),
    ENABLE_MICROSECOND: directive(conf, 'ENABLE_MICROSECOND'),
    DATA_TYPE: directive(conf, 'DATA_TYPE'),
    MODIFY_TYPE: directive(conf, 'MODIFY_TYPE'),
    REPLACE_AS_BOOLEAN: directive(conf, 'REPLACE_AS_BOOLEAN'),
    NULL_EQUAL_EMPTY: directive(conf, 'NULL_EQUAL_EMPTY'),
    DISABLE_COMMENT: directive(conf, 'DISABLE_COMMENT'),
    EXPORT_INVALID: directive(conf, 'EXPORT_INVALID'),
    SKIP: directive(conf, 'SKIP'),
    PG_VERSION: directive(conf, 'PG_VERSION'),
    CLIENT_ENCODING: directive(conf, 'CLIENT_ENCODING'),
    NLS_LANG: directive(conf, 'NLS_LANG'),
    DEFAULT_PARALLELISM_DEGREE: directive(conf, 'DEFAULT_PARALLELISM_DEGREE'),
    DATA_LIMIT: directive(conf, 'DATA_LIMIT'),
  }).toEqual({
    PRESERVE_CASE: '1', USE_RESERVED_WORDS: '0', PG_NUMERIC_TYPE: '0', PG_INTEGER_TYPE: '1', DEFAULT_NUMERIC: 'numeric',
    ENABLE_MICROSECOND: '0', DATA_TYPE: 'DATE:date', MODIFY_TYPE: 'T:C:varchar(5)', REPLACE_AS_BOOLEAN: 'T:FLAG',
    NULL_EQUAL_EMPTY: '1', DISABLE_COMMENT: '1', EXPORT_INVALID: '1', SKIP: '', // SKIP: done by the engine (ora2pg crashes on it)
    PG_VERSION: '15', CLIENT_ENCODING: 'LATIN1', NLS_LANG: 'GERMAN_GERMANY.WE8ISO8859P1',
    DEFAULT_PARALLELISM_DEGREE: '4', DATA_LIMIT: '25000',
  });
});

test('the engine\'s own settings always win, and extra directives cannot override them', async () => {
  const conf = await confFor({ ora2pg: {} });
  expect(directive(conf, 'STOP_ON_ERROR')).toBe('1');
  expect(directive(conf, 'ON_ERROR_STOP')).toBe('1');
  expect(directive(conf, 'TRUNCATE_TABLE')).toBe('0');
  for (const bad of ['PG_DSN dbi:Pg:dbname=x', 'TRUNCATE_TABLE 1', 'SCHEMA OTHER']) {
    expect(settings.validate({ extraDirectives: bad }, settings.defaults()).error).toMatch(/managed by the migration engine/);
  }
  expect(settings.validate({ extraDirectives: 'not a directive' }, settings.defaults()).error).toMatch(/must look like/);
});

test('invalid choices are refused with a clear message', () => {
  expect(settings.validate({ ora2pg: { DEFAULT_NUMERIC: 'money' } }, settings.defaults()).error).toMatch(/invalid value/);
  expect(settings.validate({ ora2pg: { PG_VERSION: '9' } }, settings.defaults()).error).toMatch(/invalid value/);
  expect(settings.validate({ targetSchema: 'Has Space' }, settings.defaults()).error).toMatch(/lower-case/);
  expect(settings.validate({ access: { readRoles: 'app_read; DROP TABLE x' } }, settings.defaults()).error).toMatch(/role names/);
});

test('skip constraint types: the engine leaves out exactly the chosen kinds (never NOT NULL)', () => {
  const { skipStatement } = require('../../services/migrate');
  const st = {
    pk: 'ALTER TABLE t ADD PRIMARY KEY (id);',
    uk: 'ALTER TABLE t ADD CONSTRAINT uq_t UNIQUE (code);',
    uix: 'CREATE UNIQUE INDEX uq_x ON t (code);',
    ck: 'ALTER TABLE t ADD CONSTRAINT ck_t CHECK (qty >= 0);',
    nn: 'ALTER TABLE t ALTER COLUMN code SET NOT NULL;',
    ix: 'CREATE INDEX ix_t ON t (station_id);',
    fk: 'ALTER TABLE t ADD CONSTRAINT fk_t FOREIGN KEY (station_id) REFERENCES s(station_id);',
  };
  const skipped = (list) => Object.keys(st).filter((k) => skipStatement(st[k], new Set(list)));
  expect(skipped(['indexes'])).toEqual(['ix']);
  expect(skipped(['checks', 'fkeys'])).toEqual(['ck', 'fk']);
  expect(skipped(['pkeys', 'ukeys'])).toEqual(['pk', 'uk', 'uix']);
  expect(skipped([])).toEqual([]);
});
