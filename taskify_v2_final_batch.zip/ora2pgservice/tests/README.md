# Tests

## Unit tests (fast, no database)

```bash
npm test
```

They check single functions: Oracle type changes converted for PostgreSQL, the speed settings DMA
chooses, admins vs normal users, ora2pg 24/25 report parsing, the private temp folder per ora2pg run,
project rename, the disk needed per load mode, the "where did the time go?" split, the one-run-per-project
lock, and the migration worker's token. Run them before every commit; `deploy\deploy.bat` runs them
before every deploy and stops if one fails.

## End-to-end tests (real migrations, a few minutes)

```bash
npm run test:e2e
```

They migrate real tables through the running API and check the results: a normal and a document
table, a re-run, a big table split into parts, one part failing (the table must be emptied and the
part named), and a project rename.

`decisions.e2e.test.js` checks that the **Migration decisions** in Settings really change the result in
PostgreSQL: lower case vs UPPER case names, reserved-word columns kept, NUMBER sizes, DATE, CLOB/BLOB
(bytea and large objects), booleans (Y/N), a data type override, a column type override, comments. It
also checks that two wrong choices are caught instead of loaded: a "boolean" column holding 0-9, and
decimals rounded by a bigint mapping. It loads into its own schema (`e2e_decisions`, dropped before
each test) and puts the project's settings back at the end. Needs `DMA_E2E_PG_URL`.

`options.e2e.test.js` does the same for the other Settings options: load modes **file** and **export
only + import**, **snapshot on** (one Oracle SCN), **unlogged** bulk load (tables end permanent), data
check off, application **roles** and the **DUAL** view (and a missing role being reported), **skip
indexes**, **microseconds** on/off, reserved words off (the table fails clearly), and **auto-tune**
(on, with a maximum of 1, and off). Its own schema: `e2e_options`. `tests/unit/settingsConfig.test.js`
checks that every option reaches the ora2pg config; `tests/unit/autoTune.test.js` checks the tuning rule
and a simulated run (it settles where more readers stop helping). Start the worker with
`AUTO_TUNE_SECONDS=10` so the short test runs see tuning decisions. Before running them:

1. The API is running (`npm run dev` or pm2).
2. A **test** project is connected (Oracle + PostgreSQL) and has a snapshot. Never use a real project:
   the tests reload its tables.
3. Set these if they differ from the defaults:

| Variable | Default | |
|---|---|---|
| `DMA_E2E_URL` | `http://localhost:5055` | the API (on RHEL: `http://127.0.0.1:5000`) |
| `DMA_E2E_PROJECT` | `E2E_TEST` | the test project |
| `DMA_E2E_TABLES` | `CALENDAR_EXCEPTION,DOCUMENTS` | a normal table and a document table |
| `DMA_E2E_BIG` | `AUDIT_TRAIL` | a table with enough rows to split into parts |
| `DMA_E2E_SCHEMA` | `e2e_test` | the target schema in PostgreSQL |
| `DMA_E2E_PG_URL` | (none) | `postgres://user:password@host:port/db` of the target; without it the "one part fails" test is skipped |
