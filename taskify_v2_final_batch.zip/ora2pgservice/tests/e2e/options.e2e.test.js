'use strict';

/**
 * End-to-end: the other Settings options (Run defaults, application access, skip lists, microseconds,
 * reserved words off) really do what the Settings page says. Same way as decisions.e2e.test.js: save
 * the option through the Settings API, migrate into a scratch schema (DMA_E2E_OPTIONS_SCHEMA, default
 * e2e_options, dropped before each run), read the result from PostgreSQL. Settings are put back at the end.
 * Needs DMA_E2E_PG_URL (skipped without it). dev-tools/run-e2e.sh sets everything.
 */
const { Client } = require('pg');
const { P, call, apiUp, getSettings, saveSettings, waitRun, migrate, types, one, loaded } = require('./helpers');

const TARGET = process.env.DMA_E2E_OPTIONS_SCHEMA || 'e2e_options';
const PG_URL = process.env.DMA_E2E_PG_URL;
const maybe = PG_URL ? describe : describe.skip;

jest.setTimeout(30 * 60 * 1000);

let saved = null;
let pg = null;

// Recommended decisions; each test changes only the option it tests.
const BASE_ORA2PG = { PRESERVE_CASE: false, USE_RESERVED_WORDS: true, PG_NUMERIC_TYPE: false, PG_INTEGER_TYPE: true, DEFAULT_NUMERIC: 'numeric', REPLACE_AS_BOOLEAN: '', DATA_TYPE: '', MODIFY_TYPE: '', SKIP: '', ENABLE_MICROSECOND: true };
const BASE_ENGINE = { auto: true, loadMode: 'direct', snapshot: 'off', bulkLoad: 'standard', verifyData: 'all', maxAttempts: 2 };

async function use({ ora2pg = {}, engine = {}, access = {} } = {}) {
  await saveSettings({
    ...saved,
    targetSchema: TARGET,
    ora2pg: { ...saved.ora2pg, ...BASE_ORA2PG, ...ora2pg },
    lob: { blobAs: 'bytea' },
    engine: { ...saved.engine, ...BASE_ENGINE, ...engine },
    access: { readRoles: '', writeRoles: '', dualView: false, ...access },
  });
}
const run = (tables) => migrate(pg, TARGET, tables);
const rows = (table) => one(pg, `SELECT count(*)::int FROM "${TARGET}".${table}`);
const indexExists = (name) => one(pg, 'SELECT count(*)::int FROM pg_indexes WHERE schemaname = $1 AND indexname = $2', [TARGET, name]);

maybe('Settings options change the migration', () => {
  beforeAll(async () => {
    await apiUp();
    saved = await getSettings();
    pg = new Client({ connectionString: PG_URL });
    await pg.connect();
  });

  afterAll(async () => {
    if (saved) await saveSettings(saved).catch(() => {});
    if (pg) {
      await pg.query(`DROP SCHEMA IF EXISTS "${TARGET}" CASCADE`).catch(() => {});
      await pg.end();
    }
  });

  test('load mode "file": through a file and psql, same result; indexes created', async () => {
    await use({ engine: { loadMode: 'file' } });
    const r = await run(['CALENDAR_EXCEPTION', 'DOCUMENTS']);
    expect(r.status).toBe('COMPLETED');
    loaded(r, 'CALENDAR_EXCEPTION');
    loaded(r, 'DOCUMENTS');
    expect(await indexExists('ix_calendar_station')).toBe(1);
  });

  test('load mode "export only", then "Import exported files": nothing loaded first, everything after', async () => {
    await use({ engine: { loadMode: 'export' } });
    const r = await run(['CALENDAR_EXCEPTION', 'DOCUMENTS']);
    expect(r.status).toBe('EXPORTED');
    expect(Object.values(r.tables).map((t) => t.status)).toEqual(['exported', 'exported']);
    expect(await rows('calendar_exception')).toBe(0);

    const resume = await call('POST', `${P}/runs/${r.runId}/resume`, { options: { loadMode: 'file' } });
    expect(resume.status).toBe(202);
    const after = await waitRun(r.runId);
    expect(after.status).toBe('COMPLETED');
    loaded(after, 'CALENDAR_EXCEPTION');
    loaded(after, 'DOCUMENTS');
  });

  test('snapshot on: every table read as of one Oracle SCN', async () => {
    await use({ engine: { snapshot: 'on' } });
    const r = await run(['CALENDAR_EXCEPTION', 'SPARE_PART']);
    expect(r.snapshot).toMatchObject({ mode: 'scn' });
    expect(Number(r.snapshot.scn)).toBeGreaterThan(0);
    loaded(r, 'CALENDAR_EXCEPTION');
    loaded(r, 'SPARE_PART');
  });

  test('unlogged bulk load: tables end permanent (logged) with autovacuum back on', async () => {
    await use({ engine: { bulkLoad: 'unlogged' } });
    const r = await run(['CALENDAR_EXCEPTION', 'CUSTOMER_MASTER']);
    loaded(r, 'CALENDAR_EXCEPTION');
    loaded(r, 'CUSTOMER_MASTER');
    const { rows: rels } = await pg.query(
      `SELECT c.relname, c.relpersistence, coalesce(array_to_string(c.reloptions, ','), '') AS opts
         FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace WHERE n.nspname = $1 AND c.relkind = 'r'`, [TARGET]);
    for (const rel of rels) {
      expect(rel.relpersistence).toBe('p');
      expect(rel.opts).not.toMatch(/autovacuum_enabled=false/);
    }
  });

  test('data check off: row counts still compared, column checksums skipped', async () => {
    await use({ engine: { verifyData: 'off' } });
    const r = await run(['CALENDAR_EXCEPTION']);
    loaded(r, 'CALENDAR_EXCEPTION');
    expect(r.tables.CALENDAR_EXCEPTION.dataCheck).toBeUndefined();
  });

  test('application access: read and write grants, and the DUAL view', async () => {
    await use({ access: { readRoles: 'public', writeRoles: 'public', dualView: true } });
    const r = await run(['CALENDAR_EXCEPTION']);
    loaded(r, 'CALENDAR_EXCEPTION');
    expect(await one(pg, `SELECT dummy FROM "${TARGET}".dual`)).toBe('X');
    const tbl = `"${TARGET}".calendar_exception`;
    expect(await one(pg, `SELECT has_table_privilege('public', $1, 'SELECT')`, [tbl])).toBe(true);
    expect(await one(pg, `SELECT has_table_privilege('public', $1, 'INSERT')`, [tbl])).toBe(true);
  });

  test('application access: a role that does not exist is reported, not ignored', async () => {
    await use({ access: { readRoles: 'dma_no_such_role' } });
    const r = await run(['CALENDAR_EXCEPTION']);
    loaded(r, 'CALENDAR_EXCEPTION');
    expect(r.phases.find((p) => p.key === 'finalize').warnings).toBeGreaterThan(0);
    expect(r.events.map((e) => e.message).join('\n')).toMatch(/does the role exist/);
  });

  test('skip indexes: the index is not created (it is in the run above)', async () => {
    await use({ ora2pg: { SKIP: 'indexes' } });
    const r = await run(['CALENDAR_EXCEPTION']);
    loaded(r, 'CALENDAR_EXCEPTION');
    expect(await indexExists('ix_calendar_station')).toBe(0);
    // Only indexes were skipped: the primary key is still there.
    expect(await one(pg, `SELECT count(*)::int FROM pg_constraint WHERE conrelid = '"${TARGET}".calendar_exception'::regclass AND contype = 'p'`)).toBe(1);
  });

  test('microseconds: kept when on, cut to whole seconds when off', async () => {
    const fractions = `SELECT count(*)::int FROM "${TARGET}".audit_trail WHERE created_at <> date_trunc('second', created_at)`;
    await use({ ora2pg: { ENABLE_MICROSECOND: true } });
    const on = await run(['AUDIT_TRAIL']);
    loaded(on, 'AUDIT_TRAIL');
    expect(await one(pg, fractions)).toBe(1500000);

    await use({ ora2pg: { ENABLE_MICROSECOND: false } });
    const off = await run(['AUDIT_TRAIL']);
    loaded(off, 'AUDIT_TRAIL');
    expect(await one(pg, fractions)).toBe(0);
  });

  test('auto-tune on: loads at once stay within the allowed range, every table loads correctly', async () => {
    await use({ engine: { autoTune: 'on', maxReaders: 0 } });
    const r = await run(['AUDIT_TRAIL', 'SPARE_PART', 'CUSTOMER_MASTER', 'CALENDAR_EXCEPTION', 'DOCUMENTS']);
    for (const t of ['AUDIT_TRAIL', 'SPARE_PART', 'CUSTOMER_MASTER', 'CALENDAR_EXCEPTION', 'DOCUMENTS']) loaded(r, t);
    expect(r.speed).toMatchObject({ auto: true, min: expect.any(Number), max: expect.any(Number) });
    expect(r.speed.max).toBeLessThanOrEqual(r.options.parallelTables * r.options.oracleCopies);
    for (const h of r.speed.history) {
      expect(h.readers).toBeGreaterThanOrEqual(r.speed.min);
      expect(h.readers).toBeLessThanOrEqual(r.speed.max);
    }
    // 2 loads at the start and 3 tables waiting: the first window (worker started with AUTO_TUNE_SECONDS=10) adds one.
    expect(r.speed.history.some((h) => h.action === 'up')).toBe(true);
    expect(r.speed.mbps).toBe(0); // the tuner stopped with the data phase
  });

  test('auto-tune with an admin maximum of 1, and auto-tune off', async () => {
    await use({ engine: { autoTune: 'on', maxReaders: 1 } });
    const one1 = await run(['SPARE_PART', 'CALENDAR_EXCEPTION']);
    loaded(one1, 'SPARE_PART');
    loaded(one1, 'CALENDAR_EXCEPTION');
    expect(one1.speed).toMatchObject({ readers: 1, max: 1 });

    await use({ engine: { autoTune: 'off' } });
    const off = await run(['CALENDAR_EXCEPTION']);
    loaded(off, 'CALENDAR_EXCEPTION');
    expect(off.speed).toBeUndefined();
  });

  test('reserved words off: a table with an OFFSET column is not silently broken', async () => {
    await use({ ora2pg: { USE_RESERVED_WORDS: false } });
    const r = await run(['CUSTOMIZED_RANK']);
    const t = r.tables.CUSTOMIZED_RANK;
    if (t.status === 'done') {
      loaded(r, 'CUSTOMIZED_RANK');
      expect(Object.keys(await types(pg, TARGET, 'customized_rank')).length).toBe(6);
    } else {
      expect(t.status).toBe('failed');
      expect(t.error).toBeTruthy();
    }
  });
});
