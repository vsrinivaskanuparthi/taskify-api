'use strict';

/**
 * Shared by the Settings e2e tests (decisions, options): save settings through the API, migrate
 * into a scratch target schema, read the result back from PostgreSQL.
 */
const API = process.env.DMA_E2E_URL || 'http://localhost:5055';
const PROJECT = process.env.DMA_E2E_PROJECT || 'E2E_TEST';
const P = `${API}/api/projects/${PROJECT}`;
const ENDED = ['COMPLETED', 'COMPLETED_WITH_ERRORS', 'FAILED', 'CANCELLED', 'INTERRUPTED', 'EXPORTED'];

async function call(method, url, body) {
  const res = await fetch(url, { method, headers: body ? { 'Content-Type': 'application/json' } : {}, body: body ? JSON.stringify(body) : undefined });
  const text = await res.text();
  let data = null;
  try { data = text ? JSON.parse(text) : null; } catch { data = text; }
  return { status: res.status, data };
}

async function apiUp() {
  const health = await call('GET', `${API}/api/health`).catch(() => null);
  if (!health || health.status !== 200) throw new Error(`The API is not running at ${API}`);
}

const getSettings = async () => (await call('GET', `${P}/settings`)).data.settings;

/** Saves settings (the whole object, as the Settings page does); fails the test when refused. */
async function saveSettings(settings) {
  const r = await call('PUT', `${P}/settings`, settings);
  if (r.status !== 200) throw new Error(`Settings refused: ${JSON.stringify(r.data)}`);
}

/** Waits until the run ends and returns its final state. */
async function waitRun(runId) {
  for (;;) {
    await new Promise((r) => setTimeout(r, 3000));
    const { data } = await call('GET', `${P}/runs/${runId}`);
    if (ENDED.includes(data.status)) return data;
  }
}

/** Empties the target schema, starts a run of these tables and waits for its end. */
async function migrate(pg, schema, tables) {
  await pg.query(`DROP SCHEMA IF EXISTS "${schema}" CASCADE`);
  const start = await call('POST', `${P}/runs`, { tables });
  if (start.status !== 202) throw new Error(`Run not started: ${JSON.stringify(start.data)}`);
  return waitRun(start.data.runId);
}

/** { column: type } of one target table, e.g. { qty: 'integer', unit_price: 'numeric(12,2)' }. */
async function types(pg, schema, table) {
  const { rows } = await pg.query(
    `SELECT a.attname AS col, format_type(a.atttypid, a.atttypmod) AS type
       FROM pg_attribute a JOIN pg_class c ON c.oid = a.attrelid JOIN pg_namespace n ON n.oid = c.relnamespace
      WHERE n.nspname = $1 AND c.relname = $2 AND a.attnum > 0 AND NOT a.attisdropped`, [schema, table]);
  return Object.fromEntries(rows.map((r) => [r.col, r.type]));
}

/** First value of the first row. */
const one = async (pg, sql, params) => Object.values((await pg.query(sql, params)).rows[0] || {})[0];

/** The table loaded completely: done, row counts equal, column checksums equal. */
function loaded(run, name) {
  const t = run.tables[name];
  expect(t.status).toBe('done');
  expect(t.pgRows).toBe(t.oracleRows);
  if (t.dataCheck) expect(t.dataCheck.ok).toBe(true);
}

module.exports = { API, P, call, apiUp, getSettings, saveSettings, waitRun, migrate, types, one, loaded };
