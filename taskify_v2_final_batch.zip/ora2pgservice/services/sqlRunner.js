'use strict';

const fs = require('fs');
const pLimit = require('p-limit');
const { getPostgresConnection } = require('../utils/postgreClient');

/**
 * Splits an ora2pg output file into statements. ora2pg writes one DDL statement per line
 * (or a few lines ending with ';'); psql meta commands (\set ...) and comments are dropped.
 * Session SET statements are returned apart so they can run on every connection.
 */
function splitSqlFile(file) {
  const text = fs.readFileSync(file, 'utf8');
  const statements = [];
  const sessionSets = [];
  let current = [];
  let inDollar = false;
  for (const raw of text.split('\n')) {
    const line = raw.replace(/\r$/, '');
    const t = line.trim();
    if (!inDollar && current.length === 0 && (t === '' || t.startsWith('--') || t.startsWith('\\'))) continue;
    current.push(line);
    const dollarCount = (line.match(/\$\$/g) || []).length;
    if (dollarCount % 2 === 1) inDollar = !inDollar;
    if (!inDollar && t.endsWith(';')) {
      const stmt = current.join('\n').trim();
      current = [];
      if (/^SET\s/i.test(stmt)) sessionSets.push(stmt);
      else statements.push(stmt);
    }
  }
  if (current.join('').trim()) statements.push(current.join('\n').trim());
  return { statements, sessionSets };
}

// Errors that only mean "this was already done by an earlier attempt": safe to ignore on resume.
const ALREADY_DONE = /already exists|multiple primary keys/i;

/**
 * Runs the statements of an ora2pg file in parallel on the project's PostgreSQL pool.
 * Statement failures do not stop the others; they are returned for the run report.
 * `transform` rewrites each statement before it runs (e.g. foreign keys added NOT VALID); a statement
 * it turns into null is left out (Settings → Skip constraint types).
 */
async function runSqlFile({ file, schema, parallel = 4, maintenanceWorkMem, transform, log, label, shouldStop, onProgress }) {
  if (!file || !fs.existsSync(file)) return { total: 0, ok: 0, skipped: 0, failed: [] };
  const split = splitSqlFile(file);
  const { sessionSets } = split;
  const statements = transform ? split.statements.map(transform).filter(Boolean) : split.statements;
  const total = statements.length;
  const result = { total, ok: 0, skipped: 0, failed: [] };
  if (!total) return result;

  log && log.info(`${label}: ${total} statements from ${file} (parallel ${parallel})`);
  const limit = pLimit(Math.max(1, parallel));
  let doneCount = 0;

  await Promise.all(statements.map((stmt) => limit(async () => {
    if (shouldStop && shouldStop()) return;
    const client = await getPostgresConnection();
    try {
      await client.query(`SET search_path = "${schema}", public`);
      if (maintenanceWorkMem) await client.query(`SET maintenance_work_mem = '${maintenanceWorkMem}'`).catch(() => {});
      for (const s of sessionSets) {
        if (!/search_path/i.test(s)) await client.query(s).catch(() => {});
      }
      await client.query(stmt);
      result.ok += 1;
    } catch (err) {
      if (ALREADY_DONE.test(err.message)) {
        result.skipped += 1;
      } else {
        result.failed.push({ statement: stmt.slice(0, 500), error: err.message });
        log && log.error(`${label}: ${err.message}\n    SQL: ${stmt.slice(0, 300)}`);
      }
    } finally {
      client.release();
      doneCount += 1;
      if (onProgress) onProgress(doneCount, total);
    }
  })));

  log && log.success(`${label}: ${result.ok} applied, ${result.skipped} already present, ${result.failed.length} failed`);
  return result;
}

module.exports = { splitSqlFile, runSqlFile };
