import { Box, Stack, Tooltip, Typography } from '@mui/material';
import { fmtDuration } from '../format';
import { SectionCard } from './ui';

/**
 * "Where did the time go?" on the run page: how long each step took, and while tables loaded,
 * which part was busy: Oracle reading, the network, ora2pg converting on this server, or PostgreSQL
 * writing (measured every few seconds by the engine, see backend services/timeSplit.js).
 */
type Split = Partial<Record<Bucket, number>>;
type Bucket = 'oracle' | 'network' | 'ora2pg' | 'pg' | 'source' | 'other';
interface Props {
  phases: { key: string; label: string; status: string; startedAt?: string; finishedAt?: string }[];
  tables: Record<string, { name: string; status: string; timeSplit?: Split }>;
  note?: string | null;
  now: number;
}

const PARTS: { key: Bucket; label: string; color: string }[] = [
  { key: 'oracle', label: 'Oracle reading', color: '#E8710A' },
  { key: 'network', label: 'Network', color: '#9334E6' },
  { key: 'ora2pg', label: 'ora2pg converting (this server)', color: '#0B57D0' },
  { key: 'pg', label: 'PostgreSQL writing', color: '#188038' },
  { key: 'source', label: 'Oracle, network or ora2pg', color: '#B06000' },
  { key: 'other', label: 'Starting / between parts', color: '#C4CBD6' },
];
const PHASE_COLORS = ['#94A3B8', '#64748B', '#7C9CC9', '#0B57D0', '#188038', '#34A853', '#9AA0A6', '#9334E6', '#5F6368'];

const ADVICE: Record<string, string> = {
  oracle: 'Oracle reading was the slowest part. If the Oracle server has spare CPU and disk, more parts per big table help; otherwise ask the DBA (busy hours, disk speed).',
  network: 'Moving rows over the network from Oracle to this server was the slowest part. A faster or closer network link helps; more tables at once does not.',
  ora2pg: 'Converting rows on this DMA server (ora2pg) was the slowest part. More tables at once helps if this server has free CPU; otherwise more CPU does.',
  pg: 'PostgreSQL writing was the slowest part. Check the PostgreSQL server’s disk and CPU; the “unlogged” load mode in Settings writes faster.',
  source: 'PostgreSQL mostly waited for rows, so Oracle, the network or ora2pg was the slow part.',
};

const sum = (s: Split) => PARTS.reduce((a, p) => a + (s[p.key] || 0), 0);

function Bar({ parts, height = 14 }: { parts: { label: string; color: string; value: number; text?: string }[]; height?: number }) {
  const total = parts.reduce((a, p) => a + p.value, 0) || 1;
  return (
    <Box sx={{ display: 'flex', height, borderRadius: 99, overflow: 'hidden', bgcolor: '#EEF1F5' }}>
      {parts.filter((p) => p.value > 0).map((p) => (
        <Tooltip key={p.label} title={`${p.label}: ${p.text || ''} (${Math.round((p.value / total) * 100)}%)`}>
          <Box sx={{ width: `${(p.value / total) * 100}%`, bgcolor: p.color, minWidth: 2 }} />
        </Tooltip>
      ))}
    </Box>
  );
}

export default function TimeReport({ phases, tables, note, now }: Props) {
  const steps = phases
    .filter((p) => p.startedAt && p.status !== 'pending' && p.status !== 'skipped')
    .map((p, i) => ({ label: p.label, color: PHASE_COLORS[i % PHASE_COLORS.length], value: (p.finishedAt ? new Date(p.finishedAt).getTime() : now) - new Date(p.startedAt!).getTime() }))
    .filter((p) => p.value > 0);
  const list = Object.values(tables).filter((t) => t.timeSplit && sum(t.timeSplit) > 0);
  if (!steps.length) return null;

  const total: Split = {};
  for (const t of list) for (const p of PARTS) total[p.key] = (total[p.key] || 0) + (t.timeSplit![p.key] || 0);
  const measured = sum(total);
  const ranked = PARTS.filter((p) => p.key !== 'other').sort((a, b) => (total[b.key] || 0) - (total[a.key] || 0));
  const top = measured && (total[ranked[0].key] || 0) / measured >= 0.4 ? ranked[0].key : null;
  const slowest = [...list].sort((a, b) => sum(b.timeSplit!) - sum(a.timeSplit!)).slice(0, 5);
  const used = PARTS.filter((p) => (total[p.key] || 0) > 0);
  const ms = (s: number) => fmtDuration(s * 1000);

  return (
    <SectionCard collapsible storeKey="run.time" title="Where did the time go?" subtitle="Each step’s time, and what was slow while tables loaded">
      <Stack spacing={2.5}>
        <Box>
          <Typography variant="caption" fontWeight={700} color="text.secondary">STEPS</Typography>
          <Box sx={{ mt: 0.75 }}><Bar parts={steps.map((s) => ({ ...s, text: fmtDuration(s.value) }))} /></Box>
          <Stack direction="row" flexWrap="wrap" useFlexGap columnGap={2} rowGap={0.5} sx={{ mt: 1 }}>
            {steps.map((s) => (
              <Stack key={s.label} direction="row" spacing={0.75} alignItems="center">
                <Box sx={{ width: 10, height: 10, borderRadius: 1, bgcolor: s.color }} />
                <Typography variant="caption">{s.label}: <b>{fmtDuration(s.value)}</b></Typography>
              </Stack>
            ))}
          </Stack>
        </Box>

        {measured > 0 ? (
          <Box>
            <Typography variant="caption" fontWeight={700} color="text.secondary">WHILE TABLES LOADED</Typography>
            <Box sx={{ mt: 0.75 }}><Bar parts={used.map((p) => ({ label: p.label, color: p.color, value: total[p.key] || 0, text: ms(total[p.key] || 0) }))} /></Box>
            <Stack direction="row" flexWrap="wrap" useFlexGap columnGap={2} rowGap={0.5} sx={{ mt: 1 }}>
              {used.map((p) => (
                <Stack key={p.key} direction="row" spacing={0.75} alignItems="center">
                  <Box sx={{ width: 10, height: 10, borderRadius: 1, bgcolor: p.color }} />
                  <Typography variant="caption">{p.label}: <b>{Math.round(((total[p.key] || 0) / measured) * 100)}%</b></Typography>
                </Stack>
              ))}
            </Stack>
            <Typography variant="body2" sx={{ mt: 1.5 }}>
              {top ? ADVICE[top] : 'No single part held the load back: the time was spread evenly.'}
            </Typography>
            {note && <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 0.5 }}>{note}</Typography>}

            <Typography variant="caption" fontWeight={700} color="text.secondary" sx={{ display: 'block', mt: 2.5 }}>SLOWEST TABLES</Typography>
            <Stack spacing={1} sx={{ mt: 0.75 }}>
              {slowest.map((t) => (
                <Box key={t.name} sx={{ display: 'grid', gridTemplateColumns: 'minmax(120px, 220px) 1fr 70px', gap: 1.5, alignItems: 'center' }}>
                  <Typography className="mono" fontSize={12.5} noWrap title={t.name}>{t.name}</Typography>
                  <Bar height={10} parts={PARTS.map((p) => ({ label: p.label, color: p.color, value: t.timeSplit![p.key] || 0, text: ms(t.timeSplit![p.key] || 0) }))} />
                  <Typography variant="caption" color="text.secondary" textAlign="right">{ms(sum(t.timeSplit!))}</Typography>
                </Box>
              ))}
            </Stack>
          </Box>
        ) : (
          <Typography variant="body2" color="text.secondary">The split of the loading time appears here a few seconds after the first table starts loading.</Typography>
        )}
      </Stack>
    </SectionCard>
  );
}
