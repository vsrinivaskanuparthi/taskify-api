'use strict';

const { CONSTANTS } = require('../utils/constants');
const migrate = require('./migrate');
const worker = require('./workerClient');
const runLock = require('./runLock');

/**
 * What the API's controllers use to start, follow and stop migrations.
 * DMA_WORKER=on: the runs live in the migration worker (worker.js), so restarting or deploying the
 * API never stops them. Otherwise the API runs them itself (as before). Run files (state, logs)
 * are read from disk either way.
 */
const viaWorker = CONSTANTS.WORKER && process.env.DMA_ROLE !== 'worker';
if (viaWorker) worker.start();

async function startRun(projectName, args) {
  if (!viaWorker) return migrate.startRun(projectName, args);
  const run = await worker.call('POST', '/runs/start', { projectName, args });
  worker.remember(projectName, run);
  return run;
}

async function resumeRun(projectName, runId, body) {
  if (!viaWorker) return migrate.resumeRun(projectName, runId, body);
  const run = await worker.call('POST', '/runs/resume', { projectName, runId, body });
  worker.remember(projectName, run);
  return run;
}

/** true when the run was running and is now being cancelled. */
async function cancelRun(projectName, runId) {
  if (!viaWorker) return migrate.cancelRun(projectName, runId);
  return (await worker.call('POST', '/runs/cancel', { projectName, runId })).ok;
}

/** Summary of the project's running run (no tables), or null. */
function activeRun(projectName) {
  if (!viaWorker) return migrate.activeRunSummary(projectName);
  // The lock file covers the moment before the worker's first event arrives (or while the API reconnects to it).
  const lock = worker.active.has(projectName) ? null : runLock.heldByOther(projectName);
  return worker.active.get(projectName) || (lock && { runId: lock.runId, status: 'RUNNING', projectName }) || null;
}

/** The running run with its tables (for a browser that just opened the project), or null. */
async function activeRunFull(projectName) {
  if (!viaWorker) return migrate.activeRunSummary(projectName);
  if (!worker.active.has(projectName)) return null;
  return worker.call('GET', `/runs/active?project=${encodeURIComponent(projectName)}`).catch(() => null);
}

module.exports = {
  viaWorker,
  startRun,
  resumeRun,
  cancelRun,
  activeRun,
  activeRunFull,
  listRuns: migrate.listRuns,
  readRunState: migrate.readRunState,
  browserState: migrate.browserState,
  runLogPath: migrate.runLogPath,
};
