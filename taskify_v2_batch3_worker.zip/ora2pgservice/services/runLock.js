'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const store = require('./projectStore');

/**
 * One migration per project, also across processes (the API and the migration worker, or a
 * second copy of either): <project>/.run.lock holds the process id that runs it. A lock whose
 * process is gone (crash, restart) is stale and is taken over.
 */
const lockPath = (projectName) => path.join(store.projectDir(projectName), '.run.lock');

function alive(pid) {
  if (!pid || pid === process.pid) return pid === process.pid;
  try {
    process.kill(pid, 0);
    return true;
  } catch (err) {
    return err.code === 'EPERM'; // exists, owned by another user
  }
}

function read(projectName) {
  try {
    return JSON.parse(fs.readFileSync(lockPath(projectName), 'utf8'));
  } catch {
    return null;
  }
}

/** The lock when another living process on this server holds it, else null. */
function heldByOther(projectName) {
  const l = read(projectName);
  if (!l || l.pid === process.pid || (l.host && l.host !== os.hostname())) return null;
  return alive(l.pid) ? l : null;
}

function acquire(projectName, runId) {
  const other = heldByOther(projectName);
  if (other) {
    throw Object.assign(new Error(`A migration of this project is already running (run ${other.runId}, process ${other.pid}).`), { status: 409 });
  }
  const file = lockPath(projectName);
  const data = JSON.stringify({ pid: process.pid, host: os.hostname(), runId, at: new Date().toISOString() });
  fs.mkdirSync(path.dirname(file), { recursive: true });
  try {
    fs.writeFileSync(file, data, { flag: 'wx' }); // fails if a lock file exists, even one written a moment ago
  } catch (err) {
    if (err.code !== 'EEXIST') throw err;
    // Stale (its process is gone) or ours: replace it, unless another process took it just now.
    const again = heldByOther(projectName);
    if (again) throw Object.assign(new Error(`A migration of this project is already running (run ${again.runId}, process ${again.pid}).`), { status: 409 });
    const tmp = `${file}.${process.pid}.tmp`;
    fs.writeFileSync(tmp, data);
    fs.renameSync(tmp, file);
  }
}

/** Removes the lock if this process holds it. */
function release(projectName) {
  const l = read(projectName);
  if (l && l.pid === process.pid) fs.rmSync(lockPath(projectName), { force: true });
}

module.exports = { acquire, release, heldByOther, lockPath };
