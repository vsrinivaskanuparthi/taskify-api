'use strict';

const crypto = require('crypto');
const fs = require('fs');
const http = require('http');
const path = require('path');
const { CONSTANTS } = require('../utils/constants');
const logger = require('../utils/logger');
const events = require('./events');

/**
 * The API's side of the migration worker (worker.js, DMA_WORKER=on).
 * Start / resume / cancel are sent to the worker over 127.0.0.1; the worker's live events come
 * back on one stream and are published here, so the browsers' event streams work as before.
 * The worker's running runs are remembered from those events (`active`), which is what the
 * "is a migration running?" checks of the API read.
 */
const TERMINAL = new Set(['COMPLETED', 'COMPLETED_WITH_ERRORS', 'FAILED', 'CANCELLED', 'INTERRUPTED', 'EXPORTED']);
const active = new Map(); // projectName -> run summary (no tables)
let connected = false;

/** Shared secret of the API and the worker: a random file in the staging folder, readable by the service user only. */
function workerToken() {
  const file = path.join(CONSTANTS.STAGING_DIR, '.dma_worker_token');
  try {
    fs.mkdirSync(CONSTANTS.STAGING_DIR, { recursive: true });
    fs.writeFileSync(file, crypto.randomBytes(24).toString('hex'), { mode: 0o600, flag: 'wx' });
  } catch (err) {
    if (err.code !== 'EEXIST') throw err;
  }
  return fs.readFileSync(file, 'utf8').trim();
}

const notRunning = () => Object.assign(new Error(
  'The migration worker is not running, so migrations cannot be started or stopped right now. '
  + 'On the server: pm2 start worker.js --name ora2pg-worker-prod (or run the deploy again).',
), { status: 503 });

/** One JSON request to the worker. Errors keep the worker's status and message. */
function call(method, urlPath, body) {
  return new Promise((resolve, reject) => {
    const data = body === undefined ? null : Buffer.from(JSON.stringify(body));
    const req = http.request({
      host: '127.0.0.1',
      port: CONSTANTS.WORKER_PORT,
      method,
      path: urlPath,
      timeout: 60000,
      headers: { 'x-dma-token': workerToken(), ...(data && { 'content-type': 'application/json', 'content-length': data.length }) },
    }, (res) => {
      let text = '';
      res.setEncoding('utf8');
      res.on('data', (c) => { text += c; });
      res.on('end', () => {
        let json = null;
        try { json = text ? JSON.parse(text) : null; } catch { /* not JSON */ }
        if (res.statusCode >= 400) return reject(Object.assign(new Error((json && json.message) || `Worker answered ${res.statusCode}`), { status: res.statusCode }));
        resolve(json);
      });
    });
    req.on('timeout', () => req.destroy(new Error('timeout')));
    req.on('error', (err) => reject(['ECONNREFUSED', 'ECONNRESET'].includes(err.code) ? notRunning() : err));
    if (data) req.write(data);
    req.end();
  });
}

function remember(projectName, summary) {
  if (!summary || TERMINAL.has(summary.status)) active.delete(projectName);
  else active.set(projectName, summary);
}

/** Keeps one event stream open to the worker, and opens it again whenever it drops (worker restarted). */
function connect() {
  let buf = '';
  const req = http.get({ host: '127.0.0.1', port: CONSTANTS.WORKER_PORT, path: '/events', headers: { 'x-dma-token': workerToken() } }, (res) => {
    if (res.statusCode !== 200) { res.resume(); return; }
    connected = true;
    logger.info('Connected to the migration worker');
    res.setEncoding('utf8');
    res.on('data', (chunk) => {
      buf += chunk;
      let i;
      while ((i = buf.indexOf('\n\n')) >= 0) {
        const block = buf.slice(0, i);
        buf = buf.slice(i + 2);
        const line = block.split('\n').find((l) => l.startsWith('data: '));
        if (!line) continue;
        let msg;
        try { msg = JSON.parse(line.slice(6)); } catch { continue; }
        if (msg.hello) {
          // The worker's running runs right now (sent first on every new connection).
          active.clear();
          for (const r of msg.active || []) active.set(r.projectName, r);
          continue;
        }
        if (msg.type === 'run') remember(msg.projectName, msg.data);
        events.publish(msg.projectName, msg.type, msg.data);
      }
    });
  });
  // Lost: the worker's runs are not known any more (a stopped worker runs nothing). Try again in 3 s.
  const retry = () => {
    if (connected) logger.warn('Lost the connection to the migration worker; trying again');
    connected = false;
    active.clear();
    setTimeout(connect, 3000).unref();
  };
  req.on('error', () => {});
  req.on('close', retry);
}

let started = false;
function start() {
  if (started) return;
  started = true;
  connect();
}

module.exports = { call, start, remember, active, workerToken, isConnected: () => connected };
