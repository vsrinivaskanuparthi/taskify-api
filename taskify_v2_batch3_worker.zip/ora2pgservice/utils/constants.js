'use strict';

const path = require('path');

const num = (v, d) => (v !== undefined && v !== '' && !Number.isNaN(Number(v)) ? Number(v) : d);

const CONSTANTS = {
    // Where ora2pg projects are created (one folder per project)
    STAGING_DIR: process.env.MIGRATION_STAGING_DIR
        ? path.resolve(path.join(__dirname, '..'), process.env.MIGRATION_STAGING_DIR)
        : '/migration_staging/',
    // Helper scripts and the ora2pg.conf template shipped with this backend
    SCRIPTS_DIR: process.env.SCRIPTS_DIR || path.join(__dirname, '..', 'scripts'),
    // PostgreSQL SSL for ora2pg and psql: not set = use SSL when the server offers it (psql's own default,
    // as in v1); PG_SSL=true = require it; PG_SSL=false = never.
    PG_SSLMODE: process.env.PG_SSL === 'false' ? 'disable' : process.env.PG_SSL === 'true' ? 'require' : 'prefer',
    // Commands (override when they are not on PATH)
    ORA2PG_BIN: process.env.ORA2PG_BIN || 'ora2pg',
    PSQL_BIN: process.env.PSQL_BIN || 'psql',
    // Host ora2pg uses to reach PostgreSQL for direct loading (defaults to the target host).
    // Only needed when ora2pg runs somewhere else, e.g. inside Docker on a dev machine.
    ORA2PG_PG_HOST: process.env.ORA2PG_PG_HOST || '',
    ORA2PG_PG_PORT: process.env.ORA2PG_PG_PORT || '',
    // Same for Oracle (dev only: ora2pg in Docker reaches Oracle through the host).
    ORA2PG_ORACLE_HOST: process.env.ORA2PG_ORACLE_HOST || '',
    ORA2PG_ORACLE_PORT: process.env.ORA2PG_ORACLE_PORT || '',

    // ---- Migration engine defaults (each can be changed per run from the UI) ----
    // direct = ora2pg streams rows straight into PostgreSQL (no data files on disk).
    // file   = ora2pg writes one table to a file, psql loads it, the file is deleted.
    LOAD_MODE: process.env.LOAD_MODE || 'direct',
    PARALLEL_TABLES: num(process.env.PARALLEL_TABLES, 4),     // tables loaded at the same time
    HUGE_TABLE_ROWS: num(process.env.HUGE_TABLE_ROWS, 2000000), // above this a table is "huge"
    ORACLE_COPIES: num(process.env.ORACLE_COPIES, 4),          // Oracle readers per huge table (-J)
    PG_JOBS: num(process.env.PG_JOBS, 4),                      // PostgreSQL writers per huge table (-j)
    DATA_LIMIT: num(process.env.DATA_LIMIT, 10000),            // rows per batch (normal tables)
    BLOB_LIMIT: num(process.env.BLOB_LIMIT, 500),              // rows per batch (tables with LOBs)
    CHUNK_ROWS: num(process.env.CHUNK_ROWS, 5000000),          // huge tables are loaded in PK-range chunks of this size (0 = off)
    MAX_ATTEMPTS: num(process.env.MAX_ATTEMPTS, 3),            // tries per table before it is marked failed
    DDL_PARALLEL: num(process.env.DDL_PARALLEL, 4),            // index / constraint statements at the same time
    MAINTENANCE_WORK_MEM: process.env.MAINTENANCE_WORK_MEM || '1GB',
    VERIFY_ROW_COUNTS: process.env.VERIFY_ROW_COUNTS !== 'false',
    CHUNK_MB: num(process.env.CHUNK_MB, 1024),                 // tables bigger than this (e.g. LOB tables) are chunked too, ~this size per chunk
    STALL_MINUTES: num(process.env.STALL_MINUTES, 20),         // a load with no progress for this long is stopped and retried (0 = off)
    VERIFY_DATA: process.env.VERIFY_DATA || 'all',             // 'all' = column checksums after the row count, 'off'
    LOB_MEMORY_MB: num(process.env.LOB_MEMORY_MB, 128),        // memory per ora2pg process for inline LOB batches
    SNAPSHOT: process.env.SNAPSHOT === 'off' ? 'off' : 'on',   // 'on' = all tables read AS OF one SCN (needs FLASHBACK and undo), 'off' = as they are now
    BULK_LOAD: process.env.BULK_LOAD === 'unlogged' ? 'unlogged' : 'standard', // 'unlogged' = tables loaded without WAL, made permanent after verification
    LOAD_GB_PER_HOUR: num(process.env.LOAD_GB_PER_HOUR, 30),  // speed assumed by the pre-flight estimate until a run of the project measured it (v1: 450 GB in 15 h)
    MAX_RUNS: num(process.env.DMA_MAX_RUNS, 2),                // migrations running at the same time on this server (all projects)

    // ---- Migration worker: runs migrations in their own process, so restarting the API never stops them ----
    // DMA_WORKER=on: the API hands migrations to the worker (node worker.js, its own pm2 app). Not set: the API runs them itself.
    WORKER: process.env.DMA_WORKER === 'on',
    WORKER_PORT: num(process.env.DMA_WORKER_PORT, 5101),        // the worker listens on 127.0.0.1 only

    // PostgreSQL reserved key words (PG 16 docs, "reserved" and "reserved (can be function or type)"),
    // plus the v1 additions. Columns with these names need quoting or renaming.
    RESERVED_WORDS: [
        "ALL", "ANALYSE", "ANALYZE", "AND", "ANY", "ARRAY", "AS", "ASC", "ASYMMETRIC", "AUTHORIZATION",
        "BINARY", "BOTH", "CASE", "CAST", "CHECK", "CLUSTER", "COLLATE", "COLLATION", "COLUMN", "CONCURRENTLY",
        "CONSTRAINT", "COPY", "CREATE", "CROSS", "CURRENT_CATALOG", "CURRENT_DATE", "CURRENT_ROLE", "CURRENT_SCHEMA", "CURRENT_TIME", "CURRENT_TIMESTAMP",
        "CURRENT_USER", "DEFAULT", "DEFERRABLE", "DESC", "DISTINCT", "DO", "ELSE", "END", "EXCEPT", "FALSE",
        "FETCH", "FOR", "FOREIGN", "FREEZE", "FROM", "FULL", "GRANT", "GROUP", "HAVING", "ILIKE",
        "IN", "INITIALLY", "INNER", "INTERSECT", "INTO", "IS", "ISNULL", "JOIN", "LATERAL", "LEADING",
        "LEFT", "LIKE", "LIMIT", "LOCALTIME", "LOCALTIMESTAMP", "NATURAL", "NOT", "NOTNULL", "NULL", "OFFSET",
        "ON", "ONLY", "OR", "ORDER", "OUTER", "OVERLAPS", "PLACING", "PRIMARY", "REFERENCES", "RETURNING",
        "RIGHT", "SELECT", "SESSION_USER", "SIMILAR", "SOME", "SYMMETRIC", "SYSTEM_USER", "TABLE", "TABLESAMPLE", "THEN",
        "TO", "TRAILING", "TRUE", "UNION", "UNIQUE", "USER", "USING", "VARIADIC", "VERBOSE", "WHEN",
        "WHERE", "WINDOW", "WITH", "ABORT", "EXPLAIN", "EXTEND", "LISTEN", "LOAD", "LOCK", "MOVE",
        "NEW", "NONE", "NOTIFY", "RESET", "SETOF", "SHOW", "UNLISTEN", "UNTIL", "VACUUM",
    ]
};


module.exports = { CONSTANTS };
