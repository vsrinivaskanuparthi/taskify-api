'use strict';

/**
 * DMA migration worker. Runs the migrations in their own process, so restarting the API
 * (a deploy, a crash, an SSO change) never stops a migration that is loading data.
 *
 *   pm2 start worker.js --name ora2pg-worker-prod     (from the backend folder, next to .env)
 *   and DMA_WORKER=on in .env, so the API sends its migrations here.
 *
 * Listens on 127.0.0.1 only (DMA_WORKER_PORT, default 5101). Every call except /health needs the
 * shared token from the staging folder (.dma_worker_token), which only the service user can read.
 * Restarting the worker itself interrupts its runs, as restarting the API did before: they are
 * marked INTERRUPTED and Resume continues them. deploy/server-deploy.sh restarts it only when no
 * migration is running.
 */
process.env.DMA_ROLE = 'worker';
require('dotenv').config({ path: require('path').join(__dirname, '.env') });

const express = require('express');
const crypto = require('crypto');
const { CONSTANTS } = require('./utils/constants');
const logger = require('./utils/logger');
const migrate = require('./services/migrate');
const events = require('./services/events');
const { workerToken } = require('./services/workerClient');

const token = workerToken();
const app = express();
app.use(express.json({ limit: '5mb' }));

app.get('/health', (req, res) => res.json({ ok: true, pid: process.pid, running: migrate.activeRuns().length }));

app.use((req, res, next) => {
  const given = Buffer.from(String(req.get('x-dma-token') || ''));
  const want = Buffer.from(token);
  if (given.length !== want.length || !crypto.timingSafeEqual(given, want)) return res.status(401).json({ message: 'Not allowed' });
  next();
});

const handle = (fn) => async (req, res) => {
  try {
    res.json(await fn(req));
  } catch (err) {
    if (!err.status) logger.error(err.stack || err.message);
    res.status(err.status || 500).json({ message: err.message });
  }
};

app.post('/runs/start', handle((req) => migrate.startRun(req.body.projectName, req.body.args || {})));
app.post('/runs/resume', handle((req) => migrate.resumeRun(req.body.projectName, req.body.runId, req.body.body || {})));
app.post('/runs/cancel', handle(async (req) => ({ ok: migrate.cancelRun(req.body.projectName, req.body.runId) })));
app.get('/runs/active', handle(async (req) => migrate.activeRunSummary(String(req.query.project || ''))));

/** Every event of every project, for the API. Starts with the runs that are running now. */
app.get('/events', (req, res) => {
  res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive' });
  const send = (msg) => res.write(`data: ${JSON.stringify(msg)}\n\n`);
  send({ hello: true, active: migrate.activeRuns() });
  const off = events.subscribeAll((projectName, evt) => send({ projectName, type: evt.type, data: evt.data }));
  const ping = setInterval(() => res.write(': ping\n\n'), 15000);
  req.on('close', () => { clearInterval(ping); off(); });
});

process.on('unhandledRejection', (err) => logger.error(`Unhandled rejection: ${err && err.stack ? err.stack : err}`));
process.on('uncaughtException', (err) => logger.error(`Uncaught exception: ${err.stack}`));

const shutdown = (signal) => {
  logger.warn(`Worker: ${signal} received, stopping running migrations (they can be resumed).`);
  migrate.shutdown();
  setTimeout(() => process.exit(0), 1500);
};
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

migrate.recoverInterruptedRuns()
  .catch((err) => logger.error(`Run recovery failed: ${err.message}`))
  .finally(() => {
    app.listen(CONSTANTS.WORKER_PORT, '127.0.0.1', () => logger.info(`DMA migration worker is running on 127.0.0.1:${CONSTANTS.WORKER_PORT}`));
  });
