'use strict';

const fs = require('fs');
const migrate = require('../services/runs');
const store = require('../services/projectStore');
const logger = require('../utils/logger');
const { preflight, sizing } = require('../services/preflight');
const { autoSettingsFor } = require('../services/autoSettings');
const { isAdmin } = require('../utils/roles');
const settingsSvc = require('../services/settings');

const fail = (res, err) => {
  if (!err.status) logger.error(err.stack || err.message);
  res.status(err.status || 500).json({ message: err.message });
};

/**
 * The options a run really uses: the project's Settings (Run defaults, set by an admin), plus the
 * numbers DMA chooses (tables at a time, parts at a time) unless Settings switched that off.
 * Whatever the browser sends is ignored, so the Migrate page is the same simple screen for everyone.
 */
async function effectiveOptions(req, tables) {
  const admin = isAdmin(req);
  const engine = settingsSvc.resolve(req.project).engine || {};
  if (engine.auto === false) return { options: {}, auto: null, admin };
  const auto = await autoSettingsFor(req.projectName, tables);
  return { options: auto.options, auto, admin };
}

/** Capacity pre-flight for the planned run (tables + options from the Migrate page). */
async function preflightRun(req, res) {
  try {
    const tables = Array.isArray((req.body || {}).tables) ? req.body.tables : [];
    const eff = await effectiveOptions(req, tables);
    res.json({ ...(await preflight(req.projectName, { tables, options: eff.options })), auto: eff.auto, admin: eff.admin });
  } catch (err) {
    fail(res, err);
  }
}

/** Assessment → Resource estimate: this server's CPU, RAM and staging disk, and what the schema needs. */
async function sizingInfo(req, res) {
  try {
    res.json(await sizing(req.projectName));
  } catch (err) {
    fail(res, err);
  }
}

async function startRun(req, res) {
  try {
    const { tables, codePackageId } = req.body;
    if (!Array.isArray(tables) || !tables.length) return res.status(400).json({ message: 'Select at least one table.' });
    const snap = await store.readSnapshot(req.projectName, req.project.selectedSchema);
    const allNames = (snap && snap.tableMetadata ? snap.tableMetadata.map((t) => t.name) : []);
    const unknown = tables.filter((t) => !allNames.includes(t));
    if (unknown.length) return res.status(400).json({ message: `Unknown tables: ${unknown.slice(0, 5).join(', ')}` });
    const { options } = await effectiveOptions(req, tables);
    // Capacity problems found by the pre-flight (staging disk, connections) stop the run here too.
    const pf = await preflight(req.projectName, { tables, options, quick: true });
    const blocked = pf.checks.filter((c) => c.level === 'block');
    if (blocked.length) return res.status(400).json({ message: `Pre-flight: ${blocked.map((c) => `${c.check}: ${c.description}`).join(' ')}` });
    const run = await migrate.startRun(req.projectName, {
      tables,
      options,
      codePackageId,
      allTablesSelected: tables.length === allNames.length,
      startedBy: store.userOf(req),
      // "Notify me when it ends": one address, checked here (the run sends to it at the end).
      notifyEmails: /^[^\s@,;]+@[^\s@,;]+\.[^\s@,;]+$/.test(String(req.body.notifyEmail || '')) ? [String(req.body.notifyEmail)] : [],
    });
    res.status(202).json(run);
  } catch (err) {
    fail(res, err);
  }
}

async function listRuns(req, res) {
  try {
    res.json({ runs: await migrate.listRuns(req.projectName) });
  } catch (err) {
    fail(res, err);
  }
}

async function getRun(req, res) {
  const state = await migrate.readRunState(req.projectName, req.params.runId);
  if (!state) return res.status(404).json({ message: 'Run not found.' });
  res.json(migrate.browserState(state));
}

async function resumeRun(req, res) {
  try {
    // Resume keeps the run's own settings; the only changes are the two buttons on the run page:
    // "Resume without snapshot" and "Import exported files".
    const body = { ...(req.body || {}) };
    const o = body.options || {};
    body.options = { ...(o.snapshot === 'off' && { snapshot: 'off' }), ...(o.loadMode === 'file' && { loadMode: 'file' }) };
    res.status(202).json(await migrate.resumeRun(req.projectName, req.params.runId, body));
  } catch (err) {
    fail(res, err);
  }
}

async function cancelRun(req, res) {
  try {
    const ok = await migrate.cancelRun(req.projectName, req.params.runId);
    if (!ok) return res.status(409).json({ message: 'This run is not running.' });
    res.status(202).json({ message: 'Cancelling…' });
  } catch (err) {
    fail(res, err);
  }
}

function downloadLog(req, res) {
  const { runId, kind } = req.params;
  if (!['master', 'error', 'success', 'table'].includes(kind) || !/^[0-9-]+$/.test(runId)) return res.status(400).end();
  const file = migrate.runLogPath(req.projectName, runId, kind, req.query.table);
  if (!fs.existsSync(file)) return res.status(404).json({ message: 'Log not found.' });
  if (req.query.tail) {
    // Last N kB, for the in-app log viewer.
    const size = fs.statSync(file).size;
    const bytes = Math.min(size, Number(req.query.tail) * 1024 || 65536);
    const fd = fs.openSync(file, 'r');
    const buf = Buffer.alloc(bytes);
    fs.readSync(fd, buf, 0, bytes, size - bytes);
    fs.closeSync(fd);
    return res.type('text/plain').send(buf.toString('utf8'));
  }
  const name = kind === 'table' ? `${req.projectName}_${runId}_${req.query.table}.log` : `${req.projectName}_${runId}_${kind}.log`;
  res.download(file, name);
}

module.exports = { sizingInfo, preflightRun, startRun, listRuns, getRun, resumeRun, cancelRun, downloadLog };
