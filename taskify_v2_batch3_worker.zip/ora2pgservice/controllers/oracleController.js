const { runPrerequisiteAnalysis } = require("../queries/oracle/analyzePrerequisites");
const { getDBSchema } = require("../queries/oracle/getDBSchema");
const { initOracle, ensureOraclePool, getOracleConnection, closeOraclePool } = require('../utils/oracleClient');
const logger = require("../utils/logger");
const secrets = require('../utils/secrets');
const store = require('../services/projectStore');
const snapshot = require('../services/snapshot');

/** Makes sure the project's Oracle pool exists (e.g. after a server restart). */
async function ensureSource(req) {
  await ensureOraclePool(store.oracleCredentials(req.project), req.projectName);
}

async function create(req, res) {
  try {
    logger.info(`Oracle connect for project ${req.projectName}`);
    const payload = req.body;
    const response = await initOracle(payload, req.projectName);

    if (response && response.isConnected) {
      const schemas = response.schema.map((r) => r[0]);
      await store.updateMeta(req.projectName, (m) => ({
        ...m,
        oracle: {
          userUrl: payload.userUrl.trim(),
          userUsername: payload.userUsername,
          password: secrets.encrypt(payload.userPassword),
          isIp: payload.userUrl.trim().startsWith('('),
          connectedAt: new Date().toISOString(),
        },
        schemas,
      }));
      res.status(200).send({ status: 200, message: 'Database successfully connected', schema: response.schema, schemas });
    } else {
      res.status(500).send({ status: 500, message: 'Database failed to connect' });
    }
  } catch (error) {
    logger.error('Oracle connect failed', error);
    res.status(400).send({ status: 400, message: error.message });
  }
}

/** Schema list from the saved connection (v1's UI called a /schemas endpoint that did not exist). */
async function listSchemas(req, res) {
  let connection;
  try {
    await ensureSource(req);
    connection = await getOracleConnection(req.projectName);
    const rows = await getDBSchema(connection);
    const schemas = rows.map((r) => r[0]);
    await store.updateMeta(req.projectName, (m) => ({ ...m, schemas }));
    res.json({ schemas });
  } catch (error) {
    res.status(400).json({ message: error.message, schemas: req.project.schemas || [] });
  } finally {
    if (connection) await connection.close().catch(() => {});
  }
}

async function selectSchema(req, res) {
  const { name } = req.body;
  const known = req.project.schemas || [];
  if (known.length && !known.includes(name)) return res.status(400).json({ message: `Unknown schema ${name}.` });
  const meta = await store.updateMeta(req.projectName, (m) => ({ ...m, selectedSchema: name }));
  const snap = await store.readSnapshot(req.projectName, name);
  res.json({ project: store.publicMeta(meta), hasSnapshot: !!snap, snapshotAt: snap ? snap.snapshotAt : null });
}

/** Starts the snapshot in the background; progress arrives over the project's event stream. */
async function startSnapshot(req, res) {
  const schemaName = req.project.selectedSchema;
  if (!schemaName) return res.status(400).json({ message: 'Select a schema first.' });
  try {
    await ensureSource(req);
  } catch (err) {
    return res.status(400).json({ message: err.message });
  }
  res.status(202).json(snapshot.start(req.projectName, schemaName));
}

async function getSnapshot(req, res) {
  const schemaName = req.query.schema || req.project.selectedSchema;
  const running = snapshot.status(req.projectName);
  const data = await store.readSnapshot(req.projectName, schemaName);
  if (!data) return res.status(running ? 202 : 404).json({ message: 'No snapshot yet.', running });
  res.json(data);
}

async function analyzePrerequisites(req, res) {
  let connection;
  try {
    const schemaName = req.project.selectedSchema;
    const migrationUser = req.project.oracle && req.project.oracle.userUsername;
    if (!schemaName || !migrationUser) {
      return res.status(400).json({ message: 'Schema name and Oracle user name are required for analysis.' });
    }
    await ensureSource(req);
    connection = await getOracleConnection(req.projectName);
    const analysisResults = await runPrerequisiteAnalysis(connection, schemaName, migrationUser);
    res.status(200).json(analysisResults);
  } catch (error) {
    logger.error('analyzePrerequisites method failed:', error);
    res.status(500).json({ message: 'An error occurred during prerequisite analysis.', error: error.message });
  } finally {
    if (connection) await connection.close().catch(() => {});
  }
}

/** Forgets the project's Oracle connection (same as PostgreSQL's Disconnect). Refused while a migration runs. */
async function disconnect(req, res) {
  if (require('../services/runs').activeRun(req.projectName)) {
    return res.status(409).json({ message: 'A migration of this project is running: wait for it or cancel it before disconnecting.' });
  }
  await closeOraclePool(req.projectName);
  await store.updateMeta(req.projectName, (m) => ({ ...m, oracle: null }));
  res.json({ message: 'Disconnected' });
}

module.exports = { create, disconnect, listSchemas, selectSchema, startSnapshot, getSnapshot, analyzePrerequisites, ensureSource };
