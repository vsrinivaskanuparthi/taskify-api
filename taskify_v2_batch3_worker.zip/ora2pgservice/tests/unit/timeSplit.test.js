'use strict';

// "Where did the time go?": what each session is doing, which table it works on, and the seconds per bucket.
const { oracleActivity, pgActivity, oracleTableOf, pgTableOf, splitSample, summarize, TimeSampler } = require('../../services/timeSplit');

describe('what a session is doing', () => {
  test('Oracle: CPU and disk reads are Oracle, sending rows is network, waiting for ora2pg is idle', () => {
    expect(oracleActivity({ state: 'WAITED SHORT TIME', event: 'db file scattered read' })).toBe('oracle');
    expect(oracleActivity({ state: 'WAITING', event: 'db file sequential read', waitClass: 'User I/O' })).toBe('oracle');
    expect(oracleActivity({ state: 'WAITING', event: 'SQL*Net more data to client', waitClass: 'Network' })).toBe('network');
    expect(oracleActivity({ state: 'WAITING', event: 'SQL*Net message from client', waitClass: 'Idle' })).toBe('idle');
  });

  test('PostgreSQL: busy is writing; waiting for its client (ClientRead) or idle is not', () => {
    expect(pgActivity({ state: 'active', waitEvent: null })).toBe('pg');
    expect(pgActivity({ state: 'active', waitEvent: 'WALWrite' })).toBe('pg');
    expect(pgActivity({ state: 'active', waitEvent: 'ClientRead' })).toBe('idle');
    expect(pgActivity({ state: 'idle in transaction', waitEvent: 'ClientRead' })).toBe('idle');
  });
});

describe('which table a statement works on', () => {
  const names = ['ORDERS', 'ORDER_ITEMS'];
  test('Oracle: the table after FROM, with or without the schema and quotes, never a longer name', () => {
    expect(oracleTableOf('SELECT "ID","QTY" FROM "SHOP"."ORDER_ITEMS" a WHERE ROWID BETWEEN :1 AND :2', 'SHOP', names)).toBe('ORDER_ITEMS');
    expect(oracleTableOf('SELECT id FROM shop.orders WHERE id > 5', 'SHOP', names)).toBe('ORDERS');
    expect(oracleTableOf('SELECT id FROM ORDERS_ARCHIVE', 'SHOP', names)).toBe(null);
    expect(oracleTableOf('SELECT 1 FROM dual', 'SHOP', names)).toBe(null);
  });

  test('PostgreSQL: COPY into the table, or its schema-qualified name', () => {
    const pgNames = [['orders', 'ORDERS'], ['order_items', 'ORDER_ITEMS']];
    expect(pgTableOf('COPY "shop"."order_items" ("id","qty") FROM STDIN', 'shop', pgNames)).toBe('ORDER_ITEMS');
    expect(pgTableOf('COPY orders (id) FROM STDIN', 'shop', pgNames)).toBe('ORDERS');
    expect(pgTableOf('SELECT count(*) FROM "shop"."orders"', 'shop', pgNames)).toBe('ORDERS');
    expect(pgTableOf('COPY orders_archive (id) FROM STDIN', 'shop', pgNames)).toBe(null);
  });
});

describe('splitting one sample', () => {
  test('working sessions share the time; all waiting means ora2pg converts; none seen is other', () => {
    expect(splitSample(['pg', 'idle'])).toEqual({ pg: 1 });
    expect(splitSample(['oracle', 'oracle', 'pg', 'network'])).toEqual({ oracle: 0.5, pg: 0.25, network: 0.25 });
    expect(splitSample(['idle', 'idle'])).toEqual({ ora2pg: 1 });
    expect(splitSample([])).toEqual({ other: 1 });
  });

  test('summary names the biggest part only when it is clearly the biggest', () => {
    expect(summarize([{ oracle: 60, pg: 20 }, { oracle: 10, ora2pg: 10 }]).top).toBe('oracle');
    expect(summarize([{ oracle: 30, pg: 30, ora2pg: 30, network: 30 }]).top).toBe(null);
  });
});

describe('TimeSampler', () => {
  const run = (tables) => ({
    state: { schema: 'SHOP', tables },
    pgSchema: 'shop',
    pgName: (n) => n.toLowerCase(),
    save: () => {},
  });

  test('adds the seconds of each sample to the loading tables only', async () => {
    const r = run({ ORDERS: { name: 'ORDERS', status: 'running' }, ORDER_ITEMS: { name: 'ORDER_ITEMS', status: 'done' } });
    const s = new TimeSampler({
      run: r,
      oracleQuery: async (sql) => (/v\$session/.test(sql)
        ? [{ state: 'WAITING', event: 'db file scattered read', waitClass: 'User I/O', sqlId: 'a1' }]
        : [{ sqlId: 'a1', text: 'SELECT * FROM "SHOP"."ORDERS"' }]),
      pgQuery: async () => [{ state: 'active', waitEvent: 'ClientRead', query: 'COPY orders (id) FROM STDIN' }],
    });
    s.last = Date.now() - 5000;
    await s.tick();
    expect(r.state.tables.ORDERS.timeSplit.oracle).toBeCloseTo(5, 0);
    expect(r.state.tables.ORDER_ITEMS.timeSplit).toBeUndefined();
  });

  test('without access to v$session: PostgreSQL measured, the rest is "source", and a note says why', async () => {
    const r = run({ ORDERS: { name: 'ORDERS', status: 'running' } });
    const s = new TimeSampler({
      run: r,
      oracleQuery: async () => { throw new Error('ORA-00942: table or view does not exist'); },
      pgQuery: async () => [{ state: 'active', waitEvent: 'ClientRead', query: 'COPY orders (id) FROM STDIN' }],
    });
    s.last = Date.now() - 5000;
    await s.tick();
    expect(r.state.tables.ORDERS.timeSplit.source).toBeCloseTo(5, 0);
    expect(r.state.timeSplitNote).toMatch(/ORA-00942/);
  });
});
