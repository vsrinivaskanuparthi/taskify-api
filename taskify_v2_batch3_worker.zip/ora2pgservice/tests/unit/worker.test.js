'use strict';

// The migration worker: one run per project across processes (lock file), and its door locked to the API.
const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');
const { spawn } = require('child_process');

const staging = fs.mkdtempSync(path.join(os.tmpdir(), 'dma-worker-'));
process.env.MIGRATION_STAGING_DIR = staging;
const runLock = require('../../services/runLock');

afterAll(() => fs.rmSync(staging, { recursive: true, force: true }));

describe('run lock', () => {
  test('a lock of a living process is respected; a stale one is taken over; release removes it', () => {
    fs.mkdirSync(path.join(staging, 'P1'), { recursive: true });
    // Held by a process that is gone: stale.
    fs.writeFileSync(runLock.lockPath('P1'), JSON.stringify({ pid: 999999, host: os.hostname(), runId: 'old' }));
    expect(runLock.heldByOther('P1')).toBe(null);
    runLock.acquire('P1', 'r1');
    expect(JSON.parse(fs.readFileSync(runLock.lockPath('P1'))).pid).toBe(process.pid);
    runLock.release('P1');
    expect(fs.existsSync(runLock.lockPath('P1'))).toBe(false);
  });

  test('held by another living process: refused with 409', () => {
    fs.mkdirSync(path.join(staging, 'P2'), { recursive: true });
    fs.writeFileSync(runLock.lockPath('P2'), JSON.stringify({ pid: process.ppid, host: os.hostname(), runId: 'r9' }));
    expect(() => runLock.acquire('P2', 'r2')).toThrow(/already running \(run r9/);
    runLock.release('P2'); // not ours: stays
    expect(fs.existsSync(runLock.lockPath('P2'))).toBe(true);
  });
});

describe('worker process', () => {
  const port = 5190 + Math.floor(Math.random() * 50);
  let child;
  const get = (p, headers = {}) => new Promise((resolve, reject) => {
    const req = http.get({ host: '127.0.0.1', port, path: p, headers }, (res) => {
      let body = '';
      res.on('data', (c) => {
        body += c;
        if (p === '/events' && body.includes('\n\n')) { req.destroy(); resolve({ status: res.statusCode, body }); }
      });
      res.on('end', () => resolve({ status: res.statusCode, body }));
    });
    req.on('error', reject);
  });

  beforeAll(async () => {
    child = spawn(process.execPath, [path.join(__dirname, '..', '..', 'worker.js')], {
      env: { ...process.env, MIGRATION_STAGING_DIR: staging, DMA_WORKER_PORT: String(port) }, stdio: 'ignore',
    });
    for (let i = 0; i < 100; i += 1) {
      try { if ((await get('/health')).status === 200) return; } catch { /* starting */ }
      await new Promise((r) => setTimeout(r, 100));
    }
    throw new Error('worker did not start');
  });
  afterAll(() => child && child.kill('SIGKILL'));

  test('health is open, everything else needs the token from the staging folder', async () => {
    expect(JSON.parse((await get('/health')).body)).toMatchObject({ ok: true, running: 0 });
    expect((await get('/events')).status).toBe(401);
    expect((await get('/events', { 'x-dma-token': 'wrong' })).status).toBe(401);
    const token = fs.readFileSync(path.join(staging, '.dma_worker_token'), 'utf8').trim();
    const ev = await get('/events', { 'x-dma-token': token });
    expect(ev.status).toBe(200);
    expect(ev.body).toMatch(/"hello":true,"active":\[\]/);
  });
});
