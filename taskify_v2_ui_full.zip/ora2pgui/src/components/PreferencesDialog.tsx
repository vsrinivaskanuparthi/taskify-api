import { Alert, Box, Button, Dialog, DialogActions, DialogContent, DialogTitle, Divider, FormControlLabel, Stack, Switch, TextField, Typography } from '@mui/material';
import { useEffect, useState } from 'react';
import { DEFAULT_PREFS, Preferences, savePrefs, usePrefs } from '../prefs';
import { useIsAdmin } from '../role';

type Item = { group: keyof Preferences; key: string; label: string; help: string; admin?: boolean };

const SECTIONS: { title: string; items: Item[] }[] = [
  { title: 'Live monitor (a running migration)', items: [
    { group: 'monitor', key: 'serverUsage', label: 'Server CPU and memory', help: 'How busy the DMA server is while the migration runs.' },
    { group: 'monitor', key: 'autoTune', label: 'Auto-tune line', help: 'How many loads run at once, and why.' },
    { group: 'monitor', key: 'phases', label: 'Phases', help: 'The steps of the run (structure, data, indexes, checks…).' },
    { group: 'monitor', key: 'logProblems', label: 'Errors in the run’s log', help: 'Each error once, with what it means.' },
    { group: 'monitor', key: 'timeReport', label: 'Where did the time go?', help: 'Oracle reading vs network vs PostgreSQL writing.', admin: true },
  ] },
  { title: 'Projects', items: [
    { group: 'projects', key: 'onlyMine', label: 'Show only my projects', help: 'Projects you created. You can still switch to all of them on the Projects page.' },
  ] },
];

/** "My preferences": what this user wants to see. Saved on the server, for this user only. */
export default function PreferencesDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const saved = usePrefs();
  const admin = useIsAdmin();
  const [p, setP] = useState<Preferences>(saved);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => { if (open) { setP(saved); setError(null); } }, [open, saved]);

  const get = (it: Item) => (p[it.group] as any)[it.key] as boolean;
  const set = (group: keyof Preferences, key: string, v: any) => setP({ ...p, [group]: { ...(p[group] as any), [key]: v } });
  const save = async () => {
    setBusy(true);
    setError(null);
    try {
      await savePrefs(p);
      onClose();
    } catch (e: any) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open={open} onClose={onClose} fullWidth maxWidth="sm">
      <DialogTitle>My preferences</DialogTitle>
      <DialogContent>
        <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
          What you want to see. Saved for you only, and remembered on any PC or browser you sign in from.
        </Typography>
        {SECTIONS.map((s) => (
          <Box key={s.title} sx={{ mb: 2 }}>
            <Typography variant="overline" color="text.secondary">{s.title}</Typography>
            <Stack spacing={0.5}>
              {s.items.filter((it) => !it.admin || admin).map((it) => (
                <FormControlLabel key={it.key} sx={{ alignItems: 'flex-start', m: 0 }}
                  control={<Switch size="small" checked={get(it)} onChange={(e) => set(it.group, it.key, e.target.checked)} sx={{ mt: 0.25 }} />}
                  label={<Box sx={{ ml: 1 }}><Typography fontWeight={600} fontSize={14}>{it.label}</Typography><Typography variant="caption" color="text.secondary">{it.help}</Typography></Box>} />
              ))}
            </Stack>
          </Box>
        ))}
        <Divider sx={{ mb: 2 }} />
        <Typography variant="overline" color="text.secondary">Migrate</Typography>
        <FormControlLabel sx={{ alignItems: 'flex-start', m: 0, display: 'flex' }}
          control={<Switch size="small" checked={p.migrate.emailMe} onChange={(e) => set('migrate', 'emailMe', e.target.checked)} sx={{ mt: 0.25 }} />}
          label={<Box sx={{ ml: 1 }}><Typography fontWeight={600} fontSize={14}>Tick “Email me when it ends” for me</Typography><Typography variant="caption" color="text.secondary">On the Migrate page, every time.</Typography></Box>} />
        <TextField size="small" fullWidth label="My email for these messages" placeholder="you@company.com" value={p.migrate.email} onChange={(e) => set('migrate', 'email', e.target.value)} sx={{ mt: 1.5 }}
          helperText="Empty: the email of your sign-in." />
        {error && <Alert severity="error" sx={{ mt: 2 }}>{error}</Alert>}
      </DialogContent>
      <DialogActions sx={{ px: 3, pb: 2.5 }}>
        <Button onClick={() => setP(DEFAULT_PREFS)} sx={{ mr: 'auto' }}>Back to defaults</Button>
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained" onClick={save} disabled={busy}>{busy ? 'Saving…' : 'Save'}</Button>
      </DialogActions>
    </Dialog>
  );
}
