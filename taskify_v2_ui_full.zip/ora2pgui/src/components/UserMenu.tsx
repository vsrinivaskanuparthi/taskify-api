import { Avatar, Box, Button, Divider, IconButton, Menu, Portal, Stack, Typography } from '@mui/material';
import PersonRoundedIcon from '@mui/icons-material/PersonRounded';
import LogoutRoundedIcon from '@mui/icons-material/LogoutRounded';
import LoginRoundedIcon from '@mui/icons-material/LoginRounded';
import TuneRoundedIcon from '@mui/icons-material/TuneRounded';
import { useEffect, useState } from 'react';
import { api, apiUrl } from '../api';
import { brand } from '../theme';
import PreferencesDialog from './PreferencesDialog';

interface SsoUser { id: string; email?: string; companyId?: string }

/** null: SSO is off on this server (no /api/auth/me); 'out': SSO is on but nobody is signed in. */
type Who = SsoUser | null | 'out';

// One call per page load, shared by every page.
let whoPromise: Promise<Who> | null = null;
const loadWho = () => {
  whoPromise = whoPromise || api<{ user: SsoUser }>('/auth/me')
    .then((r) => r.user || null)
    .catch((e) => (e.status === 401 ? 'out' : null));
  return whoPromise;
};

const known = (v?: string) => !!v && !/^(unknown_|no_email@)/.test(v);
const initials = (u: SsoUser) => (known(u.email) ? u.email! : u.id).replace(/[^A-Za-z]/g, '').slice(0, 2).toUpperCase() || '?';

function Line({ label, value }: { label: string; value: string }) {
  return (
    <Stack direction="row" spacing={1.5} sx={{ minWidth: 0 }}>
      <Typography variant="body2" color="text.secondary" sx={{ width: 76, flexShrink: 0 }}>{label}</Typography>
      <Typography variant="body2" className="mono" noWrap title={value} sx={{ minWidth: 0, fontWeight: 500 }}>{value}</Typography>
    </Stack>
  );
}

/** Header avatar: who is signed in (corporate SSO) and sign out. */
export default function UserMenu() {
  const [who, setWho] = useState<Who>(null);
  const [anchor, setAnchor] = useState<HTMLElement | null>(null);
  const [signedOut, setSignedOut] = useState(false);
  const [prefs, setPrefs] = useState(false);
  const openPrefs = () => { setAnchor(null); setPrefs(true); };
  useEffect(() => { loadWho().then(setWho); }, []);

  const user = who && who !== 'out' ? who : null;
  const signOut = async () => {
    setAnchor(null);
    await api('/auth/logout').catch(() => {});
    whoPromise = null;
    setSignedOut(true);
  };

  return (
    <>
      <IconButton onClick={(e) => setAnchor(e.currentTarget)} sx={{ p: 0.25 }} aria-label="Account">
        <Avatar sx={{ width: 34, height: 34, bgcolor: user ? brand.blue : brand.sky, color: user ? '#fff' : brand.blue, fontSize: 14, fontWeight: 700 }}>
          {user ? initials(user) : <PersonRoundedIcon fontSize="small" />}
        </Avatar>
      </IconButton>
      <Menu anchorEl={anchor} open={!!anchor} onClose={() => setAnchor(null)} anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }} transformOrigin={{ vertical: 'top', horizontal: 'right' }}
        slotProps={{ paper: { sx: { width: 320, mt: 1, borderRadius: 3 } } }}>
        {user ? (
          <Box sx={{ px: 2.25, pt: 1.25, pb: 1.5 }}>
            <Stack direction="row" spacing={1.5} alignItems="center" sx={{ mb: 1.75 }}>
              <Avatar sx={{ width: 42, height: 42, bgcolor: brand.blue, fontWeight: 700 }}>{initials(user)}</Avatar>
              <Box sx={{ minWidth: 0 }}>
                <Typography sx={{ fontWeight: 700 }} noWrap title={user.email}>{known(user.email) ? user.email : user.id}</Typography>
                <Typography variant="caption" color="text.secondary">Signed in with corporate SSO</Typography>
              </Box>
            </Stack>
            <Stack spacing={0.75}>
              <Line label="ID" value={user.id} />
              {known(user.email) && <Line label="Email" value={user.email!} />}
              {known(user.companyId) && <Line label="Company" value={user.companyId!} />}
            </Stack>
            <Divider sx={{ my: 1.5 }} />
            <Button fullWidth variant="text" startIcon={<TuneRoundedIcon />} onClick={openPrefs} sx={{ mb: 1, justifyContent: 'flex-start' }}>My preferences</Button>
            <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mb: 1.25 }}>
              Running migrations keep running after you sign out.
            </Typography>
            <Button fullWidth variant="outlined" startIcon={<LogoutRoundedIcon />} onClick={signOut}>Sign out</Button>
          </Box>
        ) : (
          <Box sx={{ px: 2.25, py: 1.5 }}>
            <Typography sx={{ fontWeight: 700, mb: 0.5 }}>{who === 'out' ? 'Not signed in' : 'No sign-in on this server'}</Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mb: who === 'out' ? 1.5 : 0 }}>
              {who === 'out' ? 'Sign in with your corporate account to use the application.' : 'Corporate single sign-on is not switched on for this installation.'}
            </Typography>
            {who === 'out' && <Button fullWidth variant="contained" startIcon={<LoginRoundedIcon />} href={apiUrl('/auth/login')}>Sign in</Button>}
            {who !== 'out' && <Button fullWidth variant="text" startIcon={<TuneRoundedIcon />} onClick={openPrefs} sx={{ mt: 1.5, justifyContent: 'flex-start' }}>My preferences</Button>}
          </Box>
        )}
      </Menu>
      <PreferencesDialog open={prefs} onClose={() => setPrefs(false)} />
      {/* Portal: the header's backdrop blur would otherwise keep a fixed box inside the header. */}
      {signedOut && (
        <Portal>
          <Box sx={{ position: 'fixed', inset: 0, zIndex: 2000, bgcolor: brand.navy, display: 'grid', placeItems: 'center', p: 3 }}>
            <Box sx={{ bgcolor: '#fff', borderRadius: 4, p: 4, maxWidth: 420, textAlign: 'center' }}>
              <Typography variant="h5" sx={{ fontWeight: 800, mb: 1 }}>You are signed out</Typography>
              <Typography color="text.secondary" sx={{ mb: 3 }}>Running migrations continue on the server. Sign in again to follow them.</Typography>
              <Button variant="contained" size="large" startIcon={<LoginRoundedIcon />} href={apiUrl('/auth/login')}>Sign in again</Button>
            </Box>
          </Box>
        </Portal>
      )}
    </>
  );
}
