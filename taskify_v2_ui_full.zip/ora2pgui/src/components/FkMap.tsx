import { Autocomplete, Box, Chip, Stack, TextField, ToggleButton, ToggleButtonGroup, Typography } from '@mui/material';
import { useMemo, useState } from 'react';
import { brand, headingFont } from '../theme';

type Edge = { from: string; to: string };

const NODE_W = 196;
const NODE_H = 36;
const COL_GAP = 96;
const ROW_GAP = 14;
const FULL_LIMIT = 60;

/** Longest-path level from the roots (tables nothing points at); cycles are cut by a pass limit. */
function levels(nodes: string[], edges: Edge[]) {
  const lvl = new Map(nodes.map((n) => [n, 0]));
  for (let pass = 0; pass < nodes.length; pass += 1) {
    let changed = false;
    for (const e of edges) {
      if (e.from === e.to) continue;
      const next = (lvl.get(e.from) || 0) + 1;
      if (next > (lvl.get(e.to) || 0) && next < nodes.length) { lvl.set(e.to, next); changed = true; }
    }
    if (!changed) break;
  }
  return lvl;
}

/**
 * Foreign key map: referenced (parent) tables on the left, tables holding the foreign key to the right,
 * i.e. left to right is the order in which the data depends on each other. Small schemas are drawn
 * whole; above FULL_LIMIT related tables (500 GB+ schemas often have thousands) one table is drawn
 * with its parents and two levels of children, so the picture stays readable at any size.
 */
export default function FkMap({ edges }: { edges: Edge[] }) {
  const all = useMemo(() => [...new Set(edges.flatMap((e) => [e.from, e.to]))].sort(), [edges]);
  const degree = useMemo(() => {
    const d = new Map<string, number>();
    edges.forEach((e) => { d.set(e.from, (d.get(e.from) || 0) + 1); d.set(e.to, (d.get(e.to) || 0) + 1); });
    return d;
  }, [edges]);
  const large = all.length > FULL_LIMIT;
  const [focus, setFocus] = useState<string | null>(() => (large ? [...all].sort((a, b) => (degree.get(b) || 0) - (degree.get(a) || 0))[0] : null));
  const [view, setView] = useState<'map' | 'list'>('map');
  const [hover, setHover] = useState<string | null>(null);

  const shown = useMemo(() => {
    if (!focus) return { nodes: all, edges };
    const keep = new Set([focus]);
    edges.forEach((e) => { if (e.to === focus) keep.add(e.from); });
    let frontier = [focus];
    for (let depth = 0; depth < 2; depth += 1) {
      const next: string[] = [];
      edges.forEach((e) => { if (frontier.includes(e.from) && !keep.has(e.to) && keep.size < FULL_LIMIT) { keep.add(e.to); next.push(e.to); } });
      frontier = next;
    }
    return { nodes: [...keep], edges: edges.filter((e) => keep.has(e.from) && keep.has(e.to)) };
  }, [focus, all, edges]);

  const layout = useMemo(() => {
    const lvl = levels(shown.nodes, shown.edges);
    const cols = new Map<number, string[]>();
    shown.nodes.forEach((n) => { const l = lvl.get(n) || 0; cols.set(l, [...(cols.get(l) || []), n]); });
    const pos = new Map<string, { x: number; y: number }>();
    const maxRows = Math.max(1, ...[...cols.values()].map((c) => c.length));
    const height = maxRows * (NODE_H + ROW_GAP) + 24;
    [...cols.entries()].sort((a, b) => a[0] - b[0]).forEach(([l, names]) => {
      const colH = names.length * (NODE_H + ROW_GAP);
      names.sort().forEach((n, i) => pos.set(n, { x: 16 + l * (NODE_W + COL_GAP), y: (height - colH) / 2 + i * (NODE_H + ROW_GAP) }));
    });
    const width = 32 + (Math.max(0, ...cols.keys()) + 1) * (NODE_W + COL_GAP) - COL_GAP;
    return { pos, width, height };
  }, [shown]);

  if (!edges.length) return <Typography color="text.secondary" sx={{ p: 3 }}>No foreign keys between the tables of this schema.</Typography>;

  const related = (n: string) => hover && (n === hover || shown.edges.some((e) => (e.from === hover && e.to === n) || (e.to === hover && e.from === n)));
  const parents = new Map<string, string[]>();
  edges.forEach((e) => parents.set(e.from, [...(parents.get(e.from) || []), e.to]));

  return (
    <Box sx={{ p: 2.5 }}>
      <Stack direction={{ xs: 'column', md: 'row' }} spacing={2} alignItems={{ md: 'center' }} sx={{ mb: 2 }}>
        <ToggleButtonGroup size="small" exclusive value={view} onChange={(_, v) => v && setView(v)}>
          <ToggleButton value="map">Map</ToggleButton>
          <ToggleButton value="list">List</ToggleButton>
        </ToggleButtonGroup>
        {view === 'map' && (
          <Autocomplete size="small" options={all} value={focus} onChange={(_, v) => setFocus(v)} sx={{ width: { xs: '100%', md: 320 } }}
            renderInput={(p) => <TextField {...p} label={large ? 'Table to show' : 'Focus on a table (optional)'} />} />
        )}
        <Typography variant="body2" color="text.secondary" sx={{ flex: 1 }}>
          {all.length} related tables, {edges.length} foreign keys.
          {large && view === 'map' ? ` Too many to draw at once: showing ${focus || 'one table'} with its parents and children.` : ''}
        </Typography>
      </Stack>

      {view === 'map' ? (
        <>
          <Box sx={{ overflow: 'auto', maxHeight: 560, border: `1px solid ${brand.border}`, borderRadius: 3, bgcolor: '#FAFBFD',
            backgroundImage: 'radial-gradient(#E3E8F0 1px, transparent 1px)', backgroundSize: '18px 18px' }}>
            <svg width={Math.max(layout.width, 400)} height={layout.height} style={{ display: 'block' }}>
              <defs>
                <marker id="fkArrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
                  <path d="M0 0 L10 5 L0 10 z" fill="#8A9BB8" />
                </marker>
                <marker id="fkArrowHi" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">
                  <path d="M0 0 L10 5 L0 10 z" fill={brand.blue} />
                </marker>
              </defs>
              {shown.edges.map((e) => {
                const a = layout.pos.get(e.from);
                const b = layout.pos.get(e.to);
                if (!a || !b || e.from === e.to) return null;
                const x1 = a.x + NODE_W;
                const y1 = a.y + NODE_H / 2;
                const x2 = b.x - 2;
                const y2 = b.y + NODE_H / 2;
                const hi = hover && (e.from === hover || e.to === hover);
                return (
                  <path key={`${e.from}>${e.to}`} d={`M${x1} ${y1} C ${x1 + COL_GAP / 2} ${y1}, ${x2 - COL_GAP / 2} ${y2}, ${x2} ${y2}`}
                    fill="none" stroke={hi ? brand.blue : '#B8C4D8'} strokeWidth={hi ? 2 : 1.3} opacity={hover && !hi ? 0.25 : 1}
                    markerEnd={`url(#${hi ? 'fkArrowHi' : 'fkArrow'})`} />
                );
              })}
              {shown.nodes.map((n) => {
                const p = layout.pos.get(n)!;
                const isFocus = n === focus;
                const dim = hover && !related(n);
                return (
                  <g key={n} transform={`translate(${p.x} ${p.y})`} style={{ cursor: 'pointer' }} opacity={dim ? 0.35 : 1}
                    onMouseEnter={() => setHover(n)} onMouseLeave={() => setHover(null)} onClick={() => setFocus(n === focus ? null : n)}>
                    <rect width={NODE_W} height={NODE_H} rx={10} fill={isFocus ? brand.blue : '#fff'} stroke={hover === n || isFocus ? brand.blue : '#C9D3E3'} strokeWidth={hover === n ? 2 : 1} />
                    <rect width={4} height={NODE_H - 12} x={8} y={6} rx={2} fill={isFocus ? '#fff' : brand.cyan} opacity={0.9} />
                    <text x={20} y={NODE_H / 2 + 4.5} fontFamily={headingFont} fontSize={12.5} fontWeight={650} fill={isFocus ? '#fff' : brand.ink}>
                      {n.length > 24 ? `${n.slice(0, 23)}…` : n}
                      <title>{n}</title>
                    </text>
                  </g>
                );
              })}
            </svg>
          </Box>
          <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 1 }}>
            Arrows go from the referenced (parent) table to the table holding the foreign key. Click a table to focus on it; click it again to see everything.
            Data loads in any order: foreign keys are added after all tables are loaded.
          </Typography>
        </>
      ) : (
        <Stack spacing={1}>
          {[...parents.entries()].sort().map(([p, kids]) => (
            <Stack key={p} direction={{ xs: 'column', sm: 'row' }} spacing={1.5} sx={{ py: 1, borderBottom: `1px solid ${brand.border}` }}>
              <Typography fontWeight={700} sx={{ width: 240, flexShrink: 0 }}>{p}</Typography>
              <Stack direction="row" spacing={0.75} flexWrap="wrap" useFlexGap>
                {kids.map((k) => <Chip key={k} size="small" label={k} variant="outlined" />)}
              </Stack>
            </Stack>
          ))}
        </Stack>
      )}
    </Box>
  );
}
