import { Box, Card, Chip, ChipProps, Collapse, IconButton, Stack, Tooltip, Typography } from '@mui/material';
import CheckCircleRoundedIcon from '@mui/icons-material/CheckCircleRounded';
import ErrorRoundedIcon from '@mui/icons-material/ErrorRounded';
import WarningRoundedIcon from '@mui/icons-material/WarningRounded';
import RemoveCircleOutlineRoundedIcon from '@mui/icons-material/RemoveCircleOutlineRounded';
import RadioButtonUncheckedRoundedIcon from '@mui/icons-material/RadioButtonUncheckedRounded';
import ExpandMoreRoundedIcon from '@mui/icons-material/ExpandMoreRounded';
import { ReactNode, useEffect, useState } from 'react';
import { brand, headingFont } from '../theme';

export function PageHeader({ title, subtitle, actions, overline, icon }: { title: string; subtitle?: ReactNode; actions?: ReactNode; overline?: string; icon?: ReactNode }) {
  return (
    <Stack direction={{ xs: 'column', lg: 'row' }} spacing={2} alignItems={{ lg: 'center' }} justifyContent="space-between" sx={{ mb: 3.5 }}>
      <Stack direction="row" spacing={2} alignItems="center" sx={{ minWidth: 0 }}>
        {icon && (
          <Box sx={{ width: 52, height: 52, borderRadius: 3.5, flexShrink: 0, display: 'grid', placeItems: 'center', color: '#fff', background: brand.gradient, boxShadow: '0 12px 24px -12px rgba(0,32,91,.6)', '& svg': { fontSize: 26 } }}>{icon}</Box>
        )}
        <Box sx={{ minWidth: 0 }}>
          {overline && <Typography variant="overline" sx={{ color: brand.blue, display: 'block', lineHeight: 1.6 }}>{overline}</Typography>}
          <Typography variant="h4" sx={{ color: brand.ink, lineHeight: 1.15 }}>{title}</Typography>
          {subtitle && <Typography color="text.secondary" sx={{ mt: 0.75, maxWidth: 880 }}>{subtitle}</Typography>}
        </Box>
      </Stack>
      {actions && <Stack direction="row" spacing={1.25} flexShrink={0} flexWrap="wrap" useFlexGap>{actions}</Stack>}
    </Stack>
  );
}

/** KPI tile. Long values wrap instead of overflowing (a v1 layout bug). */
export function StatCard({ label, value, hint, icon, accent = brand.blue, footer }: { label: string; value: ReactNode; hint?: ReactNode; icon?: ReactNode; accent?: string; footer?: ReactNode }) {
  return (
    <Card sx={{ height: '100%', p: 2.25, display: 'flex', flexDirection: 'column', gap: 1.25 }}>
      <Stack direction="row" spacing={1.5} alignItems="center" justifyContent="space-between">
        <Typography variant="subtitle2" noWrap title={label}>{label}</Typography>
        {icon && (
          <Box sx={{ width: 36, height: 36, borderRadius: 2.5, display: 'grid', placeItems: 'center', flexShrink: 0, bgcolor: `${accent}14`, color: accent, '& svg': { fontSize: 20 } }}>{icon}</Box>
        )}
      </Stack>
      <Typography sx={{ fontFamily: headingFont, fontWeight: 800, fontSize: { xs: 22, md: 26 }, lineHeight: 1.1, letterSpacing: '-0.02em', color: brand.ink, overflowWrap: 'anywhere' }}>{value}</Typography>
      {hint && <Typography variant="caption" color="text.secondary" sx={{ mt: 'auto' }}>{hint}</Typography>}
      {footer}
    </Card>
  );
}

const STATUS: Record<string, { label: string; color: ChipProps['color'] }> = {
  READY: { label: 'Ready', color: 'default' },
  RUNNING: { label: 'Running', color: 'primary' },
  QUEUED: { label: 'Queued', color: 'primary' },
  IN_PROGRESS: { label: 'Running', color: 'primary' },
  COMPLETED: { label: 'Completed', color: 'success' },
  COMPLETED_WITH_ERRORS: { label: 'Completed with errors', color: 'warning' },
  FAILED: { label: 'Failed', color: 'error' },
  CANCELLED: { label: 'Cancelled', color: 'default' },
  INTERRUPTED: { label: 'Interrupted', color: 'warning' },
  EXPORTED: { label: 'Exported to files', color: 'info' },
  exported: { label: 'Exported', color: 'info' },
  pending: { label: 'Waiting', color: 'default' },
  running: { label: 'Loading', color: 'primary' },
  done: { label: 'Done', color: 'success' },
  failed: { label: 'Failed', color: 'error' },
  warning: { label: 'Warnings', color: 'warning' },
  skipped: { label: 'Skipped', color: 'default' },
  applied: { label: 'Applied', color: 'success' },
  exists: { label: 'Already present', color: 'default' },
};

export function StatusChip({ status, size = 'small' }: { status?: string | null; size?: ChipProps['size'] }) {
  const s = STATUS[status || 'READY'] || { label: status, color: 'default' };
  const dot = s.color === 'default' ? '#98A2B3' : undefined;
  return (
    <Chip size={size} label={s.label} color={s.color} variant={s.color === 'default' ? 'outlined' : 'filled'}
      icon={<Box component="span" sx={{ width: 7, height: 7, borderRadius: '50%', bgcolor: dot || 'currentColor', ml: '8px !important', opacity: 0.9, ...(status === 'RUNNING' || status === 'running' ? { animation: 'dmaBlink 1.2s ease-in-out infinite', '@keyframes dmaBlink': { '50%': { opacity: 0.3 } } } : {}) }} />}
      sx={s.color !== 'default' ? { '& .MuiChip-icon': { color: '#fff' } } : { bgcolor: '#fff' }} />
  );
}

export function CheckIcon({ ok, warn, pending, skipped }: { ok?: boolean; warn?: boolean; pending?: boolean; skipped?: boolean }) {
  if (skipped) return <RemoveCircleOutlineRoundedIcon fontSize="small" sx={{ color: 'text.disabled' }} />;
  if (pending) return <RadioButtonUncheckedRoundedIcon fontSize="small" sx={{ color: 'text.disabled' }} />;
  if (ok) return <CheckCircleRoundedIcon fontSize="small" color="success" />;
  if (warn) return <WarningRoundedIcon fontSize="small" color="warning" />;
  return <ErrorRoundedIcon fontSize="small" color="error" />;
}

type SectionCardProps = {
  title?: ReactNode; subtitle?: ReactNode; action?: ReactNode; children: ReactNode; dense?: boolean; icon?: ReactNode;
  /** Adds a chevron; the header toggles the body. */
  collapsible?: boolean;
  /** First state when nothing is remembered (default open). */
  defaultOpen?: boolean;
  /** Controlled state (e.g. a page that opens the card when something needs attention). */
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
  /** Shown under the title while the card is closed, e.g. "14 OK · 2 warnings". */
  summary?: ReactNode;
  /** Remembers the open/closed choice in this browser under this key. */
  storeKey?: string;
  /** Stretch to the height of the grid row, so cards side by side line up. */
  fill?: boolean;
};

function readStored(key?: string): boolean | null {
  if (!key) return null;
  try { const v = localStorage.getItem(`dma.section.${key}`); return v === null ? null : v === '1'; } catch { return null; }
}

export function SectionCard({ title, subtitle, action, children, dense, icon, collapsible, defaultOpen = true, open: openProp, onOpenChange, summary, storeKey, fill }: SectionCardProps) {
  const [own, setOwn] = useState<boolean>(() => readStored(storeKey) ?? defaultOpen);
  useEffect(() => { if (openProp === undefined) { const v = readStored(storeKey); if (v !== null) setOwn(v); } }, [storeKey, openProp]);
  const open = !collapsible || (openProp ?? own);
  const toggle = () => {
    const next = !open;
    if (openProp === undefined) setOwn(next);
    if (storeKey) { try { localStorage.setItem(`dma.section.${storeKey}`, next ? '1' : '0'); } catch { /* storage blocked */ } }
    onOpenChange?.(next);
  };
  const head = (title || action || collapsible) && (
    <Stack direction="row" alignItems="center" justifyContent="space-between" spacing={2}
      onClick={collapsible ? toggle : undefined}
      sx={{ px: 2.75, pt: 2.5, pb: open ? 2 : 2.5, cursor: collapsible ? 'pointer' : undefined, userSelect: collapsible ? 'none' : undefined, borderRadius: 4,
        '&:hover .dma-chev': { bgcolor: brand.sky } }}>
      <Stack direction="row" spacing={1.5} alignItems="center" sx={{ minWidth: 0 }}>
        {icon && <Box sx={{ width: 34, height: 34, borderRadius: 2.5, display: 'grid', placeItems: 'center', bgcolor: brand.sky, color: brand.blue, flexShrink: 0, '& svg': { fontSize: 19 } }}>{icon}</Box>}
        <Box sx={{ minWidth: 0 }}>
          {title && <Typography variant="h6">{title}</Typography>}
          {open && subtitle && <Typography variant="body2" color="text.secondary" sx={{ mt: 0.25 }}>{subtitle}</Typography>}
          {!open && (summary ?? subtitle) && <Typography component="div" variant="body2" color="text.secondary" sx={{ mt: 0.25 }}>{summary ?? subtitle}</Typography>}
        </Box>
      </Stack>
      <Stack direction="row" spacing={1} alignItems="center" sx={{ flexShrink: 0 }} onClick={(e) => e.stopPropagation()}>
        {action}
        {collapsible && (
          <Tooltip title={open ? 'Collapse' : 'Expand'}>
            <IconButton size="small" className="dma-chev" onClick={toggle} aria-expanded={open} aria-label={open ? 'Collapse section' : 'Expand section'}
              sx={{ border: `1px solid ${brand.border}`, transition: 'transform .2s', transform: open ? 'rotate(180deg)' : 'none' }}>
              <ExpandMoreRoundedIcon fontSize="small" />
            </IconButton>
          </Tooltip>
        )}
      </Stack>
    </Stack>
  );
  return (
    <Card sx={fill ? { height: '100%', display: 'flex', flexDirection: 'column' } : undefined}>
      {head}
      {collapsible
        ? <Collapse in={open} unmountOnExit={false}><Box sx={{ px: dense ? 0 : 2.75, pb: dense ? 0 : 2.75 }}>{children}</Box></Collapse>
        : <Box sx={{ px: dense ? 0 : 2.75, pb: dense ? 0 : 2.75, ...(fill ? { flex: 1, display: 'flex', flexDirection: 'column' } : {}) }}>{children}</Box>}
    </Card>
  );
}

export function Hint({ title, children }: { title: string; children: ReactNode }) {
  return <Tooltip title={title} arrow><span style={{ display: 'inline-flex', cursor: 'help' }}>{children}</span></Tooltip>;
}

export function EmptyState({ icon, title, text, action }: { icon?: ReactNode; title: string; text?: ReactNode; action?: ReactNode }) {
  return (
    <Stack alignItems="center" spacing={1.5} sx={{ py: 8, px: 2, textAlign: 'center' }}>
      {icon && <Box sx={{ width: 72, height: 72, borderRadius: '50%', display: 'grid', placeItems: 'center', bgcolor: brand.sky, color: brand.blue, '& svg': { fontSize: 34 } }}>{icon}</Box>}
      <Typography variant="h6">{title}</Typography>
      {text && <Typography color="text.secondary" sx={{ maxWidth: 520 }}>{text}</Typography>}
      {action}
    </Stack>
  );
}

/** Soft coloured pill used for "kind" labels. */
export function Tag({ label, color = brand.blue }: { label: ReactNode; color?: string }) {
  return <Box component="span" sx={{ display: 'inline-flex', alignItems: 'center', px: 1, py: 0.25, borderRadius: 1.5, fontSize: 12, fontWeight: 650, color, bgcolor: `${color}14`, whiteSpace: 'nowrap' }}>{label}</Box>;
}
