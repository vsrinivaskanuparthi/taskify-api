import { Badge, Box, Button, Chip, CircularProgress, Drawer, Fab, IconButton, LinearProgress, Stack, Tooltip, Typography, useMediaQuery } from '@mui/material';
import { useTheme } from '@mui/material/styles';
import ForumRoundedIcon from '@mui/icons-material/ForumRounded';
import CloseRoundedIcon from '@mui/icons-material/CloseRounded';
import CheckRoundedIcon from '@mui/icons-material/CheckRounded';
import PriorityHighRoundedIcon from '@mui/icons-material/PriorityHighRounded';
import WarningAmberRoundedIcon from '@mui/icons-material/WarningAmberRounded';
import TableChartRoundedIcon from '@mui/icons-material/TableChartRounded';
import LayersRoundedIcon from '@mui/icons-material/LayersRounded';
import InfoRoundedIcon from '@mui/icons-material/InfoRounded';
import PauseRoundedIcon from '@mui/icons-material/PauseRounded';
import KeyboardArrowDownRoundedIcon from '@mui/icons-material/KeyboardArrowDownRounded';
import RemoveRoundedIcon from '@mui/icons-material/RemoveRounded';
import { ReactNode, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';
import { fmtCompact, fmtDuration, fmtInt } from '../format';
import { brand } from '../theme';

export type RunEvent = { at: string; level: string; message: string; ref?: { type: 'phase' | 'table'; key?: string; name?: string; state: string } };
type PhaseLite = { key: string; label: string; status: string; detail?: string | null; progress?: number };
type TableLite = { name: string; status: string; rowsDone: number; estRows: number; rate: number; chunkInfo?: { total: number; done: number; running: number } };

type Item = {
  id: string;
  kind: 'phase' | 'table' | 'note';
  ref?: string;
  title: string;
  at: string;
  endAt?: string;
  endMessage?: string;
  status: 'running' | 'done' | 'warning' | 'failed' | 'skipped' | 'stopped' | 'info' | 'error';
};

const SHOW_STEP = 60;

/** Events from runs made before events carried a ref are matched on their text. */
function refOf(e: RunEvent, phases: PhaseLite[]): RunEvent['ref'] | undefined {
  if (e.ref) return e.ref;
  let m = e.message.match(/^Phase (started|finished|skipped): (.+?)(?: \(\d+ warnings\))?$/);
  if (m) {
    const p = phases.find((x) => x.label === m![2]);
    if (p) return { type: 'phase', key: p.key, state: m[1] === 'started' ? 'start' : m[1] === 'skipped' ? 'skipped' : /warnings\)$/.test(e.message) ? 'warning' : 'done' };
  }
  m = e.message.match(/^Table (\S+) loaded:/);
  if (m) return { type: 'table', name: m[1], state: 'done' };
  m = e.message.match(/^Table (\S+) attempt \d+\/\d+ failed:/);
  if (m) return { type: 'table', name: m[1], state: 'failed' };
  return undefined;
}

/** Folds "started" + "finished" pairs into one item whose status follows the live run state. */
function buildItems(events: RunEvent[], phases: PhaseLite[], tables: Record<string, TableLite>, runActive: boolean): Item[] {
  const items: Item[] = [];
  const open = new Map<string, number>();
  events.forEach((e, i) => {
    const ref = refOf(e, phases);
    if (!ref) {
      items.push({ id: `n${i}`, kind: 'note', title: e.message, at: e.at, status: e.level === 'error' ? 'error' : 'info' });
      return;
    }
    const key = `${ref.type}:${ref.key || ref.name}`;
    const label = ref.type === 'phase' ? phases.find((p) => p.key === ref.key)?.label || ref.key || '' : ref.name || '';
    if (ref.state === 'start') {
      // Started again (retry or resume) without a finish: the earlier attempt was cut off.
      const prev = open.get(key);
      if (prev !== undefined) items[prev].status = 'stopped';
      open.set(key, items.length);
      items.push({ id: `i${i}`, kind: ref.type, ref: ref.key || ref.name, title: label, at: e.at, status: 'running', endMessage: ref.type === 'table' && /attempt/.test(e.message) ? e.message.replace(/^Loading table \S+ /, '') : undefined });
      return;
    }
    const idx = open.get(key);
    const status = (['done', 'warning', 'failed', 'skipped'].includes(ref.state) ? ref.state : 'done') as Item['status'];
    if (idx !== undefined) {
      Object.assign(items[idx], { status, endAt: e.at, endMessage: e.message });
      open.delete(key);
    } else {
      items.push({ id: `i${i}`, kind: ref.type, ref: ref.key || ref.name, title: label, at: e.at, endAt: e.at, endMessage: e.message, status });
    }
  });
  // Items still open: spinning while the engine really works on them, otherwise the run stopped mid-way.
  open.forEach((idx) => {
    const it = items[idx];
    const live = it.kind === 'phase' ? phases.find((p) => p.key === it.ref)?.status : tables[it.ref || '']?.status;
    if (!(runActive && live === 'running')) it.status = 'stopped';
  });
  return items;
}

function Avatar({ item }: { item: Item }) {
  const tone = {
    running: brand.blue, done: brand.success, warning: brand.warning, failed: brand.error, error: brand.error,
    skipped: '#98A2B3', stopped: '#98A2B3', info: brand.violet,
  }[item.status];
  const icon = item.status === 'running' ? null
    : item.status === 'done' ? <CheckRoundedIcon />
    : item.status === 'warning' ? <WarningAmberRoundedIcon />
    : item.status === 'failed' || item.status === 'error' ? <PriorityHighRoundedIcon />
    : item.status === 'skipped' ? <RemoveRoundedIcon />
    : item.status === 'stopped' ? <PauseRoundedIcon />
    : item.kind === 'table' ? <TableChartRoundedIcon /> : <InfoRoundedIcon />;
  return (
    <Box sx={{ position: 'relative', width: 30, height: 30, flexShrink: 0 }}>
      {item.status === 'running' && <CircularProgress size={30} thickness={3.2} sx={{ position: 'absolute', inset: 0, color: tone }} />}
      <Box sx={{
        position: 'absolute', inset: item.status === 'running' ? 4 : 0, borderRadius: '50%', display: 'grid', placeItems: 'center',
        bgcolor: item.status === 'running' ? brand.sky : `${tone}1F`, color: tone, '& svg': { fontSize: item.status === 'running' ? 13 : 17 },
      }}>
        {item.status === 'running' ? (item.kind === 'table' ? <TableChartRoundedIcon /> : <LayersRoundedIcon />) : icon}
      </Box>
    </Box>
  );
}

function Bubble({ item, now, phase, table, onOpenTable }: { item: Item; now: number; phase?: PhaseLite; table?: TableLite; onOpenTable: (t: string) => void }) {
  const [open, setOpen] = useState(false);
  const end = item.endAt ? new Date(item.endAt).getTime() : item.status === 'running' ? now : null;
  const dur = end !== null ? end - new Date(item.at).getTime() : null;
  const isErr = item.status === 'failed' || item.status === 'error';
  const clickable = item.kind === 'table' || isErr || (item.kind === 'phase' && !!phase?.detail);

  let body: ReactNode = null;
  if (item.kind === 'note') body = item.title;
  else if (item.status === 'running' && item.kind === 'phase') body = phase?.detail || 'Working…';
  else if (item.status === 'running' && table) {
    const pct = table.estRows ? Math.min((table.rowsDone / table.estRows) * 100, 99) : 0;
    body = (
      <>
        <LinearProgress variant={table.rowsDone ? 'determinate' : 'indeterminate'} value={pct} sx={{ height: 5, my: 0.75 }} />
        {fmtInt(table.rowsDone)} / {fmtInt(table.estRows)} rows{table.rate ? ` · ${fmtCompact(table.rate)}/s` : ''}
        {table.chunkInfo ? ` · chunks ${table.chunkInfo.done}/${table.chunkInfo.total}` : ''}
      </>
    );
  } else if (item.status === 'stopped') body = 'Stopped before it finished (resume picks it up).';
  else if (item.endMessage) {
    body = item.kind === 'table'
      ? item.endMessage.replace(/^Table \S+ /, '').replace(/^loaded: /, 'Loaded ')
      : item.endMessage.replace(/^Phase (finished|skipped): .+?( \((\d+ warnings)\))?$/, (_m, how, _w, warn) => (how === 'skipped' ? 'Skipped (nothing to do)' : warn ? `Finished with ${warn}` : 'Finished'));
  }

  return (
    <Stack direction="row" spacing={1.25} alignItems="flex-start" sx={{ animation: 'actIn .25s ease-out', '@keyframes actIn': { from: { opacity: 0, transform: 'translateY(6px)' }, to: { opacity: 1, transform: 'none' } } }}>
      <Avatar item={item} />
      <Box
        onClick={clickable ? () => (item.kind === 'table' ? onOpenTable(item.ref!) : setOpen((o) => !o)) : undefined}
        sx={{
          minWidth: 0, flex: 1, px: 1.5, py: 1, borderRadius: '4px 14px 14px 14px',
          bgcolor: isErr ? '#FEF3F2' : item.status === 'running' ? '#F3F7FF' : '#F6F8FB',
          border: 1, borderColor: isErr ? '#FECDCA' : item.status === 'running' ? '#C9DBFB' : 'transparent',
          cursor: clickable ? 'pointer' : 'default', transition: 'border-color .15s, background-color .15s',
          '&:hover': clickable ? { borderColor: isErr ? '#FDA29B' : '#B2CCFA' } : undefined,
        }}
      >
        <Stack direction="row" spacing={1} alignItems="baseline" justifyContent="space-between">
          <Typography fontSize={13} fontWeight={700} className={item.kind === 'table' ? 'mono' : undefined} sx={{ minWidth: 0, overflowWrap: 'anywhere', lineHeight: 1.35, color: isErr ? 'error.dark' : 'text.primary' }}>
            {item.kind === 'note' ? (isErr ? 'Problem' : 'Update') : item.title}
          </Typography>
          <Typography fontSize={11} color="text.secondary" sx={{ flexShrink: 0 }}>
            {dur !== null && item.kind !== 'note' ? `${fmtDuration(dur)} · ` : ''}{new Date(item.at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
          </Typography>
        </Stack>
        {body && (
          <Typography component="div" fontSize={12.5} color={isErr ? 'error.main' : 'text.secondary'}
            sx={{ mt: 0.25, overflowWrap: 'anywhere', ...(open || item.status === 'running' ? {} : { display: '-webkit-box', WebkitLineClamp: 3, WebkitBoxOrient: 'vertical', overflow: 'hidden' }) }}>
            {body}
          </Typography>
        )}
        {open && item.kind === 'phase' && phase?.detail && item.status !== 'running' && (
          <Typography fontSize={12} color="text.secondary" sx={{ mt: 0.5, overflowWrap: 'anywhere' }}>{phase.detail}</Typography>
        )}
        {item.kind === 'table' && item.status !== 'running' && <Typography fontSize={11} color="primary.main" sx={{ mt: 0.25, fontWeight: 600 }}>View table log →</Typography>}
      </Box>
    </Stack>
  );
}

type Filter = 'all' | 'phase' | 'table' | 'error';

function Feed({ events, phases, tables, runActive, now, live, onOpenTable, onClose }: {
  events: RunEvent[]; phases: PhaseLite[]; tables: Record<string, TableLite>; runActive: boolean; now: number; live: boolean;
  onOpenTable: (t: string) => void; onClose: () => void;
}) {
  const [filter, setFilter] = useState<Filter>('all');
  const [shown, setShown] = useState(SHOW_STEP);
  const [atBottom, setAtBottom] = useState(true);
  const scroller = useRef<HTMLDivElement>(null);

  const all = useMemo(() => buildItems(events, phases, tables, runActive), [events, phases, tables, runActive]);
  const filtered = useMemo(() => all.filter((it) => (
    filter === 'all' ? true
      : filter === 'error' ? ['failed', 'error', 'warning'].includes(it.status)
        : it.kind === filter
  )), [all, filter]);
  const visible = filtered.slice(-shown);
  const running = all.filter((it) => it.status === 'running');
  const errors = all.filter((it) => ['failed', 'error'].includes(it.status)).length;

  // Chat behaviour: stay pinned to the newest entry unless the user scrolled up to read.
  useLayoutEffect(() => {
    const el = scroller.current;
    if (el && atBottom) el.scrollTop = el.scrollHeight;
  }, [visible.length, visible[visible.length - 1]?.status, atBottom, filter]);
  const onScroll = () => {
    const el = scroller.current;
    if (el) setAtBottom(el.scrollHeight - el.scrollTop - el.clientHeight < 40);
  };
  const jump = () => {
    setAtBottom(true);
    const el = scroller.current;
    if (el) el.scrollTo({ top: el.scrollHeight, behavior: 'smooth' });
  };

  return (
    <Stack sx={{ height: '100%', minHeight: 0 }}>
      <Box sx={{ px: 2.25, pt: 2, pb: 1.5, borderBottom: 1, borderColor: 'divider' }}>
        <Stack direction="row" alignItems="center" spacing={1.25}>
          <Box sx={{ width: 34, height: 34, borderRadius: 2.5, display: 'grid', placeItems: 'center', background: brand.accentGradient, color: '#fff' }}><ForumRoundedIcon sx={{ fontSize: 18 }} /></Box>
          <Box sx={{ flex: 1, minWidth: 0 }}>
            <Typography variant="h6" fontSize={16}>Activity</Typography>
            <Stack direction="row" spacing={0.75} alignItems="center">
              <Box sx={{ width: 7, height: 7, borderRadius: '50%', bgcolor: runActive ? (live ? brand.success : brand.warning) : '#98A2B3', ...(runActive && live ? { animation: 'actPulse 1.6s infinite', '@keyframes actPulse': { '0%': { boxShadow: '0 0 0 0 rgba(14,159,110,.5)' }, '100%': { boxShadow: '0 0 0 7px rgba(14,159,110,0)' } } } : {}) }} />
              <Typography fontSize={12} color="text.secondary">{runActive ? (live ? `Live · ${running.length} in progress` : 'Reconnecting…') : 'Run not active'}</Typography>
            </Stack>
          </Box>
          <Tooltip title="Hide panel"><IconButton size="small" onClick={onClose}><CloseRoundedIcon fontSize="small" /></IconButton></Tooltip>
        </Stack>
        <Stack direction="row" spacing={0.75} sx={{ mt: 1.5 }}>
          {([['all', 'All'], ['phase', 'Phases'], ['table', 'Tables'], ['error', errors ? `Issues ${errors}` : 'Issues']] as [Filter, string][]).map(([k, label]) => (
            <Chip key={k} size="small" label={label} onClick={() => { setFilter(k); setAtBottom(true); }}
              color={filter === k ? (k === 'error' && errors ? 'error' : 'primary') : 'default'} variant={filter === k ? 'filled' : 'outlined'}
              sx={{ fontWeight: 650, ...(k === 'error' && errors && filter !== k ? { color: 'error.main', borderColor: '#FDA29B' } : {}) }} />
          ))}
        </Stack>
      </Box>

      <Box sx={{ position: 'relative', flex: 1, minHeight: 0 }}>
        <Box ref={scroller} onScroll={onScroll} sx={{ position: 'absolute', inset: 0, overflowY: 'auto', px: 2, py: 2 }}>
          {filtered.length > visible.length && (
            <Box sx={{ textAlign: 'center', mb: 1.5 }}>
              <Button size="small" variant="outlined" onClick={() => { setAtBottom(false); setShown((s) => s + SHOW_STEP); }}>
                Load {Math.min(SHOW_STEP, filtered.length - visible.length)} earlier
              </Button>
            </Box>
          )}
          {!visible.length && <Typography fontSize={13} color="text.secondary" textAlign="center" sx={{ mt: 4 }}>Nothing here yet.</Typography>}
          <Stack spacing={1.25}>
            {visible.map((it) => (
              <Bubble key={it.id} item={it} now={now} onOpenTable={onOpenTable}
                phase={it.kind === 'phase' ? phases.find((p) => p.key === it.ref) : undefined}
                table={it.kind === 'table' ? tables[it.ref || ''] : undefined} />
            ))}
          </Stack>
          {events.length >= 300 && filtered.length <= visible.length && (
            <Typography fontSize={11.5} color="text.secondary" textAlign="center" sx={{ mt: 2 }}>Older entries are in the master log (Logs ▸ Master log).</Typography>
          )}
        </Box>
        {!atBottom && (
          <Button size="small" variant="contained" onClick={jump} startIcon={<KeyboardArrowDownRoundedIcon />}
            sx={{ position: 'absolute', bottom: 12, left: '50%', transform: 'translateX(-50%)', borderRadius: 99, boxShadow: 3, px: 1.75 }}>
            Latest
          </Button>
        )}
      </Box>

      {running.length > 0 && (
        <Box sx={{ px: 2.25, py: 1.25, borderTop: 1, borderColor: 'divider', bgcolor: '#FAFBFD' }}>
          <Stack direction="row" spacing={1} alignItems="center">
            <CircularProgress size={14} thickness={5} />
            <Typography fontSize={12.5} fontWeight={650} noWrap sx={{ minWidth: 0 }}>
              Working on {running.slice(0, 2).map((r) => r.title).join(', ')}{running.length > 2 ? ` +${running.length - 2} more` : ''}
            </Typography>
            <Box sx={{ display: 'flex', gap: 0.4, ml: 'auto !important' }}>
              {[0, 1, 2].map((d) => <Box key={d} sx={{ width: 5, height: 5, borderRadius: '50%', bgcolor: brand.blue, animation: `actDot 1.2s ${d * 0.2}s infinite ease-in-out`, '@keyframes actDot': { '0%,80%,100%': { opacity: 0.25 }, '40%': { opacity: 1 } } }} />)}
            </Box>
          </Stack>
        </Box>
      )}
    </Stack>
  );
}

const PREF = 'dma.activityOpen';

/**
 * Chat-style activity feed on the right of the run monitor: docked on wide screens,
 * a slide-in drawer behind a floating button on smaller ones.
 */
export default function ActivityPanel(props: {
  events: RunEvent[]; phases: PhaseLite[]; tables: Record<string, TableLite>; runActive: boolean; now: number; live: boolean;
  onOpenTable: (t: string) => void; children: ReactNode;
}) {
  const theme = useTheme();
  const wide = useMediaQuery(theme.breakpoints.up('lg'));
  const [docked, setDocked] = useState(() => { try { return localStorage.getItem(PREF) !== '0'; } catch { return true; } });
  const [drawer, setDrawer] = useState(false);
  const [seen, setSeen] = useState(props.events.length);
  const showing = wide ? docked : drawer;

  useEffect(() => { try { localStorage.setItem(PREF, docked ? '1' : '0'); } catch { /* private mode */ } }, [docked]);
  useEffect(() => { if (showing) setSeen(props.events.length); }, [showing, props.events.length]);
  const unread = Math.max(props.events.length - seen, 0);

  const feed = (
    <Feed events={props.events} phases={props.phases} tables={props.tables} runActive={props.runActive} now={props.now} live={props.live}
      onOpenTable={props.onOpenTable} onClose={() => (wide ? setDocked(false) : setDrawer(false))} />
  );

  return (
    <>
      <Box sx={{ display: 'grid', gap: 3, alignItems: 'start', gridTemplateColumns: wide && docked ? 'minmax(0,1fr) 380px' : '1fr' }}>
        <Box sx={{ minWidth: 0 }}>{props.children}</Box>
        {wide && docked && (
          <Box sx={{
            position: 'sticky', top: 84, height: 'calc(100vh - 116px)', minHeight: 420, bgcolor: 'background.paper',
            borderRadius: 4, border: 1, borderColor: 'divider', boxShadow: '0 12px 32px -18px rgba(16,24,40,.25)', overflow: 'hidden',
          }}>
            {feed}
          </Box>
        )}
      </Box>

      {!showing && (
        <Tooltip title="Show activity" placement="left">
          <Fab color="primary" onClick={() => (wide ? setDocked(true) : setDrawer(true))}
            sx={{ position: 'fixed', right: 28, bottom: 28, background: brand.accentGradient, boxShadow: '0 14px 30px -10px rgba(11,87,208,.7)' }}>
            <Badge color="error" badgeContent={unread} max={99}><ForumRoundedIcon /></Badge>
            {props.runActive && <CircularProgress size={64} thickness={1.6} sx={{ position: 'absolute', color: 'rgba(255,255,255,.7)' }} />}
          </Fab>
        </Tooltip>
      )}

      {!wide && (
        <Drawer anchor="right" open={drawer} onClose={() => setDrawer(false)} PaperProps={{ sx: { width: { xs: '100%', sm: 420 } } }}>
          {feed}
        </Drawer>
      )}
    </>
  );
}
