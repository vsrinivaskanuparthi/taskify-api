import { Box, Button, Stack, Tooltip, Typography } from '@mui/material';
import ArrowBackRoundedIcon from '@mui/icons-material/ArrowBackRounded';
import ArrowForwardRoundedIcon from '@mui/icons-material/ArrowForwardRounded';
import CheckRoundedIcon from '@mui/icons-material/CheckRounded';
import { useNavigate } from 'react-router-dom';
import { brand, headingFont } from '../theme';

export type WizardStep = { key: string; route: string; label: string; optional?: boolean; done?: boolean; also?: string[] };

/** Where the user is in the project's steps. Every step can be opened at any time; none is forced. */
export function WizardBar({ steps, current, base }: { steps: WizardStep[]; current: number; base: string }) {
  const navigate = useNavigate();
  if (current < 0) return null;
  return (
    <Box sx={{ mb: 3, px: { xs: 1.5, md: 2.5 }, py: 1.5, borderRadius: 3.5, bgcolor: '#fff', border: `1px solid ${brand.border}`, overflowX: 'auto' }}>
      <Stack direction="row" alignItems="center" sx={{ minWidth: 640 }}>
        {steps.map((s, i) => {
          const active = i === current;
          return (
            <Stack key={s.key} direction="row" alignItems="center" sx={{ flex: i < steps.length - 1 ? 1 : 'none', minWidth: 0 }}>
              <Tooltip title={`${s.label}${s.optional ? ' (optional)' : ''}${s.done ? ' · done' : ''}`}>
                <Stack direction="row" spacing={1} alignItems="center" onClick={() => navigate(`${base}/${s.route}`)}
                  sx={{ cursor: 'pointer', flexShrink: 0, py: 0.5, pr: 1, borderRadius: 99, '&:hover .wz-dot': { borderColor: brand.blue } }}>
                  <Box className="wz-dot" sx={{
                    width: 26, height: 26, borderRadius: '50%', display: 'grid', placeItems: 'center', fontFamily: headingFont, fontWeight: 800, fontSize: 12.5,
                    border: `2px solid ${active ? brand.blue : s.done ? brand.success : '#C9D3E3'}`,
                    bgcolor: active ? brand.blue : s.done ? brand.success : '#fff', color: active || s.done ? '#fff' : brand.muted,
                    boxShadow: active ? '0 0 0 4px rgba(11,87,208,.14)' : 'none', transition: 'all .15s',
                  }}>
                    {s.done && !active ? <CheckRoundedIcon sx={{ fontSize: 16 }} /> : i + 1}
                  </Box>
                  <Typography noWrap sx={{ fontSize: 13, fontWeight: active ? 750 : 600, color: active ? brand.ink : brand.muted, display: { xs: active ? 'block' : 'none', lg: 'block' } }}>
                    {s.label}
                  </Typography>
                </Stack>
              </Tooltip>
              {i < steps.length - 1 && <Box sx={{ flex: 1, height: 2, mx: 1, minWidth: 12, borderRadius: 1, bgcolor: s.done ? '#9BE3C4' : brand.border }} />}
            </Stack>
          );
        })}
      </Stack>
    </Box>
  );
}

/** Back / Skip / Next at the bottom of each step. */
export function WizardFooter({ steps, current, base }: { steps: WizardStep[]; current: number; base: string }) {
  const navigate = useNavigate();
  if (current < 0) return null;
  const prev = steps[current - 1];
  const next = steps[current + 1];
  const here = steps[current];
  return (
    <Stack direction="row" alignItems="center" spacing={1.5} sx={{ mt: 4, pt: 2.5, borderTop: `1px solid ${brand.border}` }}>
      {prev ? <Button startIcon={<ArrowBackRoundedIcon />} onClick={() => navigate(`${base}/${prev.route}`)}>{prev.label}</Button> : <span />}
      <Box sx={{ flex: 1 }} />
      {next && (
        <>
          {here.optional && !here.done && <Typography variant="body2" color="text.secondary" sx={{ display: { xs: 'none', sm: 'block' } }}>Optional step: you can skip it.</Typography>}
          <Button variant={here.optional && !here.done ? 'outlined' : 'contained'} endIcon={<ArrowForwardRoundedIcon />} onClick={() => navigate(`${base}/${next.route}`)}>
            {here.optional && !here.done ? 'Skip' : 'Next'}: {next.label}
          </Button>
        </>
      )}
    </Stack>
  );
}
