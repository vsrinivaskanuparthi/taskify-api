import { Alert, Box, Button, CircularProgress, Dialog, DialogActions, DialogContent, DialogTitle, Stack, TextField, Typography } from '@mui/material';
import DeleteForeverRoundedIcon from '@mui/icons-material/DeleteForeverRounded';
import { useState } from 'react';
import { api, projectPath } from '../api';

/**
 * Deletes a project's folder on the server (rm -rf of <staging>/<project>): ora2pg project tree,
 * config, snapshots, run logs, exports and uploaded packages. Typing the name confirms it.
 */
export default function DeleteProjectDialog({ name, open, onClose, onDeleted }: { name: string; open: boolean; onClose: () => void; onDeleted: () => void }) {
  const [typed, setTyped] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const close = () => { if (!busy) { setTyped(''); setError(null); onClose(); } };
  const remove = async () => {
    setBusy(true);
    setError(null);
    try {
      await api(projectPath(name), { method: 'DELETE', body: { confirm: name } });
      setTyped('');
      onDeleted();
    } catch (e: any) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open={open} onClose={close} maxWidth="sm" fullWidth>
      <DialogTitle sx={{ display: 'flex', alignItems: 'center', gap: 1.25 }}>
        <Box sx={{ width: 38, height: 38, borderRadius: 2.5, display: 'grid', placeItems: 'center', bgcolor: '#FEF3F2', color: 'error.main' }}><DeleteForeverRoundedIcon /></Box>
        Delete project {name}?
      </DialogTitle>
      <DialogContent>
        <Typography variant="body2" color="text.secondary">
          The project folder on the migration server is removed with everything ora2pg and this tool created in it:
        </Typography>
        <Stack component="ul" spacing={0.25} sx={{ my: 1.25, pl: 2.5, color: 'text.secondary', fontSize: 14 }}>
          <li>ora2pg project tree and ora2pg.conf files</li>
          <li>snapshots, analysis reports, run history and all logs</li>
          <li>exported SQL, GenAI candidate zips and uploaded converted packages</li>
        </Stack>
        <Alert severity="info" sx={{ mb: 2 }}>Oracle and the PostgreSQL target are not touched: migrated schemas and data stay where they are.</Alert>
        <TextField fullWidth autoFocus label={`Type ${name} to confirm`} value={typed} onChange={(e) => setTyped(e.target.value)}
          onKeyDown={(e) => { if (e.key === 'Enter' && typed === name) remove(); }} inputProps={{ spellCheck: false, autoComplete: 'off' }} />
        {error && <Alert severity="error" sx={{ mt: 2, overflowWrap: 'anywhere' }}>{error}</Alert>}
      </DialogContent>
      <DialogActions sx={{ px: 3, pb: 2.5 }}>
        <Button onClick={close} disabled={busy}>Keep project</Button>
        <Button variant="contained" color="error" disabled={typed !== name || busy} onClick={remove}
          startIcon={busy ? <CircularProgress size={16} color="inherit" /> : <DeleteForeverRoundedIcon />}>
          Delete permanently
        </Button>
      </DialogActions>
    </Dialog>
  );
}
