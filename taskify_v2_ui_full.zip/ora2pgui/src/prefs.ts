import { useEffect, useState } from 'react';
import { api } from './api';

/**
 * The signed-in user's own display preferences (account menu → My preferences), kept on the server
 * so they follow the user to any browser. Loaded once per page load; a save updates every screen.
 */
export interface Preferences {
  monitor: { phases: boolean; serverUsage: boolean; autoTune: boolean; timeReport: boolean; logProblems: boolean };
  projects: { onlyMine: boolean };
  migrate: { emailMe: boolean; email: string };
}

export const DEFAULT_PREFS: Preferences = {
  monitor: { phases: true, serverUsage: true, autoTune: true, timeReport: true, logProblems: true },
  projects: { onlyMine: false },
  migrate: { emailMe: false, email: '' },
};

let current: Preferences | null = null;
let loading: Promise<Preferences> | null = null;
const listeners = new Set<(p: Preferences) => void>();

const load = () => {
  loading = loading || api<{ preferences: Preferences }>('/preferences')
    .then((r) => (current = r.preferences))
    .catch(() => (current = DEFAULT_PREFS));
  return loading;
};

/** Saves the user's preferences on the server; every screen using usePrefs() follows. */
export async function savePrefs(p: Preferences): Promise<Preferences> {
  const r = await api<{ preferences: Preferences }>('/preferences', { method: 'PUT', body: { preferences: p } });
  current = r.preferences;
  listeners.forEach((l) => l(r.preferences));
  return r.preferences;
}

/** The user's preferences (the defaults until they are loaded). */
export function usePrefs(): Preferences {
  const [p, setP] = useState<Preferences>(current || DEFAULT_PREFS);
  useEffect(() => {
    listeners.add(setP);
    load().then(setP);
    return () => { listeners.delete(setP); };
  }, []);
  return p;
}

/** Saves one group of the preferences in the background (e.g. a filter the user just changed). */
export function rememberPref<K extends keyof Preferences>(group: K, values: Partial<Preferences[K]>) {
  const base = current || DEFAULT_PREFS;
  savePrefs({ ...base, [group]: { ...base[group], ...values } }).catch(() => { /* kept for this page only */ });
}
