import { useEffect, useRef, useState } from 'react';
import { apiUrl, projectPath } from '../api';

export type ProjectEvent = { type: string; data: any };

const TYPES = ['snapshot', 'run', 'runFull', 'table', 'log', 'codeExport', 'codeApply', 'analysis', 'projectDeleted'];
const SILENCE_MS = 45000; // the server pings every 15 s

/**
 * One Server-Sent Events connection per open project. The server pushes snapshot progress,
 * run status, table progress and log lines the moment they happen. This replaces v1's polling.
 *
 * Two ways a stream dies without the browser noticing, both handled here:
 *  - the server (or a proxy) answers with an HTTP error, e.g. while the service restarts: EventSource
 *    then closes for good, so it is reopened (1 s, 2 s, … up to 15 s);
 *  - a proxy keeps its side of the connection open after the server went away: nothing arrives any
 *    more, not even the server's 15 s ping, so after 45 s of silence the stream is replaced.
 * Every successful (re)connect is reported with a new `connectedAt`, so pages reload their data and
 * pick up whatever finished while they were disconnected. A deleted project stops the retries.
 */
export function useProjectEvents(projectName: string | undefined, onEvent: (e: ProjectEvent) => void) {
  const handler = useRef(onEvent);
  handler.current = onEvent;
  const [state, setState] = useState<{ connected: boolean; connectedAt: number }>({ connected: false, connectedAt: 0 });

  useEffect(() => {
    if (!projectName) return undefined;
    let es: EventSource | null = null;
    let retry: ReturnType<typeof setTimeout> | null = null;
    let delay = 1000;
    let stopped = false;
    let lastSeen = Date.now();

    const reconnect = async () => {
      if (es) { es.close(); es = null; }
      setState((s) => (s.connected ? { ...s, connected: false } : s));
      if (stopped || retry) return;
      // Stop for good if the project is gone (deleted in another tab); otherwise try again later.
      const res = await fetch(apiUrl(projectPath(projectName))).catch(() => null);
      if (res && res.status === 404) { stopped = true; return; }
      retry = setTimeout(() => { retry = null; open(); }, delay);
      delay = Math.min(15000, delay * 2);
    };

    const open = () => {
      if (stopped) return;
      lastSeen = Date.now();
      const source = new EventSource(apiUrl(`${projectPath(projectName)}/events`), { withCredentials: true });
      es = source;
      const seen = () => { lastSeen = Date.now(); };
      source.addEventListener('ping', seen);
      TYPES.forEach((type) => source.addEventListener(type, (ev) => {
        seen();
        try { handler.current({ type, data: JSON.parse((ev as MessageEvent).data) }); } catch { /* ignore malformed */ }
      }));
      source.onopen = () => {
        seen();
        delay = 1000;
        setState({ connected: true, connectedAt: Date.now() });
      };
      source.onerror = () => {
        if (source !== es) return;
        if (source.readyState === EventSource.CLOSED) reconnect();
        else setState((s) => (s.connected ? { ...s, connected: false } : s)); // the browser retries by itself
      };
    };

    open();
    // A watchdog on silence, not polling: no request is made while events or pings keep arriving.
    const watchdog = setInterval(() => {
      if (!stopped && es && Date.now() - lastSeen > SILENCE_MS) reconnect();
    }, 10000);
    return () => {
      stopped = true;
      clearInterval(watchdog);
      if (retry) clearTimeout(retry);
      if (es) es.close();
    };
  }, [projectName]);

  return state;
}
