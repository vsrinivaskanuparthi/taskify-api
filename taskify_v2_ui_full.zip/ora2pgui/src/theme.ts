import { alpha, createTheme } from '@mui/material/styles';
import '@fontsource-variable/inter';
import '@fontsource-variable/plus-jakarta-sans';

/** Airbus-blue enterprise palette. Fonts are bundled (no Google Fonts call from the corporate network). */
export const brand = {
  navy: '#00205B',
  ink: '#0B1B3F',
  deep: '#083E8C',
  blue: '#0B57D0',
  sky: '#EAF1FD',
  cyan: '#22A6F2',
  bg: '#F4F6FB',
  border: '#E3E8F0',
  text: '#101828',
  muted: '#5D6B82',
  success: '#0E9F6E',
  warning: '#D97706',
  error: '#DC2626',
  violet: '#7C3AED',
  gradient: 'linear-gradient(135deg, #00205B 0%, #0A3F96 55%, #0B57D0 100%)',
  accentGradient: 'linear-gradient(135deg, #0B57D0 0%, #22A6F2 100%)',
  sidebar: 'linear-gradient(180deg, #061637 0%, #00205B 60%, #04307A 100%)',
};

export const headingFont = '"Plus Jakarta Sans Variable", "Inter Variable", "Segoe UI", system-ui, sans-serif';
export const bodyFont = '"Inter Variable", "Segoe UI", system-ui, -apple-system, Roboto, Arial, sans-serif';
export const monoFont = '"JetBrains Mono", "Cascadia Code", "SFMono-Regular", Consolas, monospace';

const theme = createTheme({
  palette: {
    primary: { main: brand.blue, dark: brand.deep, light: '#4C8DF6', contrastText: '#fff' },
    secondary: { main: brand.navy },
    success: { main: brand.success },
    warning: { main: brand.warning },
    error: { main: brand.error },
    info: { main: brand.cyan },
    background: { default: brand.bg, paper: '#FFFFFF' },
    text: { primary: brand.text, secondary: brand.muted },
    divider: brand.border,
  },
  shape: { borderRadius: 12 },
  typography: {
    fontFamily: bodyFont,
    fontSize: 14,
    h3: { fontFamily: headingFont, fontWeight: 800, letterSpacing: '-0.03em' },
    h4: { fontFamily: headingFont, fontWeight: 800, letterSpacing: '-0.025em', fontSize: 28 },
    h5: { fontFamily: headingFont, fontWeight: 750, letterSpacing: '-0.02em' },
    h6: { fontFamily: headingFont, fontWeight: 700, letterSpacing: '-0.01em', fontSize: 17 },
    subtitle1: { fontWeight: 600 },
    subtitle2: { fontWeight: 600, color: brand.muted, fontSize: 13 },
    body2: { fontSize: 13.5 },
    button: { textTransform: 'none', fontWeight: 650, letterSpacing: 0 },
    overline: { fontWeight: 700, letterSpacing: '0.1em', fontSize: 11 },
    caption: { fontSize: 12 },
  },
  components: {
    MuiCssBaseline: {
      styleOverrides: {
        body: {
          backgroundColor: brand.bg,
          backgroundImage: 'radial-gradient(1200px 500px at 85% -10%, rgba(11,87,208,.07), transparent 60%), radial-gradient(900px 400px at -10% 110%, rgba(34,166,242,.06), transparent 60%)',
          backgroundAttachment: 'fixed',
        },
        '.mono': { fontFamily: monoFont, fontSize: '0.92em' },
        '*::-webkit-scrollbar': { width: 10, height: 10 },
        '*::-webkit-scrollbar-thumb': { background: '#C9D3E3', borderRadius: 8, border: '2px solid transparent', backgroundClip: 'padding-box' },
      },
    },
    MuiPaper: {
      defaultProps: { elevation: 0 },
      styleOverrides: { root: { border: `1px solid ${brand.border}`, backgroundImage: 'none' } },
    },
    MuiCard: {
      styleOverrides: { root: { borderRadius: 16, boxShadow: '0 1px 2px rgba(16,24,40,.04), 0 8px 24px -12px rgba(0,32,91,.10)' } },
    },
    MuiButton: {
      defaultProps: { disableElevation: true },
      styleOverrides: {
        root: { borderRadius: 10, paddingInline: 16, minHeight: 38 },
        containedPrimary: { background: brand.accentGradient, '&:hover': { background: 'linear-gradient(135deg, #0A4DB8 0%, #1C93D9 100%)' }, '&.Mui-disabled': { background: '#E4E9F2' } },
        outlined: { borderColor: brand.border, backgroundColor: '#fff', '&:hover': { borderColor: '#C7D2E3', backgroundColor: '#F8FAFD' } },
        sizeLarge: { minHeight: 46, fontSize: 15 },
      },
    },
    MuiChip: { styleOverrides: { root: { fontWeight: 650, borderRadius: 8 }, sizeSmall: { height: 24, fontSize: 12 } } },
    MuiTableCell: {
      styleOverrides: {
        head: { fontWeight: 700, color: brand.muted, fontSize: 11.5, textTransform: 'uppercase', letterSpacing: '.06em', backgroundColor: '#F8FAFD', borderBottom: `1px solid ${brand.border}` },
        root: { borderColor: '#EEF2F7', fontSize: 13.5 },
      },
    },
    MuiTableRow: { styleOverrides: { root: { '&.MuiTableRow-hover:hover': { backgroundColor: '#F7FAFF' } } } },
    MuiTooltip: { styleOverrides: { tooltip: { backgroundColor: brand.ink, fontSize: 12, borderRadius: 8, padding: '6px 10px' } } },
    MuiLinearProgress: {
      styleOverrides: { root: { borderRadius: 6, height: 8, backgroundColor: alpha(brand.blue, 0.1) }, bar: { borderRadius: 6 } },
    },
    MuiTab: { styleOverrides: { root: { textTransform: 'none', fontWeight: 650, minHeight: 48, fontSize: 14 } } },
    MuiOutlinedInput: {
      styleOverrides: {
        root: { borderRadius: 10, backgroundColor: '#fff', '& .MuiOutlinedInput-notchedOutline': { borderColor: '#D9E0EA' } },
      },
    },
    MuiDialog: { styleOverrides: { paper: { borderRadius: 18, border: 'none' } } },
    MuiAlert: { styleOverrides: { root: { borderRadius: 12, alignItems: 'center' } } },
    MuiAccordion: { styleOverrides: { root: { borderRadius: 16 } } },
  },
});

export default theme;
