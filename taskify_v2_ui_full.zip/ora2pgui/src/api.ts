import { API_HOST } from './components/constants';

export class ApiError extends Error {
  status: number;
  constructor(message: string, status: number) {
    super(message);
    this.status = status;
  }
}

/** JSON fetch helper: throws ApiError with the server's message on failure. */
export async function api<T = any>(path: string, init: { method?: string; body?: unknown } = {}): Promise<T> {
  let res: Response;
  try {
    res = await fetch(`${API_HOST}${path}`, {
      method: init.method || (init.body !== undefined ? 'POST' : 'GET'),
      headers: init.body !== undefined ? { 'Content-Type': 'application/json' } : undefined,
      body: init.body !== undefined ? JSON.stringify(init.body) : undefined,
      credentials: 'include',
    });
  } catch {
    throw new ApiError('Cannot reach the migration server. Check that the backend is running.', 0);
  }
  const text = await res.text();
  let data: any = null;
  try { data = text ? JSON.parse(text) : null; } catch { data = text; }
  if (!res.ok) throw new ApiError((data && data.message) || `Request failed (${res.status})`, res.status);
  return data as T;
}

export const projectPath = (name: string) => `/projects/${encodeURIComponent(name)}`;
export const apiUrl = (path: string) => `${API_HOST}${path}`;
