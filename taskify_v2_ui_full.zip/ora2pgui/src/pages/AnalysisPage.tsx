import { Alert, Box, Button, Card, CircularProgress, Collapse, LinearProgress, Menu, MenuItem, Stack, Table, TableBody, TableCell, TableHead, TableRow, Typography } from '@mui/material';
import AssessmentRoundedIcon from '@mui/icons-material/AssessmentRounded';
import PlayArrowRoundedIcon from '@mui/icons-material/PlayArrowRounded';
import CloudDownloadRoundedIcon from '@mui/icons-material/CloudDownloadRounded';
import OpenInNewRoundedIcon from '@mui/icons-material/OpenInNewRounded';
import ExpandMoreRoundedIcon from '@mui/icons-material/ExpandMoreRounded';
import HistoryRoundedIcon from '@mui/icons-material/HistoryRounded';
import BuildCircleRoundedIcon from '@mui/icons-material/BuildCircleRounded';
import TaskAltRoundedIcon from '@mui/icons-material/TaskAltRounded';
import ScheduleRoundedIcon from '@mui/icons-material/ScheduleRounded';
import Inventory2RoundedIcon from '@mui/icons-material/Inventory2Rounded';
import ChecklistRoundedIcon from '@mui/icons-material/ChecklistRounded';
import CheckCircleRoundedIcon from '@mui/icons-material/CheckCircleRounded';
import WarningRoundedIcon from '@mui/icons-material/WarningRounded';
import { useCallback, useEffect, useMemo, useState } from 'react';
import { api, apiUrl, projectPath } from '../api';
import { useProject } from '../context/ProjectContext';
import { CheckIcon, EmptyState, PageHeader, SectionCard, Tag } from '../components/ui';
import { fmtDate, fmtDuration, fmtInt, fmtMb } from '../format';
import { brand, headingFont } from '../theme';
import { useIsAdmin } from '../role';
import { Link as RouterLink } from 'react-router-dom';

type Severity = 'critical' | 'high' | 'medium' | 'low' | 'info';
type Action = 'auto' | 'decide' | 'manual';
type Finding = { id: string; severity: Severity; category: string; title: string; detail: string; handling?: string; recommendation?: string; objects: string[]; count: number; action?: Action };

const ACTION: Record<Action, { label: string; short: string; color: string }> = {
  manual: { label: 'need work by the team', short: 'Needs work', color: '#B54708' },
  decide: { label: 'need a decision', short: 'Decision', color: '#175CD3' },
  auto: { label: 'handled automatically', short: 'Automatic', color: '#067647' },
};
type Report = {
  id: string; schema: string; createdAt: string;
  decisions?: { agreedBy: string; agreedAt: string | null } | null;
  ora2pgOnly?: boolean;
  source: { version?: string; charset?: string };
  summary: {
    score: number; rating: string; counts: Record<Severity, number>; actions?: Record<Action, number>; sizeMb: number; lobMb: number; tables: number; rows: number; codeObjects: number; codeLines: number;
    ora2pg: { level: string; levelText: string; cost: number; days: string; objects: number; invalid: number } | null;
    load: { measuredMbps: number | null; estimates: { label: string; mbps: number; ms: number }[]; targetDiskGb: number };
  };
  findings: Finding[];
  inventory: { object: string; number: number; invalid: number; cost: number; comment: string; details: string }[];
  topTables: { name: string; sizeMb: number; lobSizeMb: number; rowCount: number; partitioned: boolean }[];
  plsqlTop: { type: string; name: string; lines: number; features: string[] }[];
  checklist: { phase: string; items: string[] }[];
  failedChecks: { check: string; error: string }[];
};
type Overview = { reports: { id: string; schema: string; createdAt: string; score: number; level?: string }[]; latest: Report | null; job: any };

export const SEV: Record<Severity, { label: string; color: string; bg: string }> = {
  critical: { label: 'Critical', color: '#B42318', bg: '#FEF3F2' },
  high: { label: 'High', color: '#C4320A', bg: '#FFF4ED' },
  medium: { label: 'Medium', color: '#B54708', bg: '#FFFAEB' },
  low: { label: 'Low', color: '#175CD3', bg: '#EFF8FF' },
  info: { label: 'Info', color: '#475467', bg: '#F2F4F7' },
};

function SevPill({ s }: { s: Severity }) {
  return <Box component="span" sx={{ px: 1.1, py: 0.3, borderRadius: 99, fontSize: 11, fontWeight: 800, letterSpacing: '.04em', textTransform: 'uppercase', color: SEV[s].color, bgcolor: SEV[s].bg, flexShrink: 0 }}>{SEV[s].label}</Box>;
}

function FindingCard({ f, index, simple = false }: { f: Finding; index: number; simple?: boolean }) {
  // simple: the choices view (closed, no severity or category); all details: the full card.
  const [open, setOpen] = useState(!simple && (f.severity === 'critical' || f.severity === 'high'));
  const [all, setAll] = useState(false);
  const objs = all ? f.objects : f.objects.slice(0, 24);
  return (
    <Box sx={{ border: 1, borderColor: open ? '#C9DBFB' : 'divider', borderRadius: 3, overflow: 'hidden', transition: 'border-color .15s', borderLeft: `4px solid ${SEV[f.severity].color}` }}>
      <Stack direction="row" spacing={1.5} alignItems="center" onClick={() => setOpen((o) => !o)} sx={{ px: 2, py: 1.5, cursor: 'pointer', '&:hover': { bgcolor: '#FAFBFD' } }}>
        {!simple && <SevPill s={f.severity} />}
        {!simple && f.action && <Box component="span" sx={{ fontSize: 11, fontWeight: 700, color: ACTION[f.action].color, flexShrink: 0, display: { xs: 'none', md: 'inline' } }}>{ACTION[f.action].short}</Box>}
        {!simple && <Typography variant="caption" color="text.secondary" sx={{ width: 92, flexShrink: 0, display: { xs: 'none', sm: 'block' } }}>{f.category}</Typography>}
        <Typography fontWeight={650} fontSize={14.5} sx={{ flex: 1, minWidth: 0 }}>{f.title}</Typography>
        {!simple && <Typography variant="caption" color="text.disabled">#{index + 1}</Typography>}
        <ExpandMoreRoundedIcon sx={{ color: 'text.secondary', transform: open ? 'rotate(180deg)' : 'none', transition: 'transform .2s' }} />
      </Stack>
      <Collapse in={open} unmountOnExit>
        <Box sx={{ px: 2.5, pb: 2.25, pt: 0.5 }}>
          <Typography variant="body2" color="text.secondary">{f.detail}</Typography>
          <Box sx={{ display: 'grid', gap: 1.5, gridTemplateColumns: { xs: '1fr', md: '1fr 1fr' }, mt: 1.75 }}>
            <Box sx={{ p: 1.5, borderRadius: 2.5, bgcolor: '#F3F7FF' }}>
              <Stack direction="row" spacing={0.75} alignItems="center"><BuildCircleRoundedIcon sx={{ fontSize: 18, color: brand.blue }} /><Typography variant="caption" fontWeight={800} color={brand.blue} sx={{ letterSpacing: '.05em' }}>HOW THE TOOL HANDLES IT</Typography></Stack>
              <Typography variant="body2" sx={{ mt: 0.5 }}>{f.handling || '—'}</Typography>
            </Box>
            <Box sx={{ p: 1.5, borderRadius: 2.5, bgcolor: '#ECFDF3' }}>
              <Stack direction="row" spacing={0.75} alignItems="center"><TaskAltRoundedIcon sx={{ fontSize: 18, color: brand.success }} /><Typography variant="caption" fontWeight={800} color={brand.success} sx={{ letterSpacing: '.05em' }}>RECOMMENDED ACTION</Typography></Stack>
              <Typography variant="body2" sx={{ mt: 0.5 }}>{f.recommendation || '—'}</Typography>
            </Box>
          </Box>
          {f.objects.length > 0 && (
            <>
              <Typography variant="caption" fontWeight={700} color="text.secondary" sx={{ display: 'block', mt: 2, mb: 0.75, letterSpacing: '.05em' }}>AFFECTED OBJECTS ({fmtInt(f.objects.length)})</Typography>
              <Stack direction="row" flexWrap="wrap" useFlexGap spacing={0.75} sx={{ maxHeight: all ? 320 : 'none', overflow: 'auto' }}>
                {objs.map((o) => <Box key={o} className="mono" sx={{ fontSize: 12, px: 1, py: 0.4, borderRadius: 1.5, bgcolor: '#F2F4F7' }}>{o}</Box>)}
              </Stack>
              {f.objects.length > 24 && <Button size="small" sx={{ mt: 1 }} onClick={() => setAll((a) => !a)}>{all ? 'Show less' : `Show all ${fmtInt(f.objects.length)}`}</Button>}
            </>
          )}
        </Box>
      </Collapse>
    </Box>
  );
}

export default function AnalysisPage() {
  const admin = useIsAdmin();
  const { name, project, snapshot, subscribe, connectedAt } = useProject();
  const [ov, setOv] = useState<Overview | null>(null);
  const [report, setReport] = useState<Report | null>(null);
  const [job, setJob] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  const [showAll, setShowAll] = useState(false);
  const [history, setHistory] = useState<HTMLElement | null>(null);

  const load = useCallback(async () => {
    try {
      const r = await api<Overview>(`${projectPath(name)}/analysis`);
      setOv(r);
      setReport(r.latest);
      setJob(r.job);
    } catch (e: any) {
      setError(e.message);
    }
  }, [name]);
  useEffect(() => { load(); }, [load, connectedAt]);
  useEffect(() => subscribe((e) => {
    if (e.type !== 'analysis') return;
    setJob(e.data);
    if (e.data.status !== 'RUNNING') {
      if (e.data.status === 'FAILED') setError(e.data.error);
      load();
    }
  }), [subscribe, load]);

  const run = async () => {
    setError(null);
    try { setJob((await api(`${projectPath(name)}/analysis`, { body: {} })).job); } catch (e: any) { setError(e.message); }
  };
  const openReport = async (id: string) => {
    setHistory(null);
    try { setReport((await api<{ report: Report }>(`${projectPath(name)}/analysis/${id}`)).report); } catch (e: any) { setError(e.message); }
  };

  // Shown by default: only what needs a decision. Everything else is behind "Show all details".
  const decisions = useMemo(() => (report ? report.findings.filter((f) => f.action === 'decide') : []), [report]);
  const findings = showAll ? report?.findings || [] : decisions;
  // Findings that mean wrong data with the current settings (decimals cut or turned into floating point).
  const dataRisk = useMemo(() => (report ? report.findings.filter((f: any) => f.dataRisk || f.id === 'number-float' || (f.id === 'number-noprec' && f.severity === 'high')) : []), [report]);
  const running = job?.status === 'RUNNING';
  const canRun = !!project?.oracle && !!project?.selectedSchema;
  const dl = (kind: string, view = false) => apiUrl(`${projectPath(name)}/analysis/${report?.id}/download/${kind}${view ? '?view=1' : ''}`);

  if (!ov) return error ? <Alert severity="error">{error}</Alert> : <LinearProgress />;
  const s = report?.summary;

  return (
    <>
      <PageHeader overline={admin === false ? 'Optional' : 'Optional · for the DBA or architect'} title={admin === false ? 'ora2pg report' : 'Detailed report'} icon={<AssessmentRoundedIcon />}
        subtitle={admin === false
          ? <>ora2pg’s standard assessment of <b>{project?.selectedSchema || 'the schema'}</b>: object counts and the estimated conversion effort. Not needed to migrate.</>
          : <>A deeper look at <b>{project?.selectedSchema || 'the schema'}</b> to share with the team. Not needed to migrate: the Assessment page has everything for that.</>}
        actions={
          <Stack direction="row" spacing={1}>
            {ov.reports.length > 1 && <Button variant="outlined" startIcon={<HistoryRoundedIcon />} onClick={(e) => setHistory(e.currentTarget)}>History ({ov.reports.length})</Button>}
            <Button variant="contained" size="large" startIcon={running ? <CircularProgress size={18} color="inherit" /> : <PlayArrowRoundedIcon />} disabled={running || !canRun} onClick={run}>
              {running ? 'Analysing…' : report ? 'Run again' : 'Run analysis'}
            </Button>
          </Stack>
        } />
      <Menu anchorEl={history} open={!!history} onClose={() => setHistory(null)}>
        {ov.reports.map((r) => (
          <MenuItem key={r.id} selected={r.id === report?.id} onClick={() => openReport(r.id)}>
            <Stack direction="row" spacing={2} alignItems="center" sx={{ width: '100%' }}>
              <Typography fontSize={13.5} fontWeight={600} sx={{ flex: 1 }}>{r.schema} · {fmtDate(r.createdAt)}</Typography>
            </Stack>
          </MenuItem>
        ))}
      </Menu>
      {error && <Alert severity="error" sx={{ mb: 3 }} onClose={() => setError(null)}>{error}</Alert>}
      {!snapshot && <Alert severity="info" sx={{ mb: 3 }}>Take a snapshot of the schema first (Schema & snapshot); the analysis builds on it.</Alert>}

      {running && (
        <Card sx={{ p: 2.5, mb: 3 }}>
          <Stack spacing={1.25}>
            {job.steps.map((st: any) => (
              <Stack key={st.key} direction="row" spacing={1.25} alignItems="center">
                <Box sx={{ width: 22, display: 'grid', placeItems: 'center' }}>{st.status === 'running' ? <CircularProgress size={18} thickness={5} /> : <CheckIcon ok={st.status === 'done'} warn={st.status === 'warning'} pending={st.status === 'pending'} />}</Box>
                <Typography fontWeight={st.status === 'running' ? 700 : 500} sx={{ flex: 1 }}>{st.label}</Typography>
                {st.total ? <Typography variant="caption" color="text.secondary">{st.done} / {st.total}</Typography> : null}
              </Stack>
            ))}
          </Stack>
        </Card>
      )}

      {!report && !running && (
        <Card><EmptyState icon={<AssessmentRoundedIcon />} title="No analysis yet" text="Runs ora2pg's migration assessment and our complexity checks on the selected schema. Takes about a minute; nothing is changed in Oracle."
          action={<Button variant="contained" startIcon={<PlayArrowRoundedIcon />} disabled={!canRun} onClick={run}>Run analysis</Button>} /></Card>
      )}

      {report && (admin === false || report.ora2pgOnly) && (
        <Card sx={{ p: 3 }}>
          <Typography fontWeight={750} sx={{ mb: 0.5 }}>ora2pg report · {fmtDate(report.createdAt)}</Typography>
          <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>{admin === false ? 'The DBA team has the detailed DMA analysis; this is ora2pg’s own report of the schema.' : 'This run made only ora2pg’s own report. Press “Run again” for the detailed DMA analysis.'}</Typography>
          <Stack direction="row" spacing={1.5}>
            <Button variant="contained" startIcon={<OpenInNewRoundedIcon />} href={dl('ora2pg', true)} target="_blank">Open ora2pg report</Button>
            <Button variant="outlined" href={dl('ora2pg')}>Download</Button>
          </Stack>
        </Card>
      )}

      {report && s && admin !== false && !report.ora2pgOnly && (
        <>
          {/* Summary in plain words: no score, no ora2pg level (both stay in the downloadable report) */}
          <Box sx={{ background: brand.gradient, color: '#fff', borderRadius: 4, p: { xs: 2.5, md: 3.5 }, mb: 3, position: 'relative', overflow: 'clip' }}>
            <Box sx={{ position: 'absolute', right: -80, top: -120, width: 360, height: 360, borderRadius: '50%', background: 'radial-gradient(circle, rgba(255,255,255,.12), transparent 70%)' }} />
            <Stack direction={{ xs: 'column', md: 'row' }} spacing={4} alignItems={{ md: 'center' }} sx={{ position: 'relative' }}>
              <Box sx={{ flex: 1, minWidth: 0 }}>
                <Typography sx={{ opacity: 0.8, fontSize: 13 }}>{report.schema} · {fmtDate(report.createdAt)} · Oracle {report.source.version}</Typography>
                <Typography sx={{ opacity: 0.8, fontSize: 13 }}>{report.decisions ? `Decisions agreed with ${report.decisions.agreedBy}${report.decisions.agreedAt ? ` on ${fmtDate(report.decisions.agreedAt)}` : ''}` : 'Decisions not agreed yet: record it in Settings, then generate the report again.'}</Typography>
                <Stack spacing={1.5} sx={{ mt: 1.5 }}>
                  {[
                    ['Data', dataRisk.length
                      ? `Not yet: ${dataRisk.map((f) => f.title.toLowerCase()).join('; ')} with the current settings (values would change). Change that in Settings first; then all ${fmtInt(s.tables)} tables can be migrated automatically.`
                      : `Ready: all ${fmtInt(s.tables)} tables (${fmtMb(s.sizeMb)}) can be migrated automatically.${decisions.length ? ` ${decisions.length} choice${decisions.length === 1 ? '' : 's'} to confirm in Settings.` : ''}`, dataRisk.length > 0],
                    ['Code', s.codeObjects ? `${fmtInt(s.codeObjects)} PL/SQL objects (functions, procedures, package bodies, triggers; ${fmtInt(s.codeLines)} lines) to convert with GenAI${s.ora2pg?.days ? `, about ${s.ora2pg.days}` : ''}. Views and other objects are listed on Code objects.` : 'No PL/SQL code to convert.', false],
                  ].map(([k, v, warn]) => (
                    <Stack key={k as string} direction="row" spacing={1.5} alignItems="flex-start">
                      {warn ? <WarningRoundedIcon sx={{ color: '#FDE68A', mt: 0.4 }} /> : <CheckCircleRoundedIcon sx={{ color: '#6EE7B7', mt: 0.4 }} />}
                      <Box><Typography sx={{ fontSize: 12, opacity: 0.75, fontWeight: 700, letterSpacing: '.06em', textTransform: 'uppercase' }}>{k}</Typography>
                        <Typography sx={{ fontSize: { xs: 17, md: 20 }, fontWeight: 650, lineHeight: 1.3 }}>{v}</Typography></Box>
                    </Stack>
                  ))}
                </Stack>
              </Box>
              <Stack spacing={1} sx={{ flexShrink: 0 }}>
                <Button variant="contained" sx={{ bgcolor: '#fff', backgroundImage: 'none', color: brand.navy, '&:hover': { bgcolor: brand.sky, backgroundImage: 'none' } }} startIcon={<CloudDownloadRoundedIcon />} href={dl('html')}>Download report</Button>
                <Button variant="outlined" sx={{ color: '#fff', borderColor: 'rgba(255,255,255,.45)', bgcolor: 'rgba(255,255,255,.06)', '&:hover': { bgcolor: 'rgba(255,255,255,.14)', borderColor: '#fff' } }} startIcon={<OpenInNewRoundedIcon />} href={dl('html', true)} target="_blank">Open full report</Button>
                <Button variant="text" sx={{ color: 'rgba(255,255,255,.85)' }} startIcon={<OpenInNewRoundedIcon />} href={dl('ora2pg', true)} target="_blank">ora2pg's own report</Button>
              </Stack>
            </Stack>
          </Box>

          {/* Key numbers */}
          <Box sx={{ display: 'grid', gap: 2, gridTemplateColumns: { xs: 'repeat(2, 1fr)', md: 'repeat(4, 1fr)' }, mb: 3 }}>
            {[
              ['Schema size', fmtMb(s.sizeMb), s.lobMb ? `${fmtMb(s.lobMb)} in LOBs` : 'No LOB data'],
              ['Tables / rows', `${fmtInt(s.tables)}`, `${fmtInt(s.rows)} rows`],
              ['Code objects', fmtInt(s.codeObjects), `${fmtInt(s.codeLines)} lines of PL/SQL`],
              ['Target disk', `~${fmtInt(s.load.targetDiskGb)} GB`, 'data + indexes, excl. WAL'],
            ].map(([k, v, h]) => (
              <Card key={k} sx={{ p: 2.25 }}>
                <Typography variant="subtitle2" color="text.secondary">{k}</Typography>
                <Typography sx={{ fontFamily: headingFont, fontWeight: 800, fontSize: 26, color: brand.ink, mt: 0.5 }}>{v}</Typography>
                <Typography variant="caption" color="text.secondary">{h}</Typography>
              </Card>
            ))}
          </Box>

          <Box sx={{ display: 'grid', gap: 3, gridTemplateColumns: { xs: '1fr', xl: 'minmax(0, 1fr) 380px' }, alignItems: 'start' }}>
            <SectionCard
              title={showAll ? `Everything the analysis found (${report.findings.length})`
                : report.decisions ? `Choices agreed with ${report.decisions.agreedBy}` : `Choices to confirm (${decisions.length})`}
              subtitle={showAll ? 'Including everything DMA handles by itself.'
                : report.decisions ? 'Recorded in Settings. Open a line to see what it means.' : 'Each one is set once in Settings → Migration decisions. Everything else is handled automatically.'}
              action={<Stack direction="row" spacing={1}>
                {!showAll && <Button size="small" variant="contained" component={RouterLink} to="../settings">Open Settings</Button>}
                <Button size="small" variant="outlined" onClick={() => setShowAll((v) => !v)}>{showAll ? 'Show only the choices' : 'Show everything'}</Button>
              </Stack>}>
              <Stack spacing={1}>
                {findings.map((f) => <FindingCard key={f.id} f={f} index={report.findings.indexOf(f)} simple={!showAll} />)}
                {!findings.length && <Typography color="text.secondary">Nothing to decide: the tool handles everything it found.</Typography>}
              </Stack>
            </SectionCard>

            <Stack spacing={3}>
              <SectionCard collapsible storeKey="analysis.load" title="Load time estimate" icon={<ScheduleRoundedIcon />} subtitle={`${fmtMb(s.sizeMb)} of data, excluding indexes and code.`}>
                <Stack spacing={1.25}>
                  {s.load.estimates.map((e) => (
                    <Stack key={e.label} direction="row" justifyContent="space-between" alignItems="baseline" spacing={2}>
                      <Typography variant="body2" color="text.secondary">{e.label}</Typography>
                      <Typography fontWeight={800} sx={{ fontFamily: headingFont, flexShrink: 0 }}>{fmtDuration(Math.max(e.ms, 60000))}</Typography>
                    </Stack>
                  ))}
                </Stack>
                {!s.load.measuredMbps && <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 1.5 }}>Run a trial migration of a large table to measure your real speed.</Typography>}
              </SectionCard>

              <SectionCard collapsible storeKey="analysis.checklist" title="Checklist" icon={<ChecklistRoundedIcon />} summary="Before, during and after the migration">
                {report.checklist.map((g) => (
                  <Box key={g.phase} sx={{ mb: 1.5 }}>
                    <Typography variant="overline" color="text.secondary">{g.phase} the migration</Typography>
                    <Stack spacing={0.75}>
                      {g.items.map((i) => (
                        <Stack key={i} direction="row" spacing={1} alignItems="flex-start">
                          <Box sx={{ width: 6, height: 6, borderRadius: '50%', bgcolor: brand.blue, mt: 0.9, flexShrink: 0 }} />
                          <Typography variant="body2">{i}</Typography>
                        </Stack>
                      ))}
                    </Stack>
                  </Box>
                ))}
              </SectionCard>
            </Stack>
          </Box>

          {report.inventory.length > 0 && (
            <Box sx={{ mt: 3 }}>
              <SectionCard collapsible storeKey="analysis.inventory" title="Object inventory & ora2pg cost" icon={<Inventory2RoundedIcon />} subtitle={`ora2pg cost units (≈ 5 min of expert time each). Total ${s.ora2pg?.cost} units · ${s.ora2pg?.days}.`} dense>
                <Box sx={{ overflowX: 'auto' }}>
                  <Table size="small">
                    <TableHead><TableRow><TableCell>Object</TableCell><TableCell align="right">Count</TableCell><TableCell align="right">Invalid</TableCell><TableCell align="right">Cost</TableCell><TableCell>ora2pg note</TableCell></TableRow></TableHead>
                    <TableBody>
                      {report.inventory.map((o) => (
                        <TableRow key={o.object}>
                          <TableCell sx={{ fontWeight: 650, whiteSpace: 'nowrap' }}>{o.object}</TableCell>
                          <TableCell align="right">{fmtInt(o.number)}</TableCell>
                          <TableCell align="right">{o.invalid ? <Tag label={o.invalid} color={brand.error} /> : 0}</TableCell>
                          <TableCell align="right">{Number(o.cost).toFixed(1)}</TableCell>
                          <TableCell sx={{ color: 'text.secondary', fontSize: 12.5, minWidth: 320 }}>{o.comment}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </Box>
              </SectionCard>
            </Box>
          )}

          {report.failedChecks.length > 0 && (
            <Alert severity="warning" sx={{ mt: 3 }}>
              {report.failedChecks.length} checks could not run ({report.failedChecks.map((f) => f.check).join(', ')}), usually a missing privilege on a DBA_ view. Grant SELECT_CATALOG_ROLE to the migration user and run again.
            </Alert>
          )}
        </>
      )}
    </>
  );
}
