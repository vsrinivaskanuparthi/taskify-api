import { Alert, Box, Button, Chip, CircularProgress, Collapse, Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle, IconButton, InputAdornment, List, ListItemButton, MenuItem, Stack, Tab, Tabs, TextField, ToggleButton, ToggleButtonGroup, Tooltip, Typography } from '@mui/material';
import PlayArrowRoundedIcon from '@mui/icons-material/PlayArrowRounded';
import TerminalRoundedIcon from '@mui/icons-material/TerminalRounded';
import LockRoundedIcon from '@mui/icons-material/LockRounded';
import EditNoteRoundedIcon from '@mui/icons-material/EditNoteRounded';
import SearchRoundedIcon from '@mui/icons-material/SearchRounded';
import TableChartRoundedIcon from '@mui/icons-material/TableChartRounded';
import ExpandMoreRoundedIcon from '@mui/icons-material/ExpandMoreRounded';
import ChevronRightRoundedIcon from '@mui/icons-material/ChevronRightRounded';
import HistoryRoundedIcon from '@mui/icons-material/HistoryRounded';
import DownloadRoundedIcon from '@mui/icons-material/DownloadRounded';
import DeleteSweepRoundedIcon from '@mui/icons-material/DeleteSweepRounded';
import WarningAmberRoundedIcon from '@mui/icons-material/WarningAmberRounded';
import CodeMirror, { keymap, Prec, ReactCodeMirrorRef } from '@uiw/react-codemirror';
import { PLSQL, PostgreSQL, sql as sqlLang } from '@codemirror/lang-sql';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { api, apiUrl, projectPath } from '../api';
import { useProject } from '../context/ProjectContext';
import DataTable from '../components/DataTable';
import ErrorHelp from '../components/ErrorHelp';
import { PageHeader } from '../components/ui';
import { downloadCsv, downloadXlsx, safeFileName } from '../exportFile';
import { fmtDate, fmtInt } from '../format';
import { brand, monoFont } from '../theme';
import { useIsAdmin } from '../role';

type Target = 'postgres' | 'oracle';
type ResultSet = { statement: string; command: string; rowCount: number; more: boolean; ms: number; columns: { name: string; type: string }[]; rows: (string | null)[][] };
type RunResponse = { schema: string; results?: ResultSet[]; needsWrite?: boolean; statement?: string; message?: string; admin: boolean; ms: number };
type RunError = { message: string; statement?: string | null; position?: string | null; hint?: string | null; done?: number };
type HistoryItem = { at: string; user: string | null; target: Target; sql: string; write: boolean; ms: number; result: string | null; error: string | null };

const DRAFT_KEY = (p: string, t: Target) => `dma.sql.${p}.${t}`;
const readDraft = (p: string, t: Target) => { try { return localStorage.getItem(DRAFT_KEY(p, t)); } catch { return null; } };
const writeDraft = (p: string, t: Target, v: string) => { try { localStorage.setItem(DRAFT_KEY(p, t), v); } catch { /* storage blocked */ } };
const STARTER: Record<Target, string> = {
  postgres: '-- PostgreSQL target. Ctrl+Enter runs the query (or only the selected text).\nSELECT table_name\n  FROM information_schema.tables\n WHERE table_schema = current_schema()\n ORDER BY 1;\n',
  oracle: '-- Oracle source: SELECT only. Ctrl+Enter runs the query (or only the selected text).\nSELECT table_name, num_rows\n  FROM all_tables\n WHERE owner = SYS_CONTEXT(\'USERENV\', \'CURRENT_SCHEMA\')\n ORDER BY 1\n',
};

/** Left side: the tables (and their columns) of the chosen database; a click writes a SELECT for it. */
function ObjectList({ tables, loading, onPick }: { tables: Record<string, string[]>; loading: boolean; onPick: (t: string) => void }) {
  const [q, setQ] = useState('');
  const [open, setOpen] = useState<string | null>(null);
  const names = Object.keys(tables).filter((t) => t.toLowerCase().includes(q.toLowerCase()));
  return (
    <Stack sx={{ minHeight: 0, height: '100%' }}>
      <TextField size="small" placeholder="Search tables" value={q} onChange={(e) => setQ(e.target.value)} sx={{ m: 1.5, mb: 1 }}
        InputProps={{ startAdornment: <InputAdornment position="start"><SearchRoundedIcon fontSize="small" /></InputAdornment> }} />
      {loading && <Box sx={{ p: 2, display: 'grid', placeItems: 'center' }}><CircularProgress size={20} /></Box>}
      {!loading && !names.length && <Typography variant="body2" color="text.secondary" sx={{ px: 2, py: 1 }}>No tables.</Typography>}
      <List dense sx={{ overflow: 'auto', flex: 1, py: 0 }}>
        {names.map((t) => (
          <Box key={t}>
            <ListItemButton sx={{ py: 0.4, pl: 1 }} onClick={() => setOpen(open === t ? null : t)} onDoubleClick={() => onPick(t)}>
              {open === t ? <ExpandMoreRoundedIcon fontSize="small" sx={{ color: 'text.secondary' }} /> : <ChevronRightRoundedIcon fontSize="small" sx={{ color: 'text.secondary' }} />}
              <TableChartRoundedIcon sx={{ fontSize: 16, mx: 0.75, color: brand.blue }} />
              <Typography className="mono" fontSize={12.5} noWrap sx={{ flex: 1 }} title={t}>{t}</Typography>
              <Tooltip title="Write a SELECT for this table"><IconButton size="small" onClick={(e) => { e.stopPropagation(); onPick(t); }}><PlayArrowRoundedIcon sx={{ fontSize: 16 }} /></IconButton></Tooltip>
            </ListItemButton>
            <Collapse in={open === t} unmountOnExit>
              <Box sx={{ pl: 5.5, pb: 0.5 }}>
                {tables[t].map((c) => <Typography key={c} className="mono" fontSize={11.5} color="text.secondary" noWrap>{c}</Typography>)}
              </Box>
            </Collapse>
          </Box>
        ))}
      </List>
    </Stack>
  );
}

/** One result set as a sortable, searchable grid with its column types. */
function ResultGrid({ r }: { r: ResultSet }) {
  const rows = useMemo(() => r.rows.map((row, i) => Object.fromEntries([['__i', i], ...row.map((v, j) => [`c${j}`, v])])), [r]);
  if (!r.columns.length) {
    return <Box sx={{ p: 3 }}><Typography fontWeight={700}>{r.command} {fmtInt(r.rowCount)}</Typography><Typography variant="body2" color="text.secondary">No rows returned by this statement.</Typography></Box>;
  }
  return (
    <DataTable rows={rows} rowKey={(x) => String(x.__i)} pageSize={50} dense maxHeight={420} searchKeys={r.columns.map((_, j) => `c${j}`)}
      columns={r.columns.map((c, j) => ({
        key: `c${j}`,
        label: <Box><Typography fontSize={12.5} fontWeight={700} sx={{ textTransform: 'none' }}>{c.name}</Typography><Typography fontSize={10.5} color="text.secondary" sx={{ textTransform: 'none' }}>{c.type}</Typography></Box> as any,
        sortValue: (x: any) => { const v = x[`c${j}`]; const n = Number(v); return v !== null && v !== '' && Number.isFinite(n) ? n : String(v ?? ''); },
        render: (x: any) => (x[`c${j}`] === null
          ? <Typography component="span" fontSize={12} sx={{ color: 'text.disabled', fontStyle: 'italic' }}>NULL</Typography>
          : <Typography component="span" className="mono" fontSize={12.5} sx={{ whiteSpace: 'pre', maxWidth: 420, display: 'inline-block', overflow: 'hidden', textOverflow: 'ellipsis', verticalAlign: 'bottom' }} title={x[`c${j}`]}>{x[`c${j}`]}</Typography>),
      }))} />
  );
}

export default function SqlPage() {
  const { name, project } = useProject();
  const admin = useIsAdmin();
  const [target, setTarget] = useState<Target>('postgres');
  const [text, setText] = useState(() => readDraft(name, 'postgres') ?? STARTER.postgres);
  const [objects, setObjects] = useState<{ schema: string; tables: Record<string, string[]> } | null>(null);
  const [objLoading, setObjLoading] = useState(false);
  const [maxRows, setMaxRows] = useState(500);
  const [timeoutSec, setTimeoutSec] = useState(60);
  const [busy, setBusy] = useState(false);
  const [res, setRes] = useState<RunResponse | null>(null);
  const [err, setErr] = useState<RunError | null>(null);
  const [tab, setTab] = useState(0);
  const [confirm, setConfirm] = useState<{ sql: string; statement: string } | null>(null);
  const [history, setHistory] = useState<HistoryItem[] | null>(null);
  const [showHistory, setShowHistory] = useState(false);
  // The table list is closed by default; opening it is remembered in this browser.
  const [showTables, setShowTables] = useState(() => { try { return localStorage.getItem('dma.sql.tables') === '1'; } catch { return false; } });
  const toggleTables = (v: boolean) => { setShowTables(v); try { localStorage.setItem('dma.sql.tables', v ? '1' : '0'); } catch { /* storage blocked */ } };
  const editor = useRef<ReactCodeMirrorRef>(null);
  const connected = target === 'postgres' ? !!project?.postgres : !!project?.oracle;

  // Tables of the chosen database, for the side list and the completion.
  useEffect(() => {
    if (!connected) { setObjects(null); return; }
    setObjLoading(true);
    api<{ schema: string; tables: Record<string, string[]> }>(`${projectPath(name)}/sql/objects?target=${target}`)
      .then(setObjects).catch(() => setObjects(null)).finally(() => setObjLoading(false));
  }, [name, target, connected]);

  const loadHistory = useCallback(() => {
    api<{ items: HistoryItem[] }>(`${projectPath(name)}/sql/history`).then((r) => setHistory(r.items)).catch(() => setHistory([]));
  }, [name]);
  useEffect(() => { if (showHistory) loadHistory(); }, [showHistory, loadHistory]);

  const switchTarget = (t: Target | null) => {
    if (!t || t === target) return;
    writeDraft(name, target, text);
    setTarget(t);
    setText(readDraft(name, t) ?? STARTER[t]);
    setRes(null);
    setErr(null);
  };

  /** Runs the selected text, or everything. allowWrite: an admin confirmed a change. */
  const run = async (sqlText?: string, allowWrite = false) => {
    const view = editor.current?.view;
    const sel = view ? view.state.selection.main : null;
    const q = sqlText ?? (view && sel && !sel.empty ? view.state.sliceDoc(sel.from, sel.to) : text);
    if (!q.trim() || busy) return;
    setBusy(true);
    setErr(null);
    try {
      // Plain fetch: a failed query answers with the statement and the position, not only a message.
      const http = await fetch(apiUrl(`${projectPath(name)}/sql`), { method: 'POST', credentials: 'include', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ target, sql: q, allowWrite, maxRows, timeoutSec }) });
      const data = await http.json().catch(() => ({ message: `Request failed (${http.status})` }));
      if (!http.ok) { setRes(null); setErr(data as RunError); return; }
      const r = data as RunResponse;
      if (r.needsWrite) {
        setRes(null);
        if (r.admin) setConfirm({ sql: q, statement: r.statement || q });
        else setErr({ message: r.message || 'This statement changes data. Your queries run read-only.', statement: r.statement });
      } else {
        setRes(r);
        setTab(Math.max(0, (r.results || []).findIndex((x) => x.columns.length) ?? 0));
      }
    } catch (e: any) {
      setRes(null);
      setErr({ message: e.message || 'Cannot reach the migration server.' });
    } finally {
      setBusy(false);
      if (showHistory) loadHistory();
    }
  };
  const runRef = useRef(run);
  runRef.current = run;

  const extensions = useMemo(() => [
    sqlLang({ dialect: target === 'postgres' ? PostgreSQL : PLSQL, schema: objects?.tables || {}, upperCaseKeywords: true }),
    Prec.highest(keymap.of([{ key: 'Mod-Enter', run: () => { runRef.current(); return true; } }])),
  ], [target, objects]);

  const pick = (t: string) => {
    const q = target === 'postgres' ? `SELECT *\n  FROM ${/^[a-z_][a-z0-9_]*$/.test(t) ? t : `"${t}"`}\n LIMIT 100;\n` : `SELECT *\n  FROM ${t}\n FETCH FIRST 100 ROWS ONLY\n`;
    setText(q);
    writeDraft(name, target, q);
    setTimeout(() => runRef.current(q), 0);
  };

  const results = res?.results || [];
  const current = results[tab];
  const exportRows = (r: ResultSet, kind: 'csv' | 'xlsx') => {
    const header = r.columns.map((c) => c.name);
    const file = safeFileName(`${name}_${target}_${new Date().toISOString().slice(0, 19)}`);
    if (kind === 'csv') downloadCsv(`${file}.csv`, header, r.rows);
    else downloadXlsx(`${file}.xlsx`, results.filter((x) => x.columns.length).map((x, i) => ({ name: `Result ${i + 1}`, header: x.columns.map((c) => c.name), rows: x.rows })));
  };

  const mode = target === 'oracle'
    ? { icon: <LockRoundedIcon sx={{ fontSize: 16 }} />, label: 'Oracle source · SELECT only', color: '#FDE68A' }
    : admin
      ? { icon: <EditNoteRoundedIcon sx={{ fontSize: 16 }} />, label: 'Read-only · changes ask you to confirm', color: '#A7F3D0' }
      : { icon: <LockRoundedIcon sx={{ fontSize: 16 }} />, label: 'Read-only', color: '#A7F3D0' };

  return (
    <>
      <PageHeader overline="Tools" title="SQL Workbench" icon={<TerminalRoundedIcon />}
        subtitle={target === 'postgres'
          ? <>Query the migrated PostgreSQL schema <b className="mono">{objects?.schema || '…'}</b>: read-only unless an administrator confirms a change. Every query is kept in the history.</>
          : <>Query the Oracle source schema <b className="mono">{project?.selectedSchema}</b>: SELECT only, nothing is ever changed in Oracle. Every query is kept in the history.</>} />

      {/* Which database, and the table list (hidden until asked for: the editor completes names anyway) */}
      <Stack direction="row" spacing={1.5} alignItems="center" flexWrap="wrap" useFlexGap sx={{ mb: 2 }}>
        <ToggleButtonGroup exclusive size="small" value={target} onChange={(_, v) => switchTarget(v)} sx={{ bgcolor: '#fff', '& .MuiToggleButton-root': { textTransform: 'none', fontWeight: 700, px: 2 } }}>
          <ToggleButton value="postgres">PostgreSQL</ToggleButton>
          <ToggleButton value="oracle">Oracle</ToggleButton>
        </ToggleButtonGroup>
        <Typography variant="body2" color="text.secondary" noWrap>
          {connected ? (target === 'postgres' ? `${project?.postgres?.dbname} · schema ${objects?.schema || '…'}` : `${project?.oracle?.userUrl} · schema ${project?.selectedSchema}`) : 'Not connected: see Connections'}
        </Typography>
        <Box sx={{ flex: 1 }} />
        <Button size="small" variant={showTables ? 'contained' : 'outlined'} startIcon={<TableChartRoundedIcon />} onClick={() => toggleTables(!showTables)}>
          {showTables ? 'Hide tables' : `Tables${objects ? ` (${Object.keys(objects.tables).length})` : ''}`}
        </Button>
      </Stack>

      <Box sx={{ display: 'grid', gridTemplateColumns: { xs: 'minmax(0,1fr)', lg: showTables ? '270px minmax(0,1fr)' : 'minmax(0,1fr)' }, gap: 2.5, alignItems: 'start' }}>
        {showTables && (
          <Box sx={{ border: `1px solid ${brand.border}`, borderRadius: 3, bgcolor: '#fff', height: { lg: 'calc(100vh - 280px)' }, maxHeight: { xs: 360, lg: 'none' }, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
            <ObjectList tables={objects?.tables || {}} loading={objLoading} onPick={pick} />
          </Box>
        )}

        <Stack spacing={2} sx={{ minWidth: 0 }}>
          {/* Editor */}
          <Box sx={{ borderRadius: 3, overflow: 'hidden', bgcolor: '#0B1730', boxShadow: '0 18px 40px -24px rgba(0,32,91,.6)' }}>
            <Stack direction="row" alignItems="center" spacing={1} flexWrap="wrap" useFlexGap sx={{ px: 1.5, py: 1, borderBottom: '1px solid rgba(255,255,255,.08)' }}>
              <Button variant="contained" size="small" disabled={busy || !connected} onClick={() => run()} startIcon={busy ? <CircularProgress size={14} color="inherit" /> : <PlayArrowRoundedIcon />}
                sx={{ bgcolor: '#12B76A', backgroundImage: 'none', '&:hover': { bgcolor: '#0E9F5E', backgroundImage: 'none' } }}>Run</Button>
              <Typography sx={{ color: 'rgba(255,255,255,.55)', fontSize: 12 }}>Ctrl+Enter · runs the selection if any</Typography>
              <Box sx={{ flex: 1 }} />
              <Chip size="small" icon={mode.icon} label={mode.label} sx={{ bgcolor: 'rgba(255,255,255,.08)', color: mode.color, '& .MuiChip-icon': { color: mode.color } }} />
              <TextField select size="small" value={maxRows} onChange={(e) => setMaxRows(Number(e.target.value))}
                sx={{ width: 120, '& .MuiInputBase-root': { color: '#fff', fontSize: 13, bgcolor: 'rgba(255,255,255,.06)' }, '& fieldset': { borderColor: 'rgba(255,255,255,.15)' }, '& svg': { color: '#fff' } }}>
                {[100, 500, 1000].map((n) => <MenuItem key={n} value={n}>{n} rows</MenuItem>)}
              </TextField>
              <TextField select size="small" value={timeoutSec} onChange={(e) => setTimeoutSec(Number(e.target.value))}
                sx={{ width: 110, '& .MuiInputBase-root': { color: '#fff', fontSize: 13, bgcolor: 'rgba(255,255,255,.06)' }, '& fieldset': { borderColor: 'rgba(255,255,255,.15)' }, '& svg': { color: '#fff' } }}>
                {[30, 60, 300].map((n) => <MenuItem key={n} value={n}>{n < 60 ? `${n} s` : `${n / 60} min`}</MenuItem>)}
              </TextField>
              <Tooltip title="Clear the editor"><IconButton size="small" onClick={() => { setText(''); writeDraft(name, target, ''); }} sx={{ color: 'rgba(255,255,255,.7)' }}><DeleteSweepRoundedIcon fontSize="small" /></IconButton></Tooltip>
              <Tooltip title="Query history"><IconButton size="small" onClick={() => setShowHistory(!showHistory)} sx={{ color: showHistory ? '#7FB2FF' : 'rgba(255,255,255,.7)' }}><HistoryRoundedIcon fontSize="small" /></IconButton></Tooltip>
            </Stack>
            <CodeMirror ref={editor} value={text} height="260px" theme="dark" extensions={extensions}
              onChange={(v) => { setText(v); writeDraft(name, target, v); }}
              basicSetup={{ lineNumbers: true, highlightActiveLine: true, autocompletion: true, bracketMatching: true, foldGutter: false }}
              style={{ fontFamily: monoFont, fontSize: 13.5 }} />
          </Box>

          {/* History */}
          <Collapse in={showHistory} unmountOnExit>
            <Box sx={{ border: `1px solid ${brand.border}`, borderRadius: 3, bgcolor: '#fff', maxHeight: 280, overflow: 'auto' }}>
              <Typography fontWeight={700} sx={{ px: 2, pt: 1.5 }}>Query history</Typography>
              <Typography variant="caption" color="text.secondary" sx={{ px: 2, display: 'block', mb: 1 }}>{admin ? 'Every query on this project, newest first.' : 'Your queries on this project, newest first.'} Click one to load it.</Typography>
              {history === null && <Box sx={{ p: 2 }}><CircularProgress size={18} /></Box>}
              {history?.length === 0 && <Typography variant="body2" color="text.secondary" sx={{ px: 2, pb: 2 }}>No queries yet.</Typography>}
              {history?.map((h, i) => (
                <ListItemButton key={i} onClick={() => { if (h.target !== target) switchTarget(h.target); setText(h.sql); setShowHistory(false); }} sx={{ display: 'block', borderTop: `1px solid ${brand.border}` }}>
                  <Stack direction="row" spacing={1} alignItems="center">
                    <Chip size="small" label={h.target === 'oracle' ? 'Oracle' : 'PostgreSQL'} variant="outlined" sx={{ height: 20, fontSize: 11 }} />
                    {h.write && <Chip size="small" color="warning" label="change" sx={{ height: 20, fontSize: 11 }} />}
                    <Typography variant="caption" color="text.secondary">{fmtDate(h.at)}{h.user ? ` · ${h.user}` : ''} · {h.ms} ms</Typography>
                    <Box sx={{ flex: 1 }} />
                    <Typography variant="caption" color={h.error ? 'error.main' : 'success.main'} noWrap sx={{ maxWidth: 260 }}>{h.error ? h.error.split('\n')[0] : h.result}</Typography>
                  </Stack>
                  <Typography className="mono" fontSize={12} noWrap sx={{ mt: 0.25 }}>{h.sql.replace(/\s+/g, ' ')}</Typography>
                </ListItemButton>
              ))}
            </Box>
          </Collapse>

          {/* Results */}
          {err && (
            <Alert severity="error" sx={{ overflowWrap: 'anywhere' }}>
              <Typography fontWeight={700} fontSize={14}>{err.message.split('\n')[0]}</Typography>
              {err.statement && <Typography className="mono" fontSize={12} sx={{ mt: 0.5, whiteSpace: 'pre-wrap' }}>{err.statement}</Typography>}
              {err.position && err.statement && <Typography variant="caption" sx={{ display: 'block', mt: 0.5 }}>Near character {err.position}: <b className="mono">{err.statement.slice(Math.max(0, Number(err.position) - 1), Number(err.position) + 30)}</b></Typography>}
              {err.hint && <Typography variant="caption" sx={{ display: 'block' }}>Hint: {err.hint}</Typography>}
              {!!err.done && <Typography variant="caption" sx={{ display: 'block' }}>{err.done} statement{err.done === 1 ? '' : 's'} before it ran; nothing was kept (one transaction).</Typography>}
              <ErrorHelp text={err.message} />
            </Alert>
          )}
          {!res && !err && !busy && (
            <Box sx={{ border: `1px dashed ${brand.border}`, borderRadius: 3, p: 4, textAlign: 'center', color: 'text.secondary' }}>
              <TerminalRoundedIcon sx={{ fontSize: 36, opacity: 0.5 }} />
              <Typography>Write a query and press <b>Run</b>. Table and column names are suggested as you type; <b>Tables</b> (top right) lists them.</Typography>
              <Typography variant="caption">Queries never change data unless an administrator confirms it. Oracle is read-only.</Typography>
            </Box>
          )}
          {res && (
            <Box sx={{ border: `1px solid ${brand.border}`, borderRadius: 3, bgcolor: '#fff', overflow: 'hidden' }}>
              <Stack direction="row" alignItems="center" spacing={1} sx={{ borderBottom: 1, borderColor: 'divider', pr: 1.5 }}>
                <Tabs value={Math.min(tab, results.length - 1)} onChange={(_, v) => setTab(v)} variant="scrollable" sx={{ flex: 1, minHeight: 44, '& .MuiTab-root': { minHeight: 44, textTransform: 'none', fontWeight: 650 } }}>
                  {results.map((r, i) => <Tab key={i} value={i} label={`${results.length > 1 ? `${i + 1}. ` : ''}${r.command} · ${fmtInt(r.rowCount)}${r.more ? '+' : ''} row${r.rowCount === 1 ? '' : 's'}`} />)}
                </Tabs>
                {current?.columns.length ? (
                  <>
                    <Button size="small" startIcon={<DownloadRoundedIcon />} onClick={() => exportRows(current, 'csv')}>CSV</Button>
                    <Button size="small" startIcon={<DownloadRoundedIcon />} onClick={() => exportRows(current, 'xlsx')}>Excel</Button>
                  </>
                ) : null}
              </Stack>
              {current && <ResultGrid r={current} />}
              <Stack direction="row" spacing={2} alignItems="center" sx={{ px: 2, py: 1, bgcolor: '#F7F9FC', borderTop: `1px solid ${brand.border}` }}>
                <Typography variant="caption" color="text.secondary">{current ? `${fmtInt(current.rowCount)} row${current.rowCount === 1 ? '' : 's'}${current.more ? ` shown, more available (raise the limit or add WHERE / LIMIT)` : ''} · ${current.ms} ms` : ''} · total {res.ms} ms · schema {res.schema}</Typography>
                {current?.more && <WarningAmberRoundedIcon fontSize="small" color="warning" />}
              </Stack>
            </Box>
          )}
        </Stack>
      </Box>

      {/* An admin confirms a statement that changes data */}
      <Dialog open={!!confirm} onClose={() => setConfirm(null)} maxWidth="sm" fullWidth>
        <DialogTitle>Change data in PostgreSQL?</DialogTitle>
        <DialogContent>
          <DialogContentText sx={{ mb: 1.5 }}>
            This statement changes the target schema <b>{res?.schema || objects?.schema}</b>. The whole script runs in one transaction and is committed only if every statement succeeds. It is recorded in the SQL history with your name.
          </DialogContentText>
          <Box component="pre" className="mono" sx={{ m: 0, p: 1.5, bgcolor: '#0B1730', color: '#D6E4FF', borderRadius: 2, fontSize: 12.5, maxHeight: 220, overflow: 'auto', whiteSpace: 'pre-wrap' }}>{confirm?.statement}</Box>
        </DialogContent>
        <DialogActions sx={{ px: 3, pb: 2.5 }}>
          <Button onClick={() => setConfirm(null)}>Cancel</Button>
          <Button variant="contained" color="warning" onClick={() => { const c = confirm; setConfirm(null); if (c) run(c.sql, true); }}>Run and commit</Button>
        </DialogActions>
      </Dialog>
    </>
  );
}
