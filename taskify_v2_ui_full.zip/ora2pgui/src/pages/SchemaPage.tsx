import { Alert, Autocomplete, Box, Button, CircularProgress, IconButton, LinearProgress, Stack, TextField, Tooltip, Typography } from '@mui/material';
import RefreshRoundedIcon from '@mui/icons-material/RefreshRounded';
import CameraAltRoundedIcon from '@mui/icons-material/CameraAltRounded';
import ArrowForwardRoundedIcon from '@mui/icons-material/ArrowForwardRounded';
import AccountTreeRoundedIcon from '@mui/icons-material/AccountTreeRounded';
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api, projectPath } from '../api';
import { useProject } from '../context/ProjectContext';
import { CheckIcon, PageHeader, SectionCard } from '../components/ui';
import { fmtDate } from '../format';

export default function SchemaPage() {
  const { name, project, reload, snapshot, snapshotProgress } = useProject();
  const navigate = useNavigate();
  const [schemas, setSchemas] = useState<string[]>(project?.schemas || []);
  const [value, setValue] = useState<string | null>(project?.selectedSchema || null);
  const [loadingList, setLoadingList] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [starting, setStarting] = useState(false);

  useEffect(() => { if (project?.schemas) setSchemas(project.schemas); }, [project?.schemas]);
  useEffect(() => { if (project?.selectedSchema) setValue(project.selectedSchema); }, [project?.selectedSchema]);

  const refreshList = async () => {
    setLoadingList(true);
    setError(null);
    try {
      setSchemas((await api<{ schemas: string[] }>(`${projectPath(name)}/oracle/schemas`)).schemas);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoadingList(false);
    }
  };

  const running = snapshotProgress?.status === 'RUNNING';
  const changed = value && value !== project?.selectedSchema;

  const takeSnapshot = async () => {
    if (!value) return;
    setStarting(true);
    setError(null);
    try {
      if (changed) await api(`${projectPath(name)}/schema`, { body: { name: value } });
      await reload();
      await api(`${projectPath(name)}/snapshot`, { body: {} });
    } catch (e: any) {
      setError(e.message);
    } finally {
      setStarting(false);
    }
  };

  const steps = snapshotProgress?.steps || [];
  const doneSteps = steps.filter((s) => s.status === 'done' || s.status === 'failed').length;
  const pct = steps.length ? (doneSteps / steps.length) * 100 : 0;
  const hasSnapshot = !!snapshot && !changed;

  return (
    <>
      <PageHeader overline="Step 2" title="Schema & snapshot" icon={<AccountTreeRoundedIcon />}
        subtitle="Choose the Oracle schema to migrate. The snapshot reads its metadata (tables, sizes, keys, indexes, LOBs, code objects) once and saves it, so the next steps open instantly."
        actions={hasSnapshot && !running ? <Button variant="contained" endIcon={<ArrowForwardRoundedIcon />} onClick={() => navigate('../assessment')}>View assessment</Button> : undefined} />
      {!project?.oracle && <Alert severity="warning" sx={{ mb: 3 }}>Connect the Oracle source first.</Alert>}
      <Box sx={{ display: 'grid', gap: 3, gridTemplateColumns: { xs: '1fr', xl: '420px minmax(0,1fr)' }, alignItems: 'start' }}>
        <SectionCard title="Schema" subtitle={`${schemas.length} schemas visible to ${project?.oracle?.userUsername || 'the user'}`}
          action={<Tooltip title="Reload schema list"><span><IconButton onClick={refreshList} disabled={loadingList || !project?.oracle}>{loadingList ? <CircularProgress size={18} /> : <RefreshRoundedIcon />}</IconButton></span></Tooltip>}>
          <Stack spacing={2}>
            <Autocomplete options={schemas} value={value} onChange={(_, v) => setValue(v)} disabled={running}
              renderInput={(p) => <TextField {...p} label="Oracle schema" placeholder="Type to search" />} />
            {error && <Alert severity="error">{error}</Alert>}
            <Button variant="contained" size="large" startIcon={<CameraAltRoundedIcon />} onClick={takeSnapshot} disabled={!value || running || starting || !project?.oracle}>
              {running ? 'Snapshot running…' : hasSnapshot ? 'Refresh snapshot' : 'Take snapshot'}
            </Button>
            {hasSnapshot && (
              <Typography variant="body2" color="text.secondary">
                Last snapshot of <b>{project?.selectedSchema}</b>: {fmtDate(snapshot.snapshotAt)}. Refresh it after schema changes in Oracle.
              </Typography>
            )}
          </Stack>
        </SectionCard>

        <SectionCard title={running ? `Reading metadata of ${snapshotProgress?.schema}` : 'Snapshot progress'}
          subtitle={running ? 'Queries run 4 at a time so a production database is not flooded.' : snapshotProgress ? `Finished ${fmtDate(snapshotProgress.finishedAt)}` : 'Start a snapshot to see each metadata query here.'}>
          {steps.length > 0 ? (
            <>
              <LinearProgress variant="determinate" value={pct} sx={{ mb: 2 }} />
              <Box sx={{ display: 'grid', gap: 1, gridTemplateColumns: { xs: '1fr', md: '1fr 1fr' } }}>
                {steps.map((s) => (
                  <Stack key={s.key} direction="row" spacing={1.25} alignItems="center" sx={{ p: 1.25, borderRadius: 2, bgcolor: s.status === 'running' ? '#EEF4FD' : 'transparent', border: '1px solid', borderColor: s.status === 'failed' ? 'error.light' : 'divider', minWidth: 0 }}>
                    {s.status === 'running' ? <CircularProgress size={18} /> : <CheckIcon ok={s.status === 'done'} pending={s.status === 'pending'} />}
                    <Typography variant="body2" sx={{ flex: 1, minWidth: 0 }} noWrap title={s.error || s.label}>{s.label}</Typography>
                    <Typography variant="caption" color="text.secondary">{s.ms !== null ? `${(s.ms / 1000).toFixed(1)}s` : ''}</Typography>
                  </Stack>
                ))}
              </Box>
              {snapshotProgress?.status === 'COMPLETED_WITH_ERRORS' && <Alert severity="warning" sx={{ mt: 2 }}>Some metadata queries failed (hover them for the error). The rest of the snapshot is usable.</Alert>}
              {snapshotProgress?.status === 'FAILED' && <Alert severity="error" sx={{ mt: 2 }}>{snapshotProgress.error || 'The snapshot failed: the table list could not be read.'}</Alert>}
            </>
          ) : (
            <Typography color="text.secondary" variant="body2">{hasSnapshot ? 'The saved snapshot is up to date.' : 'No snapshot yet.'}</Typography>
          )}
        </SectionCard>
      </Box>
    </>
  );
}
