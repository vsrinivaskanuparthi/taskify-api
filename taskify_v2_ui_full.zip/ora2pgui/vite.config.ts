import react from '@vitejs/plugin-react-swc';
import { defineConfig } from 'vite';
import { viteSingleFile } from 'vite-plugin-singlefile';

// https://vitejs.dev/config/
export default defineConfig({
  // Like v1: `npm run build` produces ONE file, dist/index.html (scripts, styles and fonts inlined),
  // so it replaces v1's index.html in the existing nginx folder with no other change.
  plugins: [react(), viteSingleFile()],
  server: {
    port: 5175,
    // npm run dev: calls to /api go to the backend on port 5000 (like v1). API_TARGET=http://host:port changes it.
    proxy: { '/api': { target: process.env.API_TARGET || 'http://localhost:5000', changeOrigin: true } },
  },
});
