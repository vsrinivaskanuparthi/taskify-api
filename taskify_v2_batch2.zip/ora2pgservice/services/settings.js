'use strict';

const { CONSTANTS } = require('../utils/constants');
const notify = require('./notify');

/**
 * Per-project settings (Settings page). Stored in project_meta.json under `settings`.
 *
 *  ora2pg  directives written into the project's ora2pg.conf on every run (on top of the
 *          template in scripts/ora2pg.conf and the engine's own required settings)
 *  lob     how LOB columns are stored in PostgreSQL
 *  engine  defaults for the migration run screen
 *  notify  email / Google Chat notifications (services/notify.js)
 */
const ORA2PG_OPTIONS = [
  { key: 'PRESERVE_CASE', type: 'bool', default: false, group: 'Naming', label: 'Preserve case of object names', help: 'Off: names become lower case (recommended, no quoting needed). On: names keep Oracle upper case and must be quoted in every query.' },
  { key: 'USE_RESERVED_WORDS', type: 'bool', default: true, group: 'Naming', label: 'Keep reserved-word names, quoted', help: 'Columns named OFFSET, TYPE, VALUE, USER… keep their name and are quoted. Renaming them breaks applications that still use the original names.' },
  { key: 'PG_NUMERIC_TYPE', type: 'bool', default: true, group: 'Data types', label: 'Map NUMBER(p,s) to native types', help: 'On: NUMBER(p,0) → smallint/integer/bigint, others → numeric/real/double. Off: always numeric.' },
  { key: 'PG_INTEGER_TYPE', type: 'bool', default: true, group: 'Data types', label: 'Map NUMBER without precision to integers', help: 'On: NUMBER with no precision uses DEFAULT_NUMERIC below.' },
  { key: 'DEFAULT_NUMERIC', type: 'select', options: ['bigint', 'numeric', 'integer', 'double precision'], default: 'bigint', group: 'Data types', label: 'Type for NUMBER without precision' },
  { key: 'ENABLE_MICROSECOND', type: 'bool', default: true, group: 'Data types', label: 'Keep microseconds in timestamps' },
  { key: 'DATA_TYPE', type: 'text', default: '', group: 'Data types', label: 'Data type overrides', placeholder: 'NUMBER(*\\,0):bigint,DATE:timestamp(0)', help: 'Oracle type:PostgreSQL type pairs, comma separated (escape commas in types with \\,).' },
  { key: 'MODIFY_TYPE', type: 'text', default: '', group: 'Data types', label: 'Column type overrides', placeholder: 'ORDERS:STATUS:varchar(20),ORDERS:FLAGS:smallint', help: 'TABLE:COLUMN:type, comma separated.' },
  { key: 'REPLACE_AS_BOOLEAN', type: 'text', default: '', group: 'Data types', label: 'Columns to convert to boolean', placeholder: 'ORDERS:IS_PAID USERS:ACTIVE', help: 'TABLE:COLUMN, space separated. Values follow BOOLEAN_VALUES.' },
  { key: 'NULL_EQUAL_EMPTY', type: 'bool', default: false, group: 'Data', label: 'Treat empty strings as NULL', help: 'Oracle stores \'\' as NULL. On: code conversion keeps that behaviour.' },
  { key: 'TRUNCATE_TABLE', type: 'fixed', default: false, group: 'Data', label: 'Truncate before load', help: 'Always done by the engine (every table is emptied before it is loaded or reloaded).' },
  { key: 'DISABLE_COMMENT', type: 'bool', default: false, group: 'Objects', label: 'Skip table and column comments' },
  { key: 'EXPORT_INVALID', type: 'bool', default: false, group: 'Objects', label: 'Export invalid code objects', help: 'Also export views / PL/SQL marked INVALID in Oracle (for the GenAI package).' },
  { key: 'SKIP', type: 'text', default: '', group: 'Objects', label: 'Skip constraint types', placeholder: 'checks', help: 'Any of: fkeys pkeys ukeys indexes checks (space separated).' },
  { key: 'PG_VERSION', type: 'select', options: ['12', '13', '14', '15', '16', '17'], default: '16', group: 'Target', label: 'Target PostgreSQL version' },
  { key: 'CLIENT_ENCODING', type: 'text', default: 'UTF8', group: 'Target', label: 'Client encoding' },
  { key: 'NLS_LANG', type: 'text', default: 'AMERICAN_AMERICA.AL32UTF8', group: 'Source', label: 'Oracle NLS_LANG' },
];

const ENGINE_DEFAULTS = () => ({
  auto: true, // DMA chooses tables at a time and parts at a time (services/autoSettings.js)
  loadMode: CONSTANTS.LOAD_MODE,
  parallelTables: CONSTANTS.PARALLEL_TABLES,
  hugeTableRows: CONSTANTS.HUGE_TABLE_ROWS,
  oracleCopies: CONSTANTS.ORACLE_COPIES,
  pgJobs: CONSTANTS.PG_JOBS,
  chunkRows: CONSTANTS.CHUNK_ROWS,
  maxAttempts: CONSTANTS.MAX_ATTEMPTS,
  dataLimit: CONSTANTS.DATA_LIMIT,
  blobLimit: CONSTANTS.BLOB_LIMIT,
  ddlParallel: CONSTANTS.DDL_PARALLEL,
  maintenanceWorkMem: CONSTANTS.MAINTENANCE_WORK_MEM,
  verifyRowCounts: CONSTANTS.VERIFY_ROW_COUNTS,
  chunkMb: CONSTANTS.CHUNK_MB,
  stallMinutes: CONSTANTS.STALL_MINUTES,
  verifyData: CONSTANTS.VERIFY_DATA,
  snapshot: CONSTANTS.SNAPSHOT,
  bulkLoad: CONSTANTS.BULK_LOAD,
});

// The choices to agree with the application team before the first migration (Settings → Migration decisions).
const DECISION_KEYS = ['PRESERVE_CASE', 'USE_RESERVED_WORDS', 'PG_NUMERIC_TYPE', 'PG_INTEGER_TYPE', 'DEFAULT_NUMERIC', 'REPLACE_AS_BOOLEAN'];
const ROLE_LIST = /^\s*([A-Za-z_][A-Za-z0-9_$]{0,62}\s*(,\s*[A-Za-z_][A-Za-z0-9_$]{0,62}\s*)*)?$/;

function defaults() {
  return {
    targetSchema: '',
    access: { readRoles: '', writeRoles: '', dualView: false },
    decisions: { agreedBy: '', agreedAt: null },
    ora2pg: Object.fromEntries(ORA2PG_OPTIONS.filter((o) => o.type !== 'fixed').map((o) => [o.key, o.default])),
    extraDirectives: '',
    lob: { blobAs: 'bytea' },
    engine: ENGINE_DEFAULTS(),
    notify: notify.defaults(),
  };
}

/** Saved settings merged over the defaults (new options get their default automatically). */
function resolve(meta) {
  const d = defaults();
  const s = (meta && meta.settings) || {};
  return {
    targetSchema: s.targetSchema || '',
    access: { ...d.access, ...(s.access || {}) },
    decisions: { ...d.decisions, ...(s.decisions || {}) },
    ora2pg: { ...d.ora2pg, ...(s.ora2pg || {}) },
    extraDirectives: s.extraDirectives || '',
    lob: { ...d.lob, ...(s.lob || {}) },
    engine: { ...d.engine, ...(s.engine || {}) },
    notify: { ...d.notify, ...(s.notify || {}) }, // webhook stays encrypted here (see notify.resolve)
  };
}

const DIRECTIVE_LINE = /^[A-Z][A-Z0-9_]*\s+\S.*$/;
// Directives the engine manages itself (connections, output, parallelism): not overridable.
const RESERVED = new Set(['ORACLE_DSN', 'ORACLE_USER', 'ORACLE_PWD', 'PG_DSN', 'PG_USER', 'PG_PWD', 'SCHEMA', 'PG_SCHEMA', 'OUTPUT', 'OUTPUT_DIR', 'TYPE', 'ALLOW', 'EXCLUDE', 'JOBS', 'ORACLE_COPIES', 'PARALLEL_TABLES', 'FILE_PER_INDEX', 'FILE_PER_CONSTRAINT', 'FILE_PER_FKEYS', 'STOP_ON_ERROR', 'LOG_ON_ERROR', 'TRUNCATE_TABLE', 'FDW_SERVER', 'EXPORT_SCHEMA', 'CREATE_SCHEMA', 'WHERE']);

/** Validates a settings payload from the UI. Returns { settings } or { error }. */
function validate(input, current) {
  const d = defaults();
  const out = { ...d };
  if (input.targetSchema) {
    if (!/^[a-z_][a-z0-9_]{0,62}$/.test(input.targetSchema)) return { error: 'Target schema: lower-case letters, digits and _ only.' };
    out.targetSchema = input.targetSchema;
  }
  for (const o of ORA2PG_OPTIONS) {
    if (o.type === 'fixed' || !input.ora2pg || input.ora2pg[o.key] === undefined) continue;
    const v = input.ora2pg[o.key];
    if (o.type === 'bool') out.ora2pg[o.key] = !!v;
    else if (o.type === 'select') {
      if (!o.options.includes(String(v))) return { error: `${o.label}: invalid value.` };
      out.ora2pg[o.key] = String(v);
    } else {
      if (/[\r\n]/.test(String(v))) return { error: `${o.label}: one line only.` };
      out.ora2pg[o.key] = String(v).trim();
    }
  }
  const extra = String(input.extraDirectives || '').split('\n').map((l) => l.trim()).filter((l) => l && !l.startsWith('#'));
  for (const line of extra) {
    if (!DIRECTIVE_LINE.test(line)) return { error: `Extra directive "${line}" must look like: KEY value` };
    const key = line.split(/\s+/)[0];
    if (RESERVED.has(key)) return { error: `${key} is managed by the migration engine and cannot be overridden.` };
  }
  out.extraDirectives = extra.join('\n');
  out.lob = { blobAs: input.lob && input.lob.blobAs === 'oid' ? 'oid' : 'bytea' };
  const a = input.access || {};
  for (const k of ['readRoles', 'writeRoles']) {
    if (a[k] && !ROLE_LIST.test(a[k])) return { error: 'Application roles: database role names separated by commas.' };
  }
  out.access = { readRoles: roles(a.readRoles).join(', '), writeRoles: roles(a.writeRoles).join(', '), dualView: !!a.dualView };
  const dcs = input.decisions || {};
  out.decisions = { agreedBy: String(dcs.agreedBy || '').trim().slice(0, 120), agreedAt: dcs.agreedBy ? (dcs.agreedAt || new Date().toISOString()) : null };
  out.engine = { ...d.engine, ...(input.engine || {}) };
  const n = notify.validate(input.notify || {}, notify.resolve({ settings: current }));
  if (n.error) return { error: n.error };
  out.notify = n.notify;
  return { settings: out };
}

function roles(list) {
  return String(list || '').split(',').map((r) => r.trim()).filter(Boolean);
}

const qi = (n) => `"${String(n).replace(/"/g, '""')}"`;

/**
 * Grants for the application's database roles, run after the load and after code is applied:
 * read roles get USAGE + SELECT + EXECUTE, write roles also DML and sequence USAGE. Default
 * privileges cover objects created later (e.g. code applied afterwards). Optional DUAL view.
 */
function accessSql(settings, pgSchema) {
  const sch = qi(pgSchema);
  const read = roles(settings.access.readRoles);
  const write = roles(settings.access.writeRoles);
  const out = [];
  if (settings.access.dualView) {
    out.push(`CREATE OR REPLACE VIEW ${sch}.dual AS SELECT 'X'::varchar(1) AS dummy`);
  }
  for (const r of [...read, ...write]) {
    const role = r; // validated name, unquoted: folds to lower case like the CREATE ROLE that made it
    out.push(`GRANT USAGE ON SCHEMA ${sch} TO ${role}`);
    out.push(`GRANT SELECT ON ALL TABLES IN SCHEMA ${sch} TO ${role}`);
    out.push(`GRANT SELECT ON ALL SEQUENCES IN SCHEMA ${sch} TO ${role}`);
    out.push(`GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA ${sch} TO ${role}`);
    out.push(`ALTER DEFAULT PRIVILEGES IN SCHEMA ${sch} GRANT SELECT ON TABLES TO ${role}`);
    out.push(`ALTER DEFAULT PRIVILEGES IN SCHEMA ${sch} GRANT EXECUTE ON FUNCTIONS TO ${role}`);
  }
  for (const r of write) {
    const role = r;
    out.push(`GRANT INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA ${sch} TO ${role}`);
    out.push(`GRANT USAGE, UPDATE ON ALL SEQUENCES IN SCHEMA ${sch} TO ${role}`);
    out.push(`ALTER DEFAULT PRIVILEGES IN SCHEMA ${sch} GRANT INSERT, UPDATE, DELETE ON TABLES TO ${role}`);
    out.push(`ALTER DEFAULT PRIVILEGES IN SCHEMA ${sch} GRANT USAGE, UPDATE ON SEQUENCES TO ${role}`);
  }
  return out;
}

/** The directive → value pairs written into ora2pg.conf for this project. */
function ora2pgDirectives(settings) {
  const pairs = {};
  for (const o of ORA2PG_OPTIONS) {
    if (o.type === 'fixed') continue;
    const v = settings.ora2pg[o.key];
    if (o.type === 'bool') pairs[o.key] = v ? 1 : 0;
    else if (v !== '' && v !== undefined && v !== null) pairs[o.key] = v;
  }
  if (settings.lob.blobAs === 'oid') {
    // BLOB is still copied as bytea (fast, streams through COPY) and converted to large objects
    // (oid) by the engine after the load, so no lo_import shell scripts are needed.
  }
  for (const line of (settings.extraDirectives || '').split('\n').filter(Boolean)) {
    const [k, ...rest] = line.split(/\s+/);
    pairs[k] = rest.join(' ');
  }
  return pairs;
}

module.exports = { ORA2PG_OPTIONS, DECISION_KEYS, defaults, resolve, validate, ora2pgDirectives, accessSql, appRoles: (s) => [...roles(s.access.readRoles), ...roles(s.access.writeRoles)] };
