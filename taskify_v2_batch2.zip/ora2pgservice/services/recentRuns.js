'use strict';

const fs = require('fs');
const fsp = require('fs').promises;
const path = require('path');
const store = require('./projectStore');

/**
 * The header's bell: runs that are running, or ended in the last days, across all projects.
 * Each run's state.json is read again only when it changed (cached by modification time).
 */
const cache = new Map(); // file -> { mtimeMs, item }
const ENDED = new Set(['COMPLETED', 'COMPLETED_WITH_ERRORS', 'FAILED', 'CANCELLED', 'INTERRUPTED', 'EXPORTED']);

function summarize(projectName, s) {
  const tables = Object.values(s.tables || {});
  return {
    projectName,
    runId: s.runId,
    status: s.status,
    startedAt: s.startedAt || s.createdAt,
    finishedAt: s.finishedAt || null,
    startedBy: s.startedBy ? s.startedBy.id : null,
    tables: tables.length,
    done: tables.filter((t) => t.status === 'done' || t.status === 'exported').length,
    failed: tables.filter((t) => t.status === 'failed').length,
  };
}

async function recentRuns({ days = 14, perProject = 5, limit = 30 } = {}) {
  const since = Date.now() - days * 86400000;
  const items = [];
  for (const p of await store.listProjects()) {
    const dir = store.runsDir(p.projectName);
    if (!fs.existsSync(dir)) continue;
    const ids = (await fsp.readdir(dir)).sort().reverse().slice(0, perProject);
    for (const id of ids) {
      const file = path.join(dir, id, 'state.json');
      let st;
      try { st = await fsp.stat(file); } catch { continue; }
      let hit = cache.get(file);
      if (!hit || hit.mtimeMs !== st.mtimeMs) {
        const s = await store.readJson(file);
        hit = { mtimeMs: st.mtimeMs, item: s ? summarize(p.projectName, s) : null };
        cache.set(file, hit);
      }
      const it = hit.item;
      if (!it) continue;
      const when = new Date(it.finishedAt || it.startedAt || 0).getTime();
      if (!ENDED.has(it.status) || when >= since) items.push(it);
    }
  }
  return items
    .sort((a, b) => String(b.finishedAt || b.startedAt).localeCompare(String(a.finishedAt || a.startedAt)))
    .slice(0, limit);
}

module.exports = { recentRuns, summarize };
