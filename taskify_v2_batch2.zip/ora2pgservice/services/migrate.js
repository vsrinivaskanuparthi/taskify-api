'use strict';

/**
 * Migration engine (v2).
 *
 * What changed from v1, and why (target: 1 TB schemas without manual rescue):
 *  - Data is streamed by ora2pg straight into PostgreSQL (LOAD_MODE=direct). v1 wrote every table
 *    to a .sql file and then loaded it with psql, which needed the full schema size in free disk
 *    and read everything twice. LOAD_MODE=file keeps the v1 style for servers without DBD::Pg,
 *    but deletes each file as soon as it is loaded.
 *  - Tables are loaded in parallel (PARALLEL_TABLES), biggest first; huge tables also use several
 *    Oracle readers (-J) and PostgreSQL writers (-j).
 *  - Every table is a unit of work with its own status, attempts, rows, speed and log. A failed
 *    table is retried automatically (MAX_ATTEMPTS); the target table is truncated first, so a
 *    retry never duplicates rows. Other tables keep going.
 *  - Each loaded table is verified (row count in Oracle vs PostgreSQL) before it is marked done.
 *  - Indexes, constraints and foreign keys are created after the data (much faster), in parallel.
 *  - Sequence values are taken from Oracle after the load (v1 never reset sequences).
 *  - The whole run state is saved to runs/<runId>/state.json. If the server stops, the run is
 *    marked INTERRUPTED and "Resume" continues with only the work that is not done.
 *  - Progress is pushed to the browser with Server-Sent Events (services/events.js).
 *  - A failed run is reported as failed (v1 reported COMPLETED even when steps failed).
 */

const fs = require('fs');
const fsp = require('fs').promises;
const path = require('path');
const pLimit = require('p-limit');
const oracledb = require('oracledb');

const logger = require('../utils/logger');
const { CONSTANTS } = require('../utils/constants');
const { runWithProject } = require('../utils/context');
const oracleClient = require('../utils/oracleClient');
const pgClient = require('../utils/postgreClient');
const { createRunLogger, executeAndLog, killProcessTree } = require('../errorHandling/error');
const { buildConfig } = require('./config_modify');
const { ora2pgMajor } = require('../utils/ora2pgVersion');
const { RunNotifier } = require('./notify');
const settingsSvc = require('./settings');
const code = require('./code');
const { runSqlFile } = require('./sqlRunner');
const store = require('./projectStore');
const events = require('./events');

const PHASES = [
  { key: 'prepare', label: 'Prepare workspace & configuration' },
  { key: 'ddl', label: 'Export schema definitions from Oracle' },
  { key: 'tables', label: 'Create schema, types, sequences & tables' },
  { key: 'data', label: 'Load table data' },
  { key: 'indexes', label: 'Create indexes & constraints' },
  { key: 'fkeys', label: 'Create foreign keys' },
  { key: 'sequences', label: 'Set sequence values' },
  { key: 'code', label: 'Apply converted code objects (GenAI package)' },
  { key: 'finalize', label: 'Analyze tables & finalize' },
];

// Phases whose work is fully recorded on disk and is not repeated on resume.
const KEEP_ON_RESUME = new Set(['ddl']);


const TERMINAL = new Set(['COMPLETED', 'COMPLETED_WITH_ERRORS', 'FAILED', 'CANCELLED', 'INTERRUPTED', 'EXPORTED']);
// Phases that only make sense once the data is in PostgreSQL: skipped by an export-only run, run on import.
const AFTER_LOAD = new Set(['indexes', 'fkeys', 'sequences', 'code', 'finalize']);

const active = new Map(); // projectName -> Run

/**
 * Running child processes of a run. Their ids are also saved in state.json, so that after a
 * server crash the leftover ora2pg / psql processes can be stopped before the run is resumed
 * (otherwise they would keep writing into tables that the resume truncates and reloads).
 */
class ChildRegistry {
  constructor(run) {
    this.run = run;
    this.set = new Set();
  }

  add(child) {
    this.set.add(child);
    if (child.pid) {
      this.run.state.pids = [...new Set([...(this.run.state.pids || []), child.pid])];
      this.run.save(true);
    }
  }

  delete(child) {
    this.set.delete(child);
    if (child.pid) this.run.state.pids = (this.run.state.pids || []).filter((p) => p !== child.pid);
  }

  [Symbol.iterator]() {
    return this.set[Symbol.iterator]();
  }
}

class CancelledError extends Error {}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const qi = (s) => `"${String(s).replace(/"/g, '""')}"`;
const nowIso = () => new Date().toISOString();
const runDirOf = (projectName, runId) => path.join(store.runsDir(projectName), runId);

class Run {
  constructor(projectName, state) {
    this.projectName = projectName;
    this.state = state;
    this.dir = runDirOf(projectName, state.runId);
    this.children = new ChildRegistry(this);
    this.cancelRequested = false;
    this.lastTableEmit = new Map();
    this.saveTimer = null;
    this.tickTimer = null;
  }

  // ---------- state, persistence, events ----------

  summary() {
    const { tables, ...rest } = this.state;
    return { ...rest, totals: this.totals() };
  }

  totals() {
    const list = Object.values(this.state.tables);
    const t = { tables: list.length, done: 0, failed: 0, running: 0, pending: 0, estRows: 0, rowsDone: 0, sizeMb: 0, rate: 0 };
    for (const x of list) {
      t[x.status] = (t[x.status] || 0) + 1;
      t.estRows += x.estRows || 0;
      t.rowsDone += x.status === 'done' ? Math.max(x.rowsDone || 0, x.pgRows || 0) : (x.rowsDone || 0);
      t.sizeMb += x.sizeMb || 0;
      if (x.status === 'running') t.rate += x.rate || 0;
    }
    return t;
  }

  save(immediate = false) {
    const write = () => {
      this.saveTimer = null;
      try {
        store.writeJsonAtomicSync(path.join(this.dir, 'state.json'), this.state);
      } catch (err) {
        logger.error(`Could not save run state ${this.state.runId}: ${err.message}`);
      }
    };
    if (immediate) {
      if (this.saveTimer) clearTimeout(this.saveTimer);
      write();
    } else if (!this.saveTimer) {
      this.saveTimer = setTimeout(write, 2000);
    }
  }

  emitRun() {
    events.publish(this.projectName, 'run', this.summary());
  }

  emitTable(name, force = false) {
    const last = this.lastTableEmit.get(name) || 0;
    if (!force && Date.now() - last < 1000) return; // at most one update per table per second
    this.lastTableEmit.set(name, Date.now());
    events.publish(this.projectName, 'table', { runId: this.state.runId, table: publicTable(this.state.tables[name]) });
  }

  /** ref ties an entry to a phase or table so the UI can pair "started" with "finished". */
  event(level, message, ref) {
    const entry = ref ? { at: nowIso(), level, message, ref } : { at: nowIso(), level, message };
    this.state.events.push(entry);
    if (this.state.events.length > 300) this.state.events.splice(0, this.state.events.length - 300);
    if (level === 'error') this.log.error(message);
    else this.log.info(message);
    events.publish(this.projectName, 'log', { runId: this.state.runId, ...entry });
  }

  setStatus(status, error) {
    this.state.status = status;
    if (error !== undefined) this.state.error = error;
    if (TERMINAL.has(status)) this.state.finishedAt = nowIso();
    this.save(true);
    this.emitRun();
  }

  phase(key) {
    return this.state.phases.find((p) => p.key === key);
  }

  updatePhase(key, patch) {
    Object.assign(this.phase(key), patch);
    this.save();
    this.emitRun();
  }

  updateTable(name, patch, force = false) {
    Object.assign(this.state.tables[name], patch);
    this.save();
    this.emitTable(name, force || patch.status !== undefined);
  }

  checkCancelled() {
    if (this.cancelRequested) throw new CancelledError('Run cancelled by user');
  }

  cancel() {
    this.cancelRequested = true;
    for (const child of this.children) killProcessTree(child);
  }

  // ---------- main loop ----------

  async execute() {
    this.log = createRunLogger(this.dir);
    this.state.startedAt = this.state.startedAt || nowIso();
    this.state.resumedAt = this.state.attempt > 1 ? nowIso() : undefined;
    this.setStatus('RUNNING', null);
    this.event('info', this.state.attempt > 1 ? `Resuming run (attempt ${this.state.attempt})` : `Migration started for schema ${this.state.schema} (${Object.keys(this.state.tables).length} tables)`);
    // Live totals (rows, speed) to the browser every 2 seconds while running.
    this.tickTimer = setInterval(() => this.emitRun(), 2000);
    this.notifier = new RunNotifier(this.projectName, this.state.runId, this.state.notifyEmails || []);
    this.notifier.started(this.state);

    try {
      for (const p of PHASES) {
        this.checkCancelled();
        const ph = this.phase(p.key);
        if (ph.status === 'done' || ph.status === 'skipped') continue;
        if (this.state.options.loadMode === 'export' && AFTER_LOAD.has(p.key)) {
          this.updatePhase(p.key, { status: 'skipped', detail: 'Export only: runs when the files are imported' });
          continue;
        }
        this.updatePhase(p.key, { status: 'running', startedAt: nowIso(), finishedAt: null, detail: null, progress: 0 });
        this.event('info', `Phase started: ${p.label}`, { type: 'phase', key: p.key, state: 'start' });
        try {
          await this[`phase_${p.key}`]();
          const after = this.phase(p.key);
          const status = after.skipped ? 'skipped' : after.warnings ? 'warning' : 'done';
          this.updatePhase(p.key, { status, finishedAt: nowIso(), progress: 100 });
          this.event('info', `Phase ${status === 'skipped' ? 'skipped' : 'finished'}: ${p.label}${after.warnings ? ` (${after.warnings} warnings)` : ''}`, { type: 'phase', key: p.key, state: status });
        } catch (err) {
          if (err instanceof CancelledError) throw err;
          this.updatePhase(p.key, { status: 'failed', finishedAt: nowIso(), detail: err.message });
          throw err;
        }
      }
      const t = this.totals();
      if (t.failed > 0) {
        this.setStatus('COMPLETED_WITH_ERRORS', `${t.failed} of ${t.tables} tables failed. Fix the cause and press Resume to retry only those tables.`);
        this.event('error', `Run finished with ${t.failed} failed tables`);
      } else if (this.state.options.loadMode === 'export') {
        this.setStatus('EXPORTED', `All ${t.tables} tables are exported to files in this run's data folder. Press "Import exported files" to load them into PostgreSQL.`);
        this.event('info', `Export completed: ${t.tables} tables, ${t.rowsDone.toLocaleString()} rows in files`);
      } else {
        this.setStatus('COMPLETED');
        this.event('info', `Migration completed: ${t.done} tables, ${t.rowsDone.toLocaleString()} rows`);
      }
    } catch (err) {
      if (this.shutdownRequested) {
        this.resetRunningTables('Server stopped');
        this.setStatus('INTERRUPTED', 'The server was stopped while this run was in progress. Press Resume to continue where it stopped.');
        this.event('error', 'Run interrupted by a server shutdown');
      } else if (err instanceof CancelledError || this.cancelRequested) {
        this.resetRunningTables('Cancelled');
        this.setStatus('CANCELLED', 'Cancelled by user. Press Resume to continue.');
        this.event('info', 'Run cancelled');
      } else {
        logger.error(`Run ${this.state.runId} failed: ${err.stack}`);
        this.resetRunningTables(err.message);
        this.setStatus('FAILED', err.message);
        this.event('error', `Run failed: ${err.message}`);
      }
    } finally {
      clearInterval(this.tickTimer);
      this.save(true);
      this.emitRun();
      this.log.close();
      active.delete(this.projectName);
      this.notifier.finished(this.state, this.totals());
      await store.updateMeta(this.projectName, (m) => ({
        ...m,
        migrationStatus: this.state.status,
        lastMigrationDate: this.state.finishedAt,
        currentMigrationId: this.state.runId,
      })).catch(() => {});
    }
  }

  resetRunningTables(reason) {
    for (const t of Object.values(this.state.tables)) {
      if (t.status === 'running') Object.assign(t, { status: 'pending', rate: 0, error: reason });
      (t.chunks || []).forEach((c) => { if (c.status === 'running') Object.assign(c, { status: 'pending', rate: 0 }); });
    }
    for (const p of this.state.phases) if (p.status === 'running') p.status = 'pending';
  }

  // ---------- helpers ----------

  get schemaDir() { return path.join(this.dir, 'schema'); }
  get pgSchema() { return this.state.targetSchema; }

  /** Table / column name in PostgreSQL (lower case unless the project preserves case). */
  pgName(name) { return this.state.preserveCase ? name : name.toLowerCase(); }

  ora2pg(args, label, extra = {}) {
    return executeAndLog({
      cmd: CONSTANTS.ORA2PG_BIN,
      args,
      // Direct load: ora2pg's own PostgreSQL sessions (DBD::Pg reads PGOPTIONS) do not wait for the
      // WAL flush at each commit either. Safe here: every table is counted and checked afterwards.
      cwd: this.dir,
      log: this.log,
      children: this.children,
      label,
      ...extra,
      env: { PGOPTIONS: '-c synchronous_commit=off', ...(extra.env || {}) },
    });
  }

  psqlEnv() {
    return {
      PGPASSWORD: this.pg.password,
      PGSSLMODE: CONSTANTS.PG_SSLMODE,
      // Bulk load: commits do not wait for the WAL flush (ora2pg does the same for its own loads).
      PGOPTIONS: `-c search_path=${this.pgSchema},public -c synchronous_commit=off`,
    };
  }

  psqlArgs(extra) {
    return ['--host', this.pg.hostip, '--port', String(this.pg.port), '--dbname', this.pg.dbname, '--username', this.pg.username, '--no-psqlrc', ...extra];
  }

  psqlFile(file, label, { stopOnError = false, out } = {}) {
    if (!fs.existsSync(file)) {
      this.log.info(`${label}: nothing to apply (${path.relative(this.dir, file)} not generated)`);
      return Promise.resolve({ code: 0, skipped: true });
    }
    return executeAndLog({
      cmd: CONSTANTS.PSQL_BIN,
      args: this.psqlArgs(['-v', `ON_ERROR_STOP=${stopOnError ? 1 : 0}`, '-f', file]),
      env: this.psqlEnv(),
      cwd: this.dir,
      log: this.log,
      out,
      children: this.children,
      label,
    });
  }

  async pgTableExists(name) {
    const { rows } = await pgClient.pgQuery(
      'SELECT 1 FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace WHERE n.nspname = $1 AND c.relname = $2 AND c.relkind IN (\'r\',\'p\')',
      [this.pgSchema, this.pgName(name)],
      this.projectName,
    );
    return rows.length > 0;
  }

  // ---------- phases ----------

  async phase_prepare() {
    const meta = await store.readMeta(this.projectName);
    this.oracle = store.oracleCredentials(meta);
    this.pg = store.postgresCredentials(meta);
    if (!this.oracle) throw new Error('Oracle source is not connected for this project.');
    if (!this.pg) throw new Error('PostgreSQL target is not connected for this project.');

    await oracleClient.ensureOraclePool(this.oracle, this.projectName);
    await pgClient.ensurePostgresPool(this.pg, this.projectName);

    const replaceCols = (meta.columnRenames || []).length
      ? Object.entries((meta.columnRenames || []).reduce((acc, c) => {
        (acc[c.tableName] = acc[c.tableName] || []).push(`${c.oldName}:${c.name}`);
        return acc;
      }, {})).map(([t, cols]) => `${t}(${cols.join(',')})`).join(' ')
      : null;

    const opts = this.state.options;
    this.settings = settingsSvc.resolve(meta);
    const base = {
      oracle: this.oracle,
      schema: this.state.schema,
      options: { dataLimit: opts.dataLimit, blobLimit: opts.blobLimit, replaceCols, pgSchema: this.pgSchema, directives: settingsSvc.ora2pgDirectives(this.settings) },
    };
    // ddl.conf: exports to files. data.conf: streams rows into PostgreSQL (direct mode).
    this.ddlConf = await buildConfig({ ...base, outFile: path.join(this.dir, 'config', 'ddl.conf'), outputDir: this.schemaDir });
    this.dataConf = await buildConfig({
      ...base,
      options: { ...base.options, forData: true },
      outFile: path.join(this.dir, 'config', 'data.conf'),
      outputDir: path.join(this.dir, 'data'),
      postgres: opts.loadMode === 'direct' ? this.pg : null,
    });

    // Config for loads that go through a file even in direct mode (ROWID chunks, see copyTable).
    this.fileConf = opts.loadMode === 'direct'
      ? await buildConfig({ ...base, options: { ...base.options, forData: true }, outFile: path.join(this.dir, 'config', 'data_file.conf'), outputDir: path.join(this.dir, 'data'), postgres: null })
      : this.dataConf;
    this.columnRenames = meta.columnRenames || [];

    // Table definitions only for the selected tables (ALLOW list in its own config).
    const allTables = this.state.allTablesSelected;
    let tableConf = await fsp.readFile(this.ddlConf, 'utf8');
    if (!allTables) {
      const names = Object.keys(this.state.tables).map((n) => n.replace(/\$/g, '\\$'));
      tableConf = tableConf.replace(/^#?\s*ALLOW\s.*$/m, '') + `\nALLOW\t${names.join(' ')}\n`;
    }
    this.tableConf = path.join(this.dir, 'config', 'ddl_tables.conf');
    await fsp.writeFile(this.tableConf, tableConf, { mode: 0o600 });

    for (const d of ['data', 'schema']) await fsp.mkdir(path.join(this.dir, d), { recursive: true });

    const check = await executeAndLog({ cmd: CONSTANTS.ORA2PG_BIN, args: ['--version'], log: this.log, label: 'Check ora2pg', captureStdout: true });
    if (check.code !== 0) throw new Error(`ora2pg is not available (${CONSTANTS.ORA2PG_BIN}). ${check.errorTail}`);
    this.state.ora2pgMajor = ora2pgMajor(check.stdout);
    if (this.state.ora2pgMajor && this.state.ora2pgMajor < 24) throw new Error(`ora2pg ${this.state.ora2pgMajor} is too old: version 24 or newer is needed.`);
    const psql = await executeAndLog({ cmd: CONSTANTS.PSQL_BIN, args: ['--version'], log: this.log, label: 'Check psql' });
    if (psql.code !== 0) throw new Error(`psql is not available (${CONSTANTS.PSQL_BIN}). ${psql.errorTail}`);

    this.event('info', `Load mode: ${opts.loadMode}, ${opts.parallelTables} tables in parallel, huge tables ≥ ${opts.hugeTableRows.toLocaleString()} rows use ${opts.oracleCopies} Oracle readers / ${opts.pgJobs} writers`);
    await this.chooseSnapshot();
  }

  /**
   * ora2pg 25 reads every table AS OF SCN by default (ora2pg 24 only when given --scn), which needs the FLASHBACK privilege; without it every
   * load fails with ORA-41900. With the privilege the run uses ONE SCN for all tables, chunks,
   * retries and row-count checks: a consistent point in time even if the application keeps writing.
   * Without it, data is read as it is now (--no_start_scn) and the application must be stopped.
   * A resumed run keeps its SCN; if Oracle's undo no longer reaches back that far, see snapshotTooOld().
   */
  async chooseSnapshot() {
    const prev = this.state.snapshot;
    if (this.state.options.snapshot === 'off') {
      this.state.snapshot = { mode: 'current', reason: 'turned off in the run settings', at: nowIso() };
      this.event('info', prev && prev.mode === 'scn'
        ? `Snapshot turned off for this resume: the remaining tables are read as they are now (tables already loaded keep SCN ${prev.scn}). Keep the application stopped.`
        : 'Snapshot off: tables are read as they are now. Keep the application stopped during the load.');
      this.save(true);
      return;
    }
    const conn = await oracleClient.getOracleConnection(this.projectName);
    try {
      const scn = prev && prev.mode === 'scn' ? prev.scn : String((await conn.execute('SELECT current_scn FROM v$database')).rows[0][0]);
      const probe = Object.keys(this.state.tables)[0];
      if (probe) await conn.execute(`SELECT 1 FROM ${qi(this.state.schema)}.${qi(probe)} AS OF SCN ${scn} WHERE ROWNUM = 1`);
      this.state.snapshot = { mode: 'scn', scn, at: prev && prev.mode === 'scn' ? prev.at : nowIso() };
      if (!prev || prev.mode !== 'scn') this.event('info', `Consistent snapshot: all tables are read as of Oracle SCN ${scn}`);
    } catch (err) {
      const reason = /ORA-41900|ORA-01031|ORA-00942/.test(err.message) ? 'the migration user has no FLASHBACK privilege' : err.message.split('\n')[0];
      if (prev && prev.mode === 'scn' && /ORA-01555|ORA-08180|ORA-08181/.test(err.message)) {
        throw new Error(`The run's snapshot (SCN ${prev.scn}) is older than Oracle's undo retention (${err.message.split('\n')[0]}). Start a new run, or raise UNDO_RETENTION.`);
      }
      this.state.snapshot = { mode: 'current', reason, at: nowIso() };
      this.event('error', `No consistent snapshot (${reason}): tables are read as they are now. Keep the application stopped during the load, or grant FLASHBACK ANY TABLE to the migration user.`);
    } finally {
      await conn.close().catch(() => {});
    }
    this.save(true);
  }

  /**
   * ora2pg arguments for the run's snapshot. --scn works in ora2pg 24 and 25. Without a snapshot,
   * ora2pg 25 must be told --no_start_scn (it reads AS OF the current SCN by default, which needs
   * FLASHBACK); ora2pg 24 reads current data by default and does not know that option.
   */
  snapshotArgs() {
    if (this.state.snapshot && this.state.snapshot.mode === 'scn') return ['--scn', this.state.snapshot.scn];
    return this.state.ora2pgMajor && this.state.ora2pgMajor < 25 ? [] : ['--no_start_scn'];
  }

  /** Identifies the data an export file holds: a file is only re-imported for the same snapshot. */
  snapshotKey() {
    const snap = this.state.snapshot && this.state.snapshot.mode === 'scn' ? `scn:${this.state.snapshot.scn}` : 'current';
    return `${snap}|${this.state.decisionsHash || ''}`;
  }

  asOf() {
    return this.state.snapshot && this.state.snapshot.mode === 'scn' ? ` AS OF SCN ${this.state.snapshot.scn}` : '';
  }

  /** Selected tables that are partitioned in Oracle, or null when the dictionary cannot be read. */
  async partitionedTables() {
    let conn;
    try {
      conn = await oracleClient.getOracleConnection(this.projectName);
      const r = await conn.execute(`SELECT table_name FROM dba_tables WHERE owner = :owner AND partitioned = 'YES'`, { owner: this.state.schema });
      const names = r.rows.map((row) => row[0]);
      return this.state.allTablesSelected ? names : names.filter((n) => this.state.tables[n]);
    } catch (err) {
      this.log.info(`Partitioned tables could not be listed (${err.message.split('\n')[0]}): partitions are exported`);
      return null;
    } finally {
      if (conn) await conn.close().catch(() => {});
    }
  }

  async phase_ddl() {
    const exportType = (type, dir, file, conf, required) => async () => {
      this.checkCancelled();
      await fsp.mkdir(path.join(this.schemaDir, dir), { recursive: true });
      const res = await this.ora2pg(['-p', '-t', type, '-c', conf, '-b', path.join(this.schemaDir, dir), '-o', file], `Export ${type}`);
      if (res.code !== 0) {
        if (required) throw new Error(`ora2pg could not export ${type}: ${res.errorTail || 'see master.log'}`);
        this.phase('ddl').warnings = (this.phase('ddl').warnings || 0) + 1;
        this.event('error', `Export ${type} failed (not blocking): ${res.errorTail.split('\n')[0] || 'see log'}`);
      }
      done += 1;
      this.updatePhase('ddl', { progress: Math.round((done / total) * 100), detail: `Exported ${type}` });
    };

    const jobs = [
      exportType('TABLE', 'tables', 'table.sql', this.tableConf, true),
      exportType('SEQUENCE', 'sequences', 'sequence.sql', this.ddlConf, true),
      exportType('TYPE', 'types', 'type.sql', this.ddlConf, false),
    ];
    // Partitions of partitioned tables: without them PostgreSQL has a partitioned table that accepts no rows.
    // ora2pg's PARTITION export reads the indexes and keys of the whole schema, which is slow on a large
    // one, so it only runs when a selected table is partitioned.
    const parted = await this.partitionedTables();
    if (!parted || parted.length) jobs.push(exportType('PARTITION', 'partitions', 'partition.sql', this.tableConf, false));
    else this.event('info', 'No partitioned tables selected: partition export skipped');
    // Views, PL/SQL, triggers, DB links… are exported separately as the GenAI package
    // (Code objects page) and applied by the "code" phase when a converted package is chosen.
    let done = 0;
    const total = jobs.length;
    await Promise.all(jobs.map((j) => j()));

    // v1 helper scripts: remove duplicate sequences, convert Oracle Text indexes on LOBs.
    const seqDir = path.join(this.schemaDir, 'sequences');
    if (fs.existsSync(path.join(seqDir, 'sequence.sql'))) {
      await executeAndLog({ cmd: 'bash', args: [path.join(CONSTANTS.SCRIPTS_DIR, 'sequence.sh'), 'sequence.sql', 'modified_sequence.sql'], cwd: seqDir, log: this.log, label: 'Remove duplicate sequences' });
    }
    const tblDir = path.join(this.schemaDir, 'tables');
    if (fs.existsSync(path.join(tblDir, 'INDEXES_table.sql'))) {
      // Oracle Text indexes on LOBs become a text column + GIN index. v1 had two variants of the
      // helper: fts_bytea.sh (BLOB stored as bytea) and fts_oid.sh (BLOB stored as large object).
      const oid = this.settings.lob.blobAs === 'oid';
      await executeAndLog({
        cmd: 'bash',
        args: oid
          ? [path.join(CONSTANTS.SCRIPTS_DIR, 'fts_oid.sh'), 'INDEXES_table.sql']
          : [path.join(CONSTANTS.SCRIPTS_DIR, 'fts_bytea.sh'), 'INDEXES_table.sql', 'modified_INDEXES_table.sql'],
        cwd: tblDir,
        log: this.log,
        label: 'Prepare full-text indexes',
      });
    }
  }

  async phase_tables() {
    await pgClient.pgQuery(`CREATE SCHEMA IF NOT EXISTS ${qi(this.pgSchema)}`, [], this.projectName);
    const out = this.log.tableLog('_ddl');
    const seqFile = fs.existsSync(path.join(this.schemaDir, 'sequences', 'modified_sequence.sql'))
      ? path.join(this.schemaDir, 'sequences', 'modified_sequence.sql')
      : path.join(this.schemaDir, 'sequences', 'sequence.sql');

    this.updatePhase('tables', { detail: 'Creating types', progress: 10 });
    await this.psqlFile(await this.pgTypesFile(), 'Create types', { out });
    await this.fixTypeLengths(out);
    this.updatePhase('tables', { detail: 'Creating sequences', progress: 30 });
    await this.psqlFile(await this.noStopCopy(seqFile), 'Create sequences', { out });
    this.checkCancelled();
    this.updatePhase('tables', { detail: 'Creating tables', progress: 50 });
    // Existing tables (from an earlier run) only produce "already exists" errors; their data is
    // truncated before loading, so re-running is safe.
    await this.psqlFile(await this.noStopCopy(path.join(this.schemaDir, 'tables', 'table.sql')), 'Create tables', { out });
    this.updatePhase('tables', { detail: 'Creating partitions', progress: 70 });
    await this.psqlFile(await this.noStopCopy(path.join(this.schemaDir, 'partitions', 'partition.sql')), 'Create partitions', { out });
    await this.ensureDefaultPartitions(out);
    out.end();

    // Oracle object tables: ora2pg cannot create them, so (as in v1) a TEXT-column copy is created.
    for (const t of Object.values(this.state.tables).filter((x) => x.kind === 'object')) {
      if (!(await this.pgTableExists(t.name))) await this.createObjectTableFallback(t.name);
    }

    // Every selected table must now exist in PostgreSQL.
    let missing = 0;
    for (const t of Object.values(this.state.tables)) {
      if (t.status === 'done') continue;
      if (!(await this.pgTableExists(t.name))) {
        missing += 1;
        this.updateTable(t.name, { status: 'failed', error: 'Table definition could not be created in PostgreSQL (see the _ddl table log)' }, true);
      }
    }
    if (missing) {
      this.phase('tables').warnings = missing;
      this.event('error', `${missing} tables could not be created; their data load is skipped`);
    }
  }

  async createObjectTableFallback(table) {
    const conn = await oracleClient.getOracleConnection(this.projectName);
    try {
      const r = await conn.execute(
        'SELECT column_name FROM all_tab_columns WHERE owner = :o AND table_name = :t ORDER BY column_id',
        { o: this.state.schema, t: table },
      );
      const cols = r.rows.map((x) => `${qi(this.pgName(x[0]))} TEXT`);
      if (!cols.length) return;
      await pgClient.pgQuery(`CREATE TABLE IF NOT EXISTS ${qi(this.pgSchema)}.${qi(this.pgName(table))} (${cols.join(', ')})`, [], this.projectName);
      this.event('info', `Created TEXT fallback table for Oracle object table ${table}`);
    } finally {
      await conn.close();
    }
  }

  /**
   * ora2pg 25 gives every VARCHAR2 attribute of an object type the length of the last one
   * (ADDRESS_T(street varchar2(80), …, country varchar2(2)) became four varchar(2)), so the data does
   * not fit. The real lengths come from DBA_TYPE_ATTRS; shorter attributes in PostgreSQL are widened
   * (CASCADE also fixes tables that already use the type, e.g. on resume).
   */
  /**
   * A copy of an ora2pg DDL file without its "\set ON_ERROR_STOP ON": one statement PostgreSQL
   * rejects (on a re-run usually "already exists") must not stop every statement after it, such as
   * a new table further down. The error is still logged; the existence check after the DDL
   * reports any table that really could not be created.
   */
  async noStopCopy(file, transform = (text) => text) {
    if (!fs.existsSync(file)) return file;
    const dst = file.replace(/\.sql$/, '_pg.sql');
    const text = (await fsp.readFile(file, 'utf8')).replace(/^\s*\\set\s+ON_ERROR_STOP\s+ON\s*$/gim, '');
    await fsp.writeFile(dst, transform(text));
    return dst;
  }

  /** type.sql as PostgreSQL can run it: Oracle type changes (ALTER TYPE ... MODIFY / ADD / DROP ATTRIBUTE) rewritten. */
  pgTypesFile() {
    return this.noStopCopy(path.join(this.schemaDir, 'types', 'type.sql'), pgTypeSql);
  }

  async fixTypeLengths(out) {
    const conn = await oracleClient.getOracleConnection(this.projectName);
    let attrs;
    try {
      attrs = (await conn.execute(
        `SELECT a.type_name, a.attr_name, a.attr_type_name, a.length
           FROM dba_type_attrs a JOIN dba_types t ON t.owner = a.owner AND t.type_name = a.type_name
          WHERE a.owner = :o AND t.typecode = 'OBJECT' AND a.attr_type_name IN ('VARCHAR2', 'NVARCHAR2', 'VARCHAR', 'CHAR', 'NCHAR') AND a.length > 0`,
        { o: this.state.schema })).rows;
    } catch (err) {
      this.log.error(`Object type lengths: ${err.message}`);
      return;
    } finally {
      await conn.close().catch(() => {});
    }
    if (!attrs.length) return;
    const pg = new Map((await pgClient.pgQuery(
      `SELECT t.typname, a.attname, a.atttypmod - 4 AS len
         FROM pg_type t JOIN pg_namespace n ON n.oid = t.typnamespace JOIN pg_attribute a ON a.attrelid = t.typrelid
        WHERE n.nspname = $1 AND t.typtype = 'c' AND a.attnum > 0 AND a.atttypmod > 4`,
      [this.pgSchema], this.projectName)).rows.map((r) => [`${r.typname}.${r.attname}`, Number(r.len)]));
    const wrong = attrs.filter(([type, attr, , len]) => {
      const key = `${this.pgName(type)}.${this.pgName(attr)}`;
      return pg.has(key) && pg.get(key) < Number(len);
    });
    for (const type of [...new Set(wrong.map((w) => w[0]))]) {
      const pgType = `${qi(this.pgSchema)}.${qi(this.pgName(type))}`;
      // PostgreSQL cannot alter a composite type that a table column uses (resumed runs): those
      // columns go to text and back around the change, keeping their data.
      const users = (await pgClient.pgQuery(
        `SELECT n.nspname, c.relname, a.attname FROM pg_attribute a JOIN pg_class c ON c.oid = a.attrelid JOIN pg_namespace n ON n.oid = c.relnamespace
          WHERE a.atttypid = $1::regtype AND c.relkind IN ('r', 'p') AND NOT a.attisdropped`, [pgType], this.projectName)).rows;
      const statements = [
        ...users.map((u) => `ALTER TABLE ${qi(u.nspname)}.${qi(u.relname)} ALTER COLUMN ${qi(u.attname)} TYPE text USING ${qi(u.attname)}::text`),
        ...wrong.filter((w) => w[0] === type).map(([, attr, , len]) => `ALTER TYPE ${pgType} ALTER ATTRIBUTE ${qi(this.pgName(attr))} TYPE varchar(${Number(len)})`),
        ...users.map((u) => `ALTER TABLE ${qi(u.nspname)}.${qi(u.relname)} ALTER COLUMN ${qi(u.attname)} TYPE ${pgType} USING ${qi(u.attname)}::${pgType}`),
      ];
      const client = await pgClient.getPostgresConnection(this.projectName);
      try {
        await client.query('BEGIN');
        for (const sql of statements) await client.query(sql);
        await client.query('COMMIT');
        statements.forEach((sql) => out.write(`${sql};\n`));
        this.log.info(`Fixed attribute lengths of ${type} (ora2pg exported them too short)`);
      } catch (err) {
        await client.query('ROLLBACK').catch(() => {});
        this.log.error(`Fixing attribute lengths of ${type}: ${err.message}`);
      } finally {
        client.release();
      }
    }
  }

  /**
   * A partitioned table with no partition that fits a row rejects it. Oracle INTERVAL partitioning
   * creates partitions on the fly; PostgreSQL does not, so every partitioned table gets a DEFAULT
   * partition: rows of periods that had no partition yet still load (split later with pg_partman).
   */
  async ensureDefaultPartitions(out) {
    const { rows } = await pgClient.pgQuery(
      `SELECT c.relname FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
        WHERE n.nspname = $1 AND c.relkind = 'p'
          AND NOT EXISTS (SELECT 1 FROM pg_inherits i JOIN pg_class d ON d.oid = i.inhrelid
                           WHERE i.inhparent = c.oid AND pg_get_expr(d.relpartbound, d.oid) = 'DEFAULT')`,
      [this.pgSchema], this.projectName);
    for (const { relname } of rows) {
      const sql = `CREATE TABLE IF NOT EXISTS ${qi(this.pgSchema)}.${qi(`${relname}_default`)} PARTITION OF ${qi(this.pgSchema)}.${qi(relname)} DEFAULT`;
      await pgClient.pgQuery(sql, [], this.projectName)
        .then(() => out.write(`${sql};\n`))
        .catch((err) => this.log.error(`Default partition for ${relname}: ${err.message}`));
    }
  }

  async phase_data() {
    const opts = this.state.options;
    const todo = Object.values(this.state.tables)
      .filter((t) => t.status !== 'done' && !(opts.loadMode === 'export' && t.status === 'exported') && !(t.status === 'failed' && /could not be created/.test(t.error || '')))
      .sort((a, b) => (b.sizeMb || 0) - (a.sizeMb || 0) || (b.estRows || 0) - (a.estRows || 0));

    const total = Object.keys(this.state.tables).length;
    const limit = pLimit(Math.max(1, opts.parallelTables));
    const updateProgress = () => {
      const t = this.totals();
      this.updatePhase('data', {
        progress: Math.round(((t.done + (t.exported || 0) + t.failed) / Math.max(1, total)) * 100),
        detail: opts.loadMode === 'export'
          ? `${t.exported || 0} exported, ${t.running} exporting, ${t.failed} failed of ${total} tables`
          : `${t.done} done, ${t.running} loading, ${t.failed} failed of ${total} tables`,
      });
    };

    await Promise.all(todo.map((t) => limit(async () => {
      if (this.cancelRequested) return;
      await this.loadTableWithRetry(t.name);
      updateProgress();
    })));
    this.checkCancelled();
    updateProgress();
    const failed = this.totals().failed;
    if (failed) this.phase('data').warnings = failed;
  }

  async loadTableWithRetry(name) {
    const maxAttempts = this.state.options.maxAttempts;
    const t = this.state.tables[name];
    t.attempts = 0;
    if (t.udt === undefined && t.kind !== 'object') {
      // Columns of user-defined object types: ora2pg writes them in a format PostgreSQL misreads,
      // so these tables are loaded by the engine's own reader (loadObjectTable).
      const conn = await oracleClient.getOracleConnection(this.projectName);
      try {
        const r = await conn.execute(
          `SELECT COUNT(*) FROM dba_tab_columns WHERE owner = :o AND table_name = :t
              AND data_type_owner IS NOT NULL AND data_type_owner NOT IN ('SYS', 'PUBLIC', 'MDSYS')`, { o: this.state.schema, t: name });
        t.udt = Number(r.rows[0][0]) > 0;
      } catch (err) {
        t.udt = false;
        this.log.error(`Object type check for ${name}: ${err.message}`);
      } finally {
        await conn.close().catch(() => {});
      }
    }
    if (t.kind === 'lob' && t.lobPlan === undefined) {
      await this.planLobs(t).catch((err) => {
        t.lobPlan = null;
        this.log.error(`LOB plan for ${name} failed, using LOB locators: ${err.message}`);
      });
    }
    if (!t.udt && this.shouldChunk(t) && t.chunks === undefined) {
      await this.planChunks(t).catch((err) => {
        t.chunks = null;
        this.log.error(`Chunk plan for ${name} failed, loading it in one piece: ${err.message}`);
      });
    }
    while (t.attempts < maxAttempts) {
      this.checkCancelled();
      t.attempts += 1;
      const chunked = Array.isArray(t.chunks) && t.chunks.length > 0;
      this.updateTable(name, { status: 'running', startedAt: t.startedAt && chunked ? t.startedAt : nowIso(), finishedAt: null, rowsDone: chunked ? t.rowsDone : 0, rate: 0, error: null }, true);
      this.event('info', `Loading table ${name}${t.attempts > 1 ? ` (attempt ${t.attempts})` : ''}`, { type: 'table', name, state: 'start' });
      try {
        if (chunked) await this.loadChunked(t);
        else await this.loadTable(t);
        const exported = this.state.options.loadMode === 'export';
        if (!exported) await this.bulkFinish(t);
        this.updateTable(name, { status: exported ? 'exported' : 'done', finishedAt: nowIso(), rate: 0, error: null }, true);
        this.event('info', `Table ${name} ${exported ? 'exported' : 'loaded'}: ${(exported ? t.rowsDone : (t.pgRows ?? t.rowsDone)).toLocaleString()} rows${t.attempts > 1 ? ` (attempt ${t.attempts})` : ''}`, { type: 'table', name, state: 'done' });
        return;
      } catch (err) {
        if (err instanceof CancelledError || this.cancelRequested) throw new CancelledError();
        // A data checksum difference is a mapping problem (e.g. decimals into an integer column): reloading won't fix it.
        if (/ORA-01555|ORA-08180|ORA-08181|snapshot too old/i.test(err.message) && this.state.snapshot && this.state.snapshot.mode === 'scn') {
          // Retrying reads the same SCN, which Oracle's undo no longer reaches: say what to do instead.
          err.message = `Oracle's undo no longer reaches the run's snapshot (SCN ${this.state.snapshot.scn}): ${firstError(err.message)}. `
            + 'Resume with "Consistent snapshot" off (keep the application stopped), or raise UNDO_RETENTION and start a new run.';
          err.noRetry = true;
        }
        const last = t.attempts >= maxAttempts || !!err.noRetry;
        if (last) {
          await this.emptyFailedTable(t);
          if (this.state.options.loadMode !== 'export') err.message += ' The table was emptied, so it is never left half loaded: Resume loads it again.';
        }
        this.updateTable(name, { status: last ? 'failed' : 'running', error: err.message, failedParts: last ? err.failedParts || null : null, rate: 0, rowsDone: last && this.state.options.loadMode !== 'export' ? 0 : t.rowsDone, finishedAt: last ? nowIso() : null }, true);
        this.event('error', `Table ${name} attempt ${t.attempts}/${maxAttempts} failed: ${err.message}`, { type: 'table', name, state: 'failed' });
        if (last) this.notifier.attention(`• Table ${name} failed after ${t.attempts} attempt(s): ${firstError(err.message).slice(0, 300)}`);
        else if (isStalled(err)) this.notifier.attention(`• Table ${name}: hung load stopped (no progress for ${this.state.options.stallMinutes} min), retrying`);
        if (last) return;
        await sleep(Math.min(60000, 10000 * t.attempts));
      }
    }
  }

  /** Empties the target table so a (re)load never duplicates rows. */
  async prepareTarget(name) {
    await this.dropReferencingFks(name);
    // Without ONLY: PostgreSQL refuses TRUNCATE ONLY on a partitioned table, and its partitions must be emptied too.
    await pgClient.pgQuery(`TRUNCATE TABLE ${qi(this.pgSchema)}.${qi(this.pgName(name))}`, [], this.projectName);
    await this.bulkPrepare(this.state.tables[name]);
  }

  /** The table and, for a partitioned table, its partitions (leaf tables hold the data). */
  async pgRelations(name) {
    const { rows } = await pgClient.pgQuery(
      `WITH RECURSIVE r AS (
         SELECT c.oid, c.relname, c.relkind, c.relpersistence, false AS part
           FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace WHERE n.nspname = $1 AND c.relname = $2
         UNION ALL
         SELECT c.oid, c.relname, c.relkind, c.relpersistence, true FROM pg_inherits i JOIN r ON i.inhparent = r.oid JOIN pg_class c ON c.oid = i.inhrelid)
       SELECT relname, relkind, relpersistence, part FROM r`,
      [this.pgSchema, this.pgName(name)],
      this.projectName,
    );
    return rows;
  }

  /**
   * Bulk-load mode, on the empty table: autovacuum is switched off while the table is loaded (it
   * would scan the table again and again during a long load), and with "Unlogged load" a plain
   * table is made UNLOGGED: its rows are written without WAL. bulkFinish() undoes both once the
   * table is verified. An unlogged table is emptied by a PostgreSQL crash: the row count check
   * then fails and the table is reloaded, so a table is only marked done once it is permanent.
   */
  async bulkPrepare(t) {
    if (!t || this.state.options.loadMode === 'export') return;
    const sch = qi(this.pgSchema);
    const rels = await this.pgRelations(t.name).catch(() => []);
    for (const r of rels.filter((x) => x.relkind === 'r')) {
      await pgClient.pgQuery(`ALTER TABLE ${sch}.${qi(r.relname)} SET (autovacuum_enabled = false, toast.autovacuum_enabled = false)`, [], this.projectName)
        .catch(() => pgClient.pgQuery(`ALTER TABLE ${sch}.${qi(r.relname)} SET (autovacuum_enabled = false)`, [], this.projectName).catch(() => {}));
    }
    t.autovacuumOff = true;
    const plain = rels.length === 1 && rels[0].relkind === 'r';
    if (this.state.options.bulkLoad === 'unlogged' && plain) {
      try {
        await pgClient.pgQuery(`ALTER TABLE ${sch}.${qi(this.pgName(t.name))} SET UNLOGGED`, [], this.projectName);
        t.unlogged = true;
      } catch (err) {
        this.log.info(`${t.name}: loaded as a normal table (${err.message.split('\n')[0]})`);
      }
    } else if (this.state.options.bulkLoad === 'unlogged' && !plain) {
      this.log.info(`${t.name}: partitioned, loaded as a normal table`);
    }
    this.save(true);
  }

  /** After a verified load: the table becomes permanent again (SET LOGGED writes it to WAL once) and autovacuum is back on. */
  async bulkFinish(t) {
    const sch = qi(this.pgSchema);
    if (!(await this.pgRelations(t.name).catch(() => [])).length) {
      // The table is not in PostgreSQL (dropped, or never created): nothing to switch back.
      Object.assign(t, { unlogged: false, autovacuumOff: false });
      return;
    }
    if (t.unlogged) {
      this.updateTable(t.name, { rate: 0 });
      this.event('info', `Making ${t.name} permanent (writes it to the WAL once)`);
      const started = Date.now();
      await pgClient.pgQuery(`ALTER TABLE ${sch}.${qi(this.pgName(t.name))} SET LOGGED`, [], this.projectName);
      t.unlogged = false;
      this.log.info(`${t.name}: SET LOGGED in ${Math.round((Date.now() - started) / 1000)}s`);
    }
    if (t.autovacuumOff) {
      const rels = await this.pgRelations(t.name).catch(() => []);
      for (const r of rels.filter((x) => x.relkind === 'r')) {
        await pgClient.pgQuery(`ALTER TABLE ${sch}.${qi(r.relname)} RESET (autovacuum_enabled, toast.autovacuum_enabled)`, [], this.projectName)
          .catch(() => pgClient.pgQuery(`ALTER TABLE ${sch}.${qi(r.relname)} RESET (autovacuum_enabled)`, [], this.projectName).catch(() => {}));
      }
      t.autovacuumOff = false;
    }
    this.save(true);
  }

  async dropReferencingFks(name) {
    const pgName = this.pgName(name);
    // Foreign keys pointing at this table would block TRUNCATE; they are dropped here and
    // re-created by the foreign key phase.
    const { rows } = await pgClient.pgQuery(
      `SELECT con.conname, cn.nspname AS sch, cl.relname AS tbl
         FROM pg_constraint con
         JOIN pg_class cl ON cl.oid = con.conrelid
         JOIN pg_namespace cn ON cn.oid = cl.relnamespace
        WHERE con.contype = 'f'
          AND con.confrelid = (SELECT c.oid FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace WHERE n.nspname = $1 AND c.relname = $2)`,
      [this.pgSchema, pgName],
      this.projectName,
    );
    for (const fk of rows) {
      await pgClient.pgQuery(`ALTER TABLE ${qi(fk.sch)}.${qi(fk.tbl)} DROP CONSTRAINT IF EXISTS ${qi(fk.conname)}`, [], this.projectName);
      this.log.info(`Dropped FK ${fk.conname} on ${fk.tbl} to reload ${name} (re-created in the foreign key phase)`);
      this.phase('fkeys').status = 'pending';
    }
  }

  async loadTable(t) {
    const opts = this.state.options;
    if (opts.loadMode === 'export') return this.exportTable(t);
    await this.prepareTarget(t.name);
    this.checkCancelled();

    const out = this.log.tableLog(t.name);
    out.write(`\n===== ${nowIso()} attempt ${t.attempts} =====\n`);
    try {
      if (t.kind === 'object' || t.udt) {
        await this.loadObjectTable(t, out);
      } else {
        await this.copyTable(t, { out, huge: t.kind === 'huge', onRows: (rows, rate) => this.updateTable(t.name, { rowsDone: rows, rate }) });
      }
    } finally {
      out.end();
    }
    await this.verifyTable(t);
    await this.verifyData(t);
  }

  /** Export-only run: the table goes to a file, checked against Oracle's count, and stays there for the import. */
  async exportTable(t) {
    if (t.kind === 'object' || t.udt) {
      this.log.info(`${t.name}: has object types, read directly from Oracle when the files are imported`);
      return;
    }
    const out = this.log.tableLog(t.name);
    out.write(`\n===== ${nowIso()} export attempt ${t.attempts} =====\n`);
    try {
      const rows = await this.copyTable(t, { out, huge: t.kind === 'huge', onRows: (r, rate) => this.updateTable(t.name, { rowsDone: r, rate }) });
      const expected = await this.oracleCount(t);
      if (rows !== expected) {
        await this.dropExport(t);
        throw new Error(`export has ${rows} rows, Oracle has ${expected}: exported again on the next attempt`);
      }
      this.updateTable(t.name, { rowsDone: rows, oracleRows: expected });
    } finally {
      out.end();
    }
  }

  dataFile(t, fileTag) {
    return path.join(this.dir, 'data', `${t.name}${fileTag ? `_${fileTag}` : ''}_data.sql`);
  }

  async dropExport(t, fileTag) {
    const f = this.dataFile(t, fileTag);
    await fsp.unlink(f).catch(() => {});
    await fsp.unlink(`${f}.done.json`).catch(() => {});
  }

  /** Exact Oracle row count (of a WHERE range), at the run's snapshot. */
  async oracleCount(t, where) {
    const conn = await oracleClient.getOracleConnection(this.projectName);
    try {
      const r = await conn.execute(`SELECT /*+ PARALLEL(t, 4) */ COUNT(*) FROM ${qi(this.state.schema)}.${qi(t.name)}${this.asOf()} t${where ? ` WHERE ${where}` : ''}`);
      return Number(r.rows[0][0]);
    } finally {
      await conn.close().catch(() => {});
    }
  }

  /**
   * Runs ora2pg -t COPY for one table (or one PK range of it with `where`). In file mode the data
   * file is loaded with psql and deleted. Returns the number of rows ora2pg reported.
   */
  async copyTable(t, { out, huge, where, fileTag, onRows, viaFile }) {
    const opts = this.state.options;
    // Through a file: file / export runs, and ROWID chunks (whose load must be all-or-nothing, see loadChunked).
    const useFile = opts.loadMode !== 'direct' || !!viaFile;
    const conf = t.lobPlan && t.lobPlan.inline ? await this.inlineLobConf(useFile ? this.fileConf : this.dataConf, t.lobPlan) : (useFile ? this.fileConf : this.dataConf);
    const args = ['-t', 'COPY', '-c', conf, '-a', t.name.replace(/\$/g, '\\$'), ...this.snapshotArgs()];
    if (huge) args.push('-J', String(opts.oracleCopies), '-j', String(opts.pgJobs));
    if (where) args.push('-W', where);
    if (t.kind === 'lob') args.push('-L', String(t.lobPlan && t.lobPlan.inline ? t.lobPlan.batch : opts.blobLimit));
    const label = `${t.name}${fileTag ? ` ${fileTag}` : ''}`;

    let dataFile = null;
    let marker = null;
    let rows = null;
    if (useFile) {
      dataFile = this.dataFile(t, fileTag);
      marker = `${dataFile}.done.json`;
      // A complete export of the same snapshot is re-imported instead of reading Oracle again.
      const m = await store.readJson(marker);
      if (m && m.snapshot === this.snapshotKey() && fs.existsSync(dataFile)) {
        rows = m.rows;
        if (out) out.write(`Re-using the export from ${m.at} (${rows} rows): Oracle is not read again\n`);
        this.log.info(`${label}: re-importing existing export (${rows} rows)`);
        if (onRows) onRows(rows, 0);
      } else {
        await this.dropExport(t, fileTag);
        args.push('-b', path.dirname(dataFile), '-o', path.basename(dataFile));
      }
    }

    if (rows === null) {
      let lastRows = 0;
      const res = await this.ora2pg(args, `${useFile ? 'Export' : 'Load'} ${label}`, {
        out,
        idleTimeoutMs: opts.stallMinutes ? opts.stallMinutes * 60000 : 0,
        onLine: (line) => {
          // Single reader:  [=====>   ] 120000/500000 rows (24.0%) Table EMPLOYEES (10000 recs/sec)
          // Parallel (-J):  [=>       ] 150000/2500000 total rows (6.0%) - (6 sec., avg: 25000 recs/sec), ORDERS in progress.
          const m = line.match(/(\d+)\/(\d+)\s+rows\s+\([\d.]+%\)\s+Table\s+(\S+).*?(\d+)\s+recs\/sec/)
            || line.match(/(\d+)\/(\d+)\s+total rows.*?avg:\s+(\d+)\s+recs\/sec\),\s+(\S+)\s+in progress/);
          if (!m) return;
          const isTotal = m[0].includes('total rows');
          const tableName = isTotal ? m[4] : m[3];
          if (tableName.toUpperCase().startsWith(t.name.toUpperCase())) {
            lastRows = Math.max(lastRows, Number(m[1]));
            if (onRows) onRows(lastRows, Number(isTotal ? m[3] : m[4]));
          }
        },
      });
      this.checkCancelled();
      if (res.stalled) throw new Error(`No progress for ${opts.stallMinutes} min: stopped as hung (network?), retried`);
      if (res.code !== 0) throw new Error(firstError(res.errorTail) || `ora2pg exited with code ${res.code}`);
      if (res.errorTail) throw new Error(firstError(res.errorTail));
      rows = lastRows;
      if (dataFile) {
        if (!fs.existsSync(dataFile)) throw new Error('ora2pg produced no data file');
        await store.writeJsonAtomic(marker, { rows, snapshot: this.snapshotKey(), at: nowIso() });
      }
    }

    if (dataFile && opts.loadMode !== 'export') {
      // ora2pg wraps the file in one BEGIN ... COMMIT: a failed load leaves no rows behind, and the file
      // is kept so the retry only re-imports it.
      const load = await this.psqlFile(dataFile, `psql load ${label}`, { stopOnError: true, out });
      if (load.code !== 0) {
        const msg = firstError(load.errorTail) || 'psql load failed';
        // Bad values fail the same way every time: no retries, say what to fix. The file is kept either way.
        const dataError = /invalid input syntax|out of range|value too long|violates|invalid byte sequence|null value in column/i.test(msg);
        const err = new Error(dataError
          ? `${msg}. The data does not fit the target column: fix the mapping in Migration decisions and start a new run (it rebuilds the table with the new type).`
          : `${msg} (export kept: the retry re-imports it without reading Oracle again)`);
        err.noRetry = dataError;
        throw err;
      }
      await this.dropExport(t, fileTag);
    }
    return rows;
  }

  /**
   * Huge tables with a single-column numeric primary key are split into PK ranges of about
   * CHUNK_ROWS rows. Each chunk is its own ora2pg run (WHERE pk BETWEEN lo AND hi), several run at
   * once, and each one is verified against an Oracle count of its range. A failed chunk is
   * deleted and reloaded on its own: a network drop at 90% of a 300 GB table costs one chunk,
   * not the whole table. Shorter Oracle queries also avoid ORA-01555 (snapshot too old).
   */
  /**
   * LOB tables are the slowest part of a migration. With LOB locators (ora2pg's safe default) every
   * LOB costs extra round trips; measured on a CLOB table it is ~10x slower than fetching the LOBs
   * inline. Inline needs LONGREADLEN >= the largest LOB and reserves that much per row and LOB
   * column in each batch, so the largest LOB is measured first and the batch is sized to a memory
   * budget. Tables with LOBs over 16 MB, or LONG / XMLTYPE / BFILE columns, keep the locators.
   */
  async planLobs(t) {
    const conn = await oracleClient.getOracleConnection(this.projectName);
    try {
      const cols = (await conn.execute(
        `SELECT column_name, data_type FROM dba_tab_columns WHERE owner = :o AND table_name = :t
            AND data_type IN ('BLOB', 'CLOB', 'NCLOB', 'LONG', 'LONG RAW', 'XMLTYPE', 'BFILE')`,
        { o: this.state.schema, t: t.name })).rows;
      if (!cols.length || cols.some(([, type]) => !['BLOB', 'CLOB', 'NCLOB'].includes(type))) { t.lobPlan = { inline: false }; return; }
      const r = await conn.execute(`SELECT ${cols.map(([c]) => `NVL(MAX(DBMS_LOB.GETLENGTH(${qi(c)})), 0)`).join(', ')} FROM ${qi(this.state.schema)}.${qi(t.name)}${this.asOf()}`);
      // CLOB lengths are in characters: up to 4 bytes each in UTF-8.
      const maxBytes = Math.max(1, ...cols.map(([, type], i) => Number(r.rows[0][i]) * (type === 'BLOB' ? 1 : 4)));
      const limit = 16 * 1024 * 1024;
      if (maxBytes > limit) { t.lobPlan = { inline: false, maxBytes }; return; }
      let longReadLen = 65536;
      while (longReadLen < maxBytes) longReadLen *= 2;
      const budget = CONSTANTS.LOB_MEMORY_MB * 1024 * 1024;
      const batch = Math.max(1, Math.min(this.state.options.dataLimit, Math.floor(budget / (longReadLen * cols.length))));
      t.lobPlan = { inline: true, maxBytes, longReadLen, batch };
      this.event('info', `${t.name}: LOBs up to ${(maxBytes / 1048576).toFixed(1)} MB, fetched inline in batches of ${batch} rows`);
    } finally {
      await conn.close().catch(() => {});
    }
  }

  /** A copy of a data config that fetches LOBs inline (one per LONGREADLEN size). */
  async inlineLobConf(base, plan) {
    const file = base.replace(/\.conf$/, `_lob${plan.longReadLen}.conf`);
    if (!fs.existsSync(file)) {
      const c = (await fsp.readFile(base, 'utf8'))
        .replace(/^\s*(USE_LOB_LOCATOR|NO_LOB_LOCATOR|LONGREADLEN)\s.*$/gm, '')
        .concat(`\nUSE_LOB_LOCATOR\t0\nLONGREADLEN\t${plan.longReadLen}\n`);
      await fsp.writeFile(file, c, { mode: 0o600 });
    }
    return file;
  }

  /** Big by rows or by size (LOB tables are big in GB with few rows): loaded in chunks. */
  shouldChunk(t) {
    const o = this.state.options;
    return o.chunkRows > 0 && t.kind !== 'object' && ((t.estRows || 0) >= o.hugeTableRows || (t.sizeMb || 0) >= o.chunkMb);
  }

  /**
   * Splits a big table into chunks of about chunkRows rows / chunkMb MB:
   *  - single numeric primary key: key ranges (first/last open-ended);
   *  - anything else (GUID key, no key, LOB tables): ROWID ranges built from the table's extents,
   *    so every table can be split, even one without any key.
   */
  async planChunks(t) {
    const o = this.state.options;
    const n = Math.max(Math.ceil((t.estRows || 0) / o.chunkRows), Math.ceil((t.sizeMb || 0) / o.chunkMb));
    if (n < 2) { t.chunks = null; return; }
    const conn = await oracleClient.getOracleConnection(this.projectName);
    try {
      const pk = await conn.execute(
        `SELECT cc.column_name, tc.data_type
           FROM dba_constraints c
           JOIN dba_cons_columns cc ON cc.owner = c.owner AND cc.constraint_name = c.constraint_name
           JOIN dba_tab_columns tc ON tc.owner = cc.owner AND tc.table_name = cc.table_name AND tc.column_name = cc.column_name
          WHERE c.owner = :o AND c.table_name = :t AND c.constraint_type = 'P'`,
        { o: this.state.schema, t: t.name },
      );
      if (pk.rows.length === 1 && ['NUMBER', 'INTEGER', 'FLOAT'].includes(pk.rows[0][1])) {
        const col = pk.rows[0][0];
        const mm = await conn.execute(`SELECT MIN(${qi(col)}), MAX(${qi(col)}) FROM ${qi(this.state.schema)}.${qi(t.name)}`);
        const [min, max] = mm.rows[0].map(Number);
        if (Number.isFinite(min) && Number.isFinite(max)) {
          const width = Math.ceil((max - min + 1) / n);
          t.chunkKind = 'pk';
          t.chunkKey = col;
          t.chunks = [];
          for (let lo = Math.floor(min), i = 0; lo <= max; lo += width, i += 1) {
            t.chunks.push({ i, lo, hi: Math.min(lo + width - 1, Math.ceil(max)), status: 'pending', rows: 0, attempts: 0 });
          }
          // The first and last chunk are open-ended so rows outside MIN/MAX are never missed.
          t.chunks[0].open = 'low';
          t.chunks[t.chunks.length - 1].open = t.chunks.length === 1 ? 'both' : 'high';
          this.event('info', `${t.name}: ${t.chunks.length} chunks on ${col}`);
          this.save(true);
          return;
        }
      }
      // ROWID ranges: extents in ROWID order (object, file, block), grouped into n chunks of ~equal blocks.
      const ext = await conn.execute(
        `SELECT ROWIDTOCHAR(DBMS_ROWID.ROWID_CREATE(1, o.data_object_id, e.relative_fno, e.block_id, 0)),
                ROWIDTOCHAR(DBMS_ROWID.ROWID_CREATE(1, o.data_object_id, e.relative_fno, e.block_id + e.blocks - 1, 32767)),
                e.blocks
           FROM dba_extents e
           JOIN dba_objects o ON o.owner = e.owner AND o.object_name = e.segment_name
                             AND NVL(o.subobject_name, '#') = NVL(e.partition_name, '#') AND o.object_type LIKE 'TABLE%'
          WHERE e.owner = :o AND e.segment_name = :t AND e.segment_type LIKE 'TABLE%'
          ORDER BY o.data_object_id, e.relative_fno, e.block_id`,
        { o: this.state.schema, t: t.name },
      );
      if (ext.rows.length < 2) { t.chunks = null; return; }
      const total = ext.rows.reduce((sum, r) => sum + Number(r[2]), 0);
      const per = total / Math.min(n, ext.rows.length);
      const chunks = [];
      let cur = null;
      let acc = 0;
      for (const [lo, hi, blocks] of ext.rows) {
        if (!cur) cur = { i: chunks.length, lo, hi, blocks: 0, status: 'pending', rows: 0, attempts: 0 };
        cur.hi = hi;
        cur.blocks += Number(blocks);
        acc += Number(blocks);
        if (acc >= per * (chunks.length + 1) - 1e-9) { chunks.push(cur); cur = null; }
      }
      if (cur) chunks.push(cur);
      t.chunkKind = 'rowid';
      t.chunkKey = 'ROWID';
      t.chunks = chunks;
      this.event('info', `${t.name}: ${chunks.length} ROWID-range chunks (no single numeric key)`);
      this.save(true);
    } finally {
      await conn.close().catch(() => {});
    }
  }

  /** A part's rows in words, e.g. "ORDER_ID 5000001 to 10000000", for messages people read. */
  partRange(t, c) {
    if (t.chunkKind === 'rowid') return `${Number(c.blocks || 0).toLocaleString()} Oracle blocks by ROWID`;
    if (c.open === 'both') return 'all rows';
    if (c.open === 'low') return `${t.chunkKey} up to ${c.hi}`;
    if (c.open === 'high') return `${t.chunkKey} from ${c.lo}`;
    return `${t.chunkKey} ${c.lo} to ${c.hi}`;
  }

  /**
   * A table that finally failed is emptied: PostgreSQL never keeps half a table, and a chunked
   * table's parts all start again on Resume (the error names the parts that failed).
   */
  async emptyFailedTable(t) {
    if (this.state.options.loadMode === 'export') return;
    try {
      await pgClient.pgQuery(`TRUNCATE TABLE ${qi(this.pgSchema)}.${qi(this.pgName(t.name))}`, [], this.projectName);
    } catch (err) {
      this.log.error(`${t.name}: could not empty the failed table: ${err.message}`);
      return;
    }
    if (Array.isArray(t.chunks)) t.chunks.forEach((c) => Object.assign(c, { status: 'pending', dirty: false, rows: 0, rate: 0 }));
    t.rowsDone = 0;
    this.log.info(`${t.name}: emptied after the failure, so it is never left half loaded`);
  }

  /** WHERE clause of a chunk (quote = Oracle or PostgreSQL identifier quoting). */
  chunkWhere(t, c, quote) {
    if (t.chunkKind === 'rowid') return `ROWID BETWEEN CHARTOROWID('${c.lo}') AND CHARTOROWID('${c.hi}')`;
    const col = quote(t.chunkKey);
    if (c.open === 'both') return '1=1';
    if (c.open === 'low') return `${col} <= ${c.hi}`;
    if (c.open === 'high') return `${col} >= ${c.lo}`;
    return `${col} >= ${c.lo} AND ${col} <= ${c.hi}`;
  }

  updateChunkInfo(t) {
    const info = { total: t.chunks.length, done: 0, running: 0, failed: 0 };
    let rows = 0;
    let rate = 0;
    for (const c of t.chunks) {
      if (c.status === 'done' || c.status === 'exported') info.done += 1;
      if (c.status === 'running') { info.running += 1; rate += c.rate || 0; }
      if (c.status === 'failed') info.failed += 1;
      rows += c.rows || 0;
    }
    this.updateTable(t.name, { chunkInfo: info, rowsDone: rows, rate });
  }

  async loadChunked(t) {
    const opts = this.state.options;
    const pgCol = (c) => qi(this.pgName(c));
    const exportOnly = opts.loadMode === 'export';
    const finished = exportOnly ? 'exported' : 'done';
    const rowid = t.chunkKind === 'rowid';
    if (!exportOnly) {
      if (!t.chunks.some((c) => c.status === 'done')) await this.prepareTarget(t.name);
      else await this.dropReferencingFks(t.name);
    }
    this.checkCancelled();

    const out = this.log.tableLog(t.name);
    out.write(`\n===== ${nowIso()} attempt ${t.attempts} (chunked on ${t.chunkKey}) =====\n`);
    const limit = pLimit(Math.max(1, opts.oracleCopies));
    try {
      await Promise.all(t.chunks.filter((c) => c.status !== finished).map((c) => limit(async () => {
        if (this.cancelRequested) return;
        c.attempts += 1;
        // A key-range chunk that was started before (crash, failure) is deleted first: never duplicated.
        // ROWID chunks need no delete: each one is loaded from a file in a single transaction.
        if (c.dirty && !rowid && !exportOnly) {
          await pgClient.pgQuery(`DELETE FROM ${qi(this.pgSchema)}.${qi(this.pgName(t.name))} WHERE ${this.chunkWhere(t, c, pgCol)}`, [], this.projectName);
        }
        Object.assign(c, { status: 'running', dirty: true, rows: 0, rate: 0, error: null });
        this.save(true);
        this.updateChunkInfo(t);
        try {
          const rows = await this.copyTable(t, {
            out,
            where: this.chunkWhere(t, c, qi),
            fileTag: `c${c.i}`,
            viaFile: rowid,
            onRows: (r, rate) => { c.rows = r; c.rate = rate; this.updateChunkInfo(t); },
          });
          const expected = await this.oracleCount(t, this.chunkWhere(t, c, qi));
          if (rows !== expected) {
            if (exportOnly) await this.dropExport(t, `c${c.i}`);
            throw new Error(`chunk ${c.i}: ora2pg ${exportOnly ? 'exported' : 'loaded'} ${rows} rows, Oracle has ${expected}`);
          }
          Object.assign(c, { status: finished, rows, rate: 0, dirty: false });
        } catch (err) {
          if (this.cancelRequested) { c.status = 'pending'; return; }
          Object.assign(c, { status: 'failed', rate: 0, error: err.message });
          this.log.error(`${t.name} chunk ${c.i} (${c.lo}..${c.hi}) failed: ${err.message}`);
        } finally {
          this.save(true);
          this.updateChunkInfo(t);
        }
      })));
    } finally {
      out.end();
    }
    this.checkCancelled();
    const failed = t.chunks.filter((c) => c.status !== finished);
    if (failed.length) {
      failed.forEach((c) => { if (c.status === 'failed') c.status = 'pending'; });
      const err = new Error(`Part${failed.length === 1 ? '' : 's'} ${failed.slice(0, 5).map((c) => c.i + 1).join(', ')}${failed.length > 5 ? ', …' : ''} of ${t.chunks.length} failed (${this.partRange(t, failed[0])}): ${failed[0].error || 'see table log'}`);
      err.failedParts = failed.map((c) => ({ part: c.i + 1, of: t.chunks.length, rows: this.partRange(t, c), error: c.error || null }));
      throw err;
    }
    if (exportOnly) return;
    try {
      await this.verifyTable(t);
    } catch (err) {
      // Should not happen (every chunk was verified); reload everything on the next attempt.
      t.chunks.forEach((c) => Object.assign(c, { status: 'pending', dirty: false, rows: 0 }));
      throw err;
    }
    await this.verifyData(t);
  }

  /**
   * Tables ora2pg cannot copy correctly, read by the engine itself and loaded with \copy:
   *  - Oracle object tables (kind 'object'): each row goes into the TEXT-column fallback table;
   *  - tables with columns of user-defined object types (t.udt): object values are written as
   *    PostgreSQL composite literals "(street,city,…)", collections as arrays "{…}".
   * DATE / TIMESTAMP values are written as the wall-clock time Oracle holds (no timezone shift).
   */
  async loadObjectTable(t, out) {
    const conn = await oracleClient.getOracleConnection(this.projectName);
    const csv = path.join(this.dir, 'data', `${t.name}.csv`);
    const pad = (n, w = 2) => String(n).padStart(w, '0');
    const wallClock = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}:${pad(d.getSeconds())}.${pad(d.getMilliseconds(), 3)}`;
    const isDbObject = (v) => v && typeof v === 'object' && v.constructor && v.constructor.name === 'DbObject';
    const quote = (x) => `"${x.replace(/\\/g, '\\\\').replace(/"/g, '\\"')}"`;
    const asText = (v) => {
      if (v instanceof Date) return wallClock(v);
      if (Buffer.isBuffer(v)) return `\\x${v.toString('hex')}`;
      if (isDbObject(v)) {
        if (v.isCollection) return `{${v.getValues().map((e) => (e === null || e === undefined ? 'NULL' : quote(asText(e)))).join(',')}}`;
        return `(${Object.keys(v.attributes || {}).map((a) => (v[a] === null || v[a] === undefined ? '' : quote(asText(v[a])))).join(',')})`;
      }
      if (typeof v === 'object') return JSON.stringify(v);
      return String(v);
    };
    const cell = (v) => (v === null || v === undefined ? '' : `"${asText(v).replace(/"/g, '""')}"`);
    try {
      let select = '*';
      let target = `${qi(this.pgSchema)}.${qi(this.pgName(t.name))}`;
      if (t.kind !== 'object') {
        // Explicit columns, in order, without virtual columns (generated columns in PostgreSQL).
        const cols = (await conn.execute(
          `SELECT column_name FROM dba_tab_cols WHERE owner = :o AND table_name = :t AND hidden_column = 'NO' AND virtual_column = 'NO' ORDER BY column_id`,
          { o: this.state.schema, t: t.name })).rows.map((r) => r[0]);
        const renames = new Map((this.columnRenames || []).filter((r) => r.tableName === t.name).map((r) => [r.oldName, r.name]));
        select = cols.map((c) => qi(c)).join(', ');
        target += ` (${cols.map((c) => qi(renames.get(c) || this.pgName(c))).join(', ')})`;
      }
      const r = await conn.execute(`SELECT ${select} FROM ${qi(this.state.schema)}.${qi(t.name)}${this.asOf()}`, [], { resultSet: true, outFormat: oracledb.OUT_FORMAT_ARRAY });
      const ws = fs.createWriteStream(csv);
      let rows = 0;
      let batch;
      while ((batch = await r.resultSet.getRows(5000)).length) {
        this.checkCancelled();
        const chunk = batch.map((row) => row.map(cell).join(',')).join('\n') + '\n';
        if (!ws.write(chunk)) await new Promise((res) => ws.once('drain', res));
        rows += batch.length;
        this.updateTable(t.name, { rowsDone: rows });
      }
      await r.resultSet.close();
      await new Promise((res) => ws.end(res));
      const res = await executeAndLog({
        cmd: CONSTANTS.PSQL_BIN,
        args: this.psqlArgs(['-v', 'ON_ERROR_STOP=1', '-c', `\\copy ${target} FROM '${csv.replace(/'/g, "''")}' WITH (FORMAT csv)`]),
        env: this.psqlEnv(),
        log: this.log,
        out,
        children: this.children,
        label: `Copy ${t.kind === 'object' ? 'object table' : 'table with object types'} ${t.name}`,
      });
      if (res.code !== 0) throw new Error(firstError(res.errorTail) || 'psql \\copy failed');
    } finally {
      await conn.close().catch(() => {});
      await fsp.unlink(csv).catch(() => {});
    }
  }

  /** Compares the exact row count in Oracle and PostgreSQL. */
  async verifyTable(t) {
    const { rows } = await pgClient.pgQuery(`SELECT count(*)::bigint AS n FROM ${qi(this.pgSchema)}.${qi(this.pgName(t.name))}`, [], this.projectName);
    const pgRows = Number(rows[0].n);
    t.pgRows = pgRows;
    t.rowsDone = Math.max(t.rowsDone || 0, pgRows);
    if (!this.state.options.verifyRowCounts) return;

    const conn = await oracleClient.getOracleConnection(this.projectName);
    try {
      const r = await conn.execute(`SELECT /*+ PARALLEL(t, 4) */ COUNT(*) FROM ${qi(this.state.schema)}.${qi(t.name)}${this.asOf()} t`);
      t.oracleRows = Number(r.rows[0][0]);
    } finally {
      await conn.close().catch(() => {});
    }
    this.updateTable(t.name, { pgRows, oracleRows: t.oracleRows });
    if (t.oracleRows !== pgRows) {
      throw new Error(`Row count mismatch: Oracle ${t.oracleRows.toLocaleString()}, PostgreSQL ${pgRows.toLocaleString()}`);
    }
  }

  /**
   * Column checksums after the row count: per column, Oracle and PostgreSQL must agree on
   *   numbers:  SUM(column)                     (catches decimals cut by an integer mapping, booleans that were not 0/1)
   *   strings:  SUM(LENGTH(column))             (catches truncation, stripped or broken characters)
   *   LOBs:     SUM(DBMS_LOB.GETLENGTH(column)) (catches cut or empty LOBs)
   * Both sides read the same snapshot. CHAR (padding), dates (time zones) and floats are not compared.
   * A difference is a mapping problem, not a transient error: the table is failed without reloading.
   */
  async verifyData(t) {
    if (this.state.options.verifyData === 'off' || t.kind === 'object') return;
    const conn = await oracleClient.getOracleConnection(this.projectName);
    let oraCols;
    try {
      oraCols = (await conn.execute(
        `SELECT column_name, data_type FROM dba_tab_cols
          WHERE owner = :o AND table_name = :t AND hidden_column = 'NO' AND virtual_column = 'NO'
            AND data_type IN ('NUMBER', 'VARCHAR2', 'NVARCHAR2', 'CLOB', 'NCLOB', 'BLOB')
          ORDER BY column_id`, { o: this.state.schema, t: t.name })).rows;
      const pgTypes = new Map((await pgClient.pgQuery(
        `SELECT a.attname, format_type(a.atttypid, a.atttypmod) AS typ
           FROM pg_attribute a JOIN pg_class c ON c.oid = a.attrelid JOIN pg_namespace n ON n.oid = c.relnamespace
          WHERE n.nspname = $1 AND c.relname = $2 AND a.attnum > 0 AND NOT a.attisdropped`,
        [this.pgSchema, this.pgName(t.name)], this.projectName)).rows.map((r) => [r.attname, r.typ]));
      const renames = new Map((this.columnRenames || []).filter((r) => r.tableName === t.name).map((r) => [r.oldName, r.name]));
      const pairs = [];
      for (const [col, otype] of oraCols) {
        const pgCol = renames.get(col) || this.pgName(col);
        const typ = pgTypes.get(pgCol);
        if (!typ) continue;
        const ora = otype === 'NUMBER' ? `SUM(${qi(col)})` : /LOB$/.test(otype) ? `SUM(DBMS_LOB.GETLENGTH(${qi(col)}))` : `SUM(LENGTH(${qi(col)}))`;
        let pg;
        if (typ === 'boolean') pg = `sum(${qi(pgCol)}::int)`;
        else if (typ === 'bytea') pg = `sum(octet_length(${qi(pgCol)}))`;
        else if (/^(text|character varying)/.test(typ)) pg = otype === 'NUMBER' ? null : `sum(length(${qi(pgCol)}))`;
        else if (/^(numeric|bigint|integer|smallint)/.test(typ)) pg = `sum(${qi(pgCol)}::numeric)`;
        else if (/^(real|double precision)/.test(typ)) pg = `sum(${qi(pgCol)}::numeric)`;
        else pg = null;
        if (pg) pairs.push({ col, pgCol, typ, ora, pg, float: /^(real|double)/.test(typ) });
      }
      const diffs = [];
      for (let i = 0; i < pairs.length; i += 40) {
        const batch = pairs.slice(i, i + 40);
        const o = (await conn.execute(`SELECT /*+ PARALLEL(t, 4) */ ${batch.map((p) => `TO_CHAR(${p.ora})`).join(', ')} FROM ${qi(this.state.schema)}.${qi(t.name)}${this.asOf()} t`)).rows[0];
        const g = (await pgClient.pgQuery(`SELECT ${batch.map((p, k) => `(${p.pg})::text AS c${k}`).join(', ')} FROM ${qi(this.pgSchema)}.${qi(this.pgName(t.name))}`, [], this.projectName)).rows[0];
        batch.forEach((p, k) => {
          const a = normDecimal(o[k]);
          const b = normDecimal(g[`c${k}`]);
          const same = p.float ? Math.abs(Number(a) - Number(b)) <= 1e-9 * Math.max(1, Math.abs(Number(a))) : a === b;
          if (!same) diffs.push({ column: p.col, oracle: a, postgres: b, type: p.typ });
        });
      }
      t.dataCheck = { columns: pairs.length, ok: diffs.length === 0, diffs: diffs.slice(0, 10) };
      this.updateTable(t.name, { dataCheck: t.dataCheck }, true);
      if (diffs.length) {
        const d = diffs[0];
        const err = new Error(`Data check failed on ${diffs.length} column(s), e.g. ${d.column} (${d.type}): Oracle ${d.oracle}, PostgreSQL ${d.postgres}. Check the type mapping (Migration decisions) before reloading.`);
        err.noRetry = true;
        throw err;
      }
    } finally {
      await conn.close().catch(() => {});
    }
  }

  async runDdlPhase(key, files, { transform } = {}) {
    let warnings = 0;
    const failures = [];
    for (const [label, file] of files) {
      this.checkCancelled();
      this.updatePhase(key, { detail: label });
      const r = await runSqlFile({
        file,
        schema: this.pgSchema,
        parallel: this.state.options.ddlParallel,
        maintenanceWorkMem: this.state.options.maintenanceWorkMem,
        transform,
        log: this.log,
        label,
        shouldStop: () => this.cancelRequested,
        onProgress: (d, total) => this.updatePhase(key, { detail: `${label}: ${d}/${total}`, progress: Math.round((d / total) * 100) }),
      });
      warnings += r.failed.length;
      failures.push(...r.failed.map((f) => ({ step: label, ...f })));
      if (r.total) this.event(r.failed.length ? 'error' : 'info', `${label}: ${r.ok} created, ${r.skipped} already present, ${r.failed.length} failed`);
    }
    this.checkCancelled();
    this.state.ddlFailures = [...(this.state.ddlFailures || []).filter((f) => !files.some(([l]) => l === f.step)), ...failures].slice(-500);
    this.phase(key).warnings = warnings || undefined;
  }

  async phase_indexes() {
    if (this.settings.lob.blobAs === 'oid') await this.convertBlobsToOid();
    const dir = path.join(this.schemaDir, 'tables');
    const idx = fs.existsSync(path.join(dir, 'modified_INDEXES_table.sql')) ? 'modified_INDEXES_table.sql' : 'INDEXES_table.sql';
    await this.runDdlPhase('indexes', [
      ['Constraints (primary, unique, check)', path.join(dir, 'CONSTRAINTS_table.sql')],
      ['Indexes', path.join(dir, idx)],
    ]);
  }

  /**
   * Foreign keys in two steps, like EDB's loader: ADD ... NOT VALID is instant (no table scan, so
   * keys on the same parent do not wait for each other), then VALIDATE CONSTRAINT checks the
   * existing rows, in parallel, without blocking reads or writes. A key whose rows do not match
   * stays in place as NOT VALID (new rows are checked) and is reported with the reason.
   * Keys on partitioned tables are added in one step (PostgreSQL has no NOT VALID for them).
   */
  async phase_fkeys() {
    // PostgreSQL refuses NOT VALID keys on partitioned tables: those are added (and checked) in one step.
    const { rows: parts } = await pgClient.pgQuery(
      `SELECT c.relname FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace WHERE n.nspname = $1 AND c.relkind = 'p'`,
      [this.pgSchema], this.projectName,
    );
    const partitioned = new Set(parts.map((r) => r.relname));
    const tableOf = (stmt) => {
      const m = /^ALTER\s+TABLE\s+(?:ONLY\s+)?(?:(?:"[^"]+"|[\w$]+)\.)?("([^"]+)"|[\w$]+)/i.exec(stmt);
      return m ? (m[2] || m[1].toLowerCase()) : null;
    };
    const notValid = (stmt) => (/FOREIGN\s+KEY/i.test(stmt) && !/NOT\s+VALID/i.test(stmt) && !partitioned.has(tableOf(stmt))
      ? stmt.replace(/;\s*$/, ' NOT VALID;') : stmt);
    await this.runDdlPhase('fkeys', [['Foreign keys', path.join(this.schemaDir, 'tables', 'FKEYS_table.sql')]], { transform: notValid });
    this.checkCancelled();

    const tables = new Set(Object.keys(this.state.tables).map((n) => this.pgName(n)));
    const { rows } = await pgClient.pgQuery(
      `SELECT con.conname, cl.relname FROM pg_constraint con
         JOIN pg_class cl ON cl.oid = con.conrelid JOIN pg_namespace n ON n.oid = cl.relnamespace
        WHERE n.nspname = $1 AND con.contype = 'f' AND NOT con.convalidated AND con.conparentid = 0`,
      [this.pgSchema], this.projectName,
    );
    const todo = rows.filter((r) => tables.has(r.relname));
    const failures = [];
    let n = 0;
    const limit = pLimit(Math.max(1, this.state.options.ddlParallel));
    await Promise.all(todo.map((r) => limit(async () => {
      if (this.cancelRequested) return;
      const sql = `ALTER TABLE ${qi(this.pgSchema)}.${qi(r.relname)} VALIDATE CONSTRAINT ${qi(r.conname)}`;
      try {
        await pgClient.pgQuery(sql, [], this.projectName);
      } catch (err) {
        failures.push({ step: 'Validate foreign keys', statement: sql, error: err.message });
        this.log.error(`Validate foreign keys: ${err.message}\n    SQL: ${sql}`);
      }
      n += 1;
      this.updatePhase('fkeys', { detail: `Validating foreign keys ${n}/${todo.length}`, progress: Math.round((n / todo.length) * 100) });
    })));
    this.checkCancelled();
    if (todo.length) {
      this.event(failures.length ? 'error' : 'info', `Foreign keys validated: ${todo.length - failures.length} of ${todo.length}${failures.length ? `; ${failures.length} kept as NOT VALID because existing rows do not match (see the DDL failures)` : ''}`);
    }
    this.state.ddlFailures = [...(this.state.ddlFailures || []).filter((f) => f.step !== 'Validate foreign keys'), ...failures].slice(-500);
    if (failures.length) this.phase('fkeys').warnings = (this.phase('fkeys').warnings || 0) + failures.length;
  }

  async phase_sequences() {
    // Exported now (after the data load) so the values match the data that was copied.
    const dir = path.join(this.schemaDir, 'sequence_values');
    await fsp.mkdir(dir, { recursive: true });
    const res = await this.ora2pg(['-t', 'SEQUENCE_VALUES', '-c', this.ddlConf, '-b', dir, '-o', 'sequence_value.sql'], 'Export sequence values');
    if (res.code !== 0) {
      this.phase('sequences').warnings = 1;
      this.event('error', `Sequence values could not be exported: ${firstError(res.errorTail)}`);
      return;
    }
    await this.runDdlPhase('sequences', [['Sequence values', path.join(dir, 'sequence_value.sql')]]);
  }

  /**
   * Optional (Settings → BLOB storage = large objects): BLOB columns are loaded as bytea (fast,
   * streamed with COPY) and then converted in PostgreSQL with lo_from_bytea, so v1's lo_import
   * shell scripts (blob.sh) are not needed. Runs before the indexes so the full-text index helper
   * (fts_oid.sh) finds oid columns.
   */
  async convertBlobsToOid() {
    const loaded = Object.values(this.state.tables).filter((t) => t.status === 'done').map((t) => t.name);
    if (!loaded.length) return;
    const conn = await oracleClient.getOracleConnection(this.projectName);
    let cols;
    try {
      const r = await conn.execute(`SELECT table_name, column_name FROM dba_tab_columns WHERE owner = :o AND data_type = 'BLOB'`, { o: this.state.schema });
      cols = r.rows.filter((x) => loaded.includes(x[0]));
    } finally {
      await conn.close().catch(() => {});
    }
    let n = 0;
    for (const [table, column] of cols) {
      this.checkCancelled();
      this.updatePhase('indexes', { detail: `BLOB → large object: ${table}.${column}` });
      const { rows } = await pgClient.pgQuery(
        `SELECT format_type(a.atttypid, a.atttypmod) AS t FROM pg_attribute a JOIN pg_class c ON c.oid = a.attrelid JOIN pg_namespace n ON n.oid = c.relnamespace
          WHERE n.nspname = $1 AND c.relname = $2 AND a.attname = $3`,
        [this.pgSchema, this.pgName(table), this.pgName(column)], this.projectName);
      if (!rows.length || rows[0].t !== 'bytea') continue; // already converted (resume) or renamed
      try {
        await pgClient.pgQuery(`ALTER TABLE ${qi(this.pgSchema)}.${qi(this.pgName(table))} ALTER COLUMN ${qi(this.pgName(column))} TYPE oid USING lo_from_bytea(0, ${qi(this.pgName(column))})`, [], this.projectName);
        n += 1;
      } catch (err) {
        this.phase('indexes').warnings = (this.phase('indexes').warnings || 0) + 1;
        this.event('error', `BLOB → oid failed for ${table}.${column}: ${err.message}`);
      }
    }
    if (n) this.event('info', `${n} BLOB columns stored as large objects (oid)`);
  }

  /** Applies the converted GenAI package chosen for this run (Code objects page). */
  async phase_code() {
    if (!this.state.codePackageId) {
      this.phase('code').skipped = true;
      this.updatePhase('code', { detail: 'No converted package chosen: apply it later from Code objects' });
      return;
    }
    const r = await code.applyPackage(this.projectName, this.state.codePackageId, {
      pg: this.pg,
      pgSchema: this.pgSchema,
      log: this.log,
      children: this.children,
      runId: this.state.runId,
      shouldStop: () => this.cancelRequested,
      onProgress: (applied, total, pass) => this.updatePhase('code', { detail: `${applied}/${total} files applied (pass ${pass})`, progress: Math.round((applied / Math.max(1, total)) * 100) }),
    });
    this.state.codeResult = { packageId: this.state.codePackageId, applied: r.applied, existing: r.existing || 0, failed: r.failed.slice(0, 200), dbLinks: r.dbLinks };
    if (r.failed.length) this.phase('code').warnings = r.failed.length;
    this.event(r.failed.length ? 'error' : 'info', `Converted code: ${r.applied} files applied, ${r.failed.length} failed${r.dbLinks ? `, DB links: ${r.dbLinks}` : ''}`);
  }

  async phase_finalize() {
    // Safety net for bulk-load mode: no table is left unlogged or without autovacuum.
    for (const t of Object.values(this.state.tables).filter((x) => x.unlogged || x.autovacuumOff)) {
      await this.bulkFinish(t).catch((err) => {
        this.phase('finalize').warnings = (this.phase('finalize').warnings || 0) + 1;
        this.event('error', `${t.name}: could not be made permanent / autovacuum switched back on: ${err.message}`);
      });
    }
    const loaded = Object.values(this.state.tables).filter((t) => t.status === 'done');
    const limit = pLimit(Math.max(1, this.state.options.ddlParallel));
    let n = 0;
    await Promise.all(loaded.map((t) => limit(async () => {
      if (this.cancelRequested) return;
      await pgClient.pgQuery(`ANALYZE ${qi(this.pgSchema)}.${qi(this.pgName(t.name))}`, [], this.projectName)
        .catch((err) => this.log.error(`ANALYZE ${t.name}: ${err.message}`));
      n += 1;
      this.updatePhase('finalize', { detail: `ANALYZE ${n}/${loaded.length}`, progress: Math.round((n / Math.max(1, loaded.length)) * 100) });
    })));
    this.checkCancelled();
    // Application access (Settings → decisions): grants for the app roles and the optional DUAL view.
    const access = settingsSvc.accessSql(this.settings, this.pgSchema);
    let failed = 0;
    for (const sql of access) {
      await pgClient.pgQuery(sql, [], this.projectName).catch((err) => { failed += 1; this.log.error(`${sql}: ${err.message}`); });
    }
    if (access.length) {
      this.event(failed ? 'error' : 'info', `Application access: ${access.length - failed} grants applied${failed ? `, ${failed} failed (does the role exist?)` : ''}`);
      if (failed) this.phase('finalize').warnings = failed;
    }
    await store.writeJsonAtomic(path.join(this.dir, 'summary.json'), { ...this.summary(), tables: this.state.tables });
  }
}

/** A table as sent to the browser: the chunk list is replaced by its summary. */
function publicTable(t) {
  if (!t || !t.chunks) return t;
  const { chunks, ...rest } = t;
  return rest;
}

/** Decimal string from Oracle TO_CHAR / PostgreSQL ::text in one canonical form ('.50' -> '0.5'). */
/**
 * Fingerprint of everything that shapes the tables and the data files: names, type mapping, booleans,
 * LOB storage, target schema, column renames. A run is only resumed, and an export file only
 * re-imported, while this is unchanged.
 */
const isStalled = (err) => /stopped as hung/.test(err.message || '');

function decisionsHash(settings, meta) {
  return require('crypto').createHash('sha1').update(JSON.stringify({
    o: settings.ora2pg, x: settings.extraDirectives, l: settings.lob, t: settings.targetSchema, r: meta.columnRenames || [],
  })).digest('hex').slice(0, 12);
}

function normDecimal(v) {
  if (v === null || v === undefined) return null;
  let s = String(v).trim();
  const neg = s.startsWith('-');
  if (neg || s.startsWith('+')) s = s.slice(1);
  if (s.startsWith('.')) s = `0${s}`;
  if (s.includes('.')) s = s.replace(/0+$/, '').replace(/\.$/, '');
  s = s.replace(/^0+(?=\d)/, '');
  return (neg && s !== '0' ? '-' : '') + s;
}

/** Splits "a varchar(255), b numeric(10,2)" at the commas outside parentheses. */
function splitTopLevel(list) {
  const parts = [];
  let depth = 0;
  let cur = '';
  for (const ch of list) {
    if (ch === '(') depth += 1;
    if (ch === ')') depth -= 1;
    if (ch === ',' && depth === 0) { parts.push(cur.trim()); cur = ''; } else cur += ch;
  }
  if (cur.trim()) parts.push(cur.trim());
  return parts;
}

/**
 * Oracle type evolution in PostgreSQL syntax:
 *   ALTER TYPE t MODIFY ATTRIBUTE (a varchar(255), b ...) [CASCADE]  ->  ALTER TYPE t ALTER ATTRIBUTE a TYPE varchar(255), ...
 *   ALTER TYPE t ADD ATTRIBUTE (a int)                               ->  ALTER TYPE t ADD ATTRIBUTE a int
 *   ALTER TYPE t DROP ATTRIBUTE (a, b)                               ->  ALTER TYPE t DROP ATTRIBUTE a, DROP ATTRIBUTE b
 * Oracle-only options (INVALIDATE, INCLUDING TABLE DATA, ...) are dropped; CASCADE is kept.
 */
function pgTypeSql(text) {
  return text
    .replace(/^\s*\\set\s+ON_ERROR_STOP\s+ON\s*$/gim, '')
    .replace(/ALTER\s+TYPE\s+([\w$#."]+)\s+(MODIFY|ADD|DROP)\s+ATTRIBUTE\s*(\(([\s\S]*?)\)|([^;]*?))\s*((?:CASCADE|INVALIDATE|INCLUDING|NOT|TABLE|DATA|FORCE|CONVERT|TO|SUBSTITUTABLE|\s)*)\s*;/gi,
      (all, type, op, _p, inParens, bare, opts) => {
        const items = splitTopLevel(inParens !== undefined ? inParens : bare).filter(Boolean);
        if (!items.length) return all;
        const cascade = /\bCASCADE\b/i.test(opts || '') ? ' CASCADE' : '';
        const parts = items.map((item) => {
          const [, name, rest] = /^("[^"]+"|\S+)\s*([\s\S]*)$/.exec(item);
          if (/^MODIFY$/i.test(op)) return `ALTER ATTRIBUTE ${name} TYPE ${rest.trim()}${cascade}`;
          if (/^ADD$/i.test(op)) return `ADD ATTRIBUTE ${name} ${rest.trim()}${cascade}`;
          return `DROP ATTRIBUTE ${name}${cascade}`;
        });
        return `ALTER TYPE ${type} ${parts.join(', ')};`;
      });
}

function firstError(text) {
  if (!text) return '';
  const lines = String(text).split('\n').map((l) => l.trim()).filter(Boolean);
  return (lines.find((l) => /ERROR|FATAL|ORA-\d{5}/.test(l)) || lines[0] || '').slice(0, 500);
}

// ---------- public API ----------

/**
 * Classifies the selected tables from the snapshot (as v1 did: object, LOB, huge, normal).
 */
function buildTables(selected, snapshot, options) {
  const meta = new Map((snapshot.tableMetadata || []).map((t) => [t.name, t]));
  const lob = new Set((snapshot.lobTables || (snapshot.blobColumns || []).map((b) => b.tableName)) || []);
  const objects = new Set((snapshot.objectTables || []).map((o) => o.tableName || o));
  const tables = {};
  for (const name of selected) {
    // Oracle's materialized view log tables are internal (older snapshots still listed them).
    if (/^(MLOG|RUPD)\$/.test(name)) continue;
    const m = meta.get(name) || {};
    const estRows = Number(m.rowCount) || 0;
    const kind = objects.has(name) ? 'object' : lob.has(name) ? 'lob' : estRows >= options.hugeTableRows ? 'huge' : 'normal';
    tables[name] = { name, kind, estRows, sizeMb: Number(m.sizeMb) || 0, status: 'pending', attempts: 0, rowsDone: 0, rate: 0 };
  }
  return tables;
}

function normalizeOptions(o = {}) {
  const n = (v, d, min, max) => {
    const x = Number(v);
    return Number.isFinite(x) ? Math.min(max, Math.max(min, Math.round(x))) : d;
  };
  return {
    loadMode: ['direct', 'file', 'export'].includes(o.loadMode) ? o.loadMode : CONSTANTS.LOAD_MODE,
    parallelTables: n(o.parallelTables, CONSTANTS.PARALLEL_TABLES, 1, 32),
    hugeTableRows: n(o.hugeTableRows, CONSTANTS.HUGE_TABLE_ROWS, 1000, 1e12),
    oracleCopies: n(o.oracleCopies, CONSTANTS.ORACLE_COPIES, 1, 32),
    chunkRows: o.chunkRows === 0 || o.chunkRows === '0' ? 0 : n(o.chunkRows, CONSTANTS.CHUNK_ROWS, 100000, 1e10),
    pgJobs: n(o.pgJobs, CONSTANTS.PG_JOBS, 1, 32),
    dataLimit: n(o.dataLimit, CONSTANTS.DATA_LIMIT, 100, 1000000),
    blobLimit: n(o.blobLimit, CONSTANTS.BLOB_LIMIT, 1, 100000),
    maxAttempts: n(o.maxAttempts, CONSTANTS.MAX_ATTEMPTS, 1, 10),
    ddlParallel: n(o.ddlParallel, CONSTANTS.DDL_PARALLEL, 1, 32),
    maintenanceWorkMem: /^\d+(kB|MB|GB)$/.test(o.maintenanceWorkMem || '') ? o.maintenanceWorkMem : CONSTANTS.MAINTENANCE_WORK_MEM,
    verifyRowCounts: o.verifyRowCounts === undefined ? CONSTANTS.VERIFY_ROW_COUNTS : !!o.verifyRowCounts,
    chunkMb: n(o.chunkMb, CONSTANTS.CHUNK_MB, 64, 1e7),
    stallMinutes: o.stallMinutes === 0 || o.stallMinutes === '0' ? 0 : n(o.stallMinutes, CONSTANTS.STALL_MINUTES, 1, 1440),
    verifyData: ['all', 'off'].includes(o.verifyData) ? o.verifyData : CONSTANTS.VERIFY_DATA,
    snapshot: ['on', 'off'].includes(o.snapshot) ? o.snapshot : CONSTANTS.SNAPSHOT,
    bulkLoad: ['standard', 'unlogged'].includes(o.bulkLoad) ? o.bulkLoad : CONSTANTS.BULK_LOAD,
  };
}

function launch(projectName, state) {
  const run = new Run(projectName, state);
  active.set(projectName, run);
  run.save(true);
  // The job keeps the project context for cache / pool lookups deep in the call stack.
  runWithProject(projectName, () => run.execute()).catch((err) => logger.error(`Run crashed: ${err.stack}`));
  return run;
}

async function startRun(projectName, { tables, options, allTablesSelected, codePackageId, startedBy, notifyEmails }) {
  if (active.has(projectName)) {
    const err = new Error('A migration is already running for this project.');
    err.status = 409;
    throw err;
  }
  const meta = await store.readMeta(projectName);
  const schema = meta && meta.selectedSchema;
  if (!schema) throw Object.assign(new Error('Select a schema first.'), { status: 400 });
  const snapshot = await store.readSnapshot(projectName, schema);
  if (!snapshot) throw Object.assign(new Error('Take the schema snapshot first.'), { status: 400 });

  const settings = settingsSvc.resolve(meta);
  const opts = normalizeOptions({ ...settings.engine, ...(options || {}) });
  if (codePackageId && !(await code.readPackage(projectName, codePackageId))) {
    throw Object.assign(new Error('The selected converted package does not exist.'), { status: 400 });
  }
  const runId = new Date().toISOString().replace(/[-:]/g, '').replace(/\..+/, '').replace('T', '-');
  const state = {
    runId,
    projectName,
    schema,
    targetSchema: settings.targetSchema || schema.toLowerCase(),
    preserveCase: !!settings.ora2pg.PRESERVE_CASE,
    decisionsHash: decisionsHash(settings, meta),
    codePackageId: codePackageId || null,
    status: 'QUEUED',
    attempt: 1,
    createdAt: nowIso(),
    startedBy: startedBy || null,
    notifyEmails: notifyEmails || [], // "Notify me when it ends" (Migrate page)
    startedAt: null,
    finishedAt: null,
    options: opts,
    allTablesSelected: !!allTablesSelected,
    phases: PHASES.map((p) => ({ key: p.key, label: p.label, status: 'pending', progress: 0 })),
    tables: buildTables(tables, snapshot, opts),
    events: [],
    error: null,
  };
  await store.updateMeta(projectName, (m) => ({ ...m, migrationStatus: 'RUNNING', currentMigrationId: runId, lastMigrationDate: state.createdAt }));
  return launch(projectName, state).summary();
}

async function readRunState(projectName, runId) {
  const run = active.get(projectName);
  if (run && run.state.runId === runId) return run.state;
  return store.readJson(path.join(runDirOf(projectName, runId), 'state.json'));
}

async function resumeRun(projectName, runId, { tables: onlyTables, options, codePackageId } = {}) {
  if (active.has(projectName)) throw Object.assign(new Error('A migration is already running for this project.'), { status: 409 });
  const state = await readRunState(projectName, runId);
  if (!state) throw Object.assign(new Error('Run not found.'), { status: 404 });
  if (!TERMINAL.has(state.status)) throw Object.assign(new Error(`Run is ${state.status}.`), { status: 409 });

  const meta = await store.readMeta(projectName);
  const current = decisionsHash(settingsSvc.resolve(meta), meta);
  if (state.decisionsHash && state.decisionsHash !== current) {
    throw Object.assign(new Error('The migration decisions (names, type mapping, booleans, LOBs, target schema or column renames) changed since this run started. Its tables and files follow the old ones: start a new run, which rebuilds the tables with the new mapping.'), { status: 409 });
  }
  state.attempt = (state.attempt || 1) + 1;
  state.finishedAt = null;
  state.error = null;
  if (options) state.options = normalizeOptions({ ...state.options, ...options });
  if (codePackageId !== undefined) state.codePackageId = codePackageId || null;
  for (const t of Object.values(state.tables)) {
    const retry = onlyTables ? onlyTables.includes(t.name) : t.status !== 'done';
    if (retry) {
      Object.assign(t, { status: 'pending', attempts: 0, error: null, rate: 0 });
      // Chunks already loaded stay loaded; the rest is reloaded.
      (t.chunks || []).forEach((c) => { if (c.status !== 'done') Object.assign(c, { status: 'pending', rate: 0 }); });
    }
  }
  for (const p of state.phases) {
    if (!(KEEP_ON_RESUME.has(p.key) && p.status === 'done')) Object.assign(p, { status: 'pending', progress: 0, warnings: undefined, detail: null });
  }
  return launch(projectName, state).summary();
}

function cancelRun(projectName, runId) {
  const run = active.get(projectName);
  if (!run || run.state.runId !== runId) return false;
  run.cancel();
  return true;
}

async function listRuns(projectName) {
  const dir = store.runsDir(projectName);
  if (!fs.existsSync(dir)) return [];
  const ids = (await fsp.readdir(dir)).sort().reverse();
  const runs = [];
  for (const id of ids) {
    const s = await readRunState(projectName, id);
    if (!s) continue;
    const run = new Run(projectName, s);
    const { events: _e, ...summary } = run.summary();
    runs.push(summary);
  }
  return runs;
}

/** Full state of the running run (tables without their chunk lists), or null. */
function activeRunSummary(projectName) {
  const run = active.get(projectName);
  return run ? browserState(run.state) : null;
}

function browserState(state) {
  if (!state) return state;
  return { ...state, tables: Object.fromEntries(Object.entries(state.tables).map(([k, t]) => [k, publicTable(t)])) };
}

/** Stops ora2pg / psql process groups left over from a crashed server (checked by command name). */
function stopLeftoverProcesses(pids) {
  if (process.platform === 'win32') return;
  const { execFileSync } = require('child_process');
  for (const pid of pids) {
    try {
      const cmd = execFileSync('ps', ['-o', 'command=', '-p', String(pid)], { encoding: 'utf8' }).trim();
      if (!/ora2pg|psql|docker/.test(cmd)) continue;
      process.kill(-pid, 'SIGTERM');
      logger.warn(`Stopped leftover process group ${pid} (${cmd.slice(0, 80)})`);
    } catch { /* not running any more */ }
  }
}

/** At start-up: runs that were RUNNING when the server stopped are marked INTERRUPTED. */
async function recoverInterruptedRuns() {
  const projects = await store.listProjects();
  for (const p of projects) {
    const dir = store.runsDir(p.projectName);
    if (!fs.existsSync(dir)) continue;
    for (const id of await fsp.readdir(dir)) {
      const file = path.join(dir, id, 'state.json');
      const s = await store.readJson(file);
      if (s && !TERMINAL.has(s.status)) {
        stopLeftoverProcesses(s.pids || []);
        s.pids = [];
        for (const t of Object.values(s.tables)) {
          if (t.status === 'running') Object.assign(t, { status: 'pending', rate: 0 });
          (t.chunks || []).forEach((c) => { if (c.status === 'running') Object.assign(c, { status: 'pending', rate: 0 }); });
        }
        for (const ph of s.phases) if (ph.status === 'running') ph.status = 'pending';
        s.status = 'INTERRUPTED';
        s.error = 'The server stopped while this run was in progress. Press Resume to continue where it stopped.';
        s.finishedAt = nowIso();
        await store.writeJsonAtomic(file, s);
        await store.updateMeta(p.projectName, (m) => ({ ...m, migrationStatus: 'INTERRUPTED' }));
        logger.warn(`Run ${p.projectName}/${id} marked INTERRUPTED`);
      }
    }
  }
}

function runLogPath(projectName, runId, kind, table) {
  const base = path.join(runDirOf(projectName, runId), 'logs');
  if (kind === 'table') return path.join(base, 'tables', `${String(table).replace(/[^A-Za-z0-9_$#.-]/g, '_')}.log`);
  return path.join(base, `${kind}.log`);
}

function shutdown() {
  for (const run of active.values()) {
    run.shutdownRequested = true;
    run.cancelRequested = true;
    for (const child of run.children) killProcessTree(child);
  }
}

module.exports = {
  PHASES,
  normalizeOptions,
  startRun,
  resumeRun,
  cancelRun,
  listRuns,
  readRunState,
  activeRunSummary,
  publicTable,
  browserState,
  recoverInterruptedRuns,
  runLogPath,
  runDirOf,
  shutdown,
  pgTypeSql,
};
