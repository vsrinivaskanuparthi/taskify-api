'use strict';

const nodemailer = require('nodemailer');
const logger = require('../utils/logger');
const secrets = require('../utils/secrets');
const store = require('./projectStore');

/**
 * Run notifications by email and Google Chat (Settings → Notifications), so a 15-hour run
 * does not need someone watching the screen.
 *   start      a run started (off by default)
 *   attention  a table failed after all its attempts, or a hung load was stopped
 *              (at most one message per 10 minutes per run; the rest are grouped into the next one)
 *   finish     a run ended: completed, completed with errors, failed, exported, cancelled, interrupted
 * Email goes through the SMTP server in backend/.env (SMTP_HOST ...). Google Chat uses a space's
 * incoming webhook (space → Apps & integrations → Webhooks); the messages of one run are kept in
 * one thread of the space.
 */
const ATTENTION_EVERY_MS = 10 * 60 * 1000;
const COLORS = { good: 'Good', warning: 'Warning', attention: 'Attention', accent: 'Accent' };

let transport = null;
function mailer() {
  if (!process.env.SMTP_HOST) return null;
  if (!transport) {
    transport = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT) || 25,
      secure: process.env.SMTP_SECURE === 'true',
      auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASSWORD || '' } : undefined,
      tls: { rejectUnauthorized: process.env.SMTP_TLS_REJECT_UNAUTHORIZED !== 'false' },
    });
  }
  return transport;
}

function defaults() {
  return { emails: '', webhook: '', onStart: false, onAttention: true, onFinish: true };
}

/** Saved notification settings, with the webhook URL decrypted. */
function resolve(meta) {
  const n = { ...defaults(), ...((meta && meta.settings && meta.settings.notify) || {}) };
  if (n.webhook && n.webhook.startsWith('v1:')) {
    try { n.webhook = secrets.decrypt(n.webhook); } catch { n.webhook = ''; }
  }
  return n;
}

const EMAIL = /^[^\s@,;]+@[^\s@,;]+\.[^\s@,;]+$/;
function emailList(text) {
  return String(text || '').split(/[,;\s]+/).map((e) => e.trim()).filter(Boolean);
}

/** Validates the Notifications section of a settings payload. `current` keeps a masked webhook. */
function validate(input = {}, current = defaults()) {
  const emails = emailList(input.emails);
  const bad = emails.find((e) => !EMAIL.test(e));
  if (bad) return { error: `Notifications: "${bad}" is not an email address.` };
  let webhook = String(input.webhook || '').trim();
  if (webhook.startsWith('••••')) webhook = current.webhook || '';
  // https only; plain http just for a listener on this server (local testing).
  if (webhook && !/^(https:\/\/\S+|http:\/\/(localhost|127\.0\.0\.1)(:\d+)?\/\S*)$/.test(webhook)) return { error: 'Notifications: the Google Chat webhook must be an https:// URL (https://chat.googleapis.com/v1/spaces/…).' };
  return {
    notify: {
      emails: emails.join(', '),
      webhook: webhook ? secrets.encrypt(webhook) : '',
      onStart: !!input.onStart,
      onAttention: input.onAttention !== false,
      onFinish: input.onFinish !== false,
    },
  };
}

/** For the browser: the webhook URL is never sent back, only that one is set. */
function publicView(n) {
  return { ...n, webhook: n.webhook ? `••••${n.webhook.slice(-6)}` : '' };
}

function channels() {
  return { email: !!process.env.SMTP_HOST, from: process.env.SMTP_FROM || '' };
}

/**
 * Sends one message to the configured channels. msg = { title, color, facts: [[k, v]], text, link }.
 * Returns { email, webhook } with 'sent', 'off' or the error text.
 */
async function deliver(n, msg) {
  const result = { email: 'off', webhook: 'off' };
  const to = emailList(n.emails);
  if (to.length) {
    const m = mailer();
    if (!m) {
      result.email = 'SMTP is not configured on the server (SMTP_HOST in backend/.env)';
    } else {
      try {
        await m.sendMail({ from: process.env.SMTP_FROM || process.env.SMTP_USER || 'dma@localhost', to: to.join(', '), subject: msg.title, text: plainText(msg), html: html(msg) });
        result.email = 'sent';
      } catch (err) {
        result.email = err.message;
      }
    }
  }
  if (n.webhook) {
    try {
      const res = await fetch(chatUrl(n.webhook, !!msg.thread), { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(chatCard(msg)), signal: AbortSignal.timeout(15000) });
      result.webhook = res.ok ? 'sent' : `HTTP ${res.status} ${(await res.text().catch(() => '')).slice(0, 200)}`;
    } catch (err) {
      result.webhook = err.message;
    }
  }
  return result;
}

/**
 * Who gets one message. The project's channels (Settings → Notifications) follow its on/off
 * switches; extraEmails are the run's own recipients ("Notify me when it ends" on the Migrate
 * page): they get the attention and finish messages whatever the project's switches say.
 */
function recipientsFor(project, kind, extraEmails = []) {
  const on = { start: project.onStart, attention: project.onAttention, finish: project.onFinish }[kind];
  const extra = kind === 'start' ? [] : extraEmails;
  return on
    ? { ...project, emails: [...new Set([...emailList(project.emails), ...extra])].join(', ') }
    : { ...project, emails: extra.join(', '), webhook: '' };
}

async function send(projectName, kind, msg, extraEmails = []) {
  try {
    const meta = await store.readMeta(projectName);
    const n = recipientsFor(resolve(meta), kind, extraEmails);
    if (!n.emails && !n.webhook) return null;
    const r = await deliver(n, msg);
    for (const [ch, v] of Object.entries(r)) if (v !== 'sent' && v !== 'off') logger.error(`Notification (${ch}) for ${projectName}: ${v}`);
    return r;
  } catch (err) {
    logger.error(`Notification for ${projectName} failed: ${err.message}`);
    return null;
  }
}

function runLink(projectName, runId) {
  const base = (process.env.APP_URL || '').replace(/\/+$/, '');
  return base ? `${base}/projects/${encodeURIComponent(projectName)}/runs/${runId}` : null;
}

/**
 * Per-run notifier used by the migration engine. Attention items are grouped: the first goes out
 * at once, later ones at most every 10 minutes; anything still waiting goes into the final message.
 */
class RunNotifier {
  constructor(projectName, runId, extraEmails = []) {
    this.projectName = projectName;
    this.runId = runId;
    this.extraEmails = extraEmails;
    this.pending = [];
    this.lastSent = 0;
    this.timer = null;
  }

  base(title, color, facts, text) {
    return { title: `[DMA] ${this.projectName}: ${title}`, status: title, color, facts, text, link: runLink(this.projectName, this.runId), thread: `dma-${this.projectName}-${this.runId}` };
  }

  started(state) {
    const n = Object.keys(state.tables).length;
    send(this.projectName, 'start', this.base(`migration ${state.attempt > 1 ? 'resumed' : 'started'}`, COLORS.accent,
      [['Schema', `${state.schema} → ${state.targetSchema}`], ['Run', this.runId], ['Tables', String(n)], ['Load mode', state.options.loadMode]]));
  }

  attention(line) {
    this.pending.push(line);
    if (this.timer) return;
    const wait = Math.max(0, this.lastSent + ATTENTION_EVERY_MS - Date.now());
    this.timer = setTimeout(() => this.flush(), wait);
    if (this.timer.unref) this.timer.unref();
  }

  flush() {
    clearTimeout(this.timer);
    this.timer = null;
    if (!this.pending.length) return;
    const items = this.pending.splice(0);
    this.lastSent = Date.now();
    send(this.projectName, 'attention', this.base(`needs attention (${items.length})`, COLORS.warning,
      [['Run', this.runId]], items.slice(0, 20).join('\n') + (items.length > 20 ? `\n… and ${items.length - 20} more` : '')), this.extraEmails);
  }

  finished(state, totals) {
    clearTimeout(this.timer);
    this.timer = null;
    const waiting = this.pending.splice(0);
    const color = state.status === 'COMPLETED' || state.status === 'EXPORTED' ? COLORS.good
      : state.status === 'COMPLETED_WITH_ERRORS' || state.status === 'CANCELLED' ? COLORS.warning : COLORS.attention;
    const failed = Object.values(state.tables).filter((t) => t.status === 'failed');
    const ms = new Date(state.finishedAt || Date.now()) - new Date(state.startedAt || state.createdAt);
    const lines = [];
    if (state.error) lines.push(state.error);
    if (failed.length) lines.push(`Failed tables:\n${failed.slice(0, 15).map((t) => `• ${t.name}: ${(t.error || '').split('\n')[0].slice(0, 200)}`).join('\n')}${failed.length > 15 ? `\n… and ${failed.length - 15} more` : ''}`);
    const warn = state.phases.filter((p) => p.warnings).map((p) => `${p.label}: ${p.warnings} warning(s)`);
    if (warn.length) lines.push(warn.join('\n'));
    if (waiting.length) lines.push(`Also during the run:\n${waiting.slice(0, 10).join('\n')}`);
    return send(this.projectName, 'finish', this.base(`migration ${state.status.replace(/_/g, ' ').toLowerCase()}`, color, [
      ['Schema', `${state.schema} → ${state.targetSchema}`],
      ['Run', this.runId],
      ['Duration', duration(ms)],
      ['Tables', `${totals.done} done, ${totals.failed} failed of ${totals.tables}`],
      ['Rows', Number(totals.rowsDone || 0).toLocaleString('en-US')],
    ], lines.join('\n\n')), this.extraEmails);
  }
}

function duration(ms) {
  const m = Math.round(ms / 60000);
  return m >= 60 ? `${Math.floor(m / 60)} h ${m % 60} min` : `${m} min`;
}

function plainText(msg) {
  return [msg.title, '', ...(msg.facts || []).map(([k, v]) => `${k}: ${v}`), '', msg.text || '', msg.link ? `\nOpen: ${msg.link}` : ''].join('\n');
}

const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
const HEX = { Good: '#15803d', Warning: '#b45309', Attention: '#b91c1c', Accent: '#1d4ed8' };

function html(msg) {
  const facts = (msg.facts || []).map(([k, v]) => `<tr><td style="padding:4px 16px 4px 0;color:#64748b">${esc(k)}</td><td style="padding:4px 0;font-weight:600">${esc(v)}</td></tr>`).join('');
  return `<div style="font-family:Segoe UI,Arial,sans-serif;font-size:14px;color:#0f172a;max-width:640px">
  <div style="border-left:4px solid ${HEX[msg.color] || '#1d4ed8'};padding:4px 0 4px 12px;font-size:17px;font-weight:700">${esc(msg.title)}</div>
  <table style="margin:14px 0;border-collapse:collapse">${facts}</table>
  ${msg.text ? `<pre style="white-space:pre-wrap;font-family:inherit;background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;padding:12px">${esc(msg.text)}</pre>` : ''}
  ${msg.link ? `<p><a href="${esc(msg.link)}" style="color:#1d4ed8;font-weight:600">${esc(msg.linkTitle || 'Open the run')}</a></p>` : ''}
  <p style="color:#94a3b8;font-size:12px">Database Migration Accelerator</p></div>`;
}

/** Google Chat card (cardsV2). Text widgets accept a few HTML tags, so values are escaped. */
function chatCard(msg) {
  const widgets = [
    { textParagraph: { text: `<font color="${HEX[msg.color] || '#1d4ed8'}"><b>${esc(msg.status || '')}</b></font>` } },
    ...(msg.facts || []).map(([k, v]) => ({ decoratedText: { topLabel: esc(k), text: esc(v), wrapText: true } })),
  ].filter((w) => !w.textParagraph || msg.status);
  if (msg.text) widgets.push({ textParagraph: { text: esc(msg.text).replace(/\n/g, '<br>') } });
  if (msg.link) widgets.push({ buttonList: { buttons: [{ text: msg.linkTitle || 'Open the run', onClick: { openLink: { url: msg.link } } }] } });
  const body = {
    cardsV2: [{ cardId: 'dma', card: { header: { title: msg.title, subtitle: 'Database Migration Accelerator' }, sections: [{ widgets }] } }],
  };
  // All messages of one run go into one thread of the space.
  if (msg.thread) body.thread = { threadKey: msg.thread };
  return body;
}

/** Thread replies need this option on the webhook URL (the URL from Google Chat does not have it). */
function chatUrl(url, threaded) {
  if (!threaded || /messageReplyOption=/.test(url)) return url;
  return `${url}${url.includes('?') ? '&' : '?'}messageReplyOption=REPLY_MESSAGE_FALLBACK_TO_NEW_THREAD`;
}

/** Settings → Notifications → "Send a test": uses the values on screen, saved or not. */
async function test(projectName, input) {
  const meta = await store.readMeta(projectName);
  const current = resolve(meta);
  const v = validate(input, current);
  if (v.error) return { error: v.error };
  const n = { ...v.notify, webhook: v.notify.webhook ? secrets.decrypt(v.notify.webhook) : '' };
  if (!n.emails && !n.webhook) return { error: 'Enter an email address or a Google Chat webhook first.' };
  const result = await deliver(n, {
    title: `[DMA] ${projectName}: test notification`,
    color: COLORS.accent,
    facts: [['Project', projectName], ['Sent', new Date().toISOString()]],
    text: 'Notifications work. Run messages will arrive here.',
    link: (runLink(projectName, 'latest') || '').replace(/\/runs\/latest$/, '') || null,
    linkTitle: 'Open the project',
  });
  return { result };
}

module.exports = { RunNotifier, resolve, validate, publicView, channels, test, defaults, recipientsFor };
