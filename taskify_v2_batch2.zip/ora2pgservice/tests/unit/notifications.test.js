'use strict';

// Who gets a run message, and the bell's list of recent runs.
const fs = require('fs');
const os = require('os');
const path = require('path');

const staging = fs.mkdtempSync(path.join(os.tmpdir(), 'dma-bell-'));
process.env.MIGRATION_STAGING_DIR = staging;
const { recipientsFor } = require('../../services/notify');
const { recentRuns } = require('../../services/recentRuns');
const settings = require('../../services/settings');

afterAll(() => fs.rmSync(staging, { recursive: true, force: true }));

describe('recipientsFor', () => {
  const project = { emails: 'dba@x.com', webhook: 'https://chat', onStart: false, onAttention: true, onFinish: true };

  test('finish: project recipients plus "Email me when it ends", without duplicates', () => {
    const n = recipientsFor(project, 'finish', ['me@x.com', 'dba@x.com']);
    expect(n.emails).toBe('dba@x.com, me@x.com');
    expect(n.webhook).toBe('https://chat');
  });

  test('start: the run\'s own address is not used (only attention and finish)', () => {
    const n = recipientsFor(project, 'start', ['me@x.com']);
    expect(n.emails).toBe('');
    expect(n.webhook).toBe('');
  });

  test('project messages switched off: only the run\'s own address, no Google Chat', () => {
    const n = recipientsFor({ ...project, onFinish: false }, 'finish', ['me@x.com']);
    expect(n.emails).toBe('me@x.com');
    expect(n.webhook).toBe('');
  });
});

describe('recentRuns (the bell)', () => {
  const run = (project, id, state) => {
    const dir = path.join(staging, project, 'runs', id);
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(path.join(staging, project, 'project_meta.json'), JSON.stringify({ projectName: project, appName: 'A', appCode: 'A', createdAt: '2026-11-01T00:00:00Z' }));
    fs.writeFileSync(path.join(dir, 'state.json'), JSON.stringify({ runId: id, ...state }));
  };
  const now = Date.now();
  const iso = (msAgo) => new Date(now - msAgo).toISOString();

  test('running and recently ended runs, newest first (a running one started 10 min ago is newer); old ones left out', async () => {
    run('P1', '20261101-100000', { status: 'COMPLETED', startedAt: iso(30 * 86400000), finishedAt: iso(30 * 86400000), tables: {} });
    run('P1', '20261103-100000', { status: 'COMPLETED', startedAt: iso(7200000), finishedAt: iso(3600000), startedBy: { id: 'NG1' },
      tables: { A: { status: 'done' }, B: { status: 'failed' } } });
    run('P2', '20261103-110000', { status: 'RUNNING', startedAt: iso(600000), finishedAt: null, tables: { C: { status: 'running' } } });
    const items = await recentRuns();
    expect(items.map((i) => `${i.projectName}/${i.runId}`)).toEqual(['P2/20261103-110000', 'P1/20261103-100000']);
    expect(items[1]).toMatchObject({ status: 'COMPLETED', tables: 2, done: 1, failed: 1, startedBy: 'NG1' });
  });
});

describe('settings', () => {
  test('DMA chooses the speed by default', () => {
    expect(settings.defaults().engine.auto).toBe(true);
  });
});
