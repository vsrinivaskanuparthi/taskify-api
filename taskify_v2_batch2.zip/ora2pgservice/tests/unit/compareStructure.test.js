'use strict';

// Structure validation: Oracle columns against PostgreSQL columns.
const { compareColumns } = require('../../queries/pg/compareStructure');

const o = (column, type, extra = {}) => ({ table: 'ORDERS', column, type, length: null, precision: null, scale: null, nullable: true, hasDefault: false, ...extra });
const p = (column, type, extra = {}) => ({ table: 'orders', column, type, length: null, precision: null, scale: null, nullable: true, hasDefault: false, ...extra });
const problemOf = (rows, column) => rows.find((r) => r[1] === column)[4];

describe('compareColumns', () => {
  test('matching columns are fine', () => {
    const rows = compareColumns(
      [o('ID', 'NUMBER', { precision: 10, scale: 0, nullable: false }), o('NAME', 'VARCHAR2', { length: 100 }), o('CREATED', 'DATE')],
      [p('id', 'bigint', { nullable: false }), p('name', 'character varying', { length: 100 }), p('created', 'timestamp without time zone')],
    );
    expect(rows.every((r) => r[5] === 'yes')).toBe(true);
    expect(rows.find((r) => r[1] === 'name').slice(2, 4)).toEqual(['VARCHAR2(100)', 'character varying(100)']);
  });

  test('missing column, and a column only PostgreSQL has', () => {
    const rows = compareColumns([o('ID', 'NUMBER'), o('NOTE', 'VARCHAR2', { length: 10 })], [p('id', 'numeric'), p('extra', 'text')]);
    expect(problemOf(rows, 'note')).toBe('Column missing in PostgreSQL');
    expect(problemOf(rows, 'extra')).toMatch(/Only in PostgreSQL/);
  });

  test('shorter text, cut decimals, fewer digits', () => {
    const rows = compareColumns(
      [o('NAME', 'VARCHAR2', { length: 255 }), o('PRICE', 'NUMBER', { precision: 10, scale: 2 }), o('QTY', 'NUMBER', { precision: 12, scale: 0 })],
      [p('name', 'character varying', { length: 45 }), p('price', 'integer'), p('qty', 'numeric', { precision: 8, scale: 0 })],
    );
    expect(problemOf(rows, 'name')).toMatch(/Shorter in PostgreSQL \(45 < 255\)/);
    expect(problemOf(rows, 'price')).toMatch(/Decimals would be cut/);
    expect(problemOf(rows, 'qty')).toMatch(/Fewer digits \(8 < 12\)/);
  });

  test('different kind of type, NOT NULL and default differences', () => {
    const rows = compareColumns(
      [o('CODE', 'VARCHAR2', { length: 5, nullable: false, hasDefault: true }), o('FLAG', 'NUMBER', { precision: 1, scale: 0 })],
      [p('code', 'integer', { nullable: true }), p('flag', 'smallint', { nullable: false })],
    );
    expect(problemOf(rows, 'code')).toMatch(/Different kind of type \(text in Oracle, number in PostgreSQL\)/);
    expect(problemOf(rows, 'code')).toMatch(/NOT NULL missing/);
    expect(problemOf(rows, 'code')).toMatch(/Default value missing/);
    expect(problemOf(rows, 'flag')).toMatch(/Required in PostgreSQL/);
  });

  test('boolean columns from Settings, column renames and tables not migrated', () => {
    const rows = compareColumns(
      [o('ACTIVE', 'NUMBER', { precision: 1, scale: 0 }), o('OFFSET', 'NUMBER'), { ...o('X', 'NUMBER'), table: 'NOT_MIGRATED' }],
      [p('active', 'boolean'), p('offset_value', 'numeric')],
      { booleans: new Set(['ORDERS:ACTIVE']), renames: [{ tableName: 'ORDERS', oldName: 'OFFSET', name: 'offset_value' }] },
    );
    expect(rows).toHaveLength(2);
    expect(rows.every((r) => r[5] === 'yes')).toBe(true);
  });

  test('a calculated (virtual) column: fine when PostgreSQL generates it, reported when not', () => {
    const ok = compareColumns([o('TOTAL', 'NUMBER', { hasDefault: true, virtual: true })], [p('total', 'double precision', { generated: true })]);
    expect(ok[0][5]).toBe('yes');
    const bad = compareColumns([o('TOTAL', 'NUMBER', { hasDefault: true, virtual: true })], [p('total', 'numeric')]);
    expect(bad[0][4]).toMatch(/Calculated column in Oracle/);
  });

  test('a boolean column that stayed a number is reported', () => {
    const rows = compareColumns([o('ACTIVE', 'NUMBER')], [p('active', 'smallint')], { booleans: new Set(['ORDERS:ACTIVE']) });
    expect(problemOf(rows, 'active')).toMatch(/Should be boolean/);
  });
});
