'use strict';

/**
 * Structure validation: every column of every migrated table, Oracle against PostgreSQL.
 * Catches design mistakes a row count cannot see:
 *   missing column, a different kind of type (text vs number), text shorter than in Oracle,
 *   decimals that would be cut (NUMBER(10,2) as integer), fewer digits, NOT NULL lost or added,
 *   a default value that was not carried over, a calculated (virtual) column that became a normal one,
 *   a column only PostgreSQL has.
 * Rows: [table, column, Oracle type, PostgreSQL type, problem ('' when fine), 'yes' | 'no'].
 */

const FAMILY_ORA = [
  [/^(N?VARCHAR2|VARCHAR|N?CHAR|N?CLOB|LONG)$/, 'text'],
  [/^(NUMBER|FLOAT|BINARY_FLOAT|BINARY_DOUBLE|INTEGER)$/, 'number'],
  [/^(DATE|TIMESTAMP.*)$/, 'datetime'],
  [/^(BLOB|RAW|LONG RAW)$/, 'binary'],
  [/^XMLTYPE$/, 'xml'],
];
const FAMILY_PG = [
  [/^(character varying|character|text)$/, 'text'],
  [/^(numeric|integer|bigint|smallint|double precision|real)$/, 'number'],
  [/^boolean$/, 'boolean'],
  [/^(timestamp.*|date)$/, 'datetime'],
  [/^(bytea|oid)$/, 'binary'],
  [/^xml$/, 'xml'],
];
const family = (list, type) => (list.find(([re]) => re.test(type)) || [null, 'other'])[1];
const INT_TYPES = new Set(['integer', 'bigint', 'smallint']);

function oraText(c) {
  if (c.type === 'NUMBER') return c.precision != null ? `NUMBER(${c.precision}${c.scale ? `,${c.scale}` : ''})` : 'NUMBER';
  if (/CHAR/.test(c.type) && c.length) return `${c.type}(${c.length})`;
  return c.type;
}

function pgText(c) {
  if (c.length != null) return `${c.type}(${c.length})`;
  if (c.type === 'numeric' && c.precision != null) return `numeric(${c.precision}${c.scale ? `,${c.scale}` : ''})`;
  return c.type;
}

/**
 * Pure comparison (unit-tested).
 *   ora: [{ table, column, type, length, precision, scale, nullable: bool, hasDefault: bool, virtual: bool }]
 *   pg:  [{ table, column, type, length, precision, scale, nullable: bool, hasDefault: bool, generated: bool }]
 *   options.pgName(name)          Oracle name → PostgreSQL name (case setting)
 *   options.renames               [{ tableName, oldName, name }] column renames
 *   options.booleans              Set of 'TABLE:COLUMN' converted to boolean
 */
function compareColumns(ora, pg, { pgName = (n) => n.toLowerCase(), renames = [], booleans = new Set() } = {}) {
  const pgByTable = new Map();
  for (const c of pg) {
    if (!pgByTable.has(c.table)) pgByTable.set(c.table, new Map());
    pgByTable.get(c.table).set(c.column, c);
  }
  const renamed = new Map(renames.map((r) => [`${r.tableName}:${r.oldName}`, r.name]));
  const rows = [];
  const seen = new Set();
  for (const o of ora) {
    const table = pgName(o.table);
    const cols = pgByTable.get(table);
    if (!cols) continue; // table not migrated: the row counts say so
    const column = renamed.get(`${o.table}:${o.column}`) || pgName(o.column);
    const p = cols.get(column);
    seen.add(`${table}.${column}`);
    if (!p) { rows.push([table, column, oraText(o), '—', 'Column missing in PostgreSQL', 'no']); continue; }

    const problems = [];
    const of = family(FAMILY_ORA, o.type);
    const pf = family(FAMILY_PG, p.type);
    const isBool = booleans.has(`${o.table}:${o.column}`);
    if (isBool && pf !== 'boolean') problems.push('Should be boolean (Settings → Boolean columns)');
    else if (!isBool && of !== 'other' && pf !== 'other' && of !== pf) problems.push(`Different kind of type (${of} in Oracle, ${pf} in PostgreSQL)`);
    if (of === 'text' && pf === 'text' && o.length && p.length != null && p.length < o.length) problems.push(`Shorter in PostgreSQL (${p.length} < ${o.length})`);
    if (o.type === 'NUMBER' && o.scale > 0 && INT_TYPES.has(p.type)) problems.push('Decimals would be cut (whole-number type)');
    if (o.type === 'NUMBER' && p.type === 'numeric' && o.precision != null && p.precision != null && p.precision < o.precision) problems.push(`Fewer digits (${p.precision} < ${o.precision})`);
    if (!o.nullable && p.nullable) problems.push('NOT NULL missing in PostgreSQL');
    if (o.nullable && !p.nullable) problems.push('Required in PostgreSQL, optional in Oracle');
    // A calculated (virtual) column keeps its formula where a default would be: compare it as such.
    if (o.virtual && !p.generated) problems.push('Calculated column in Oracle, a normal column in PostgreSQL');
    else if (!o.virtual && o.hasDefault && !p.hasDefault) problems.push('Default value missing in PostgreSQL');
    rows.push([table, column, oraText(o), pgText(p), problems.join('; '), problems.length ? 'no' : 'yes']);
  }
  // Columns only PostgreSQL has, in the migrated tables.
  for (const [table, cols] of pgByTable) {
    if (!ora.some((o) => pgName(o.table) === table)) continue;
    for (const [column, p] of cols) {
      if (!seen.has(`${table}.${column}`)) rows.push([table, column, '—', pgText(p), 'Only in PostgreSQL (not in Oracle)', 'no']);
    }
  }
  return rows;
}

/** Reads both dictionaries and compares them. oracle: an Oracle connection; pg: a PostgreSQL client. */
async function compareStructure(oracle, pg, schema, pgSchema, { preserveCase = false, renames = [], booleans = '' } = {}) {
  const o = await oracle.execute(
    `SELECT c.table_name, c.column_name, c.data_type, c.char_length, c.data_precision, c.data_scale, c.nullable,
            CASE WHEN c.default_length > 0 THEN 'Y' ELSE 'N' END, c.virtual_column
       FROM dba_tab_cols c JOIN dba_tables t ON t.owner = c.owner AND t.table_name = c.table_name
      WHERE c.owner = :o AND c.hidden_column = 'NO' AND t.temporary = 'N' AND t.secondary = 'N'
        AND t.table_name NOT LIKE 'MLOG$%' AND t.table_name NOT LIKE 'RUPD$%' AND t.table_name NOT LIKE 'BIN$%'
      ORDER BY c.table_name, c.column_id`, { o: schema });
  const ora = o.rows.map(([table, column, type, len, precision, scale, nullable, def, virtual]) => ({
    table, column, type: String(type).replace(/\(\d+\)/g, ''), length: Number(len) || null,
    precision: precision == null ? null : Number(precision), scale: scale == null ? null : Number(scale),
    nullable: nullable === 'Y', hasDefault: def === 'Y',
    // A calculated column has a formula; Oracle also marks XMLTYPE and object columns "virtual" (stored hidden).
    virtual: virtual === 'YES' && def === 'Y' && type !== 'XMLTYPE',
  }));
  const p = await pg.query(
    `SELECT table_name, column_name, data_type, character_maximum_length, numeric_precision, numeric_scale, is_nullable, column_default IS NOT NULL AS has_default, is_generated
       FROM information_schema.columns WHERE table_schema = $1 ORDER BY table_name, ordinal_position`, [pgSchema]);
  const pgCols = p.rows.map((r) => ({
    table: r.table_name, column: r.column_name, type: r.data_type, length: r.character_maximum_length == null ? null : Number(r.character_maximum_length),
    precision: r.data_type === 'numeric' && r.numeric_precision != null ? Number(r.numeric_precision) : null,
    scale: r.data_type === 'numeric' && r.numeric_scale != null ? Number(r.numeric_scale) : null,
    nullable: r.is_nullable === 'YES', hasDefault: !!r.has_default, generated: r.is_generated === 'ALWAYS',
  }));
  const boolSet = new Set(String(booleans || '').split(/[\s,]+/).filter(Boolean).map((b) => b.toUpperCase()));
  return compareColumns(ora, pgCols, { pgName: preserveCase ? (n) => n : (n) => n.toLowerCase(), renames, booleans: boolSet });
}

module.exports = { compareColumns, compareStructure };
