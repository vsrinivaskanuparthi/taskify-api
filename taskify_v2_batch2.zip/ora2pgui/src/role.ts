import { useEffect, useState } from 'react';
import { api } from './api';

/**
 * Who is signed in (corporate SSO) and whether they are an admin (DMA_ADMINS in the backend's
 * .env, or everybody when the list is empty or SSO is off). Admins see Settings, the run
 * defaults and the detailed analysis. Asked once per page load.
 */
interface WhoAmI { admin: boolean; user: { id: string; email: string | null } | null }
let whoPromise: Promise<WhoAmI> | null = null;
const loadWho = () => {
  whoPromise = whoPromise || api<WhoAmI>('/whoami').catch(() => ({ admin: true, user: null }));
  return whoPromise;
};

export function useIsAdmin(): boolean | null {
  const [admin, setAdmin] = useState<boolean | null>(null);
  useEffect(() => { loadWho().then((w) => setAdmin(!!w.admin)); }, []);
  return admin;
}

/** The signed-in user (null without SSO). */
export function useMe(): WhoAmI['user'] {
  const [me, setMe] = useState<WhoAmI['user']>(null);
  useEffect(() => { loadWho().then((w) => setMe(w.user)); }, []);
  return me;
}
