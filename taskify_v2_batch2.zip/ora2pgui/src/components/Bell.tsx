import { Badge, Box, Divider, IconButton, Menu, MenuItem, Stack, Tooltip, Typography } from '@mui/material';
import NotificationsRoundedIcon from '@mui/icons-material/NotificationsRounded';
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../api';
import { timeAgo } from '../format';
import { brand } from '../theme';
import { StatusChip } from './ui';

interface Item { projectName: string; runId: string; status: string; startedAt: string | null; finishedAt: string | null; startedBy: string | null; tables: number; done: number; failed: number }

const SEEN_KEY = 'dma.bell.seen';
const readSeen = () => { try { return localStorage.getItem(SEEN_KEY) || ''; } catch { return ''; } };
const writeSeen = (v: string) => { try { localStorage.setItem(SEEN_KEY, v); } catch { /* private window */ } };

/** Header bell: running migrations and the ones that ended lately, in every project. */
export default function Bell() {
  const navigate = useNavigate();
  const [items, setItems] = useState<Item[]>([]);
  const [anchor, setAnchor] = useState<HTMLElement | null>(null);
  const [seen, setSeen] = useState(readSeen);

  useEffect(() => {
    let alive = true;
    const load = () => api<{ items: Item[] }>('/notifications').then((r) => alive && setItems(r.items)).catch(() => {});
    load();
    const t = setInterval(load, 60000);
    return () => { alive = false; clearInterval(t); };
  }, []);

  // New = ended since the bell was last opened.
  const unread = items.filter((i) => i.finishedAt && i.finishedAt > seen).length;
  const running = items.filter((i) => !i.finishedAt).length;
  const open = (e: React.MouseEvent<HTMLElement>) => {
    setAnchor(e.currentTarget);
    const latest = items.map((i) => i.finishedAt || '').sort().pop() || seen;
    writeSeen(latest);
    setSeen(latest);
  };

  return (
    <>
      <Tooltip title="Migrations">
        <IconButton onClick={open} aria-label="Migrations">
          <Badge badgeContent={unread || (running ? '●' : 0)} color={unread ? 'error' : 'primary'} overlap="circular">
            <NotificationsRoundedIcon sx={{ color: brand.ink }} />
          </Badge>
        </IconButton>
      </Tooltip>
      <Menu anchorEl={anchor} open={!!anchor} onClose={() => setAnchor(null)} anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }} transformOrigin={{ vertical: 'top', horizontal: 'right' }}
        slotProps={{ paper: { sx: { width: 380, maxHeight: 480, mt: 1, borderRadius: 3 } } }}>
        <Box sx={{ px: 2, py: 1.25 }}>
          <Typography fontWeight={750}>Migrations</Typography>
          <Typography variant="caption" color="text.secondary">Running now, and ended in the last 14 days, in every project.</Typography>
        </Box>
        <Divider />
        {!items.length && <Typography variant="body2" color="text.secondary" sx={{ px: 2, py: 2 }}>Nothing yet.</Typography>}
        {items.map((i) => (
          <MenuItem key={`${i.projectName}/${i.runId}`} onClick={() => { setAnchor(null); navigate(`/projects/${encodeURIComponent(i.projectName)}/runs/${i.runId}`); }}
            sx={{ py: 1.25, alignItems: 'flex-start', whiteSpace: 'normal' }}>
            <Stack spacing={0.5} sx={{ width: '100%', minWidth: 0 }}>
              <Stack direction="row" spacing={1} alignItems="center">
                <Typography fontWeight={700} fontSize={14} noWrap sx={{ flex: 1, minWidth: 0 }}>{i.projectName}</Typography>
                <StatusChip status={i.status} />
              </Stack>
              <Typography variant="caption" color="text.secondary">
                {i.finishedAt ? `Ended ${timeAgo(i.finishedAt)}` : `Started ${timeAgo(i.startedAt)}`}
                {` · ${i.done} of ${i.tables} tables`}{i.failed ? ` · ${i.failed} failed` : ''}{i.startedBy ? ` · by ${i.startedBy}` : ''}
              </Typography>
            </Stack>
          </MenuItem>
        ))}
      </Menu>
    </>
  );
}
