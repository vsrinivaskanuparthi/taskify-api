import { Alert, Box, Button, Chip, CircularProgress, FormControlLabel, LinearProgress, Stack, Switch, Tooltip, Typography } from '@mui/material';
import FactCheckRoundedIcon from '@mui/icons-material/FactCheckRounded';
import RefreshRoundedIcon from '@mui/icons-material/RefreshRounded';
import FileDownloadRoundedIcon from '@mui/icons-material/FileDownloadRounded';
import TableViewRoundedIcon from '@mui/icons-material/TableViewRounded';
import { useCallback, useEffect, useState } from 'react';
import { api, projectPath } from '../api';
import { useProject } from '../context/ProjectContext';
import DataTable from '../components/DataTable';
import { CheckIcon, PageHeader, SectionCard, StatCard, Tag } from '../components/ui';
import { fmtDate, fmtInt } from '../format';
import { brand } from '../theme';
import { downloadCsv, downloadXlsx, safeFileName, Sheet } from '../exportFile';

const SOURCE: Record<string, { label: string; color: string; tip: string }> = {
  run: { label: 'verified at load', color: brand.success, tip: 'Exact counts taken by the migration engine right after the table was loaded' },
  live: { label: 'counted now', color: brand.blue, tip: 'Counted now in Oracle and PostgreSQL' },
  missing: { label: 'not migrated', color: brand.warning, tip: 'The table does not exist in the PostgreSQL schema yet' },
};

const yes = (v: any) => String(v).toLowerCase() === 'yes';

/** The list checks all end with a YES/NO column; the other columns are shown as they are. */
const LIST_CHECKS: { key: string; title: string; cols: string[] }[] = [
  { key: 'primaryForeignKeys', title: 'Primary & foreign key columns', cols: ['Table', 'Column'] },
  { key: 'checkConstraintCheck', title: 'Check constraints', cols: ['Constraint', 'Table'] },
  { key: 'uniqueConstraintsCheck', title: 'Unique constraints', cols: ['Column', 'Table'] },
  { key: 'indexesCheck', title: 'Indexes', cols: ['Index', 'Table'] },
  { key: 'sequenceCheck', title: 'Sequences', cols: ['Sequence'] },
  { key: 'ftsIndexesCheck', title: 'Full-text indexes', cols: ['Index', 'Table'] },
];

// Code objects are shown as one card per type, in this order (rows: [type, object, note, YES/NO]).
const CODE_TYPES: { type: string; title: string }[] = [
  { type: 'PROCEDURE', title: 'Procedures' },
  { type: 'FUNCTION', title: 'Functions' },
  { type: 'PACKAGE ROUTINE', title: 'Package procedures & functions' },
  { type: 'VIEW', title: 'Views' },
  { type: 'MATERIALIZED VIEW', title: 'Materialized views' },
  { type: 'TRIGGER', title: 'Triggers' },
  { type: 'TYPE', title: 'Types' },
];

function CsvButton({ onClick }: { onClick: () => void }) {
  return (
    <Tooltip title="Download this table as CSV (opens in Excel)">
      <Button size="small" variant="text" startIcon={<FileDownloadRoundedIcon />} onClick={onClick} sx={{ flexShrink: 0 }}>CSV</Button>
    </Tooltip>
  );
}

export default function ValidationPage() {
  const { name, project } = useProject();
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [onlyProblems, setOnlyProblems] = useState(false);

  const load = useCallback(async (recount = false) => {
    setLoading(true);
    setError(null);
    try {
      setData(await api(`${projectPath(name)}/validation${recount ? '?recount=1' : ''}`));
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, [name]);
  useEffect(() => { load(); }, [load]);

  const rowChecks: any[] = data?.rowCountCheck || [];
  const pk = data?.primaryKeyCheck;
  const fk = data?.foreignKeyCheck;
  const sections = LIST_CHECKS.map((c) => {
    const rows: any[] = data?.[c.key] || [];
    return { ...c, rows, failed: rows.filter((r) => !yes(r[r.length - 1])).length };
  });
  const codeRows: any[] = data?.codeObjectsCheck || [];
  const knownTypes = new Set(CODE_TYPES.map((c) => c.type));
  const codeTypes = [...CODE_TYPES, ...[...new Set(codeRows.map((r) => r[0]).filter((t) => !knownTypes.has(t)))].map((t) => ({ type: t, title: t }))]
    .map((c) => {
      const rows = codeRows.filter((r) => r[0] === c.type);
      return { ...c, rows, failed: rows.filter((r) => !yes(r[r.length - 1])).length };
    })
    .filter((c) => c.rows.length);
  const rowFailed = rowChecks.filter((r) => !yes(r[4]) && r[5] !== 'missing').length;
  // Structure: one row per column [table, column, Oracle type, PostgreSQL type, problem, yes/no].
  const structRows: any[] = data?.structureCheck || [];
  const structFailed = structRows.filter((r) => !yes(r[5])).length;
  const notMigrated = rowChecks.filter((r) => r[5] === 'missing').length;
  const categories = [
    { title: 'Row counts', failed: rowFailed, total: rowChecks.length - notMigrated },
    { title: 'Table structure', failed: structFailed, total: structRows.length },
    { title: 'Primary key count', failed: pk && pk[2] === false ? 1 : 0, total: pk ? 1 : 0 },
    { title: 'Foreign key count', failed: fk && fk[2] === false ? 1 : 0, total: fk ? 1 : 0 },
    ...codeTypes.map((c) => ({ title: c.title, failed: c.failed, total: c.rows.length })),
    ...sections.map((s) => ({ title: s.title, failed: s.failed, total: s.rows.length })),
  ];

  // ---- exports (complete data, whatever "Only show problems" hides)
  const stamp = new Date().toISOString().slice(0, 10);
  const file = (what: string, ext: string) => safeFileName(`validation_${name}_${what}_${stamp}.${ext}`);
  const SRC_TEXT: Record<string, string> = { run: 'verified at load', live: 'counted now', missing: 'not migrated' };
  const rowSheet = (): Sheet => ({
    name: 'Row counts',
    header: ['Table', 'Oracle rows', 'PostgreSQL rows', 'Difference', 'Match', 'Source'],
    rows: rowChecks.map((r) => [r[1], Number(r[3]), Number(r[2]) < 0 ? 'table missing' : Number(r[2]), r[5] === 'missing' ? '' : Number(r[2]) - Number(r[3]), r[5] === 'missing' ? '' : yes(r[4]) ? 'YES' : 'NO', SRC_TEXT[r[5]] || r[5] || '']),
  });
  const codeSheet = (c: typeof codeTypes[number]): Sheet => ({ name: `Code - ${c.title}`, header: ['Object', 'Note', 'Found in PostgreSQL'], rows: c.rows.map((r) => [r[1], r[2] || '', yes(r[3]) ? 'YES' : 'NO']) });
  const listSheet = (s: typeof sections[number]): Sheet => ({ name: s.title, header: [...s.cols, 'Found in PostgreSQL'], rows: s.rows.map((r) => [...s.cols.map((_, ci) => r[ci]), yes(r[r.length - 1]) ? 'YES' : 'NO']) });
  const structSheet = (): Sheet => ({ name: 'Table structure', header: ['Table', 'Column', 'Oracle', 'PostgreSQL', 'Problem', 'Same'], rows: structRows.map((r) => [r[0], r[1], r[2], r[3], r[4], yes(r[5]) ? 'YES' : 'NO']) });
  const csv = (sh: Sheet, what: string) => downloadCsv(file(what, 'csv'), sh.header, sh.rows);
  const exportAll = () => downloadXlsx(file('all', 'xlsx'), [
    {
      name: 'Summary',
      header: ['Check', 'Passed', 'Total', 'Status'],
      rows: [
        ['Schema', `${project?.selectedSchema || ''} → PostgreSQL`, '', data?.validatedAt ? `checked ${fmtDate(data.validatedAt)}` : ''],
        ['Primary keys (PG / Oracle)', pk ? pk[0]?.[0]?.primary_key_count ?? '' : '', pk ? pk[1] : '', pk && pk[2] === false ? 'DIFFERENT' : 'OK'],
        ['Foreign keys (PG / Oracle)', fk ? fk[0]?.[0]?.foreign_key_count ?? '' : '', fk ? fk[1] : '', fk && fk[2] === false ? 'DIFFERENT' : 'OK'],
        ...categories.filter((c) => c.total).map((c) => [c.title, c.total - c.failed, c.total, c.failed ? `${c.failed} problem(s)` : 'OK']),
      ],
    },
    rowSheet(),
    ...(structRows.length ? [structSheet()] : []),
    ...codeTypes.map(codeSheet),
    ...sections.filter((s) => s.rows.length).map(listSheet),
  ]);
  const passed = categories.filter((c) => c.total > 0 && c.failed === 0).length;
  const withData = categories.filter((c) => c.total > 0).length;

  return (
    <>
      <PageHeader overline="Step 7" title="Validation" icon={<FactCheckRoundedIcon />}
        subtitle={<>Compares the Oracle schema <b>{project?.selectedSchema}</b> with PostgreSQL. Row counts are the exact counts taken when each table was loaded{data?.validatedAt ? ` · checked ${fmtDate(data.validatedAt)}` : ''}.</>}
        actions={<>
          <Button variant="outlined" startIcon={<TableViewRoundedIcon />} onClick={exportAll} disabled={loading || !data}>Export all (Excel)</Button>
          <Button variant="outlined" startIcon={<RefreshRoundedIcon />} onClick={() => load(false)} disabled={loading}>Re-check</Button>
          <Button variant="contained" startIcon={loading ? <CircularProgress size={16} color="inherit" /> : <FactCheckRoundedIcon />} onClick={() => load(true)} disabled={loading}>Recount all rows</Button>
        </>} />
      {loading && <LinearProgress sx={{ mb: 2 }} />}
      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
      {data && (
        <>
          <Box sx={{ display: 'grid', gap: 2, gridTemplateColumns: { xs: '1fr 1fr', md: 'repeat(4, 1fr)' }, mb: 3 }}>
            <StatCard label="Checks passed" value={`${passed} / ${withData}`} accent={passed === withData ? brand.success : brand.warning} />
            <StatCard label="Tables with matching rows" value={`${rowChecks.length - rowFailed - notMigrated} / ${rowChecks.length - notMigrated}`} accent={rowFailed ? brand.error : brand.success} hint={notMigrated ? `${notMigrated} tables of the snapshot not migrated yet` : 'every migrated table'} />
            <StatCard label="Primary keys (PG / Oracle)" value={pk ? `${pk[0]?.[0]?.primary_key_count ?? '—'} / ${pk[1]}` : '—'} accent={pk && pk[2] === false ? brand.warning : brand.success} />
            <StatCard label="Foreign keys (PG / Oracle)" value={fk ? `${fk[0]?.[0]?.foreign_key_count ?? '—'} / ${fk[1]}` : '—'} accent={fk && fk[2] === false ? brand.warning : brand.success} />
          </Box>
          <Stack direction="row" spacing={1} flexWrap="wrap" useFlexGap sx={{ mb: 2 }} alignItems="center">
            {categories.filter((c) => c.total).map((c) => (
              <Chip key={c.title} icon={<CheckIcon ok={c.failed === 0} warn={c.failed > 0} />} label={`${c.title}: ${c.total - c.failed}/${c.total}`} variant="outlined" sx={{ bgcolor: '#fff' }} />
            ))}
            <Box sx={{ flex: 1 }} />
            <FormControlLabel control={<Switch checked={onlyProblems} onChange={(e) => setOnlyProblems(e.target.checked)} />} label="Only show problems" />
          </Stack>
          <Stack spacing={3}>
            <SectionCard dense collapsible storeKey="validation.rows" title="Row counts" subtitle="Exact count in Oracle and PostgreSQL per table" summary={rowFailed ? `${rowFailed} table(s) differ` : 'All migrated tables match'} action={<CsvButton onClick={() => csv(rowSheet(), 'row_counts')} />}>
              <DataTable rows={rowChecks.filter((r) => !onlyProblems || (!yes(r[4]) && r[5] !== 'missing'))} rowKey={(r) => r[1]} searchKeys={[1] as any} empty={rowChecks.length ? 'No problems' : 'Take a snapshot first.'}
                initialSort={{ key: 'ok', dir: 'asc' }}
                columns={[
                  { key: 'ok', label: '', width: 40, sortValue: (r) => (r[5] === 'missing' ? 2 : yes(r[4]) ? 1 : 0), render: (r) => <CheckIcon ok={yes(r[4])} skipped={r[5] === 'missing'} /> },
                  { key: 't', label: 'Table', sortValue: (r) => r[1], render: (r) => <span className="mono">{r[1]}</span> },
                  { key: 'o', label: 'Oracle', align: 'right', sortValue: (r) => Number(r[3]), render: (r) => fmtInt(r[3]) },
                  { key: 'p', label: 'PostgreSQL', align: 'right', sortValue: (r) => Number(r[2]), render: (r) => (Number(r[2]) < 0 ? <Typography color="error.main" variant="body2">table missing</Typography> : fmtInt(r[2])) },
                  { key: 's', label: 'Source', sortValue: (r) => r[5] || '', render: (r) => (SOURCE[r[5]] ? <Tooltip title={SOURCE[r[5]].tip}><span><Tag label={SOURCE[r[5]].label} color={SOURCE[r[5]].color} /></span></Tooltip> : null) },
                  { key: 'd', label: 'Difference', align: 'right', sortValue: (r) => Number(r[2]) - Number(r[3]), render: (r) => { if (r[5] === 'missing') return '—'; const d = Number(r[2]) - Number(r[3]); return <Typography variant="body2" color={d ? 'error.main' : 'text.secondary'}>{d > 0 ? `+${fmtInt(d)}` : fmtInt(d)}</Typography>; } },
                ]} />
            </SectionCard>
            {structRows.length > 0 && (
              <SectionCard dense collapsible storeKey="validation.structure" defaultOpen={structFailed > 0} title="Table structure"
                subtitle="Column by column: kind of type, text length, decimals, required (NOT NULL), defaults, calculated columns"
                summary={structFailed ? `${structFailed} of ${structRows.length} columns differ` : `All ${structRows.length} columns match`}
                action={<CsvButton onClick={() => csv(structSheet(), 'table_structure')} />}>
                <DataTable rows={structRows.filter((r) => !onlyProblems || !yes(r[5])).map((r, i) => ({ r, i }))} rowKey={(x) => `${x.r[0]}.${x.r[1]}.${x.i}`} dense pageSize={10}
                  empty={structRows.length ? 'No problems' : 'Nothing to compare'} initialSort={{ key: 'ok', dir: 'asc' }}
                  columns={[
                    { key: 'ok', label: '', width: 40, sortValue: (x) => (yes(x.r[5]) ? 1 : 0), render: (x) => <CheckIcon ok={yes(x.r[5])} /> },
                    { key: 't', label: 'Table', sortValue: (x) => x.r[0], render: (x) => <span className="mono">{x.r[0]}</span> },
                    { key: 'c', label: 'Column', sortValue: (x) => x.r[1], render: (x) => <span className="mono">{x.r[1]}</span> },
                    { key: 'o', label: 'Oracle', sortValue: (x) => x.r[2], render: (x) => <span className="mono">{x.r[2]}</span> },
                    { key: 'p', label: 'PostgreSQL', sortValue: (x) => x.r[3], render: (x) => <span className="mono">{x.r[3]}</span> },
                    { key: 'pr', label: 'Problem', sortValue: (x) => x.r[4], render: (x) => <Typography variant="body2" color={x.r[4] ? 'warning.dark' : 'text.secondary'}>{x.r[4] || '—'}</Typography> },
                  ]} />
              </SectionCard>
            )}
            {codeTypes.length > 0 && (
              <Box>
                <Typography variant="h6" sx={{ mb: 0.5 }}>Code objects</Typography>
                <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>Every Oracle code object by name, and whether it exists in PostgreSQL. One card per type.</Typography>
                <Box sx={{ display: 'grid', gap: 3, gridTemplateColumns: { xs: '1fr', lg: '1fr 1fr', xl: '1fr 1fr 1fr' }, alignItems: 'start' }}>
                  {codeTypes.map((c) => {
                    const rows = c.rows.filter((r) => !onlyProblems || !yes(r[3]));
                    return (
                      <SectionCard key={c.type} dense collapsible defaultOpen={c.failed > 0} title={<Stack direction="row" spacing={1} alignItems="center"><CheckIcon ok={c.failed === 0} warn={c.failed > 0} /><span>{c.title}</span></Stack>}
                        subtitle={`${c.rows.length - c.failed} of ${c.rows.length} found in PostgreSQL`}
                        action={<CsvButton onClick={() => csv(codeSheet(c), `code_${c.title}`)} />}>
                        <DataTable rows={rows.map((r, i) => ({ r, i }))} rowKey={(x) => `${x.i}`} dense pageSize={8} empty="No problems"
                          initialSort={{ key: 'ok', dir: 'asc' }}
                          columns={[
                            { key: 'ok', label: '', width: 40, sortValue: (x) => (yes(x.r[3]) ? 1 : 0), render: (x) => <CheckIcon ok={yes(x.r[3])} /> },
                            { key: 'o', label: 'Object', sortValue: (x: any) => String(x.r[1]), render: (x: any) => <span className="mono">{x.r[1]}</span> },
                            { key: 'n', label: 'Note', sortValue: (x: any) => String(x.r[2] || ''), render: (x: any) => (x.r[2] ? <Typography variant="caption" color="warning.main">{x.r[2]}</Typography> : null) },
                          ]} />
                      </SectionCard>
                    );
                  })}
                </Box>
              </Box>
            )}
            <Box sx={{ display: 'grid', gap: 3, gridTemplateColumns: { xs: '1fr', xl: '1fr 1fr' }, alignItems: 'start' }}>
              {sections.map((s) => {
                const rows = s.rows.filter((r) => !onlyProblems || !yes(r[r.length - 1]));
                return (
                  <SectionCard key={s.key} dense collapsible defaultOpen={s.failed > 0} title={<Stack direction="row" spacing={1} alignItems="center"><CheckIcon ok={s.failed === 0} warn={s.failed > 0} /><span>{s.title}</span></Stack>}
                    subtitle={`${s.rows.length - s.failed} of ${s.rows.length} found in PostgreSQL`}
                    action={<CsvButton onClick={() => csv(listSheet(s), s.title)} />}>
                    <DataTable rows={rows.map((r, i) => ({ r, i }))} rowKey={(x) => `${x.i}`} dense pageSize={10} empty={s.rows.length ? 'No problems' : 'Nothing to compare'}
                      initialSort={{ key: 'ok', dir: 'asc' }}
                      columns={[
                        { key: 'ok', label: '', width: 40, sortValue: (x) => (yes(x.r[x.r.length - 1]) ? 1 : 0), render: (x) => <CheckIcon ok={yes(x.r[x.r.length - 1])} /> },
                        ...s.cols.map((label, ci) => ({ key: `c${ci}`, label, sortValue: (x: any) => String(x.r[ci]), render: (x: any) => <span className="mono">{String(x.r[ci])}</span> })),
                      ]} />
                  </SectionCard>
                );
              })}
            </Box>
          </Stack>
        </>
      )}
    </>
  );
}
