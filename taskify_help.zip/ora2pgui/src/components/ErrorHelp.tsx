import { Box, Chip, Collapse, Stack, Typography } from '@mui/material';
import HelpOutlineRoundedIcon from '@mui/icons-material/HelpOutlineRounded';
import { useState } from 'react';
import { explainError, IMPACT_TEXT, Impact } from '../errorHelp';
import { brand } from '../theme';

const IMPACT_COLOR: Record<Impact, string> = { none: '#067647', object: '#B54708', table: '#B42318', run: '#B42318' };

/**
 * A small "What does this mean?" link under an error; opens a plain-words explanation from the
 * known-errors list (errorHelp.ts). Errors not in the list get a generic next step.
 */
export default function ErrorHelp({ text, defaultOpen = false }: { text?: string | null; defaultOpen?: boolean }) {
  const [open, setOpen] = useState(defaultOpen);
  if (!text) return null;
  const e = explainError(text);
  return (
    <Box sx={{ mt: 0.5 }}>
      <Chip size="small" variant="outlined" icon={<HelpOutlineRoundedIcon />} label={open ? 'Hide explanation' : 'What does this mean?'}
        onClick={(ev) => { ev.stopPropagation(); setOpen(!open); }} sx={{ fontWeight: 650, color: brand.blue, borderColor: '#C9D8F2', bgcolor: '#F5F8FE' }} />
      <Collapse in={open} unmountOnExit>
        <Box sx={{ mt: 1, p: 1.75, borderRadius: 3, bgcolor: '#F8FAFD', border: `1px solid ${brand.border}`, maxWidth: 680, whiteSpace: 'normal' }} onClick={(ev) => ev.stopPropagation()}>
          {e ? (
            <Stack spacing={0.75}>
              <Typography fontWeight={750} fontSize={14}>{e.title}</Typography>
              <Typography variant="body2"><b>What happened:</b> {e.meaning}</Typography>
              <Typography variant="body2" sx={{ color: IMPACT_COLOR[e.impact] }}><b>How serious:</b> {IMPACT_TEXT[e.impact]}.</Typography>
              <Typography variant="body2"><b>What to do:</b> {e.action}</Typography>
            </Stack>
          ) : (
            <Stack spacing={0.75}>
              <Typography fontWeight={750} fontSize={14}>Not in DMA’s list of known errors yet</Typography>
              <Typography variant="body2">Open the table’s log (📄) to see the lines just above this error: the first error there is usually the real cause.</Typography>
              <Typography variant="body2">Send the error text to the DMA team, so it can be explained here next time.</Typography>
            </Stack>
          )}
        </Box>
      </Collapse>
    </Box>
  );
}
