'use strict';

const fs = require('fs');
const pLimit = require('p-limit');
const {
  initPostgres,
  ensurePostgresPool,
  getPostgresConnection,
  pgQuery,
} = require("../utils/postgreClient");
const { getOracleConnection } = require('../utils/oracleClient');
const { getPrimaryKeyCount } = require("../queries/pg/getPrimaryKeyCount");
const { getForeignKeyCount } = require("../queries/pg/getForeignKeyCount");
const { comparePrimaryForeignKeys } = require("../queries/pg/comparePrimaryForeignKeys");
const { compareCheckConstraints } = require("../queries/pg/compareCheckConstraints");
const { compareUniqueConstraints } = require("../queries/pg/compareUniqueConstraints");
const { compareSequences } = require("../queries/pg/compareSequences");
const { compareFtsIndexes } = require("../queries/pg/compareFtsIndexes");
const { compareNormalIndexes } = require("../queries/pg/compareNormalIndexes");
const { compareCodeObjects } = require("../queries/pg/compareCodeObjects");
const settingsSvc = require("../services/settings");
const { executeAndLog } = require('../errorHandling/error');
const { CONSTANTS } = require('../utils/constants');
const logger = require("../utils/logger");
const secrets = require('../utils/secrets');
const store = require('../services/projectStore');
const migrate = require('../services/migrate');
const { ensureSource } = require('./oracleController');

async function ensureTarget(req) {
  await ensurePostgresPool(store.postgresCredentials(req.project), req.projectName);
}

async function connectPg(req, res) {
  try {
    logger.info(`PostgreSQL connect for project ${req.projectName}`);
    const response = await initPostgres(req.body, req.projectName);
    const { hostip, port, dbname, username, password } = req.body;
    await store.updateMeta(req.projectName, (m) => ({
      ...m,
      postgres: { hostip, port: String(port), dbname, username, password: secrets.encrypt(password), connectedAt: new Date().toISOString(), version: response.version },
    }));
    res.status(200).send({ status: 200, message: 'Database successfully connected', version: response.version });
  } catch (error) {
    res.status(400).send({ status: 400, message: error.message });
  }
}

async function disconnectPg(req, res) {
  if (require('../services/migrate').activeRunSummary(req.projectName)) {
    return res.status(409).json({ message: 'A migration of this project is running: wait for it or cancel it before disconnecting.' });
  }
  await store.updateMeta(req.projectName, (m) => ({ ...m, postgres: null }));
  res.json({ message: 'Disconnected' });
}

/**
 * Checks on the PostgreSQL side and on this server, shown next to the Oracle prerequisite
 * analysis before a run is started.
 */
async function targetChecks(req, res) {
  const checks = [];
  const add = (check, ok, description) => checks.push({ check, response: !!ok, description });
  try {
    await ensureTarget(req);
    const { rows } = await pgQuery(
      `SELECT current_user AS usr, current_database() AS db,
              has_database_privilege(current_user, current_database(), 'CREATE') AS can_create,
              current_setting('server_version') AS ver,
              current_setting('max_connections')::int AS maxconn`, [], req.projectName);
    const r = rows[0];
    add('target connection', true, `Connected to ${r.db} as ${r.usr} (PostgreSQL ${r.ver}).`);
    add('create schema privilege', r.can_create, r.can_create ? 'The user can create the target schema.' : `User ${r.usr} needs CREATE on database ${r.db}.`);
    add('connection capacity', r.maxconn >= 50, `max_connections = ${r.maxconn}. Parallel loading uses about (parallel tables × writers) + 10 connections.`);
  } catch (err) {
    add('target connection', false, err.message);
  }
  const ora = await executeAndLog({ cmd: CONSTANTS.ORA2PG_BIN, args: ['--version'], label: 'check ora2pg' });
  add('ora2pg installed', ora.code === 0, ora.code === 0 ? `${CONSTANTS.ORA2PG_BIN} found on the server.` : `ora2pg not found (${CONSTANTS.ORA2PG_BIN}).`);
  const psql = await executeAndLog({ cmd: CONSTANTS.PSQL_BIN, args: ['--version'], label: 'check psql' });
  add('psql installed', psql.code === 0, psql.code === 0 ? 'psql found on the server.' : `psql not found (${CONSTANTS.PSQL_BIN}).`);
  try {
    const st = fs.statfsSync(CONSTANTS.STAGING_DIR);
    const freeGb = (st.bavail * st.bsize) / 1024 ** 3;
    add('staging disk space', freeGb > 5, `${freeGb.toFixed(1)} GB free in ${CONSTANTS.STAGING_DIR}. Direct load writes no data files; file mode needs room for the largest tables being loaded.`);
  } catch { /* statfs not available */ }
  res.json(checks);
}

/**
 * Row counts, one row per table of the snapshot:
 *   [schema, table, pgRows, oracleRows, 'yes'|'no', source]
 * source = 'run'     exact counts taken by the migration engine right after the table was loaded
 *                    (newest run of this schema that loaded the table; all runs are merged)
 *        = 'live'    the table exists in PostgreSQL but was not loaded by a run: counted now
 *        = 'missing' the table is not in PostgreSQL (not migrated yet)
 * v1 compared PostgreSQL count(*) with Oracle's statistics estimate (num_rows), which reported
 * false mismatches. ?recount=1 counts every table again on both sides (4 in parallel).
 */
async function rowCountCheck(req, schemaName, recount) {
  const pgSchema = schemaName.toLowerCase();
  const snap = await store.readSnapshot(req.projectName, schemaName);
  const snapshotTables = (snap && snap.tableMetadata) || [];

  // Newest run first: the first run that loaded a table wins.
  const fromRuns = new Map();
  for (const r of (await migrate.listRuns(req.projectName)).filter((x) => x.schema === schemaName)) {
    const state = await migrate.readRunState(req.projectName, r.runId);
    for (const t of Object.values((state && state.tables) || {})) {
      if (!fromRuns.has(t.name) && t.pgRows !== undefined) fromRuns.set(t.name, t);
    }
  }

  const { rows: pgTables } = await pgQuery(
    `SELECT c.relname FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
      WHERE n.nspname = $1 AND c.relkind IN ('r', 'p')`, [pgSchema], req.projectName);
  const inPg = new Set(pgTables.map((r) => r.relname));

  const rows = snapshotTables.map((m) => {
    const run = fromRuns.get(m.name);
    const exists = inPg.has(m.name.toLowerCase());
    if (!exists) return { name: m.name, pg: -1, ora: Number(m.rowCount) || 0, source: 'missing' };
    if (run && !recount && run.oracleRows !== undefined) return { name: m.name, pg: run.pgRows, ora: run.oracleRows, source: 'run' };
    return { name: m.name, pg: null, ora: null, source: 'live' };
  });

  // Exact counts on both sides for tables without recorded counts (or all, on recount).
  const toCount = rows.filter((r) => r.source === 'live' || (recount && r.source !== 'missing'));
  if (toCount.length) {
    await ensureSource(req);
    const limit = pLimit(4);
    await Promise.all(toCount.map((r) => limit(async () => {
      try {
        const { rows: c } = await pgQuery(`SELECT count(*)::bigint AS n FROM "${pgSchema}"."${r.name.toLowerCase()}"`, [], req.projectName);
        r.pg = Number(c[0].n);
      } catch { r.pg = -1; }
      const conn = await getOracleConnection(req.projectName);
      try {
        const o = await conn.execute(`SELECT /*+ PARALLEL(t, 4) */ COUNT(*) FROM "${schemaName}"."${r.name}" t`);
        r.ora = Number(o.rows[0][0]);
      } catch { r.ora = -1; } finally { await conn.close().catch(() => {}); }
      if (recount) r.source = 'live';
    })));
  }

  return rows.map((r) => [schemaName, r.name.toLowerCase(), r.pg, r.ora, r.source !== 'missing' && r.pg === r.ora && r.pg >= 0 ? 'yes' : 'no', r.source]);
}

async function executePg(req, res) {
  let connection;
  const schemaName = req.project.selectedSchema;
  if (!schemaName) return res.status(400).json({ message: 'Select a schema first.' });

  // Helper to catch errors without crashing the whole report
  const safeRun = async (fn, ...args) => {
    const startTime = Date.now();
    try {
      const result = await fn(...args);
      logger.info(`Query [${fn.name}] took ${Date.now() - startTime}ms`);
      return result;
    } catch (err) {
      logger.error(`Error in [${fn.name}] after ${Date.now() - startTime}ms: ${err.message}`);
      return null;
    }
  };

  try {
    await ensureTarget(req);
    // The comparisons read the Oracle side from the cache; after a restart it comes from the saved snapshot.
    await store.hydrateCacheFromSnapshot(req.projectName, schemaName);
    connection = await getPostgresConnection(req.projectName);
    // The PostgreSQL side of every check reads this (Settings → target schema; default: lower-case Oracle name).
    const settings = settingsSvc.resolve(req.project);
    connection.pgSchema = settings.targetSchema || schemaName.toLowerCase();

    // No result caching any more: v1 cached the first validation forever, so it never changed
    // after a new migration.
    const [
      rowCount,
      primaryKeyCheck,
      foreignKeyCheck,
      primaryForeignKeys,
      checkConstraintCheck,
      uniqueConstraintsCheck,
      sequenceCheck,
      ftsIndexesCheck,
      indexesCheck,
    ] = await Promise.all([
      safeRun(rowCountCheck, req, schemaName, req.query.recount === '1'),
      safeRun(getPrimaryKeyCount, connection, schemaName),
      safeRun(getForeignKeyCount, connection, schemaName),
      safeRun(comparePrimaryForeignKeys, connection, schemaName),
      safeRun(compareCheckConstraints, connection, schemaName),
      safeRun(compareUniqueConstraints, connection, schemaName),
      safeRun(compareSequences, connection, schemaName),
      safeRun(compareFtsIndexes, connection, schemaName),
      safeRun(compareNormalIndexes, connection, schemaName),
    ]);
    // Code objects need a live Oracle connection (by name, not from the snapshot); after the others
    // so the PostgreSQL client is free.
    let codeObjectsCheck = null;
    let oracle;
    try {
      await ensureSource(req);
      oracle = await getOracleConnection(req.projectName);
      codeObjectsCheck = await compareCodeObjects(oracle, connection, schemaName, connection.pgSchema, !!settings.ora2pg.PRESERVE_CASE);
    } catch (err) {
      logger.error(`compareCodeObjects: ${err.message}`);
    } finally {
      if (oracle) await oracle.close().catch(() => {});
    }

    res.status(200).send({
      rowCountCheck: rowCount,
      primaryKeyCheck,
      foreignKeyCheck,
      primaryForeignKeys,
      checkConstraintCheck,
      uniqueConstraintsCheck,
      sequenceCheck,
      ftsIndexesCheck,
      indexesCheck,
      codeObjectsCheck,
      validatedAt: new Date().toISOString(),
    });
  } catch (error) {
    logger.error('Error in executePg:', error);
    res.status(500).send({ status: 500, message: error.message });
  } finally {
    if (connection) { delete connection.pgSchema; connection.release(); }
  }
}

module.exports = { executePg, connectPg, disconnectPg, targetChecks };
