'use strict';

const fs = require('fs');
const fsp = require('fs').promises;
const path = require('path');
const { getMigrationComplexity, CHECK_KEYS } = require('../queries/oracle/getMigrationComplexity');
const { getOracleConnection, ensureOraclePool } = require('../utils/oracleClient');
const { runWithProject } = require('../utils/context');
const { createRunLogger, executeAndLog } = require('../errorHandling/error');
const { ora2pgMajor, parseTextReport } = require('../utils/ora2pgVersion');
const { CONSTANTS } = require('../utils/constants');
const { buildConfig } = require('./config_modify');
const settingsSvc = require('./settings');
const store = require('./projectStore');
const events = require('./events');
const logger = require('../utils/logger');
const { renderHtml } = require('./analysisReport');

/**
 * Migration analysis: ora2pg's own assessment (SHOW_REPORT --estimate_cost) plus deeper checks
 * on the Oracle dictionary, turned into findings with a severity, the affected objects, what the
 * tool does about it and what the team has to do. Saved per run under <project>/analysis/<id>/.
 */

const analysisDir = (p) => path.join(store.projectDir(p), 'analysis');
const stamp = () => new Date().toISOString().replace(/[-:]/g, '').replace(/\..+/, '').replace('T', '-');
const jobs = new Map();

const SEVERITY = { critical: 20, high: 8, medium: 3, low: 1, info: 0 };

const FEATURE_INFO = {
  AUTONOMOUS_TRANSACTION: ['high', 'Autonomous transactions', 'PostgreSQL has no PRAGMA AUTONOMOUS_TRANSACTION. Typical use is audit/error logging that must survive a rollback.', 'Rewrite with the dblink extension (a separate connection), pg_background, or move the logging to the application.'],
  UTL_FILE: ['high', 'File I/O (UTL_FILE)', 'Reads/writes files on the database server.', 'Use COPY ... TO/FROM, the orafce utl_file emulation, or move file handling to the application / ETL tool.'],
  UTL_HTTP: ['high', 'HTTP calls (UTL_HTTP)', 'Calls web services from the database.', 'Move to the application layer, or use the pgsql-http extension if allowed.'],
  UTL_MAIL_SMTP: ['high', 'Email from the database (UTL_SMTP / UTL_MAIL)', 'Sends mail from PL/SQL.', 'Queue the mail in a table and send it from the application or a scheduler job.'],
  DBMS_SCHEDULER_JOB: ['high', 'Job scheduling in code (DBMS_SCHEDULER / DBMS_JOB)', 'Code creates or runs scheduler jobs.', 'Use pg_cron or the enterprise scheduler (Control-M, cron).'],
  DBMS_AQ: ['critical', 'Advanced Queuing (DBMS_AQ)', 'Oracle AQ has no PostgreSQL equivalent.', 'Redesign with a queue table + SKIP LOCKED, LISTEN/NOTIFY, or an external broker (Kafka, RabbitMQ).'],
  DBMS_SQL: ['medium', 'DBMS_SQL dynamic SQL', 'Cursor-based dynamic SQL API.', 'Rewrite with EXECUTE ... USING and format(); review each use.'],
  EXECUTE_IMMEDIATE: ['medium', 'Dynamic SQL (EXECUTE IMMEDIATE)', 'SQL built as strings is not converted by ora2pg/GenAI reliably (the string contents stay Oracle syntax).', 'Review every dynamic statement text; test with real parameters.'],
  CONNECT_BY: ['medium', 'Hierarchical queries (CONNECT BY)', 'Oracle hierarchical syntax.', 'ora2pg converts simple cases to WITH RECURSIVE; verify LEVEL, SYS_CONNECT_BY_PATH and ORDER SIBLINGS BY.'],
  BULK_COLLECT: ['medium', 'BULK COLLECT / FORALL', 'Array processing has no direct equivalent.', 'Rewrite as set-based SQL (INSERT ... SELECT, UPDATE ... FROM) — usually faster in PostgreSQL.'],
  PIPELINED: ['medium', 'Pipelined table functions', 'PIPE ROW functions used in FROM TABLE(...).', 'Convert to RETURNS SETOF / RETURNS TABLE with RETURN NEXT / RETURN QUERY.'],
  MERGE: ['medium', 'MERGE statements', 'Upsert logic.', 'PostgreSQL 15+ supports MERGE; otherwise INSERT ... ON CONFLICT. Check the target version.'],
  OUTER_JOIN_PLUS: ['low', 'Oracle (+) outer joins', 'Old-style outer join syntax.', 'ora2pg converts most to ANSI joins; review complex ones.'],
  ROWNUM: ['low', 'ROWNUM', 'Row limiting / numbering.', 'LIMIT / OFFSET or row_number(); ora2pg converts simple cases.'],
  DBMS_LOB: ['medium', 'DBMS_LOB', 'LOB manipulation API.', 'Use text/bytea functions (substr, length, overlay) or orafce.'],
  DBMS_CRYPTO: ['medium', 'Encryption / hashing (DBMS_CRYPTO)', 'Crypto functions.', 'Use the pgcrypto extension; verify output encoding matches (hex/raw).'],
  DBMS_OUTPUT: ['low', 'DBMS_OUTPUT', 'Debug output.', 'RAISE NOTICE (converted automatically).'],
  REF_CURSOR: ['low', 'REF cursors', 'Procedures returning cursors.', 'refcursor works, but callers (Java/.NET) must fetch inside a transaction; check the application data layer.'],
  GLOBAL_TEMP_USE: ['medium', 'Code using global temporary tables', 'Session-private temp tables declared once.', 'CREATE TEMP TABLE IF NOT EXISTS at session start, or unlogged tables keyed by session.'],
};

function exportStatus(p) { return jobs.get(p) || null; }

async function listReports(projectName) {
  const dir = analysisDir(projectName);
  if (!fs.existsSync(dir)) return [];
  const out = [];
  for (const id of (await fsp.readdir(dir)).sort().reverse()) {
    const r = await store.readJson(path.join(dir, id, 'report.json'));
    if (r) out.push({ id, schema: r.schema, createdAt: r.createdAt, score: r.summary.score, level: r.summary.ora2pg?.level, counts: r.summary.counts });
  }
  return out;
}

async function readReport(projectName, id) {
  if (!/^[0-9-]+$/.test(id)) return null;
  return store.readJson(path.join(analysisDir(projectName), id, 'report.json'));
}

function reportFile(projectName, id, kind) {
  if (!/^[0-9-]+$/.test(id)) return null;
  const file = { html: 'analysis_report.html', ora2pg: 'ora2pg_report.html', json: 'report.json' }[kind];
  return file ? path.join(analysisDir(projectName), id, file) : null;
}

// ------------------------------------------------------------------ job

function start(projectName) {
  if (jobs.has(projectName)) return jobs.get(projectName);
  const state = {
    id: stamp(), status: 'RUNNING', startedAt: new Date().toISOString(),
    steps: [
      { key: 'ora2pg', label: 'ora2pg assessment & cost estimate', status: 'pending' },
      { key: 'oracle', label: 'Oracle dictionary checks', status: 'pending', done: 0, total: CHECK_KEYS.length },
      { key: 'findings', label: 'Findings & recommendations', status: 'pending' },
    ],
  };
  jobs.set(projectName, state);
  const emit = () => events.publish(projectName, 'analysis', state);
  const step = (key, patch) => { Object.assign(state.steps.find((s) => s.key === key), patch); emit(); };
  emit();

  runWithProject(projectName, async () => {
    const dir = path.join(analysisDir(projectName), state.id);
    const log = createRunLogger(dir);
    try {
      const meta = await store.readMeta(projectName);
      const schema = meta.selectedSchema;
      if (!schema) throw new Error('Select a schema first.');
      const oracle = store.oracleCredentials(meta);
      if (!oracle) throw new Error('Connect the Oracle source first.');
      const snapshot = await store.readSnapshot(projectName, schema);
      if (!snapshot) throw new Error(`Take a snapshot of ${schema} first (Schema & snapshot).`);
      state.schema = schema;
      const settings = settingsSvc.resolve(meta);

      // 1. ora2pg SHOW_REPORT (JSON for the findings, HTML kept as the official ora2pg report).
      step('ora2pg', { status: 'running' });
      let ora2pg = null;
      try {
        const conf = await buildConfig({
          outFile: path.join(dir, 'config', 'report.conf'), outputDir: dir, oracle, schema,
          options: { pgSchema: settings.targetSchema || schema.toLowerCase(), directives: settingsSvc.ora2pgDirectives(settings) },
        });
        const args = ['-q', '-c', conf, '-t', 'SHOW_REPORT', '--estimate_cost', '-n', schema];
        const run = (extra, label) => executeAndLog({ cmd: CONSTANTS.ORA2PG_BIN, args: [...args, ...extra], cwd: dir, log, label, captureStdout: true });
        const readText = async (text) => {
          if (text.code !== 0) throw new Error(text.errorTail.split('\n')[0] || 'ora2pg report failed');
          const r = parseTextReport(text.stdout);
          if (!r) throw new Error('could not read the ora2pg report (see the analysis log)');
          return r;
        };
        // Each SHOW_REPORT scans the whole schema, so it runs once per format and both formats at
        // the same time. JSON from ora2pg 25; ora2pg 24 writes JSON that is not always valid, so its
        // text report is read instead (and on 25 only if the JSON cannot be read).
        const version = await executeAndLog({ cmd: CONSTANTS.ORA2PG_BIN, args: ['--version'], cwd: dir, log, label: 'ora2pg --version', captureStdout: true });
        const major = ora2pgMajor(version.stdout);
        const useJson = !major || major >= 25;
        const [main, html] = await Promise.all([
          useJson ? run(['--dump_as_json'], 'ora2pg SHOW_REPORT json') : run([], 'ora2pg SHOW_REPORT text'),
          run(['--dump_as_html'], 'ora2pg SHOW_REPORT html'),
        ]);
        if (useJson) {
          try {
            ora2pg = JSON.parse(main.stdout.slice(main.stdout.indexOf('{')));
          } catch {
            ora2pg = await readText(await run([], 'ora2pg SHOW_REPORT text'));
          }
        } else {
          ora2pg = await readText(main);
        }
        if (html.code === 0) await fsp.writeFile(path.join(dir, 'ora2pg_report.html'), html.stdout);
        step('ora2pg', { status: 'done' });
      } catch (err) {
        log.error(`ora2pg report: ${err.message}`);
        step('ora2pg', { status: 'failed', error: err.message });
      }

      // 2. Dictionary checks.
      step('oracle', { status: 'running' });
      await ensureOraclePool(oracle);
      const conn = await getOracleConnection();
      let checks;
      try {
        checks = await getMigrationComplexity(conn, schema, () => { const s = state.steps[1]; s.done += 1; emit(); });
      } finally {
        await conn.close().catch(() => {});
      }
      step('oracle', { status: checks.failed.length ? 'warning' : 'done', error: checks.failed.length ? `${checks.failed.length} checks skipped (privileges)` : undefined });

      // 3. Findings.
      step('findings', { status: 'running' });
      const throughput = await measuredThroughput(projectName);
      const report = buildReport({ id: state.id, schema, meta, settings, snapshot, ora2pg, checks, throughput });
      await store.writeJsonAtomic(path.join(dir, 'report.json'), report);
      await fsp.writeFile(path.join(dir, 'analysis_report.html'), renderHtml(report));
      step('findings', { status: 'done' });

      state.status = 'COMPLETED';
      await store.updateMeta(projectName, (m) => ({ ...m, analysisAt: state.startedAt })).catch(() => {});
      state.summary = report.summary;
    } catch (err) {
      logger.error(`Analysis failed: ${err.stack}`);
      log.error(err.message);
      state.status = 'FAILED';
      state.error = err.message;
    } finally {
      state.finishedAt = new Date().toISOString();
      log.close();
      emit();
      setTimeout(() => jobs.delete(projectName), 1000);
    }
  });
  return state;
}

/** MB/s actually reached by completed runs of this project (data phase only), if any. */
async function measuredThroughput(projectName) {
  const dir = store.runsDir(projectName);
  if (!fs.existsSync(dir)) return null;
  let mb = 0;
  let ms = 0;
  for (const id of await fsp.readdir(dir)) {
    const s = await store.readJson(path.join(dir, id, 'state.json'));
    const ph = s && s.phases && s.phases.find((p) => p.key === 'data');
    if (!ph || !ph.startedAt || !ph.finishedAt) continue;
    const size = Object.values(s.tables || {}).filter((t) => t.status === 'done').reduce((a, t) => a + (t.sizeMb || 0), 0);
    const dur = new Date(ph.finishedAt) - new Date(ph.startedAt);
    if (size > 1024 && dur > 60000) { mb += size; ms += dur; } // small runs are dominated by start-up time
  }
  return ms ? mb / (ms / 1000) : null;
}

// ------------------------------------------------------------------ findings

function buildReport({ id, schema, meta, settings, snapshot, ora2pg, checks, throughput }) {
  const findings = [];
  const add = (f) => findings.push({ objects: [], ...f, count: f.count ?? (f.objects ? f.objects.length : 0) });
  // The snapshot can hold sizes and counts as strings ('440'): numbers from here on.
  const tables = (snapshot.tableMetadata || []).map((t) => ({ ...t, sizeMb: Number(t.sizeMb) || 0, lobSizeMb: Number(t.lobSizeMb) || 0, rowCount: Number(t.rowCount) || 0 }));
  const tableNames = new Set(tables.map((t) => t.name));
  const sizeOf = new Map(tables.map((t) => [t.name, t]));
  const totalMb = tables.reduce((s, t) => s + (t.sizeMb || 0), 0);
  const totalRows = tables.reduce((s, t) => s + (t.rowCount || 0), 0);
  const lobMb = tables.reduce((s, t) => s + (t.lobSizeMb || 0), 0);
  const hugeRows = settings.engine.hugeTableRows;
  const fmtMb = (v) => { const n = Number(v) || 0; return n >= 1024 ? `${(n / 1024).toFixed(1)} GB` : `${n.toFixed(1)} MB`; };

  // ---- Data
  const pk = new Map((checks.primaryKeys || []).map((p) => [p.table, p]));
  const noPk = tables.filter((t) => !pk.has(t.name));
  if (checks.primaryKeys && noPk.length) {
    add({
      id: 'no-pk', severity: noPk.some((t) => t.rowCount >= hugeRows) ? 'high' : 'medium', category: 'Data',
      title: `${noPk.length} tables without a primary key`,
      detail: 'Without a key a table cannot be split into chunks, duplicates cannot be detected, and logical replication / CDC for a low-downtime cut-over is not possible.',
      objects: noPk.sort((a, b) => b.sizeMb - a.sizeMb).map((t) => `${t.name} (${fmtMb(t.sizeMb)}, ${Number(t.rowCount || 0).toLocaleString()} rows)`),
      handling: 'Automatic: loaded in one piece, emptied and reloaded on retry; row counts verified.',
      recommendation: 'Agree a key with the application team (or add an identity column in PostgreSQL after the load).',
    });
  }
  const huge = tables.filter((t) => t.rowCount >= hugeRows || t.sizeMb >= 20 * 1024);
  const notChunkable = huge.filter((t) => { const k = pk.get(t.name); return !k || k.columns !== 1 || !['NUMBER', 'INTEGER', 'FLOAT'].includes(k.type); });
  if (huge.length) {
    add({
      id: 'huge', severity: 'info', category: 'Data',
      title: `${huge.length} large tables loaded in parallel chunks`,
      detail: `Tables with ≥ ${hugeRows.toLocaleString()} rows or ≥ 20 GB. They dominate the load time.`,
      objects: huge.sort((a, b) => b.sizeMb - a.sizeMb).map((t) => `${t.name} (${fmtMb(t.sizeMb)}, ${Number(t.rowCount || 0).toLocaleString()} rows)`),
      handling: `Automatic: chunks of ${settings.engine.chunkRows.toLocaleString()} rows on the primary key, ${settings.engine.oracleCopies} Oracle readers, each chunk verified and resumable.`,
      recommendation: 'Raise UNDO_RETENTION on Oracle for the migration window and keep the Oracle and PostgreSQL servers close on the network.',
    });
  }
  if (notChunkable.length) {
    add({
      id: 'huge-rowid', severity: 'low', category: 'Data',
      title: `${notChunkable.length} large tables split by ROWID ranges`,
      detail: 'No single numeric primary key, so these tables are split into ROWID ranges of their extents. Each chunk is loaded from its own file in one transaction and verified against Oracle; a failed chunk is retried on its own.',
      objects: notChunkable.map((t) => `${t.name} (${fmtMb(t.sizeMb)}, key: ${pk.get(t.name) ? `${pk.get(t.name).columns} col ${pk.get(t.name).type}` : 'none'})`),
      handling: 'Automatic (needs SELECT on DBA_EXTENTS; falls back to one piece with parallel readers if the extents cannot be read).',
      recommendation: 'Keep UNDO_RETENTION above the expected load time of the largest table, and give the staging folder room for the chunks loading at the same time.',
    });
  }
  if (lobMb > 0) {
    const lobTables = tables.filter((t) => t.lobSizeMb > 0).sort((a, b) => b.lobSizeMb - a.lobSizeMb);
    add({
      id: 'lob', severity: lobMb > totalMb * 0.3 && lobMb > 10 * 1024 ? 'high' : 'medium', category: 'Data',
      title: `${fmtMb(lobMb)} of LOB data in ${lobTables.length} tables (${Math.round((lobMb / Math.max(totalMb, 1)) * 100)}% of the schema)`,
      detail: 'LOBs are read row by row and are the slowest part of a migration. BLOB → bytea, CLOB → text (1 GB per value limit in PostgreSQL).',
      objects: lobTables.map((t) => `${t.name} (${fmtMb(t.lobSizeMb)} LOB)`),
      handling: `Automatic: small batches (BLOB_LIMIT ${settings.engine.blobLimit}); BLOB stored as ${settings.lob.blobAs}.`,
      recommendation: 'Check no single value exceeds 1 GB; consider archiving old documents or moving files to object storage.',
    });
  }
  const risky = checks.riskyColumns || [];
  const byType = (pred) => risky.filter(pred);
  const typeRules = [
    [(c) => c.type === 'LONG' || c.type === 'LONG RAW', 'high', 'LONG / LONG RAW columns', 'Deprecated types; cannot be read in parallel and slow down the load.', 'Exported as text / bytea. Consider converting them to CLOB/BLOB in Oracle first.'],
    [(c) => c.type === 'BFILE', 'high', 'BFILE columns', 'The data lives in files outside the database.', 'Copy the files and store them as bytea, or keep the path and move the files to shared storage.'],
    [(c) => c.type === 'XMLTYPE', 'medium', 'XMLTYPE columns', 'Mapped to the xml type; XPath / XQuery functions differ.', 'Review queries using EXTRACT, EXISTSNODE, XMLTABLE.'],
    [(c) => c.type === 'SDO_GEOMETRY', 'high', 'Spatial columns (SDO_GEOMETRY)', 'Needs PostGIS on the target.', 'Install PostGIS; ora2pg exports geometry with SRID. Review spatial queries and indexes.'],
    [(c) => ['ANYDATA', 'URITYPE'].includes(c.type), 'critical', 'ANYDATA / URITYPE columns', 'No PostgreSQL equivalent.', 'Redesign: jsonb or typed columns.'],
    [(c) => ['ROWID', 'UROWID'].includes(c.type), 'medium', 'ROWID columns', 'Physical row addresses are meaningless after migration.', 'Replace with the primary key; ora2pg stores them as text.'],
    [(c) => c.typeOwner && !['SYS', 'PUBLIC', 'MDSYS'].includes(c.typeOwner), 'high', 'Columns of user-defined object types', 'Object types become composite types; methods are not migrated.', 'Review each type; flattening to columns or jsonb is often simpler.'],
    [(c) => /LOCAL TIME ZONE/.test(c.type), 'low', 'TIMESTAMP WITH LOCAL TIME ZONE', 'Mapped to timestamptz.', 'Check the PostgreSQL timezone setting matches the application.'],
    [(c) => /^INTERVAL/.test(c.type), 'low', 'INTERVAL columns', 'Mapped to interval.', 'Check arithmetic in code.'],
  ];
  for (const [pred, severity, title, detail, recommendation] of typeRules) {
    const cols = byType(pred);
    if (cols.length) add({ id: `type-${title}`, severity, category: 'Data types', title: `${cols.length} ${title}`, detail, objects: cols.map((c) => `${c.table}.${c.column} (${c.type})`), handling: 'ora2pg type mapping', recommendation });
  }
  const numNoPrec = byType((c) => c.type === 'NUMBER' && c.precision == null && c.scale == null);
  if (numNoPrec.length) {
    const intTarget = settings.ora2pg.PG_INTEGER_TYPE && ['bigint', 'integer'].includes(settings.ora2pg.DEFAULT_NUMERIC);
    add({
      id: 'number-noprec', severity: intTarget ? 'high' : 'low', category: 'Data types',
      title: `${numNoPrec.length} NUMBER columns without precision`,
      detail: intTarget
        ? `With the current settings they become ${settings.ora2pg.DEFAULT_NUMERIC}: any decimal values would be rounded. Key and ID columns are fine.`
        : `They become ${settings.ora2pg.DEFAULT_NUMERIC || 'numeric'} (exact, but slower than integers).`,
      objects: numNoPrec.map((c) => `${c.table}.${c.column}`),
      handling: 'Settings → "Type for NUMBER without precision", or per column with MODIFY_TYPE.',
      recommendation: intTarget ? 'Check non-ID columns for decimals (amounts, rates) and map them to numeric with MODIFY_TYPE.' : 'Map ID / count columns to bigint with MODIFY_TYPE for speed.',
    });
  }
  const boolCands = checks.booleanCandidates || [];
  const chosen = new Set(String(settings.ora2pg.REPLACE_AS_BOOLEAN || '').toUpperCase().split(/\s+/).filter(Boolean));
  if (boolCands.length) {
    const open = boolCands.filter((b) => !chosen.has(`${b.table}:${b.column}`));
    add({
      id: 'booleans', severity: open.length ? 'high' : 'low', category: 'Data types',
      title: `${boolCands.length} possible boolean columns (${chosen.size} chosen)`,
      detail: 'NUMBER(1) and 1-character flags. If the application (e.g. Hibernate) maps them to boolean, they must become boolean at the first load: converting later means dropping and recreating dependent views and fixing every function that compares them with 1/0.',
      objects: boolCands.map((b) => `${b.table}.${b.column} (${b.type})${chosen.has(`${b.table}:${b.column}`) ? ' ✓ boolean' : ''}`),
      handling: 'Only the columns ticked in Settings → Migration decisions → Boolean columns are converted (REPLACE_AS_BOOLEAN); the list goes into the GenAI conversion guide.',
      recommendation: 'Get the list from the application team (entity mappings). Do not convert all NUMBER(1) blindly: some are real numbers.',
    });
  }
  const rw = snapshot.reservedWordColumns || [];
  if (rw.length) {
    add({
      id: 'reserved', severity: settings.ora2pg.USE_RESERVED_WORDS ? 'low' : 'medium', category: 'Schema',
      title: `${rw.length} columns named like PostgreSQL reserved words`,
      detail: 'Columns such as USER, ORDER, LIMIT must be quoted in every query, or renamed.',
      objects: rw.map((r) => (Array.isArray(r) ? r.join('.') : `${r.tableName || r.TABLE_NAME}.${r.columnName || r.COLUMN_NAME}`)),
      handling: settings.ora2pg.USE_RESERVED_WORDS ? 'Automatic: quoted (Settings → Quote reserved words is on).' : 'Rename them on the Assessment page, or turn on Settings → Quote reserved words.',
      recommendation: 'Renaming is cleaner for the application; quoting needs no app change in SQL generated by ORMs.',
    });
  }

  // ---- Schema features
  const parts = checks.partitions || [];
  if (parts.length) {
    const unsupported = parts.filter((p) => p.interval || ['REFERENCE', 'SYSTEM'].includes(p.type));
    add({
      id: 'partitions', severity: unsupported.length ? 'high' : 'medium', category: 'Schema',
      title: `${parts.length} partitioned tables (${parts.reduce((s, p) => s + (p.partitions || 0), 0).toLocaleString()} partitions)`,
      detail: `Converted to PostgreSQL declarative partitioning. ${unsupported.length ? `${unsupported.length} use INTERVAL/REFERENCE/SYSTEM partitioning, which PostgreSQL does not do automatically.` : 'RANGE, LIST and HASH map directly.'}`,
      objects: parts.map((p) => `${p.table} (${p.type}${p.subType && p.subType !== 'NONE' ? `/${p.subType}` : ''}${p.interval ? `, INTERVAL ${p.interval}` : ''}, ${p.partitions} partitions)`),
      handling: 'ora2pg exports partitions; data is loaded through the parent table.',
      recommendation: unsupported.length ? 'Create future partitions with pg_partman (interval) and recreate reference-partitioned children explicitly.' : 'Check that the partition key is part of every unique index (a PostgreSQL rule).',
    });
  }
  const tf = checks.tableFeatures || [];
  const gtt = tf.filter((t) => t.temporary);
  if (gtt.length) add({ id: 'gtt', severity: 'high', category: 'Schema', title: `${gtt.length} global temporary tables`, detail: 'Not supported by PostgreSQL and not exported by ora2pg.', objects: gtt.map((t) => t.table), handling: 'Manual', recommendation: 'Create them as temporary tables at session start (or unlogged tables keyed by session) and adapt the code.' });
  const iot = tf.filter((t) => t.iot);
  if (iot.length) add({ id: 'iot', severity: 'low', category: 'Schema', title: `${iot.length} index-organized tables`, detail: 'Exported as normal tables with a primary key.', objects: iot.map((t) => t.table), handling: 'Automatic', recommendation: 'Optionally CLUSTER on the primary key after load for range scans.' });
  const vcols = checks.virtualColumns || [];
  if (vcols.length) add({ id: 'virtual', severity: 'medium', category: 'Schema', title: `${vcols.length} virtual columns`, detail: 'Become GENERATED ALWAYS AS (...) STORED columns; the expression must be converted and immutable.', objects: vcols.map((c) => `${c.table}.${c.column}`), handling: 'ora2pg converts the expression', recommendation: 'Review each expression after the DDL phase.' });
  const special = checks.indexTypes ? checks.indexTypes.special : [];
  const idxRule = (type, severity, title, detail, recommendation, handling = 'Automatic') => {
    const list = special.filter((i) => (Array.isArray(type) ? type.includes(i.type) : i.type === type));
    if (list.length) add({ id: `idx-${title}`, severity, category: 'Indexes', title: `${list.length} ${title}`, detail, objects: list.map((i) => `${i.index} on ${i.table}`), handling, recommendation });
  };
  idxRule('DOMAIN', 'high', 'Oracle Text / domain indexes', 'Full-text search must be rebuilt with tsvector + GIN; queries using CONTAINS() change.', 'Rewrite search queries with to_tsquery / @@ and test relevance.', 'Partly automatic: the FTS conversion script creates tsvector columns and GIN indexes.');
  idxRule(['BITMAP', 'FUNCTION-BASED BITMAP'], 'low', 'bitmap indexes', 'Exported as btree (or btree_gin).', 'Check plans for low-cardinality filters; PostgreSQL combines btree indexes with bitmap scans automatically.');
  idxRule('NORMAL/REV', 'low', 'reverse-key indexes', 'Not exported.', 'Usually not needed in PostgreSQL; drop or replace with hash/btree.');
  idxRule('FUNCTION-BASED NORMAL', 'medium', 'function-based indexes', 'The function must exist in PostgreSQL and be IMMUTABLE.', 'Verify they were created (Live monitor → DDL failures) and that queries still match the expression.');

  // ---- Code
  const plsql = checks.plsql || [];
  const lines = plsql.reduce((s, o) => s + o.lines, 0);
  for (const [key, [severity, title, detail, recommendation]] of Object.entries(FEATURE_INFO)) {
    const objs = plsql.filter((o) => o.features.includes(key));
    if (objs.length) add({ id: `plsql-${key}`, severity, category: 'Code', title: `${title} in ${objs.length} objects`, detail, objects: objs.map((o) => `${o.type} ${o.name}`), handling: 'GenAI conversion + manual review', recommendation });
  }
  const pkgs = plsql.filter((o) => o.type === 'PACKAGE BODY');
  if (pkgs.length) {
    add({
      id: 'packages', severity: pkgs.length > 20 ? 'high' : 'medium', category: 'Code',
      title: `${pkgs.length} packages (${pkgs.reduce((s, p) => s + p.lines, 0).toLocaleString()} lines)`,
      detail: 'PostgreSQL has no packages: each becomes a schema with functions. Package variables (state kept per session) and initialisation blocks need a redesign.',
      objects: pkgs.sort((a, b) => b.lines - a.lines).map((p) => `${p.name} (${p.lines.toLocaleString()} lines)`),
      handling: 'Exported per function in the GenAI zip (Code objects page).',
      recommendation: 'Convert the largest packages first; replace package variables with set_config()/current_setting() or a session table.',
    });
  }
  const largest = plsql.filter((o) => o.lines >= 1000).sort((a, b) => b.lines - a.lines);
  if (largest.length) add({ id: 'large-code', severity: 'medium', category: 'Code', title: `${largest.length} code objects over 1,000 lines`, detail: 'Large objects are where conversion errors hide; split them for GenAI and review them line by line.', objects: largest.map((o) => `${o.type} ${o.name} (${o.lines.toLocaleString()} lines)`), handling: 'GenAI conversion', recommendation: 'Give each to GenAI in parts and add unit tests that compare Oracle and PostgreSQL results.' });
  const trg = checks.triggers || [];
  const odd = trg.filter((t) => /COMPOUND|INSTEAD OF/.test(t.type) || ['DATABASE', 'SCHEMA'].includes(t.baseType));
  if (odd.length) add({ id: 'triggers', severity: 'high', category: 'Code', title: `${odd.length} compound, INSTEAD OF or database/DDL triggers`, detail: 'Compound triggers have no equivalent; DDL/logon triggers become event triggers (superuser).', objects: odd.map((t) => `${t.name} (${t.type} ${t.event} on ${t.baseType})`), handling: 'Manual', recommendation: 'Split compound triggers into statement + row triggers; review event triggers with the DBA team.' });
  const inv = checks.invalidObjects || [];
  if (inv.length) add({ id: 'invalid', severity: 'medium', category: 'Code', title: `${inv.length} invalid objects in Oracle`, detail: 'They do not compile in Oracle today, so they will not work after conversion either.', objects: inv.map((o) => `${o.type} ${o.name}`), handling: settings.ora2pg.EXPORT_INVALID ? 'Exported (Settings → Export invalid is on).' : 'Not exported (Settings → Export invalid is off).', recommendation: 'Ask the application team: fix, or drop as dead code.' });

  // ---- Operations / dependencies
  const jobsList = checks.jobs || [];
  if (jobsList.length) add({ id: 'jobs', severity: 'high', category: 'Operations', title: `${jobsList.length} scheduler jobs`, detail: 'Jobs are not migrated by ora2pg.', objects: jobsList.map((j) => `${j.name} (${j.interval})`), handling: 'Manual', recommendation: 'Recreate with pg_cron or the enterprise scheduler; disable them in Oracle at cut-over.' });
  const mv = checks.mviews || [];
  if (mv.length) {
    const fast = mv.filter((m) => m.method === 'FAST' || m.mode === 'COMMIT');
    add({ id: 'mviews', severity: fast.length ? 'high' : 'low', category: 'Schema', title: `${mv.length} materialized views${fast.length ? ` (${fast.length} fast / on-commit refresh)` : ''}`, detail: 'PostgreSQL materialized views only refresh completely (REFRESH MATERIALIZED VIEW [CONCURRENTLY]).', objects: mv.map((m) => `${m.name} (${m.mode}/${m.method})`), handling: 'Exported in the GenAI zip (mviews/)', recommendation: fast.length ? 'For fast/on-commit refresh use a table maintained by triggers, or pg_ivm; schedule refreshes with pg_cron.' : 'Schedule REFRESH with pg_cron; add a unique index to allow CONCURRENTLY.' });
  }
  const links = checks.dbLinks || snapshot.dbLinks || [];
  if (links.length) add({ id: 'dblinks', severity: 'medium', category: 'Dependencies', title: `${links.length} database links`, detail: 'Code using table@link must use a foreign data wrapper.', objects: links.map((l) => `${l.name} → ${l.host || '?'} (used by ${l.usedBy} objects)`), handling: 'Code objects → DB links: mapped to postgres_fdw / oracle_fdw.', recommendation: 'Decide per link whether the remote database is migrating too; get the FDW extension approved on the target.' });
  const cross = checks.crossSchema || [];
  if (cross.length) add({ id: 'cross-schema', severity: 'high', category: 'Dependencies', title: `Depends on ${new Set(cross.map((c) => c.refOwner)).size} other schemas`, detail: 'Objects in this schema reference objects owned by other schemas. Those must be migrated together, or reachable from PostgreSQL.', objects: cross.map((c) => `${c.refOwner}: ${c.referenced} ${c.refType.toLowerCase()}(s) used by ${c.objects} objects`), handling: 'Manual', recommendation: 'Plan these schemas in the same wave, or expose them through FDW / views.' });
  const syn = (checks.synonyms || []).filter((s) => s.tableOwner !== schema || s.dbLink);
  if (syn.length) add({ id: 'synonyms', severity: 'low', category: 'Dependencies', title: `${syn.length} synonyms pointing outside the schema`, detail: 'PostgreSQL has no synonyms: use views or search_path.', objects: syn.map((s) => `${s.owner}.${s.name} → ${s.tableOwner}.${s.table}${s.dbLink ? `@${s.dbLink}` : ''}`), handling: 'Exported as views in the GenAI zip', recommendation: 'Prefer search_path for whole-schema synonyms.' });

  // ---- Environment
  const cs = checks.charset || {};
  if (cs.NLS_CHARACTERSET && !/UTF8/.test(cs.NLS_CHARACTERSET)) {
    add({ id: 'charset', severity: 'medium', category: 'Data', title: `Oracle character set is ${cs.NLS_CHARACTERSET}`, detail: 'Data is converted to UTF8. Characters can grow to 2–4 bytes and invalid bytes stop the load.', objects: [], handling: 'NLS_LANG in Settings controls the conversion.', recommendation: 'Run Oracle CSSCAN/DMU on large text tables; VARCHAR2(n BYTE) limits become character limits in PostgreSQL.' });
  }
  const stale = tables.filter((t) => !t.lastAnalyzed || (Date.now() - new Date(t.lastAnalyzed)) / 86400000 > 30);
  if (stale.length) add({ id: 'stats', severity: 'low', category: 'Operations', title: `${stale.length} tables with missing or old statistics`, detail: 'Row estimates drive progress, time-left and chunk planning; stale statistics make them wrong.', objects: stale.map((t) => `${t.name} (${t.lastAnalyzed || 'never'})`), handling: 'Exact counts are still verified after the load.', recommendation: `Run DBMS_STATS.GATHER_SCHEMA_STATS('${schema}') before the migration.` });
  if (settings.ora2pg.PRESERVE_CASE) add({ id: 'preserve-case', severity: 'medium', category: 'Schema', title: 'Preserve case is on', detail: 'All PostgreSQL names stay upper case and must be quoted in every query ("EMPLOYEES").', objects: [], handling: 'Settings', recommendation: 'Turn it off unless the application already quotes every identifier.' });
  add({ id: 'empty-string', severity: 'info', category: 'Code', title: 'Empty string vs NULL', detail: "Oracle treats '' as NULL; PostgreSQL does not. Code testing IS NULL on strings, and NOT NULL text columns that hold '' behave differently.", objects: [], handling: settings.ora2pg.NULL_EQUAL_EMPTY ? 'NULL_EQUAL_EMPTY is on.' : 'Review in code conversion.', recommendation: 'Add a test for every string comparison in critical procedures.' });

  // ---- Summary
  findings.sort((a, b) => SEVERITY[b.severity] - SEVERITY[a.severity] || b.count - a.count);
  const counts = Object.fromEntries(Object.keys(SEVERITY).map((s) => [s, findings.filter((f) => f.severity === s).length]));
  // Who has to act: the tool (automatic), the team once (a decision in Settings), or someone doing work (manual).
  // Only decisions and manual work lower the readiness score: what the tool handles by itself is not a risk.
  const DECIDE = new Set(['number-noprec', 'booleans', 'charset', 'preserve-case', 'dblinks', 'reserved', 'partitions', 'cross-schema']);
  for (const f of findings) {
    f.action = f.severity === 'info' || /^(Automatic|Partly automatic)/.test(f.handling || '') || ['huge', 'huge-rowid', 'lob', 'no-pk', 'stats', 'iot'].includes(f.id) || f.id.startsWith('idx-bitmap') || f.id.startsWith('idx-reverse')
      ? 'auto'
      : DECIDE.has(f.id) ? 'decide' : 'manual';
  }
  const WEIGHT = { critical: 12, high: 6, medium: 3, low: 1, info: 0 };
  const penalty = findings.reduce((sum, f) => sum + (f.action === 'manual' ? WEIGHT[f.severity] : f.action === 'decide' ? 2 : 0), 0);
  const score = Math.max(5, 100 - penalty);
  const actions = { auto: findings.filter((f) => f.action === 'auto').length, decide: findings.filter((f) => f.action === 'decide').length, manual: findings.filter((f) => f.action === 'manual').length };
  const rate = throughput || null;
  const estimate = (mbps) => (totalMb / mbps) * 1000; // ms
  const level = ora2pg && ora2pg['migration level'];
  return {
    id, schema, createdAt: new Date().toISOString(),
    // Who agreed the migration decisions (Settings), as recorded when this report was made.
    decisions: settings.decisions && settings.decisions.agreedBy ? { agreedBy: settings.decisions.agreedBy, agreedAt: settings.decisions.agreedAt } : null,
    source: { version: (snapshot.dbVersion || [])[0], charset: cs.NLS_CHARACTERSET, ncharset: cs.NLS_NCHAR_CHARACTERSET },
    summary: {
      score,
      rating: score >= 80 ? 'Straightforward' : score >= 55 ? 'Moderate' : score >= 30 ? 'Some work needed' : 'Significant code work',
      counts,
      actions,
      sizeMb: totalMb, lobMb, tables: tables.length, rows: totalRows,
      codeObjects: plsql.filter((o) => o.type !== 'PACKAGE').length, codeLines: lines,
      ora2pg: ora2pg ? { level, levelText: levelText(level), cost: ora2pg['total cost'], days: ora2pg['human days cost'], objects: ora2pg['total number'], invalid: ora2pg['total invalid'] } : null,
      load: {
        measuredMbps: rate,
        estimates: [
          ...(rate ? [{ label: `Measured in this project (${rate.toFixed(0)} MB/s)`, mbps: rate, ms: estimate(rate) }] : []),
          { label: 'Slow network / LOB-heavy (15 MB/s)', mbps: 15, ms: estimate(15) },
          { label: 'Typical (40 MB/s)', mbps: 40, ms: estimate(40) },
          { label: 'Fast, same data centre (100 MB/s)', mbps: 100, ms: estimate(100) },
        ],
        targetDiskGb: Math.ceil((totalMb * 1.4) / 1024),
      },
    },
    findings,
    inventory: ora2pg ? ora2pg.objects.filter((o) => o.number > 0).map((o) => ({ object: o.object, number: o.number, invalid: o.invalid, cost: o['cost value'], comment: o.comment, details: o.details })) : [],
    dataTypes: checks.dataTypes || [],
    booleanCandidates: boolCands.map((b) => ({ ...b, key: `${b.table}:${b.column}` })),
    topTables: [...tables].sort((a, b) => b.sizeMb - a.sizeMb).slice(0, 15),
    plsqlTop: [...plsql].sort((a, b) => b.lines - a.lines).slice(0, 25),
    failedChecks: checks.failed,
    checklist: checklist({ settings, findings, totalMb, schema }),
    tableNames: tableNames.size,
  };
}

function levelText(level) {
  if (!level) return null;
  const [l, n] = level.split('-');
  const what = { A: 'Can be migrated automatically', B: 'Code rewriting needed', C: 'Code rewriting and functional/technical difficulties' }[l] || level;
  const effort = { 1: 'very low', 2: 'low', 3: 'medium', 4: 'high', 5: 'very high' }[n] || '';
  return `${what}; ${effort} effort`;
}

function checklist({ findings, totalMb }) {
  const has = (id) => findings.some((f) => f.id === id || f.id.startsWith(id));
  return [
    { phase: 'Before', items: [
      'Agree the migration decisions with the application team (Settings): name case, reserved-word columns, NUMBER mapping, boolean columns, LOBs, application roles.',
      'Gather Oracle statistics so row estimates and time-left are accurate.',
      'Open the firewall from every client network (VDI, app servers) to the PostgreSQL port early: firewall requests often take weeks.',
      totalMb > 100 * 1024 ? 'Raise UNDO_RETENTION / undo size on Oracle for the migration window (long reads on large tables).' : null,
      `Make sure PostgreSQL has ~${Math.ceil((totalMb * 1.4) / 1024)} GB free for data and indexes, plus WAL headroom.`,
      'Target tuning for the load: max_wal_size ≥ 16GB, checkpoint_timeout 30min, maintenance_work_mem 1–2GB, autovacuum off on the target schema during the load.',
      has('plsql') || has('packages') ? 'Export the GenAI candidates zip and start code conversion early: it is usually the critical path.' : null,
      has('dblinks') || has('cross-schema') ? 'Agree with dependent teams how other schemas / DB links will be reached (FDW, same wave, API).' : null,
      has('jobs') ? 'Inventory scheduler jobs and plan pg_cron / scheduler equivalents.' : null,
      'Run a full trial migration on a copy and time it before the cut-over weekend.',
    ] },
    { phase: 'During', items: [
      'Freeze application changes in Oracle (or stop the application) for the final run.',
      'Watch the Live monitor; failed tables retry automatically and Resume continues after interruptions.',
      has('huge-no-chunk') ? 'Start the largest non-chunkable tables first and avoid Oracle maintenance jobs during their load.' : null,
    ] },
    { phase: 'After', items: [
      'Validation page: row counts, keys, indexes and sequences must all match.',
      'Turn autovacuum back on and run ANALYZE (done by the finalize phase) before testing performance.',
      'Run application regression tests, especially around empty strings, dates/time zones and rounding.',
      'Validation → Code objects: every view, function and procedure must be present before testers start.',
      'No VACUUM FULL or other exclusive-lock maintenance during test windows; watch for idle-in-transaction sessions holding locks.',
      has('mviews') ? 'Schedule materialized view refreshes.' : null,
      'Keep Oracle read-only until the business signs off.',
    ] },
  ].map((g) => ({ ...g, items: g.items.filter(Boolean) }));
}

module.exports = { start, status: exportStatus, listReports, readReport, reportFile, measuredThroughput };
