import { fireEvent, render, screen, waitFor, within } from '@testing-library/react';
import { beforeEach, describe, expect, test, vi } from 'vitest';
import PreferencesDialog from '../../src/components/PreferencesDialog';
import ErrorHelp from '../../src/components/ErrorHelp';
import { StatusChip } from '../../src/components/ui';
import { DEFAULT_PREFS } from '../../src/prefs';

// The API and the sign-in are replaced: admin or not per test, preferences kept in memory.
// (Mocked modules instead of reloading the app for every test: fast also on slower PCs.)
const server = vi.hoisted(() => ({ admin: true, prefs: null as any, saved: [] as any[] }));
vi.mock('../../src/role', () => ({ useIsAdmin: () => server.admin, useMe: () => ({ id: 'U1', email: 'u1@corp' }) }));
vi.mock('../../src/api', async (orig) => ({
  ...(await orig<typeof import('../../src/api')>()),
  api: vi.fn(async (path: string, init: any = {}) => {
    if (path === '/preferences' && init.method === 'PUT') { server.saved.push(init.body.preferences); return { preferences: init.body.preferences }; }
    if (path === '/preferences') return { preferences: server.prefs };
    throw new Error(`unexpected ${path}`);
  }),
}));

beforeEach(() => { server.saved = []; server.prefs = structuredClone(DEFAULT_PREFS); });

function renderPrefs(admin: boolean) {
  server.admin = admin;
  const onClose = vi.fn();
  render(<PreferencesDialog open onClose={onClose} />);
  return { onClose, dialog: within(screen.getByRole('dialog')) };
}

describe('My preferences', () => {
  test('a normal user does not see the admin-only "Where did the time go?"', async () => {
    const { dialog } = renderPrefs(false);
    expect(await dialog.findByText('Server CPU and memory')).toBeInTheDocument();
    expect(dialog.queryByText('Where did the time go?')).not.toBeInTheDocument();
  });

  test('an admin sees it; a change is saved for this user and the dialog closes', async () => {
    const { onClose, dialog } = renderPrefs(true);
    expect(await dialog.findByText('Where did the time go?')).toBeInTheDocument();
    fireEvent.click(dialog.getByText('Phases', { exact: true }));
    fireEvent.click(dialog.getByRole('button', { name: 'Save' }));
    await waitFor(() => expect(onClose).toHaveBeenCalled());
    expect(server.saved[0].monitor.phases).toBe(false);
    expect(server.saved[0].monitor.serverUsage).toBe(true);
  });
});

describe('"What does this mean?"', () => {
  test('a known error opens its explanation; an unknown one says how to find the cause', () => {
    const { rerender } = render(<ErrorHelp text="ERROR:  deadlock detected" />);
    fireEvent.click(screen.getByText('What does this mean?'));
    expect(screen.getByText('Two steps waited for each other')).toBeInTheDocument();
    rerender(<ErrorHelp text="something never seen" defaultOpen key="x" />);
    expect(screen.getByText(/Not in DMA’s list of known errors yet/)).toBeInTheDocument();
    rerender(<ErrorHelp text="" key="y" />);
    expect(screen.queryByText('What does this mean?')).not.toBeInTheDocument();
  });
});

describe('status chips', () => {
  test('every run and table status has a readable label', () => {
    for (const [status, label] of [['running', 'Loading'], ['pending', 'Waiting'], ['COMPLETED_WITH_ERRORS', 'Completed with errors']]) {
      const { unmount } = render(<StatusChip status={status} />);
      expect(screen.getByText(label)).toBeInTheDocument();
      unmount();
    }
    // An unknown status still shows something readable, never an empty chip.
    render(<StatusChip status="SOMETHING_NEW" />);
    expect(screen.getByText('SOMETHING_NEW')).toBeInTheDocument();
  });
});
