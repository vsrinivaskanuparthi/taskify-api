# DMA v2: batch 10, error handling hardening (DMA-073)

**No `.env` change needed. No new npm package. `server.js` is not changed.**

## What's new

| # | Gap | Before | Now |
|---|---|---|---|
| 1 | A server action failed unexpectedly (disk or file error) | The browser kept **spinning forever**, with no message | A clear message, a **DMA error code** and a **reference (R-…)** to find the full error in the server log |
| 2 | Deleting a converted code package | Deleted at once, with no question; a failed delete was silent | Asks **"Delete this converted package?"** first, and shows why a delete failed |
| 2 | Saving column renames failed | Nothing shown | "Renames not saved: …" is shown in red |
| 3 | Error codes | None | Every known error has a code: **DMA-ORA**, **DMA-PG**, **DMA-NET**, **DMA-ENG**, **DMA-SYS**. Shown under "What does this mean?" and on the Guide page (searchable, e.g. `DMA-SYS-202`) |
| 4 | The staging disk filled up during a run | Every process failed at once | Below **5 GB** free: a warning in the run and a notification (once). Below **1 GB**: the run **stops safely** (DMA-SYS-202), and **Resume** continues |
| 5 | Server restart or crash during a run | The run stayed "Interrupted" until someone pressed Resume | The run **resumes by itself** about 20 s after the worker is back (DMA-ENG-201): at most 3 times per run, only within 24 h, never after a user's Cancel, never when the migration decisions changed (then DMA-ENG-202 says why) |
| 6 | After a crash, old ora2pg processes still running | A resumed run could load a table while an old process still wrote into it (DMA's row check caught it and retried) | Starts and resumes **wait until the old processes are gone** (up to 60 s, then they are stopped) |

**Also fixed (found while testing):**
- A project's app name, code or description could be saved as invalid data. Now refused with a message.
- "Delete package" for a package that doesn't exist said "Deleted". Now it says "not found".
- A wrong export download id returned an empty error. Now there's a message.

**Small text change:** a project name was removed from the Guide page and some code comments (neutral wording).

## Optional settings (`ora2pgservice/.env`; the defaults are fine)

| Setting | Default | Meaning |
|---|---|---|
| `DISK_WARN_GB` | 5 | Warning below this much free space on the staging disk |
| `DISK_STOP_GB` | 1 | Safe stop below this |
| `DISK_CHECK_SECONDS` | 30 | How often the disk is checked during a run |
| `AUTO_RESUME` | on | `off` = never resume automatically |
| `AUTO_RESUME_MAX` | 3 | Automatic resumes per run at most |
| `AUTO_RESUME_HOURS` | 24 | Only runs stopped within this time |
| `AUTO_RESUME_DELAY_SECONDS` | 20 | Wait after the worker starts |

The disk watch needs **Node.js 18.15 or newer** (check with `node -v`). On older Node it is simply off; everything else works.

## Files

| | Files |
|---|---|
| `ora2pgservice/` new | `utils/asyncRoute.js`, `utils/errorCodes.js`, `services/runGuards.js`, `tests/unit/errorHandling.test.js`, `tests/unit/runGuards.test.js`, `tests/unit/leftovers.test.js`, `tests/e2e/robustness.e2e.test.js` (and `tests/e2e/migration.e2e.test.js` changed) |
| `ora2pgservice/` changed | `services/migrate.js`, `routes/projectRoutes.js`, `utils/roles.js`, `controllers/projectController.js`, `controllers/codeController.js`, `services/code.js`, `queries/pg/compareCodeObjects.js` (comment only) |
| `ora2pgui/` new | `tests/unit/errorCodes.test.tsx`, `tests/e2e/robustness.spec.ts` (and `tests/e2e/screens.spec.ts` changed) |
| `ora2pgui/` changed | `src/api.ts`, `src/errorHelp.ts`, `src/components/ErrorHelp.tsx`, `src/pages/CodePage.tsx`, `src/pages/AssessmentPage.tsx`, `src/pages/GuidePage.tsx` |

## Deploy

1. Copy `ora2pgservice/` and `ora2pgui/` over your folders.
2. In `ora2pgservice`, run `npm test`. It should end with **Tests: 108 passed** (on Windows a few file-permission tests are skipped).
3. In `ora2pgui`, run `npm test` (should end with **45 passed**), then `npm run build`, then copy `index.html` to nginx.
4. On RHEL, **when no migration runs**:
   ```bash
   pm2 restart ora2pg-service-prod
   ```
   ```bash
   pm2 restart ora2pg-worker-prod
   ```
5. Press Ctrl+F5 in the browser.

## Test on RHEL

- [ ] **Guide page** → error search → type `DMA-SYS-202`: "Run stopped safely: disk almost full" appears with its code.
- [ ] **Code objects** → delete icon on a package: it asks first; "Keep it" keeps it.
- [ ] Any error box → "What does this mean?": the code is shown (e.g. `DMA-ORA-105`).
- [ ] **Automatic resume:** start a small test migration, then run `pm2 restart ora2pg-worker-prod` while tables are loading. The run shows "Interrupted", then about 20 s later "Resumed automatically after a server restart (DMA-ENG-201)", and completes with every row count equal to Oracle.
- [ ] Optional (test server only), **disk stop:** set `DISK_STOP_GB=100000` in `.env`, restart the worker, and start a small run. It stops safely with DMA-SYS-202. **Remove the line again** and restart the worker.

## Tested on the Mac (real migrations)

| Proof | Result |
|---|---|
| A settings save into a read-only project folder | Before: **no answer after 15 s**. Now: answer within ms (DMA-SYS-500 + reference) |
| Disk stop (limit set above the free space) | Run stopped safely, DMA-SYS-202, nothing left "loading" |
| Disk warning | Warned once, run completed |
| Worker **killed** (`kill -9`) mid-load, 5 tables / 4.6 M rows | Resumed by itself, completed, every row count equal to Oracle |
| Worker **restarted** normally mid-load | Resumed by itself, completed, every row count equal to Oracle |

After the last fix the crash and restart runs had **0 mismatches**: every table loaded on its first try.

Tests on the final code:
- API unit **108** passed.
- API e2e full suite **41** passed, 0 failed. 7 were skipped: 4 need the oracle_fdw test database, and 3 run inside the real-migration proof above.
- UI Vitest **45** passed.
- UI Playwright **26** passed.

**Test fixes in this batch:**
- `migration.e2e` now asks the project which schema it migrates into (it once checked the wrong schema).
- A browser test (`screens.spec`) now waits for the runs list before deciding there are no runs.
