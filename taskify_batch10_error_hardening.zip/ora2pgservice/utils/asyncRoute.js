'use strict';

/**
 * Express 4 does not catch an error thrown by an async handler: the request then never gets an
 * answer and the browser keeps spinning. safeRouter() wraps every handler and middleware of a
 * router so a failure always reaches errorResponder(), which answers with a clear JSON message,
 * a DMA error code and a short reference that is also written to the server log.
 */
const crypto = require('crypto');
const logger = require('./logger');
const { codeForStatus } = require('./errorCodes');

function wrapHandler(fn) {
  // Error handlers (4 arguments) and non-functions are left as they are.
  if (typeof fn !== 'function' || fn.length === 4) return fn;
  return function safeHandler(req, res, next) {
    try {
      const result = fn(req, res, next);
      if (result && typeof result.catch === 'function') result.catch(next);
      return result;
    } catch (err) {
      return next(err);
    }
  };
}

const wrapArg = (a) => (Array.isArray(a) ? a.map(wrapHandler) : wrapHandler(a));

/** Wraps every handler added to this router (get/post/put/patch/delete/all/use) from now on. */
function safeRouter(router) {
  for (const method of ['get', 'post', 'put', 'patch', 'delete', 'all', 'use']) {
    const original = router[method].bind(router);
    router[method] = (...args) => original(...args.map(wrapArg));
  }
  return router;
}

/** Status of an error: its own (4xx/5xx), 413 for a too-large body, 400 for bad JSON, else 500. */
function statusOf(err) {
  const s = Number(err && (err.status || err.statusCode));
  if (s >= 400 && s < 600) return s;
  if (err && err.type === 'entity.too.large') return 413;
  if (err instanceof SyntaxError && 'body' in err) return 400;
  return 500;
}

/** Last middleware of the API router: one answer for every failure. */
// eslint-disable-next-line no-unused-vars
function errorResponder(err, req, res, next) {
  const status = statusOf(err);
  const code = (err && typeof err.code === 'string' && /^DMA-[A-Z]{2,3}-\d{3}$/.test(err.code)) ? err.code : codeForStatus(status);
  const ref = `R-${crypto.randomBytes(3).toString('hex').toUpperCase()}`;
  logger.error(`[${ref}] ${code} ${req.method} ${req.originalUrl}: ${err && err.stack ? err.stack : err}`);
  if (res.headersSent) {
    // A stream (live updates, a download) had already started: just close it.
    res.end();
    return;
  }
  // Server-side failures: no internal details (file paths, SQL) in the browser; the log has them.
  const message = status >= 500
    ? `Something went wrong on the DMA server. Please try again; if it happens again, send this reference to the DMA team: ${ref}.`
    : (err && err.message) || 'The request was not valid.';
  res.status(status).json({ message, code, ref });
}

module.exports = { safeRouter, wrapHandler, errorResponder, statusOf };
