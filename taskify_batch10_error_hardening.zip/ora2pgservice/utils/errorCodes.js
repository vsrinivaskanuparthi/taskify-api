'use strict';

/**
 * DMA error codes (DMA-<AREA>-<number>) for errors the server itself reports.
 * Areas: ORA (Oracle), PG (PostgreSQL), NET (network), ENG (DMA's engine and checks), SYS (server, disk).
 * The codes for known ora2pg / Oracle / PostgreSQL error texts live with their plain-words
 * explanations in the UI (frontend/src/errorHelp.ts). Every code is unique across both lists:
 * a new code is one line here or there (the unit tests check the format and that none repeats).
 */
const CODES = {
  'DMA-SYS-400': 'The request was not valid.',
  'DMA-SYS-403': 'Only DMA administrators can do this.',
  'DMA-SYS-404': 'Not found.',
  'DMA-SYS-409': 'Not possible right now: something else is running.',
  'DMA-SYS-413': 'The upload or request is too large.',
  'DMA-SYS-500': 'Unexpected error on the DMA server.',
  'DMA-SYS-201': 'Staging disk running low during a run (warning).',
  'DMA-SYS-202': 'Run stopped safely: the staging disk was almost full.',
  'DMA-ENG-201': 'Run resumed automatically after a server restart.',
  'DMA-ENG-202': 'Not resumed automatically (limit reached, decisions changed or another reason): resume by hand.',
};

/** The code for an HTTP status (when an error carries no code of its own). */
function codeForStatus(status) {
  if (status === 400 || status === 403 || status === 404 || status === 409 || status === 413) return `DMA-SYS-${status}`;
  return status >= 500 ? 'DMA-SYS-500' : 'DMA-SYS-400';
}

module.exports = { CODES, codeForStatus };
