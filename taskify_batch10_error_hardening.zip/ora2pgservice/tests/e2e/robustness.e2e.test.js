'use strict';

/**
 * End-to-end: error handling hardening (DMA-073) on the running API and worker.
 *  - Always: a failure inside the server is answered (code + reference), never left spinning;
 *    the input bugs found while checking (invalid project fields, missing package, wrong export id).
 *  - DMA_E2E_DISK_STOP=1: the worker was started with a stop limit above the free space, so a run
 *    must stop safely with DMA-SYS-202 (dev-tools/check-robustness.sh sets this up).
 *  - DMA_E2E_AUTORESUME_RUN=<runId>: that run was interrupted by killing the worker; it must have
 *    resumed by itself and completed (dev-tools/check-robustness.sh).
 */
const fs = require('fs');
const path = require('path');
const { API, P, call, apiUp, waitRun } = require('./helpers');

const STAGING = process.env.DMA_E2E_STAGING || '';
const PROJECT = process.env.DMA_E2E_PROJECT || 'E2E_TEST';
jest.setTimeout(10 * 60 * 1000);

async function timed(method, url, body, ms = 10000) {
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), ms);
  try {
    const res = await fetch(url, { method, headers: { 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined, signal: ctl.signal });
    return { status: res.status, data: await res.json().catch(() => null) };
  } catch (err) {
    return { status: 0, error: err.name === 'AbortError' ? `no answer within ${ms} ms` : err.message };
  } finally {
    clearTimeout(t);
  }
}

describe('Every failure gets an answer', () => {
  beforeAll(apiUp);

  (STAGING ? test : test.skip)('saving settings into a folder that cannot be written answers with a code, not a spinner', async () => {
    const name = 'E2E_ERR_PROBE';
    await call('POST', `${API}/api/projects`, { projectName: name, appName: 'Error probe', appCode: 'ERR' });
    const dir = path.join(STAGING, name);
    expect(fs.existsSync(dir)).toBe(true);
    fs.chmodSync(dir, 0o555);
    try {
      const r = await timed('PUT', `${API}/api/projects/${name}/settings`, { targetSchema: 'x' });
      expect(r.error).toBeUndefined();
      expect(r.status).toBe(500);
      expect(r.data).toMatchObject({ code: 'DMA-SYS-500' });
      expect(r.data.ref).toMatch(/^R-[0-9A-F]{6}$/);
    } finally {
      fs.chmodSync(dir, 0o755);
      await call('DELETE', `${API}/api/projects/${name}`, { confirm: name });
    }
  });

  test('invalid project fields are refused and nothing is saved', async () => {
    const before = (await call('GET', P)).data.project.appName;
    const r = await call('PATCH', P, { appName: { x: 1 } });
    expect(r.status).toBe(400);
    expect(r.data.code).toBe('DMA-SYS-400');
    expect((await call('GET', P)).data.project.appName).toBe(before);
  });

  test('a package that does not exist is reported, not "Deleted"', async () => {
    const r = await call('DELETE', `${P}/code/packages/19990101-000000`);
    expect(r.status).toBe(404);
    expect(r.data.code).toBe('DMA-SYS-404');
  });

  test('a wrong export id gets a message', async () => {
    const r = await call('GET', `${P}/code/exports/abc/download`);
    expect(r.status).toBe(400);
    expect(r.data).toMatchObject({ code: 'DMA-SYS-400', message: 'Invalid export id.' });
  });
});

describe('Run safety nets', () => {
  (process.env.DMA_E2E_DISK_STOP === '1' ? test : test.skip)('a run stops safely when the staging disk is (made) almost full', async () => {
    const start = await call('POST', `${P}/runs`, { tables: ['PLANT', 'STATION'] });
    expect(start.status).toBe(202);
    const run = await waitRun(start.data.runId);
    expect(run.status).toBe('FAILED');
    expect(run.error).toContain('DMA-SYS-202');
    expect(run.events.some((e) => /staging disk is almost full/.test(e.message))).toBe(true);
    // Nothing is left marked as loading: Resume can continue cleanly.
    expect(Object.values(run.tables).some((t) => t.status === 'running')).toBe(false);
    console.log(`disk-stop run: ${start.data.runId}`);
  });

  (process.env.DMA_E2E_DISK_WARN === '1' ? test : test.skip)('a low-disk warning is given once and the run still completes', async () => {
    const start = await call('POST', `${P}/runs`, { tables: ['PLANT'] });
    expect(start.status).toBe(202);
    const run = await waitRun(start.data.runId);
    expect(run.status).toBe('COMPLETED');
    expect(run.events.filter((e) => /DMA-SYS-201/.test(e.message))).toHaveLength(1);
  });

  (process.env.DMA_E2E_AUTORESUME_RUN ? test : test.skip)('a run interrupted by a worker crash resumed by itself and completed', async () => {
    const runId = process.env.DMA_E2E_AUTORESUME_RUN;
    const run = await waitRun(runId);
    expect(run.status).toBe('COMPLETED');
    expect(run.attempt).toBeGreaterThanOrEqual(2);
    expect(run.autoResumes).toBe(1);
    expect(run.events.some((e) => /Resumed automatically after a server restart/.test(e.message))).toBe(true);
    Object.values(run.tables).forEach((t) => {
      expect(t.status).toBe('done');
      expect(t.pgRows).toBe(t.oracleRows);
    });
  });
});

module.exports = { PROJECT };
