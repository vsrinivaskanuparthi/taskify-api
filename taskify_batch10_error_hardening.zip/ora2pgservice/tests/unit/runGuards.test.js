'use strict';

// Disk watch and automatic resume (DMA-073): the decisions, with every edge case.
const os = require('os');
const { diskLimits, diskLevel, diskSpace, autoResumeSettings, autoResumeDecision, GB } = require('../../services/runGuards');

describe('disk watch', () => {
  test('defaults: warning below 5 GB, safe stop below 1 GB, checked every 30 s', () => {
    expect(diskLimits({})).toEqual({ warnGb: 5, stopGb: 1, everySeconds: 30 });
  });

  test('limits come from .env; the warning is never below the stop limit; odd values fall back', () => {
    expect(diskLimits({ DISK_WARN_GB: '20', DISK_STOP_GB: '3', DISK_CHECK_SECONDS: '10' })).toEqual({ warnGb: 20, stopGb: 3, everySeconds: 10 });
    expect(diskLimits({ DISK_WARN_GB: '2', DISK_STOP_GB: '8' }).warnGb).toBe(8);
    expect(diskLimits({ DISK_WARN_GB: 'abc', DISK_CHECK_SECONDS: '1' })).toEqual({ warnGb: 5, stopGb: 1, everySeconds: 5 });
  });

  test('ok / warn / stop by free space', () => {
    const l = { warnGb: 5, stopGb: 1 };
    expect(diskLevel(50 * GB, l)).toBe('ok');
    expect(diskLevel(5 * GB, l)).toBe('ok');
    expect(diskLevel(4.9 * GB, l)).toBe('warn');
    expect(diskLevel(0.5 * GB, l)).toBe('stop');
  });

  test('unknown free space never stops a run', () => {
    expect(diskLevel(NaN, { warnGb: 5, stopGb: 1 })).toBe('ok');
    expect(diskLevel(undefined, { warnGb: 5, stopGb: 1 })).toBe('ok');
  });

  test('reads the real free space of a folder', async () => {
    const s = await diskSpace(os.tmpdir());
    expect(s.free).toBeGreaterThan(0);
    expect(s.total).toBeGreaterThanOrEqual(s.free);
    expect(await diskSpace('/no/such/folder')).toBeNull();
  });
});

describe('automatic resume after a restart', () => {
  const now = new Date('2026-11-16T12:00:00Z');
  const s = { on: true, max: 3, hours: 24, delaySeconds: 20 };
  const run = (over = {}) => ({ status: 'INTERRUPTED', interruptedBy: 'server', finishedAt: '2026-11-16T11:59:00Z', ...over });

  test('defaults: on, 3 times per run, within 24 h, after 20 s; AUTO_RESUME=off switches it off', () => {
    expect(autoResumeSettings({})).toEqual({ on: true, max: 3, hours: 24, delaySeconds: 20 });
    expect(autoResumeSettings({ AUTO_RESUME: 'OFF' }).on).toBe(false);
  });

  test('a run the server stopped a minute ago resumes', () => {
    expect(autoResumeDecision(run(), now, s)).toEqual({ resume: true });
  });

  test('a run a user cancelled, or that failed, never resumes by itself', () => {
    expect(autoResumeDecision(run({ status: 'CANCELLED', interruptedBy: null }), now, s).resume).toBe(false);
    expect(autoResumeDecision(run({ status: 'FAILED' }), now, s).resume).toBe(false);
    expect(autoResumeDecision(run({ interruptedBy: undefined }), now, s).resume).toBe(false);
  });

  test('at most 3 automatic resumes per run (no endless restart loop), reported as a limit', () => {
    expect(autoResumeDecision(run({ autoResumes: 2 }), now, s).resume).toBe(true);
    const d = autoResumeDecision(run({ autoResumes: 3 }), now, s);
    expect(d).toMatchObject({ resume: false, limit: true });
    expect(d.reason).toContain('3 times');
  });

  test('a run stopped more than 24 h ago waits for a person', () => {
    expect(autoResumeDecision(run({ finishedAt: '2026-11-14T10:00:00Z' }), now, s)).toMatchObject({ resume: false });
  });

  test('switched off: nothing resumes', () => {
    expect(autoResumeDecision(run(), now, { ...s, on: false }).resume).toBe(false);
  });
});
