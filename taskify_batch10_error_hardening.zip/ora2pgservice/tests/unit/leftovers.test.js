'use strict';

// After a crash, a resumed run waits until the old ora2pg / psql processes are really gone (DMA-073):
// a leftover process still writing into a table that is being reloaded would duplicate rows.
const { spawn } = require('child_process');
const { waitForExit } = require('../../services/migrate');

const alive = (pid) => { try { process.kill(-pid, 0); return true; } catch { return false; } };
const start = (script) => {
  const child = spawn('sh', ['-c', script], { detached: true, stdio: 'ignore' });
  child.unref();
  return child.pid;
};

(process.platform === 'win32' ? describe.skip : describe)('leftover processes after a crash', () => {
  test('returns at once when they are already gone', async () => {
    const t = Date.now();
    await waitForExit([999999], 5000);
    expect(Date.now() - t).toBeLessThan(1500);
  });

  test('waits while a leftover process is still finishing', async () => {
    const pid = start('sleep 2');
    const t = Date.now();
    await waitForExit([pid], 10000);
    expect(alive(pid)).toBe(false);
    expect(Date.now() - t).toBeGreaterThanOrEqual(1000);
  });

  test('a process that ignores the stop request is killed after the wait', async () => {
    const pid = start('trap "" TERM; sleep 60');
    process.kill(-pid, 'SIGTERM'); // ignored
    await waitForExit([pid], 1500);
    expect(alive(pid)).toBe(false);
  }, 15000);
});
