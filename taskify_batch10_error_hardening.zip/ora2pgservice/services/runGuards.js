'use strict';

/**
 * Two safety nets for running migrations (pure decisions, tested on their own):
 *
 *  Disk watch     the staging disk is checked during the run: below DISK_WARN_GB free a warning
 *                 (once), below DISK_STOP_GB the run stops safely, and Resume continues later.
 *                 Running out of disk in the middle of a load is worse: every process fails.
 *  Auto-resume    runs the server stopped (restart, deploy, crash) resume by themselves when it
 *                 comes back: at most AUTO_RESUME_MAX times per run (no endless restart loop),
 *                 only if they stopped in the last AUTO_RESUME_HOURS. AUTO_RESUME=off disables it.
 *                 Runs a user cancelled are never resumed automatically.
 */
const fsp = require('fs').promises;

const num = (v, d) => (v !== undefined && v !== '' && Number.isFinite(Number(v)) ? Number(v) : d);
const GB = 1024 ** 3;

function diskLimits(env = process.env) {
  const stopGb = Math.max(0, num(env.DISK_STOP_GB, 1));
  return { warnGb: Math.max(stopGb, num(env.DISK_WARN_GB, 5)), stopGb, everySeconds: Math.max(5, num(env.DISK_CHECK_SECONDS, 30)) };
}

/** 'ok' | 'warn' | 'stop' for this much free space. Unknown free space is never a reason to stop. */
function diskLevel(freeBytes, limits = diskLimits()) {
  if (!Number.isFinite(freeBytes) || freeBytes < 0) return 'ok';
  if (freeBytes < limits.stopGb * GB) return 'stop';
  if (freeBytes < limits.warnGb * GB) return 'warn';
  return 'ok';
}

/** Free and total bytes of the disk holding dir, or null where the system cannot tell (older Node). */
async function diskSpace(dir) {
  if (typeof fsp.statfs !== 'function') return null;
  try {
    const s = await fsp.statfs(dir);
    return { free: s.bavail * s.bsize, total: s.blocks * s.bsize };
  } catch {
    return null;
  }
}

const fmtGb = (bytes) => `${(bytes / GB).toFixed(1)} GB`;

function autoResumeSettings(env = process.env) {
  return {
    on: String(env.AUTO_RESUME || 'on').toLowerCase() !== 'off',
    max: Math.max(0, num(env.AUTO_RESUME_MAX, 3)),
    hours: Math.max(0, num(env.AUTO_RESUME_HOURS, 24)),
    delaySeconds: Math.max(0, num(env.AUTO_RESUME_DELAY_SECONDS, 20)),
  };
}

/**
 * Should this run resume by itself? { resume: true } or { resume: false, reason }.
 * state: the run's saved state; now: Date; s: autoResumeSettings().
 */
function autoResumeDecision(state, now = new Date(), s = autoResumeSettings()) {
  if (!s.on) return { resume: false, reason: 'automatic resume is switched off (AUTO_RESUME=off)' };
  if (!state || state.status !== 'INTERRUPTED' || state.interruptedBy !== 'server') return { resume: false, reason: 'not stopped by the server' };
  const done = state.autoResumes || 0;
  if (done >= s.max) return { resume: false, reason: `already resumed automatically ${done} time${done === 1 ? '' : 's'} (limit ${s.max})`, limit: true };
  const stoppedAt = Date.parse(state.finishedAt || '');
  if (Number.isFinite(stoppedAt) && now.getTime() - stoppedAt > s.hours * 3600000) return { resume: false, reason: `stopped more than ${s.hours} h ago` };
  return { resume: true };
}

module.exports = { diskLimits, diskLevel, diskSpace, fmtGb, autoResumeSettings, autoResumeDecision, GB };
