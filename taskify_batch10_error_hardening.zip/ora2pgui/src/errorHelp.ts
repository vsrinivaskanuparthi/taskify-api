/**
 * "What does this mean?": known ora2pg / psql / Oracle / PostgreSQL errors explained in plain
 * words, each with its DMA error code (the codes the server itself sends are in
 * backend/utils/errorCodes.js: no code may be used twice across both lists). Matched against the error text shown in the app (table errors, run errors, DDL failures,
 * the run's error log). Add a new entry for every new error met on a real migration.
 *
 * impact: how much of the migration it touches
 *   none   nothing is lost, the tool handles it
 *   object one object (a type, index, key, view…), the data is fine
 *   table  one table (or one piece of it) is not loaded
 *   run    the whole run is stopped or cannot start
 */
export type Impact = 'none' | 'object' | 'table' | 'run';

export interface ErrorHelpEntry {
  id: string;
  /** DMA error code: DMA-<AREA>-<number>; ORA Oracle, PG PostgreSQL, NET network, ENG DMA's checks, SYS server. Never reused. */
  code: string;
  match: RegExp;
  title: string;
  meaning: string;
  impact: Impact;
  action: string;
}

export const IMPACT_TEXT: Record<Impact, string> = {
  none: 'Nothing is lost',
  object: 'Only this object; the data is fine',
  table: 'This table is not loaded yet',
  run: 'The run is stopped',
};

export const ERROR_HELP: ErrorHelpEntry[] = [
  // ---- Reported by DMA itself (codes also sent by the server)
  {
    id: 'server-error',
    code: 'DMA-SYS-500',
    match: /DMA-SYS-500|Something went wrong on the DMA server/i,
    title: 'Unexpected error on the DMA server',
    meaning: 'The server could not finish this action because of an error it did not expect. The full error is in the server log under the reference shown (R-…).',
    impact: 'none',
    action: 'Try again. If it happens again, send the reference R-… to the DMA team: they find the exact error in the log with it.',
  },
  {
    id: 'disk-low',
    code: 'DMA-SYS-201',
    match: /DMA-SYS-201|Staging disk is running low/i,
    title: 'The staging disk is running low',
    meaning: 'The disk where DMA keeps run files and exports has little free space left. The run continues for now.',
    impact: 'none',
    action: 'Free space now (old runs, export files, logs) or ask the server team for more disk. Below the stop limit the run stops safely by itself.',
  },
  {
    id: 'disk-stop',
    code: 'DMA-SYS-202',
    match: /DMA-SYS-202|staging disk is almost full/i,
    title: 'Run stopped safely: disk almost full',
    meaning: 'DMA stopped the run before the disk filled up completely (a full disk makes every process fail at once). Tables already loaded are kept.',
    impact: 'run',
    action: 'Free disk space on the DMA server, then press Resume: the run continues where it stopped.',
  },
  {
    id: 'auto-resumed',
    code: 'DMA-ENG-201',
    match: /DMA-ENG-201|Resumed automatically after a server restart/i,
    title: 'Resumed automatically after a server restart',
    meaning: 'The server was restarted (for example a deploy) while this run was going. DMA continued the run by itself where it stopped.',
    impact: 'none',
    action: 'Nothing to do. Each run resumes by itself a few times at most, so a server that keeps crashing does not loop forever.',
  },
  {
    id: 'auto-resume-stopped',
    code: 'DMA-ENG-202',
    match: /DMA-ENG-202|Not resumed automatically/i,
    title: 'Not resumed automatically',
    meaning: 'The run was stopped by the server, but DMA did not continue it by itself: the limit of automatic resumes was reached, or the migration decisions changed.',
    impact: 'run',
    action: 'Look at the run\'s errors first (repeated stops usually have one cause), then press Resume, or start a new run if the decisions changed.',
  },
  // ---- Definitions (types, tables, indexes, keys)
  {
    id: 'type-modify',
    code: 'DMA-PG-101',
    match: /syntax error at or near "MODIFY"|ALTER TYPE .* (MODIFY|ADD|DROP) ATTRIBUTE/i,
    title: 'Oracle changed a type after creating it',
    meaning: 'Oracle has a command like “ALTER TYPE … MODIFY ATTRIBUTE” (a type made bigger later). PostgreSQL writes it differently.',
    impact: 'object',
    action: 'This version converts it automatically. If you still see it, the run was made with an older version: run it again.',
  },
  {
    id: 'already-exists',
    code: 'DMA-PG-102',
    match: /already exists/i,
    title: 'It is already there',
    meaning: 'The object was created by an earlier run or an earlier attempt.',
    impact: 'none',
    action: 'Nothing to do. Re-running is safe: existing tables are emptied before they are loaded again.',
  },
  {
    id: 'not-null',
    code: 'DMA-PG-103',
    match: /null value in column .* violates not-null/i,
    title: 'An empty value in a column that must be filled',
    meaning: 'Oracle treats an empty text (\'\') as NULL. A column marked NOT NULL in PostgreSQL then refuses those rows.',
    impact: 'table',
    action: 'Ask the application team: either allow NULL in that column, or fill it with a default. Then start a new run.',
  },
  {
    id: 'fk-violation',
    code: 'DMA-PG-104',
    match: /violates foreign key constraint|insert or update on table .* violates foreign key/i,
    title: 'Some rows point to a parent that does not exist',
    meaning: 'A child row (for example an order item) refers to a parent (an order) that is not there. Usually the same rows are already broken in Oracle.',
    impact: 'object',
    action: 'The key is kept as NOT VALID: new rows are still checked. Show the listed rows to the application team.',
  },
  {
    id: 'unique',
    code: 'DMA-PG-105',
    match: /duplicate key value violates unique|could not create unique index/i,
    title: 'Duplicate values where they must be unique',
    meaning: 'Two rows have the same key. Often Oracle had this key disabled or “not validated”, so the duplicates were already there.',
    impact: 'object',
    action: 'Find the duplicates in Oracle (GROUP BY the key HAVING COUNT(*) > 1) and agree with the application team which rows to keep.',
  },
  {
    id: 'pg-does-not-exist',
    code: 'DMA-PG-106',
    match: /(relation|type|function|schema|column) .* does not exist/i,
    title: 'Something it depends on is missing',
    meaning: 'The statement uses a table, type, function or column that PostgreSQL does not have (yet). Often an earlier error is the real cause.',
    impact: 'object',
    action: 'Look at the first error in the list: fix that one, then press Resume.',
  },
  {
    id: 'partition-not-valid',
    code: 'DMA-PG-107',
    match: /cannot add NOT VALID foreign key on partitioned table/i,
    title: 'Partitioned table key',
    meaning: 'PostgreSQL adds keys on partitioned tables in one step.',
    impact: 'none',
    action: 'Nothing to do: handled automatically.',
  },
  {
    id: 'syntax',
    code: 'DMA-PG-108',
    match: /syntax error at or near/i,
    title: 'PostgreSQL did not understand an Oracle command',
    meaning: 'A definition or a piece of code still contains Oracle-only wording.',
    impact: 'object',
    action: 'Open the log line to see the statement. Definitions: tell the DMA team (it can be converted automatically). Code: fix it in the converted package.',
  },

  // ---- Data does not fit
  {
    id: 'too-long',
    code: 'DMA-PG-201',
    match: /value too long for type/i,
    title: 'A text is longer than its column',
    meaning: 'Usually Oracle counts the size in bytes and PostgreSQL in characters, or the other way round (accents, special characters).',
    impact: 'table',
    action: 'In Settings, make that column bigger (or use text), then start a new run for this table.',
  },
  {
    id: 'invalid-input',
    code: 'DMA-PG-202',
    match: /invalid input syntax for (type )?\w+/i,
    title: 'A value does not match the column type',
    meaning: 'For example text in a number column, or a 0/1 column turned into true/false that holds another value.',
    impact: 'table',
    action: 'Check the column’s type choice in Settings (Migration decisions), then start a new run.',
  },
  {
    id: 'out-of-range',
    code: 'DMA-PG-203',
    match: /out of range|date\/time field value out of range|numeric field overflow/i,
    title: 'A number or date is too big for its column',
    meaning: 'For example a year 0000 date, or a number with more digits than the column allows.',
    impact: 'table',
    action: 'Find the value in Oracle and agree with the application team: fix the data, or use a bigger type.',
  },
  {
    id: 'encoding',
    code: 'DMA-PG-204',
    match: /invalid byte sequence for encoding|character with byte sequence/i,
    title: 'Broken characters in the data',
    meaning: 'Some text in Oracle is stored in a different character set than declared.',
    impact: 'table',
    action: 'Ask the DBA to find the rows with bad characters, or set the client encoding in Settings.',
  },

  // ---- Checks done by DMA
  {
    id: 'row-mismatch',
    code: 'DMA-ENG-101',
    match: /row count mismatch/i,
    title: 'Different number of rows in Oracle and PostgreSQL',
    meaning: 'After loading, the counts did not match. Often rows changed during the copy while the snapshot was off.',
    impact: 'table',
    action: 'Retried automatically. If it keeps happening: turn the snapshot on, or stop the application during the copy.',
  },
  {
    id: 'data-check',
    code: 'DMA-ENG-102',
    match: /data check failed/i,
    title: 'Same rows, but some values differ',
    meaning: 'A column total is different on both sides: for example decimals cut because a number became an integer.',
    impact: 'table',
    action: 'Check the type of the column named in the message (Settings), then start a new run.',
  },
  {
    id: 'hung',
    code: 'DMA-ENG-103',
    match: /no progress for|stopped as hung/i,
    title: 'The copy stopped moving',
    meaning: 'Nothing happened for a long time, usually a network connection that dropped silently.',
    impact: 'none',
    action: 'Retried automatically. If it happens often, ask the network team to check the link.',
  },
  {
    id: 'export-warning',
    code: 'DMA-ENG-104',
    match: /an error occurs during data export/i,
    title: 'ora2pg reported a problem at the end of the export',
    meaning: 'In older versions this came from parallel ora2pg runs sharing one temporary folder. This version gives each run its own folder.',
    impact: 'table',
    action: 'Retried automatically. If it stays, open the table log for the real error above this line.',
  },
  {
    id: 'undo',
    code: 'DMA-ORA-110',
    match: /ORA-01555|snapshot too old|undo no longer reaches|ORA-0818[01]/i,
    title: 'Oracle no longer keeps the data of the snapshot moment',
    meaning: 'The run reads every table as it was at its start. Oracle keeps that old data only for a limited time (undo retention).',
    impact: 'table',
    action: 'Press “Resume without snapshot” (stop the application first), or ask the DBA to raise UNDO_RETENTION and start a new run.',
  },

  // ---- Oracle
  {
    id: 'ora-priv',
    code: 'DMA-ORA-101',
    match: /ORA-01031|insufficient privileges/i,
    title: 'The Oracle user is missing a permission',
    meaning: 'The migration user may not read something it needs.',
    impact: 'run',
    action: 'Ask the DBA for SELECT ANY DICTIONARY and SELECT ANY TABLE (or SELECT on each table) for the migration user.',
  },
  {
    id: 'ora-942',
    code: 'DMA-ORA-102',
    match: /ORA-00942|table or view does not exist/i,
    title: 'Oracle says the table or view does not exist',
    meaning: 'Either it was dropped, or the migration user is not allowed to see it.',
    impact: 'table',
    action: 'Check the name and the grants with the DBA, then take a new snapshot.',
  },
  {
    id: 'ora-flashback',
    code: 'DMA-ORA-103',
    match: /ORA-41900|FLASHBACK/i,
    title: 'No permission for the snapshot',
    meaning: 'Reading every table “as of one moment” needs the FLASHBACK permission.',
    impact: 'none',
    action: 'Ask the DBA for FLASHBACK ANY TABLE, or turn the snapshot off and stop the application during the copy.',
  },
  {
    id: 'ora-types',
    code: 'DMA-ORA-104',
    match: /OCI-21700|ORA-24360|ORA-21700/i,
    title: 'The Oracle user may not use the schema’s object types',
    meaning: 'Columns of a custom Oracle type can only be read with permission on that type.',
    impact: 'table',
    action: 'Ask the DBA: GRANT EXECUTE ANY TYPE to the migration user (or EXECUTE on each type).',
  },
  {
    id: 'ora-login',
    code: 'DMA-ORA-105',
    match: /ORA-01017|invalid username\/password/i,
    title: 'Wrong Oracle user name or password',
    meaning: 'Oracle refused the login.',
    impact: 'run',
    action: 'Check the user and password on the Connections page.',
  },
  {
    id: 'ora-locked',
    code: 'DMA-ORA-106',
    match: /ORA-28000|account is locked/i,
    title: 'The Oracle account is locked',
    meaning: 'Too many wrong passwords, or the DBA locked it.',
    impact: 'run',
    action: 'Ask the DBA to unlock the account.',
  },
  {
    id: 'ora-network',
    code: 'DMA-NET-101',
    match: /ORA-12170|ORA-12541|ORA-12514|ORA-12545|ORA-12537|ORA-03113|ORA-03135|TNS:/i,
    title: 'Cannot reach Oracle',
    meaning: 'The network, the Oracle listener or the service name is not right, or the connection dropped.',
    impact: 'run',
    action: 'Check host, port and service name on the Connections page; ask the network team about the firewall. Then press Resume.',
  },
  {
    id: 'ora-temp',
    code: 'DMA-ORA-107',
    match: /ORA-01652|unable to extend temp segment/i,
    title: 'Oracle’s temporary space is full',
    meaning: 'Big reads or many readers at once need temporary space in Oracle.',
    impact: 'table',
    action: 'Ask the DBA for more TEMP space, or lower “Tables in parallel” / “Parallel chunks” on the Migrate page.',
  },
  {
    id: 'ora-memory',
    code: 'DMA-ORA-108',
    match: /ORA-0403[06]|PGA memory/i,
    title: 'Oracle ran out of memory for this session',
    meaning: 'Too many readers at the same time for the Oracle server.',
    impact: 'table',
    action: 'Lower “Tables in parallel” or “Parallel chunks” on the Migrate page.',
  },
  {
    id: 'ora-invalid-id',
    code: 'DMA-ORA-109',
    match: /ORA-00904|invalid identifier/i,
    title: 'Oracle does not know a column name',
    meaning: 'Often a column with a reserved word or special characters in its name.',
    impact: 'table',
    action: 'Check the column renames in Settings, then start a new run.',
  },

  // ---- PostgreSQL / server
  {
    id: 'pg-auth',
    code: 'DMA-PG-301',
    match: /password authentication failed|no pg_hba\.conf entry/i,
    title: 'PostgreSQL refused the login',
    meaning: 'Wrong password, or PostgreSQL does not accept connections from this server.',
    impact: 'run',
    action: 'Check the password on the Connections page; ask the PostgreSQL DBA to allow this server (pg_hba.conf).',
  },
  {
    id: 'pg-ssl',
    code: 'DMA-NET-102',
    match: /SSL (connection is required|is not enabled|off)|server does not support SSL/i,
    title: 'SSL setting does not match PostgreSQL',
    meaning: 'PostgreSQL wants an encrypted connection and DMA did not use one, or the other way round.',
    impact: 'run',
    action: 'Set PG_SSL=true or PG_SSL=false in backend/.env, restart the API, connect again.',
  },
  {
    id: 'pg-conn',
    code: 'DMA-NET-103',
    match: /could not connect to server|connection refused|ECONNREFUSED|timeout expired|ETIMEDOUT|Connection terminated/i,
    title: 'Cannot reach PostgreSQL',
    meaning: 'PostgreSQL is down, or the network/firewall blocks the port.',
    impact: 'run',
    action: 'Check that PostgreSQL is up and the port is open from this server. Then press Resume.',
  },
  {
    id: 'pg-slots',
    code: 'DMA-PG-302',
    match: /remaining connection slots|too many clients/i,
    title: 'PostgreSQL has no free connections',
    meaning: 'The run opens several connections at once and PostgreSQL’s limit (max_connections) is reached.',
    impact: 'table',
    action: 'Lower “Tables in parallel” on the Migrate page, or ask the DBA to raise max_connections.',
  },
  {
    id: 'pg-permission',
    code: 'DMA-PG-303',
    match: /permission denied/i,
    title: 'The PostgreSQL user is missing a permission',
    meaning: 'It may not create or change objects in the target schema.',
    impact: 'run',
    action: 'Ask the PostgreSQL DBA to give the user CREATE on the database and ownership of the target schema.',
  },
  {
    id: 'disk-full',
    code: 'DMA-SYS-101',
    match: /no space left on device|could not extend file|ENOSPC/i,
    title: 'A disk is full',
    meaning: 'Either the migration server’s staging folder or the PostgreSQL disk has no space left.',
    impact: 'run',
    action: 'Free disk space (old run folders, old exports), or choose Direct load. Then press Resume.',
  },
  {
    id: 'oom',
    code: 'DMA-SYS-102',
    match: /out of memory|Cannot allocate memory|signal SIGKILL|Killed/i,
    title: 'The server ran out of memory',
    meaning: 'Too many tables or documents loading at the same time.',
    impact: 'table',
    action: 'Lower “Tables in parallel”; the failed table is retried.',
  },
  {
    id: 'dbd-pg',
    code: 'DMA-SYS-103',
    match: /DBD::Pg|Can't locate DBD\/Pg/i,
    title: 'Direct load is not available on this server',
    meaning: 'Direct load needs a Perl module (DBD::Pg) that is not installed.',
    impact: 'run',
    action: 'Choose “Through files” on the Migrate page, or ask the server team to install DBD::Pg.',
  },
  {
    id: 'no-ora2pg',
    code: 'DMA-SYS-104',
    match: /ora2pg.*(not found|ENOENT)|spawn ora2pg|command not found/i,
    title: 'A required program is missing on the server',
    meaning: 'ora2pg or psql is not installed, or not in the PATH of the DMA service.',
    impact: 'run',
    action: 'Ask the server team to install it, or set ORA2PG_BIN / PSQL_BIN in backend/.env.',
  },
  {
    id: 'deadlock',
    code: 'DMA-PG-304',
    match: /deadlock detected/i,
    title: 'Two steps waited for each other',
    meaning: 'Rare: two statements locked the same objects in a different order.',
    impact: 'none',
    action: 'Retried automatically.',
  },
];

/** The explanation for an error text, or null if it is not in the list yet. */
export function explainError(text?: string | null): ErrorHelpEntry | null {
  if (!text) return null;
  // A DMA code in the text wins over matching the words.
  const code = /DMA-[A-Z]{2,3}-\d{3}/.exec(text);
  const byCode = code ? ERROR_HELP.find((e) => e.code === code[0]) : undefined;
  return byCode || ERROR_HELP.find((e) => e.match.test(text)) || null;
}
