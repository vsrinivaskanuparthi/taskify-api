import { API_HOST } from './components/constants';

export class ApiError extends Error {
  status: number;
  /** DMA error code (DMA-SYS-500…) and log reference (R-…) when the server sent them. */
  code: string | null;
  ref: string | null;
  constructor(message: string, status: number, code: string | null = null, ref: string | null = null) {
    super(message);
    this.status = status;
    this.code = code;
    this.ref = ref;
  }
}

/** JSON fetch helper: throws ApiError with the server's message on failure. */
export async function api<T = any>(path: string, init: { method?: string; body?: unknown } = {}): Promise<T> {
  let res: Response;
  try {
    res = await fetch(`${API_HOST}${path}`, {
      method: init.method || (init.body !== undefined ? 'POST' : 'GET'),
      headers: init.body !== undefined ? { 'Content-Type': 'application/json' } : undefined,
      body: init.body !== undefined ? JSON.stringify(init.body) : undefined,
      credentials: 'include',
    });
  } catch {
    throw new ApiError('Cannot reach the migration server. Check that the backend is running.', 0);
  }
  const text = await res.text();
  let data: any = null;
  try { data = text ? JSON.parse(text) : null; } catch { data = text; }
  if (!res.ok) {
    const code = data && typeof data.code === 'string' ? data.code : null;
    const ref = data && typeof data.ref === 'string' ? data.ref : null;
    const base = (data && data.message) || `Request failed (${res.status})`;
    // The code goes with the message, so every screen that shows the message shows the code too.
    throw new ApiError(code && !base.includes(code) ? `${base} (${code})` : base, res.status, code, ref);
  }
  return data as T;
}

export const projectPath = (name: string) => `/projects/${encodeURIComponent(name)}`;
export const apiUrl = (path: string) => `${API_HOST}${path}`;
