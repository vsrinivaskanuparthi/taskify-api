import { expect, test } from '@playwright/test';
import { P, pageIsFine } from './helpers';

// Error handling hardening (DMA-073) in a real browser. Failures are simulated in the browser
// (page.route), so nothing is deleted or changed in the test projects.
const FDW = `/projects/${process.env.DMA_E2E_FDW_PROJECT || 'FDW_TEST'}`;
const serverError = { status: 500, contentType: 'application/json', body: JSON.stringify({ message: 'Something went wrong on the DMA server. Please try again; if it happens again, send this reference to the DMA team: R-ABC123.', code: 'DMA-SYS-500', ref: 'R-ABC123' }) };

test('Guide: errors can be found by their DMA code', async ({ page }) => {
  await page.goto('/guide');
  await page.getByPlaceholder(/Paste an error, or search/).fill('DMA-SYS-202');
  await expect(page.getByText('Run stopped safely: disk almost full')).toBeVisible();
  await expect(page.getByText('DMA-SYS-202', { exact: true })).toBeVisible();
  await pageIsFine(page);
});

test('Code objects: deleting a package asks first, and a failed delete is explained', async ({ page }) => {
  await page.goto(`${FDW}/code`);
  const del = page.getByRole('button', { name: /^Delete package / }).first();
  await expect(del.or(page.getByText(/No converted package|Upload/).first()).first()).toBeVisible();
  test.skip((await del.count()) === 0, 'no converted package in this project');
  const label = await del.getAttribute('aria-label');
  // 1. Asks first; "Keep it" deletes nothing.
  await del.click();
  const dialog = page.getByRole('dialog');
  await expect(dialog.getByText('Delete this converted package?')).toBeVisible();
  await dialog.getByRole('button', { name: 'Keep it' }).click();
  await expect(dialog).toHaveCount(0);
  await expect(page.getByRole('button', { name: label! })).toBeVisible();
  // 2. The server fails: the reason is shown, with the code, and the package is still there.
  await page.route('**/code/packages/*', (route) => (route.request().method() === 'DELETE' ? route.fulfill(serverError) : route.continue()));
  await page.getByRole('button', { name: label! }).click();
  await page.getByRole('dialog').getByRole('button', { name: 'Delete' }).click();
  await expect(page.getByText(/The package could not be deleted: .*R-ABC123.*\(DMA-SYS-500\)/)).toBeVisible();
  await expect(page.getByRole('button', { name: label! })).toBeVisible();
  await pageIsFine(page);
});

test('Assessment: a failed save of column renames is shown, not silent', async ({ page }) => {
  await page.goto(`${P}/assessment`);
  const tab = page.getByRole('tab', { name: /^Reserved words \(\d+\)$/ });
  // The "Schema details" card is closed by default.
  if (!(await tab.isVisible())) await page.getByText('Schema details', { exact: true }).click();
  await expect(tab).toBeVisible();
  test.skip(/\(0\)/.test((await tab.textContent()) || ''), 'no reserved-word columns in this schema');
  await tab.click();
  await page.route('**/columns', (route) => route.fulfill(serverError));
  await page.getByRole('button', { name: 'Save renames' }).click();
  await expect(page.getByRole('alert').filter({ hasText: 'Renames not saved' })).toContainText('DMA-SYS-500');
  await pageIsFine(page);
});
