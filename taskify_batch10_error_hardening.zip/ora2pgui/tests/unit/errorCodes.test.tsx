import { fireEvent, render, screen } from '@testing-library/react';
import { afterEach, describe, expect, test, vi } from 'vitest';
import { ERROR_HELP, explainError } from '../../src/errorHelp';
import { api, ApiError } from '../../src/api';
import ErrorHelp from '../../src/components/ErrorHelp';

// Error handling hardening (DMA-073): DMA error codes in the UI, and API errors that carry them.
describe('DMA error codes', () => {
  test('every known error has a unique code DMA-<ORA|PG|NET|ENG|SYS>-<3 digits>', () => {
    const codes = ERROR_HELP.map((e) => e.code);
    codes.forEach((c) => expect(c).toMatch(/^DMA-(ORA|PG|NET|ENG|SYS)-\d{3}$/));
    expect(new Set(codes).size).toBe(codes.length);
  });

  test('a code in the text finds its explanation, even when the words would match another one', () => {
    expect(explainError('Something odd (DMA-ORA-105)')?.id).toBe('ora-login');
    expect(explainError('ORA-01017: invalid username/password')?.code).toBe('DMA-ORA-105');
  });

  test('the messages the server sends are explained (same words as the backend)', () => {
    expect(explainError('Something went wrong on the DMA server. Please try again; if it happens again, send this reference to the DMA team: R-1A2B3C. (DMA-SYS-500)')?.id).toBe('server-error');
    expect(explainError('Staging disk is running low: 3.2 GB free. Below 1 GB the run stops safely. (DMA-SYS-201)')?.id).toBe('disk-low');
    expect(explainError('Stopped safely: the staging disk is almost full (0.4 GB free, limit 1 GB). Free disk space, then press Resume. (DMA-SYS-202)')?.impact).toBe('run');
    expect(explainError('Resumed automatically after a server restart (attempt 2; automatic resume 1 of 3) (DMA-ENG-201)')?.id).toBe('auto-resumed');
    expect(explainError('Not resumed automatically: already resumed automatically 3 times (limit 3). (DMA-ENG-202)')?.id).toBe('auto-resume-stopped');
  });

  test('the explanation shows the code', () => {
    render(<ErrorHelp text="ORA-12170: TNS:Connect timeout occurred" />);
    fireEvent.click(screen.getByText('What does this mean?'));
    expect(screen.getByText('DMA-NET-101')).toBeInTheDocument();
  });
});

describe('API errors carry the code and the reference', () => {
  afterEach(() => vi.unstubAllGlobals());
  const reply = (status: number, body: unknown) => vi.fn().mockResolvedValue({ ok: false, status, text: () => Promise.resolve(JSON.stringify(body)) });

  test('a server failure: message, code and reference, and the code is in the message shown on screen', async () => {
    vi.stubGlobal('fetch', reply(500, { message: 'Something went wrong on the DMA server. … reference to the DMA team: R-ABC123.', code: 'DMA-SYS-500', ref: 'R-ABC123' }));
    const err: ApiError = await api('/x').catch((e) => e);
    expect(err).toMatchObject({ status: 500, code: 'DMA-SYS-500', ref: 'R-ABC123' });
    expect(err.message).toContain('R-ABC123');
    expect(err.message).toContain('(DMA-SYS-500)');
  });

  test('the code is not repeated when the message already has it; old answers without a code still work', async () => {
    vi.stubGlobal('fetch', reply(507, { message: 'Stopped (DMA-SYS-202)', code: 'DMA-SYS-202' }));
    expect((await api('/x').catch((e) => e)).message).toBe('Stopped (DMA-SYS-202)');
    vi.stubGlobal('fetch', reply(409, { message: 'Busy' }));
    const old: ApiError = await api('/x').catch((e) => e);
    expect(old.message).toBe('Busy');
    expect(old.code).toBeNull();
  });
});
