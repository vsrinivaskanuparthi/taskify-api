import { createContext, ReactNode, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { api, projectPath } from '../api';
import { ProjectEvent, useProjectEvents } from '../hooks/useProjectEvents';

export interface Project {
  projectName: string;
  appName: string;
  appCode: string;
  description?: string;
  createdAt: string;
  updatedAt?: string;
  migrationStatus: string;
  lastMigrationDate: string | null;
  currentMigrationId: string | null;
  selectedSchema?: string;
  schemas?: string[];
  snapshotAt?: string;
  snapshotSchema?: string;
  columnRenames?: { tableName: string; oldName: string; name: string }[];
  oracle: { userUrl: string; userUsername: string; connectedAt: string } | null;
  postgres: { hostip: string; port: string; dbname: string; username: string; connectedAt: string; version?: string } | null;
}

export interface SnapshotProgress {
  schema: string;
  status: string;
  startedAt: string;
  finishedAt?: string;
  error?: string;
  steps: { key: string; label: string; status: string; ms: number | null; error?: string }[];
}

interface Ctx {
  name: string;
  project: Project | null;
  error: string | null;
  reload: () => Promise<void>;
  snapshot: any | null;
  snapshotLoading: boolean;
  reloadSnapshot: () => Promise<void>;
  snapshotProgress: SnapshotProgress | null;
  activeRunId: string | null;
  live: boolean;
  /** Time of the last (re)connect of the live stream: pages reload their data when it changes. */
  connectedAt: number;
  subscribe: (fn: (e: ProjectEvent) => void) => () => void;
}

const ProjectContext = createContext<Ctx | undefined>(undefined);

export function ProjectProvider({ name, children }: { name: string; children: ReactNode }) {
  const [project, setProject] = useState<Project | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [snapshot, setSnapshot] = useState<any | null>(null);
  const [snapshotLoading, setSnapshotLoading] = useState(false);
  const [snapshotProgress, setSnapshotProgress] = useState<SnapshotProgress | null>(null);
  const [activeRunId, setActiveRunId] = useState<string | null>(null);
  const listeners = useRef(new Set<(e: ProjectEvent) => void>());

  const reload = useCallback(async () => {
    try {
      const r = await api<{ project: Project; activeRun: { runId: string } | null; snapshot: SnapshotProgress | null }>(projectPath(name));
      setProject(r.project);
      setActiveRunId(r.activeRun ? r.activeRun.runId : null);
      if (r.snapshot) setSnapshotProgress(r.snapshot);
      setError(null);
    } catch (e: any) {
      setError(e.message);
    }
  }, [name]);

  const reloadSnapshot = useCallback(async () => {
    setSnapshotLoading(true);
    try {
      setSnapshot(await api(`${projectPath(name)}/snapshot`));
    } catch {
      setSnapshot(null);
    } finally {
      setSnapshotLoading(false);
    }
  }, [name]);

  useEffect(() => { reload(); }, [reload]);
  useEffect(() => {
    if (project?.selectedSchema) reloadSnapshot();
    else setSnapshot(null);
  }, [project?.selectedSchema, project?.snapshotAt, reloadSnapshot]);

  const { connected: live, connectedAt } = useProjectEvents(name, (e) => {
    if (e.type === 'snapshot') {
      setSnapshotProgress(e.data);
      if (e.data.status !== 'RUNNING') reload();
    }
    // Finished analysis / code export: the step ticks come from the project, so refresh it.
    if ((e.type === 'analysis' || e.type === 'codeExport') && e.data.status !== 'RUNNING') reload();
    if (e.type === 'run' || e.type === 'runFull') {
      const running = ['RUNNING', 'QUEUED'].includes(e.data.status);
      setActiveRunId(running ? e.data.runId : null);
      if (!running) reload();
    }
    listeners.current.forEach((fn) => fn(e));
  });

  // After a reconnect (server restart, network drop) refresh what may have changed meanwhile.
  const firstConnect = useRef(true);
  useEffect(() => {
    if (!connectedAt) return;
    if (firstConnect.current) { firstConnect.current = false; return; }
    reload();
  }, [connectedAt, reload]);

  const subscribe = useCallback((fn: (e: ProjectEvent) => void) => {
    listeners.current.add(fn);
    return () => { listeners.current.delete(fn); };
  }, []);

  return (
    <ProjectContext.Provider value={{ name, project, error, reload, snapshot, snapshotLoading, reloadSnapshot, snapshotProgress, activeRunId, live, connectedAt, subscribe }}>
      {children}
    </ProjectContext.Provider>
  );
}

export function useProject() {
  const ctx = useContext(ProjectContext);
  if (!ctx) throw new Error('useProject must be used inside ProjectProvider');
  return ctx;
}
