import { Alert, Box, Button, Chip, LinearProgress, Stack, Tab, Tabs, TextField, Tooltip, Typography } from '@mui/material';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';
import CheckCircleRoundedIcon from '@mui/icons-material/CheckCircleRounded';
import LightbulbOutlinedIcon from '@mui/icons-material/LightbulbOutlined';
import MemoryRoundedIcon from '@mui/icons-material/MemoryRounded';
import FkMap from '../components/FkMap';
import StorageRoundedIcon from '@mui/icons-material/StorageRounded';
import DnsRoundedIcon from '@mui/icons-material/DnsRounded';
import ScheduleRoundedIcon from '@mui/icons-material/ScheduleRounded';
import WarningAmberRoundedIcon from '@mui/icons-material/WarningAmberRounded';
import RocketLaunchRoundedIcon from '@mui/icons-material/RocketLaunchRounded';
import InsightsRoundedIcon from '@mui/icons-material/InsightsRounded';
import { ReactNode, useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api, projectPath } from '../api';
import { useProject } from '../context/ProjectContext';
import { BarList, Donut } from '../components/charts';
import DataTable from '../components/DataTable';
import { EmptyState, PageHeader, SectionCard } from '../components/ui';
import { fmtDate, fmtInt, fmtMb } from '../format';
import { brand } from '../theme';

type TableMeta = { name: string; sizeMb: number | string; lobSizeMb?: number; rowCount: number | string; hasForeignKey: string; parentTable: string[] | string; lastAnalyzed?: string; partitioned?: boolean };

const CODE_TYPES = ['VIEW', 'MATERIALIZED VIEW', 'FUNCTION', 'PROCEDURE', 'PACKAGE', 'PACKAGE BODY', 'TRIGGER', 'TYPE', 'DATABASE LINK', 'SYNONYM'];

// 4 tables at a time at ~25 MB/s each over a corporate network, plus ~35% for indexes and keys.
function estimateText(totalMb: number) {
  const minutes = Math.max(1, Math.round(((totalMb / 100) * 1.35) / 60));
  return minutes < 60 ? `about ${minutes} min` : `about ${(minutes / 60).toFixed(minutes < 600 ? 1 : 0)} h`;
}

type Sizing = {
  server: { cpus: number; ramGb: number; stagingDir: string; disk: { freeGb: number; totalGb: number } | null };
  need: { parallelTables: number; loadMode: 'direct' | 'file' | 'export'; cpus: number; ramGb: number; stagingGb: { direct: number; file: number; export: number } };
};
const gbText = (g: number) => (g >= 100 ? `${Math.round(g)}` : g >= 10 ? g.toFixed(0) : g >= 1 ? g.toFixed(1) : g > 0 ? '< 1' : '0');

/** One coloured tile: icon badge, label, big value, and an optional line under it. */
function Tile({ label, value, unit, icon, color, foot, k }: { label: string; value: ReactNode; unit?: string; icon: ReactNode; color: string; foot?: ReactNode; k: number }) {
  return (
    <Box sx={{ position: 'relative', px: 2.5, py: 2.25, display: 'flex', alignItems: 'center', gap: 2, minWidth: 0,
      background: `linear-gradient(180deg, ${color}0D 0%, transparent 70%)`,
      borderLeft: { md: k ? `1px solid ${brand.border}` : 'none', xs: k % 2 ? `1px solid ${brand.border}` : 'none' },
      borderTop: { xs: k > 1 ? `1px solid ${brand.border}` : 'none', md: 'none' } }}>
      <Box sx={{ position: 'absolute', left: 0, right: 0, top: 0, height: 3, bgcolor: color }} />
      <Box sx={{ width: 48, height: 48, borderRadius: '50%', display: 'grid', placeItems: 'center', flexShrink: 0, color: '#fff',
        background: `linear-gradient(135deg, ${color}, ${color}CC)`, boxShadow: `0 8px 18px -8px ${color}`, '& svg': { fontSize: 24 } }}>{icon}</Box>
      <Box sx={{ minWidth: 0 }}>
        <Typography variant="body2" color="text.secondary" fontWeight={600}>{label}</Typography>
        <Typography sx={{ fontWeight: 800, fontSize: { xs: 24, md: 28 }, lineHeight: 1.1, whiteSpace: 'nowrap' }}>
          {value}{unit && <Box component="span" sx={{ fontSize: 15, fontWeight: 700, color: 'text.secondary', ml: 0.75 }}>{unit}</Box>}
        </Typography>
        {foot && <Box sx={{ mt: 0.25 }}>{foot}</Box>}
      </Box>
    </Box>
  );
}

/** "this server: 8" with a check or a warning, comparing what the server has with what is needed. */
function Has({ ok, text }: { ok: boolean; text: string }) {
  return (
    <Stack direction="row" spacing={0.5} alignItems="center">
      {ok ? <CheckCircleRoundedIcon sx={{ fontSize: 15, color: brand.success }} /> : <WarningAmberRoundedIcon sx={{ fontSize: 15, color: brand.warning }} />}
      <Typography variant="caption" sx={{ color: ok ? 'text.secondary' : brand.warning, fontWeight: ok ? 500 : 700 }}>{text}</Typography>
    </Stack>
  );
}

const MODE_LABEL = { direct: 'Direct load', file: 'Through files', export: 'Export only' } as const;

/**
 * Two rows: the migration server (this RHEL server: DMA + ora2pg, with the export files in its
 * staging folder) compared with what it really has, and the PostgreSQL target (same rules as v1).
 */
function Estimates({ totalMb }: { totalMb: number }) {
  const { name } = useProject();
  const [sz, setSz] = useState<Sizing | null>(null);
  useEffect(() => { api<Sizing>(`${projectPath(name)}/sizing`).then(setSz).catch(() => setSz(null)); }, [name, totalMb]);
  const gb = totalMb / 1024;
  const ram = Math.round(8 + (gb / 25) * 2);
  const cpu = Math.round(6 + gb / 25);
  const storage = Math.max(1, Math.round(gb * 1.5 + gb * 0.2));
  const duration = estimateText(totalMb).replace(/^about /, '≈ ');
  const free = sz?.server.disk?.freeGb;
  const rowLabel = (title: string, sub: ReactNode) => (
    <Stack direction={{ xs: 'column', md: 'row' }} spacing={{ xs: 0, md: 1.5 }} alignItems={{ md: 'baseline' }} sx={{ px: 2.75, py: 1.25, bgcolor: '#F7F9FC', borderTop: `1px solid ${brand.border}`, borderBottom: `1px solid ${brand.border}` }}>
      <Typography variant="overline" sx={{ fontWeight: 800, color: brand.ink, lineHeight: 1.6 }}>{title}</Typography>
      <Typography variant="caption" color="text.secondary">{sub}</Typography>
    </Stack>
  );
  return (
    <Box sx={{ mb: 3 }}>
    <SectionCard dense collapsible storeKey="assess.estimate2" title="Resource estimate"
      subtitle={`For ${fmtMb(totalMb)} of data. A starting point: the first run measures the real speed.`}
      summary={sz ? `Migration server: ${sz.need.cpus} cores, ${sz.need.ramGb} GB RAM, ${gbText(sz.need.stagingGb[sz.need.loadMode])} GB for files (${MODE_LABEL[sz.need.loadMode]}) · PostgreSQL: ${ram} GB RAM, ${cpu} cores, ${storage} GB · ${duration}` : undefined}
      action={
        <Stack direction="row" spacing={1} alignItems="center" sx={{ px: 1.75, py: 0.75, borderRadius: 99, bgcolor: '#FFF7ED', border: '1px solid #FED7AA', display: { xs: 'none', md: 'flex' } }}>
          <ScheduleRoundedIcon sx={{ color: '#D97706', fontSize: 20 }} />
          <Typography fontWeight={700} fontSize={14}>Migration time {duration}</Typography>
          <Typography variant="caption" color="text.secondary">typical network</Typography>
        </Stack>
      }>
      {rowLabel('Migration server', <>this server, where DMA and ora2pg run{sz ? <> · staging folder <span className="mono">{sz.server.stagingDir}</span></> : ''}</>)}
      <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr 1fr', md: '1fr 1fr 2fr' } }}>
        <Tile k={0} label="CPU cores" value={sz ? sz.need.cpus : '…'} unit="needed" icon={<DnsRoundedIcon />} color="#7C3AED"
          foot={sz && <Has ok={sz.server.cpus >= sz.need.cpus} text={`this server: ${sz.server.cpus} · for ${sz.need.parallelTables} tables in parallel`} />} />
        <Tile k={1} label="RAM" value={sz ? sz.need.ramGb : '…'} unit="GB needed" icon={<MemoryRoundedIcon />} color="#2563EB"
          foot={sz && <Has ok={sz.server.ramGb >= sz.need.ramGb - 0.5} text={`this server: ${Math.round(sz.server.ramGb)} GB`} />} />
        <Box sx={{ position: 'relative', px: 2.5, py: 2.25, minWidth: 0, gridColumn: { xs: 'span 2', md: 'auto' },
          background: 'linear-gradient(180deg, #0596690D 0%, transparent 70%)', borderLeft: { md: `1px solid ${brand.border}` }, borderTop: { xs: `1px solid ${brand.border}`, md: 'none' } }}>
          <Box sx={{ position: 'absolute', left: 0, right: 0, top: 0, height: 3, bgcolor: '#059669' }} />
          <Stack direction="row" spacing={2} alignItems="center">
            <Box sx={{ width: 48, height: 48, borderRadius: '50%', display: 'grid', placeItems: 'center', flexShrink: 0, color: '#fff', background: 'linear-gradient(135deg, #059669, #059669CC)', boxShadow: '0 8px 18px -8px #059669', '& svg': { fontSize: 24 } }}><StorageRoundedIcon /></Box>
            <Box sx={{ flex: 1, minWidth: 0 }}>
              <Stack direction="row" justifyContent="space-between" alignItems="baseline" spacing={1} flexWrap="wrap" useFlexGap>
                <Typography variant="body2" color="text.secondary" fontWeight={600}>Disk for export files</Typography>
                {free !== undefined && <Typography variant="caption" color="text.secondary"><b style={{ color: brand.ink }}>{gbText(free)} GB free</b> of {gbText(sz!.server.disk!.totalGb)} GB</Typography>}
              </Stack>
              <Stack spacing={0.75} sx={{ mt: 0.75 }}>
                {(['direct', 'file', 'export'] as const).map((m) => {
                  const need = sz ? sz.need.stagingGb[m] : 0;
                  const ok = free === undefined || free >= need * 1.2;
                  const pct = free ? Math.min(100, (need / free) * 100) : 0;
                  const current = sz?.need.loadMode === m;
                  return (
                    <Box key={m} sx={{ display: 'grid', gridTemplateColumns: '170px minmax(0, 1fr) 84px', alignItems: 'center', gap: 1.25 }}>
                      <Typography variant="caption" fontWeight={current ? 800 : 600} color={current ? brand.ink : 'text.secondary'}>{MODE_LABEL[m]}{current ? ' (default)' : ''}</Typography>
                      <Box sx={{ height: 8, borderRadius: 99, bgcolor: '#EEF2F6', overflow: 'hidden' }}>
                        <Box sx={{ height: '100%', width: `${Math.max(pct, need > 0 ? 2 : 0)}%`, borderRadius: 99, bgcolor: ok ? '#059669' : brand.warning, transition: 'width .4s' }} />
                      </Box>
                      <Stack direction="row" spacing={0.5} alignItems="center" justifyContent="flex-end">
                        <Typography variant="caption" fontWeight={800} sx={{ whiteSpace: 'nowrap' }}>{sz ? `${gbText(need)} GB` : '…'}</Typography>
                        {sz && free !== undefined && (ok ? <CheckCircleRoundedIcon sx={{ fontSize: 15, color: brand.success }} /> : <WarningAmberRoundedIcon sx={{ fontSize: 15, color: brand.warning }} />)}
                      </Stack>
                    </Box>
                  );
                })}
              </Stack>
              <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 0.75 }}>Direct load writes almost nothing; Export only keeps the whole schema in files until the import.</Typography>
            </Box>
          </Stack>
        </Box>
      </Box>

      {rowLabel('PostgreSQL target', 'the database server you migrate to')}
      <Box sx={{ display: 'grid', gridTemplateColumns: { xs: '1fr 1fr', md: 'repeat(3, 1fr)' } }}>
        <Tile k={0} label="RAM" value={ram} unit="GB" icon={<MemoryRoundedIcon />} color="#2563EB" foot={<Typography variant="caption" color="text.secondary">for the PostgreSQL server</Typography>} />
        <Tile k={1} label="CPU cores" value={cpu} unit="cores" icon={<DnsRoundedIcon />} color="#7C3AED" foot={<Typography variant="caption" color="text.secondary">for the PostgreSQL server</Typography>} />
        <Tile k={2} label="Storage" value={storage} unit="GB" icon={<StorageRoundedIcon />} color="#059669" foot={<Typography variant="caption" color="text.secondary">data, indexes and room to grow</Typography>} />
      </Box>
    </SectionCard>
    </Box>
  );
}

function ReservedWords({ items }: { items: any[] }) {
  const { name, project, reload } = useProject();
  const saved = new Map((project?.columnRenames || []).map((c) => [`${c.tableName}.${c.oldName}`, c.name]));
  const rows = items.map((raw: any) => {
    const tableName = Array.isArray(raw) ? String(raw[0]) : String(raw.tableName ?? '');
    const oldName = Array.isArray(raw) ? String(raw[1]) : String(raw.oldName ?? raw.name ?? '');
    return { id: `${tableName}.${oldName}`, tableName, oldName };
  });
  const [edits, setEdits] = useState<Record<string, string>>({});
  const [msg, setMsg] = useState<string | null>(null);
  const save = async () => {
    const body = rows
      .map((r) => ({ tableName: r.tableName, oldName: r.oldName, name: (edits[r.id] ?? saved.get(r.id) ?? '').trim() }))
      .filter((r) => r.name && r.name !== r.oldName);
    await api(`${projectPath(name)}/columns`, { body: { name: body } });
    setMsg(`${body.length} renames saved; applied in the next migration run.`);
    await reload();
  };
  return (
    <>
    {rows.length > 0 && (
        <Stack direction="row" spacing={1} alignItems="flex-start" sx={{ mx: 2.5, mt: 2, p: 1.5, borderRadius: 2.5, bgcolor: '#F3F7FF' }}>
          <InfoOutlinedIcon sx={{ fontSize: 19, color: brand.blue, mt: 0.15 }} />
          <Typography variant="body2" color="text.secondary">
            <b>Leave the new name empty (recommended):</b> the column keeps its name and is quoted automatically (for example <code>"offset"</code>), so the application needs no change.
            Only type a new name if the application team will use that new name too: otherwise the application will look for a column that no longer exists.
          </Typography>
        </Stack>
      )}
    <DataTable rows={rows} rowKey={(r) => r.id} searchKeys={['tableName', 'oldName']} empty="No columns use PostgreSQL reserved words."
      toolbar={rows.length ? <Stack direction="row" spacing={1} alignItems="center">{msg && <Typography variant="caption" color="success.main">{msg}</Typography>}<Button variant="contained" size="small" onClick={save}>Save renames</Button></Stack> : undefined}

      columns={[
        { key: 'tableName', label: 'Table', render: (r) => <Typography fontWeight={600} fontSize={14}>{r.tableName}</Typography> },
        { key: 'oldName', label: 'Column', render: (r) => <Typography fontWeight={600} fontSize={14}>{r.oldName}</Typography> },
        { key: 'new', label: <Stack direction="row" spacing={0.5} alignItems="center"><span>New name (optional)</span><Tooltip title='Empty = keep the name, quoted automatically. Recommended.'><InfoOutlinedIcon sx={{ fontSize: 16 }} /></Tooltip></Stack>, render: (r) => (
          <TextField size="small" placeholder="keep original (quoted)" value={edits[r.id] ?? saved.get(r.id) ?? ''} onChange={(e) => setEdits({ ...edits, [r.id]: e.target.value })} sx={{ minWidth: 220 }} />
        ) },
      ]} />
    </>
  );
}

export default function AssessmentPage() {
  const { snapshot, snapshotLoading, project } = useProject();
  const navigate = useNavigate();
  const [tab, setTab] = useState(0);

  const tables: TableMeta[] = snapshot?.tableMetadata || [];
  const d = useMemo(() => {
    const totalMb = tables.reduce((s, t) => s + Number(t.sizeMb || 0), 0);
    const lobMb = tables.reduce((s, t) => s + Number(t.lobSizeMb || 0), 0);
    const rows = tables.reduce((s, t) => s + Number(t.rowCount || 0), 0);
    const analyzed = tables.map((t) => t.lastAnalyzed).filter(Boolean).sort();
    const stale = tables.filter((t) => !t.lastAnalyzed || (Date.now() - new Date(t.lastAnalyzed).getTime()) > 30 * 86400000);
    const objects: [string, number][] = snapshot?.objects || [];
    const code = objects.filter(([t]) => CODE_TYPES.includes(t)).reduce((s, [, n]) => s + Number(n), 0);
    const pkTables = new Set((snapshot?.primaryForeignKeys || []).map((r: any) => (Array.isArray(r) ? r[0] : r.tableName)));
    const noPk = tables.filter((t) => !pkTables.has(t.name));
    const lobTables: string[] = (snapshot?.lobTables || []).filter((n: string) => tables.some((t) => t.name === n));
    return { totalMb, lobMb, rows, oldest: analyzed[0], stale, objects, code, noPk, lobTables };
  }, [snapshot]);

  if (snapshotLoading && !snapshot) return <LinearProgress />;
  if (!snapshot) {
    return <SectionCard><EmptyState icon={<InsightsRoundedIcon />} title="No snapshot yet" text="Take a schema snapshot first; the assessment is built from it." action={<Button variant="contained" onClick={() => navigate('../schema')}>Go to schema & snapshot</Button>} /></SectionCard>;
  }

  const instance = snapshot.instances?.[0] || [];
  const version = (snapshot.dbVersion?.[0] || instance[1] || '—') as string;
  const p = project as any;
  // Only what needs the user. Everything the tool handles by itself (LOBs, tables without keys,
  // reserved words, duplicate sequences, object tables, verification) is not listed here.
  const needs = [
    !p?.settings?.decisions?.agreedBy && {
      title: 'Confirm the migration decisions', tag: 'recommended',
      text: 'Name case, number types, booleans and LOBs. Agree them once with the application team, so the tables never need rebuilding.',
      action: 'Open Settings', to: '../settings',
    },
    d.code > 0 && !(p?.codeExportAt || p?.codeAppliedAt) && {
      title: `${d.code} code objects to convert`, tag: 'optional',
      text: 'Views, procedures, packages and triggers. Not needed to move the data: convert them with GenAI before or after the migration.',
      action: 'Code objects', to: '../code',
    },
    d.stale.length > 0 && {
      title: 'Table statistics are old', tag: 'optional',
      text: `${d.stale.length} tables. Only the time estimates are affected; your DBA can refresh them with DBMS_STATS.`,
    },
  ].filter(Boolean) as { title: string; tag: string; text: string; action?: string; to?: string }[];

  const top = [...tables].sort((a, b) => Number(b.sizeMb) - Number(a.sizeMb)).slice(0, 10);
  // tableMetadata.parentTable lists the tables that reference this one (as in v1's Foreign Key Dependency tab).
  const fkEdges = tables.flatMap((t) => (Array.isArray(t.parentTable) ? t.parentTable : String(t.parentTable || '').split(',')).map((c) => c.trim()).filter(Boolean).map((child) => ({ from: t.name, to: child })));
  const dups: string[] = snapshot.sequences?.duplicateSequences || [];

  return (
    <>
      <PageHeader overline="Step 3" title={`Assessment · ${snapshot.schemaName}`} icon={<InsightsRoundedIcon />}
        subtitle={<>Snapshot taken {fmtDate(snapshot.snapshotAt)} · Oracle {String(version).match(/\d+(\.\d+)*/)?.[0] || version}{snapshot.failedQueries?.length ? ` · ${snapshot.failedQueries.length} metadata queries failed` : ''}</>} />

      {/* The verdict, and the one-click path */}
      <Box sx={{ position: 'relative', overflow: 'clip', borderRadius: 4, p: { xs: 2.5, md: 3.5 }, mb: 3, color: '#fff',
        background: 'radial-gradient(700px 260px at 90% -20%, rgba(110,231,183,.28), transparent 60%), linear-gradient(135deg, #064E3B 0%, #065F46 45%, #0F766E 100%)' }}>
        <Stack direction={{ xs: 'column', lg: 'row' }} spacing={3} alignItems={{ lg: 'center' }}>
          <Box sx={{ width: 64, height: 64, borderRadius: '50%', bgcolor: 'rgba(255,255,255,.14)', display: 'grid', placeItems: 'center', flexShrink: 0 }}>
            <CheckCircleRoundedIcon sx={{ fontSize: 40, color: '#6EE7B7' }} />
          </Box>
          <Box sx={{ flex: 1, minWidth: 0 }}>
            <Typography sx={{ fontWeight: 800, fontSize: { xs: 24, md: 30 }, lineHeight: 1.15 }}>Ready to migrate</Typography>
            <Typography sx={{ opacity: 0.9, mt: 0.75, fontSize: 16 }}>
              {fmtInt(tables.length)} tables · {fmtMb(d.totalMb)} · {fmtInt(d.rows)} rows · {estimateText(d.totalMb)} on a typical network
            </Typography>
            <Typography sx={{ opacity: 0.75, mt: 0.5, fontSize: 13.5 }}>Every table is copied, counted and checksummed against Oracle automatically.</Typography>
          </Box>
          <Stack spacing={1} sx={{ flexShrink: 0, minWidth: { lg: 300 } }}>
            <Button size="large" variant="contained" startIcon={<RocketLaunchRoundedIcon />} onClick={() => navigate('../migrate', { state: { selectAll: true } })}
              sx={{ bgcolor: '#fff', backgroundImage: 'none', color: '#065F46', fontWeight: 800, fontSize: 16, py: 1.4, boxShadow: '0 10px 24px -10px rgba(0,0,0,.45)', '&:hover': { bgcolor: '#ECFDF3', backgroundImage: 'none' } }}>
              Migrate all tables
            </Button>
            <Typography sx={{ fontSize: 12, opacity: 0.8, textAlign: 'center' }}>with the recommended settings · checks run by themselves</Typography>
            <Button variant="text" onClick={() => navigate('../migrate')} sx={{ color: '#fff', textDecoration: 'underline', textUnderlineOffset: 3 }}>Choose tables myself</Button>
          </Stack>
        </Stack>
      </Box>

      {/* Right under the verdict: what the server needs, full width */}
      <Estimates totalMb={d.totalMb} />

      <Box sx={{ mb: 3 }}>
          <SectionCard title="Before you start" subtitle={needs.length ? 'Only what needs you. Everything else is handled by the tool.' : undefined}>
            {needs.length === 0 && (
              <Stack direction="row" spacing={1.25} alignItems="center"><CheckCircleRoundedIcon sx={{ color: brand.success }} /><Typography fontWeight={600}>Nothing to do: you can start the migration.</Typography></Stack>
            )}
            <Stack spacing={1.5}>
              {needs.map((n) => (
                <Stack key={n.title} direction={{ xs: 'column', sm: 'row' }} spacing={1.5} alignItems={{ sm: 'center' }} sx={{ p: 1.75, borderRadius: 3, border: `1px solid ${brand.border}` }}>
                  <LightbulbOutlinedIcon sx={{ color: n.tag === 'recommended' ? brand.blue : brand.muted, flexShrink: 0 }} />
                  <Box sx={{ flex: 1, minWidth: 0 }}>
                    <Stack direction="row" spacing={1} alignItems="center">
                      <Typography fontWeight={700} fontSize={14.5}>{n.title}</Typography>
                      <Chip size="small" label={n.tag} sx={{ height: 20, fontSize: 11, fontWeight: 700, bgcolor: n.tag === 'recommended' ? '#EFF8FF' : '#F2F4F7', color: n.tag === 'recommended' ? brand.blue : brand.muted }} />
                    </Stack>
                    <Typography variant="body2" color="text.secondary">{n.text}</Typography>
                  </Box>
                  {n.action && <Button variant="outlined" size="small" onClick={() => navigate(n.to!)} sx={{ flexShrink: 0 }}>{n.action}</Button>}
                </Stack>
              ))}
            </Stack>
          </SectionCard>
      </Box>

      <Box sx={{ mb: 3 }}>
        <SectionCard collapsible storeKey="assess.overview" title="Schema overview"
          subtitle="The largest tables (loaded first, so the run finishes sooner) and every object in the schema."
          summary={`Largest: ${top[0] ? `${top[0].name} (${fmtMb(top[0].sizeMb)})` : '—'} · ${fmtInt(d.objects.reduce((a, [, n]) => a + Number(n), 0))} objects, ${fmtInt(d.code)} of them code`}>
          <Box sx={{ display: 'grid', gap: 3, gridTemplateColumns: { xs: '1fr', lg: '1fr 1fr' } }}>
            <Box sx={{ minWidth: 0 }}>
              <Typography variant="overline" color="text.secondary">Largest tables</Typography>
              <BarList data={top.map((t) => ({ label: t.name, value: Number(t.sizeMb), extra: `${fmtInt(t.rowCount)} rows` }))} format={fmtMb} />
            </Box>
            <Box sx={{ minWidth: 0, borderLeft: { lg: `1px solid ${brand.border}` }, pl: { lg: 3 } }}>
              <Typography variant="overline" color="text.secondary">Objects in the schema</Typography>
              {d.objects.length ? <Donut data={d.objects.map(([label, value]) => ({ label: label.toLowerCase().replace(/^\w/, (c) => c.toUpperCase()), value: Number(value) }))} centerLabel="objects" /> : <Typography color="text.secondary">No objects.</Typography>}
            </Box>
          </Box>
        </SectionCard>
      </Box>

      <SectionCard dense collapsible defaultOpen={false} storeKey="assess.details" title="Schema details" summary={`All ${tables.length} tables · ${(snapshot.reservedWordColumns || []).length} reserved-word columns · ${dups.length} duplicate sequences · foreign key map (${fkEdges.length})`}>
        <Tabs value={tab} onChange={(_, v) => setTab(v)} variant="scrollable" sx={{ px: 2, borderBottom: 1, borderColor: 'divider' }}>
          <Tab label={`Tables (${tables.length})`} />
          <Tab label={`Reserved words (${(snapshot.reservedWordColumns || []).length})`} />
          <Tab label={`Duplicate sequences (${dups.length})`} />
          <Tab label={`Foreign key dependencies (${fkEdges.length})`} />
        </Tabs>
        {tab === 0 && (
          <DataTable rows={tables} rowKey={(r) => r.name} searchKeys={['name']} initialSort={{ key: 'sizeMb', dir: 'desc' }}
            columns={[
              { key: 'name', label: 'Table name', render: (r) => (
                <Stack direction="row" spacing={1} alignItems="center">
                  <Typography fontWeight={600} fontSize={14}>{r.name}</Typography>
                  {r.partitioned && <Chip size="small" label="partitioned" variant="outlined" sx={{ height: 22 }} />}
                  {d.lobTables.includes(r.name) && <Chip size="small" label="LOB" color="warning" variant="outlined" sx={{ height: 22 }} />}
                </Stack>
              ) },
              { key: 'sizeMb', label: 'Size', align: 'right', sortValue: (r) => Number(r.sizeMb), render: (r) => fmtMb(r.sizeMb) },
              { key: 'rowCount', label: 'Number of rows', align: 'right', sortValue: (r) => Number(r.rowCount), render: (r) => fmtInt(r.rowCount) },
            ]} />
        )}
        {tab === 1 && <ReservedWords items={snapshot.reservedWordColumns || []} />}
        {tab === 2 && (
          dups.length ? <DataTable rows={dups.map((n) => ({ n }))} rowKey={(r) => r.n} columns={[{ key: 'n', label: 'Sequence', render: (r) => <span className="mono">{r.n}</span> }]} />
            : <Alert severity="success" sx={{ m: 2.5 }}>No duplicate sequences.</Alert>
        )}
        {tab === 3 && <FkMap edges={fkEdges} />}
      </SectionCard>
      {project && <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 2 }}>Source: {project.oracle?.userUrl}</Typography>}
    </>
  );
}
