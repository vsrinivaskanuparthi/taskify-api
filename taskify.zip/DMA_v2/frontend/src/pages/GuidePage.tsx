import { Box, Chip, InputAdornment, Stack, Table, TableBody, TableCell, TableHead, TableRow, TextField, Typography } from '@mui/material';
import MenuBookRoundedIcon from '@mui/icons-material/MenuBookRounded';
import HomeRoundedIcon from '@mui/icons-material/HomeRounded';
import FolderCopyRoundedIcon from '@mui/icons-material/FolderCopyRounded';
import SearchRoundedIcon from '@mui/icons-material/SearchRounded';
import CheckCircleRoundedIcon from '@mui/icons-material/CheckCircleRounded';
import { ReactNode, useEffect, useMemo, useState } from 'react';
import { useLocation } from 'react-router-dom';
import Shell from '../components/Shell';
import { PageHeader, SectionCard } from '../components/ui';
import { brand, headingFont } from '../theme';

/**
 * Guide (left menu → Guide): what the tool does, what is new compared with v1, the steps of a
 * project, and every option in plain words with the recommended value. Static content: nothing
 * here changes how a migration runs. Other pages link to its sections (#options, #preflight, …).
 */

const TOC = [
  ['what', 'What DMA does'],
  ['new', 'What is new in v2'],
  ['steps', 'The steps'],
  ['recipe', 'Your first migration'],
  ['options', 'Every option explained'],
  ['preflight', 'Pre-flight checks'],
  ['problems', 'When something goes wrong'],
  ['glossary', 'Words used in the app'],
] as const;

const NEW_IN_V2: [string, string, string][] = [
  ['Parallel loading', 'One table at a time', 'Several tables at once, biggest first'],
  ['Huge tables', 'One long ora2pg run per table', 'Cut into chunks that load in parallel and restart one by one'],
  ['LOB tables', 'Slow, row by row', 'Fetched in batches when the LOBs are small enough (about 5× faster in tests)'],
  ['Data path', 'Every table written to a file, then loaded', 'Streamed straight into PostgreSQL (files only if you choose)'],
  ['Failures', 'Re-run by hand', 'Each table and chunk is retried automatically'],
  ['Checks', 'Row estimate afterwards', 'Exact row count and column checksums for every table'],
  ['Server restart', 'Start again from zero', 'Resume continues with what is left'],
  ['Consistency', 'Tables read at different times', 'Optional: all tables read at one moment (snapshot)'],
  ['Decisions', 'Changed half-way (case, booleans, OFFSET)', 'Agreed once in Settings; a run cannot continue with different ones'],
  ['Before the run', 'Problems found hours in', 'Pre-flight checks: disk, connections, undo, WAL, network, estimate'],
  ['Watching it', 'Server logs', 'Live monitor, plus email and Google Chat messages'],
  ['After the run', 'Manual checks', 'Validation page with Excel export'],
];

const STEPS: [string, string, string, boolean][] = [
  ['Connect', 'Enter the Oracle source and the PostgreSQL target.', 'Both connections tested and saved (passwords encrypted).', false],
  ['Schema & snapshot', 'Pick the Oracle schema and take a snapshot.', 'The list of tables with sizes, rows, LOBs and code objects. Everything else uses it.', false],
  ['Assessment', 'Read the verdict; press “Migrate all tables” when ready.', 'Ready-to-migrate summary, the few things that need you, estimates, largest tables.', false],
  ['Settings', 'Agree the decisions with the application team, once.', 'Names, number types, booleans, LOBs, target schema, roles, notifications.', true],
  ['Code objects (GenAI)', 'Optional: export the code, convert it with GenAI, upload the zip.', 'Views, functions, procedures, packages and triggers in PostgreSQL.', true],
  ['Migrate', 'Select tables, run the pre-flight checks, start.', 'The data in PostgreSQL, each table verified. Watch it in Live monitor.', false],
  ['Validation', 'Open it after the run.', 'Oracle and PostgreSQL side by side, exportable to Excel.', false],
];

type Opt = { name: string; where: string; what: string; def: string; when: string };
const OPTION_GROUPS: { title: string; intro: string; items: Opt[] }[] = [
  {
    title: 'How the data moves',
    intro: 'Migrate page → Performance & safety settings. Defaults come from Settings → Advanced.',
    items: [
      { name: 'Load mode: Direct load', where: 'Migrate', what: 'ora2pg reads from Oracle and writes straight into PostgreSQL. No data files.', def: 'Yes (default)', when: 'Almost always. Needs the DBD::Pg Perl module on the server.' },
      { name: 'Load mode: Through files', where: 'Migrate', what: 'Each table (or chunk) goes to a file first, then is loaded. A failed load re-uses the file.', def: 'No', when: 'If direct load is not possible on the server, or the network to PostgreSQL is unreliable. Needs disk space.' },
      { name: 'Load mode: Export only', where: 'Migrate', what: 'Only writes the files, checked against Oracle. Press “Import exported files” later.', def: 'No', when: 'To take the data off Oracle in a short window and load it later. Needs disk for the whole schema.' },
    ],
  },
  {
    title: 'Speed (parallel work)',
    intro: 'Higher numbers = faster, but more load on both databases. Start with the defaults; raise them only if both servers are quiet.',
    items: [
      { name: 'Tables in parallel', where: 'Migrate', what: 'How many tables load at the same time.', def: '4', when: 'Raise to 6–8 on a big server. Lower if Oracle or PostgreSQL is busy.' },
      { name: 'Huge table from (rows)', where: 'Migrate', what: 'Tables with more rows than this get several readers and writers.', def: '2,000,000', when: 'Rarely.' },
      { name: 'Rows per chunk', where: 'Migrate', what: 'Huge tables are cut into pieces of about this many rows. 0 = never cut.', def: '5,000,000', when: 'Rarely. Smaller chunks restart faster after an error.' },
      { name: 'Chunk tables bigger than (MB)', where: 'Migrate', what: 'Tables bigger than this are cut too, even with few rows (LOB tables).', def: '1,024 MB', when: 'Rarely.' },
      { name: 'Parallel chunks / readers', where: 'Migrate', what: 'How many pieces of one huge table load at the same time.', def: '4', when: 'Raise for one very large table if Oracle has spare CPU.' },
      { name: 'PostgreSQL writers / huge table', where: 'Migrate', what: 'How many PostgreSQL connections write one huge table.', def: '4', when: 'Rarely.' },
      { name: 'Index build memory', where: 'Migrate', what: 'Memory PostgreSQL uses to build each index after the data (maintenance_work_mem).', def: '1GB', when: 'Raise to 2–4GB on a target with plenty of RAM: indexes build faster.' },
      { name: 'Unlogged load', where: 'Migrate', what: 'Rows are written without the PostgreSQL transaction log (WAL), then each table is made permanent once its checks pass.', def: 'Off', when: 'Try it when loading is slow and the PostgreSQL disk is busy. Safe: a table is only marked done when permanent.' },
    ],
  },
  {
    title: 'Safety',
    intro: 'These protect the result. The defaults are the safe choice; turning them off is rarely needed.',
    items: [
      { name: 'Consistent snapshot', where: 'Migrate', what: 'ON: every table is read as it was when the run started, even if the application keeps writing. OFF: each table is read as it is when it is copied (like v1).', def: 'On', when: 'Application STOPPED during the migration: turn it Off (no DBA setting needed). Application RUNNING: keep it On and ask the DBA for the UNDO_RETENTION value the pre-flight check shows.' },
      { name: 'Attempts per table', where: 'Migrate', what: 'How many times a failed table or chunk is tried before it is marked failed.', def: '3', when: 'Rarely.' },
      { name: 'Stop a hung load after (min)', where: 'Migrate', what: 'If a load shows no progress for this long, it is stopped and tried again. 0 = never.', def: '20', when: 'Raise if very large LOBs take long between progress lines.' },
      { name: 'Verify every table (row count)', where: 'Migrate', what: 'Counts the rows in Oracle and PostgreSQL after each table. A difference is a failure.', def: 'On', when: 'Keep on.' },
      { name: 'Data checksums per column', where: 'Migrate', what: 'Also compares the sum of numbers, text lengths and LOB sizes per column. Catches cut decimals or truncated text. Costs one extra read of each table (about +20% time).', def: 'On', when: 'Keep on for the first migration of a schema. Can be turned off for a re-run you already trust.' },
    ],
  },
  {
    title: 'Decisions (Settings, agreed once)',
    intro: 'These change the shape of the PostgreSQL tables. Agree them with the application team before the first load; changing them later means migrating again.',
    items: [
      { name: 'Object name case', where: 'Settings', what: 'Lower case (PostgreSQL standard) or keep Oracle’s UPPER case.', def: 'Lower case', when: 'Keep lower case unless the application quotes every name.' },
      { name: 'Reserved words', where: 'Settings', what: 'Columns named like SQL words (OFFSET, ORDER…): keep the name in quotes, or rename it.', def: 'Keep, quoted', when: 'Decide with the application team (Jaguar renamed OFFSET to OFFSET_VALUE).' },
      { name: 'NUMBER mapping', where: 'Settings', what: 'Oracle NUMBER becomes integer / bigint / numeric in PostgreSQL.', def: 'Native types', when: 'Use numeric for money or anything with decimals.' },
      { name: 'Booleans', where: 'Settings', what: 'Columns that hold 0/1 or Y/N can become true/false.', def: 'None', when: 'Only the columns the application team confirms.' },
      { name: 'LOB storage', where: 'Settings', what: 'BLOB becomes bytea (in the row) or a large object (oid).', def: 'bytea', when: 'oid only if the application uses the large-object API.' },
      { name: 'Target schema & roles', where: 'Settings', what: 'The PostgreSQL schema name, and the roles that get read or write access.', def: 'Oracle schema in lower case', when: 'Set the application’s roles so it can connect after the migration.' },
      { name: 'Notifications', where: 'Settings', what: 'Email and Google Chat messages when a run ends or needs attention.', def: 'Off until filled in', when: 'Always, for long runs. Use “Send a test”.' },
    ],
  },
];

const CHECKS: [string, string, string][] = [
  ['Estimated duration', 'Selected size ÷ speed (measured on this project, else 30 GB/h like v1).', 'Information only.'],
  ['Snapshot vs undo', 'Only with Consistent snapshot on: does Oracle keep old row versions (undo) as long as the run lasts?', 'Amber: ask the DBA for the UNDO_RETENTION value shown, or stop the application and turn the snapshot off.'],
  ['Staging disk', 'Free space on the server for the files the load mode writes.', 'Red stops the start: free space, choose Direct load, or fewer tables in parallel.'],
  ['PostgreSQL connections', 'Enough free connections for the parallel writers.', 'Red stops the start: lower Tables in parallel, or ask the DBA to raise max_connections.'],
  ['Oracle processes', 'Enough free Oracle processes for the parallel readers.', 'Red stops the start: lower the parallel settings, or ask the DBA to raise PROCESSES.'],
  ['WAL & checkpoints', 'Is max_wal_size large enough for a bulk load?', 'Amber: ask the DBA for max_wal_size = 16GB and checkpoint_timeout = 15min during the migration.'],
  ['PostgreSQL space', 'How much space the data will need (Oracle size × 1.7).', 'Check with df -h on the database server.'],
  ['Network to Oracle / PostgreSQL', 'Round trip and speed from the app server.', 'Amber: the load will be slower than the estimate; run the app close to the databases.'],
];

const PROBLEMS: [string, string][] = [
  ['A table failed', 'Open the run, click the table to see its log. Fix the cause, then press “Retry failed & resume”: only failed tables are loaded again.'],
  ['“The data does not fit the target column”', 'A value is too long, out of range or not a valid number. Fix the mapping in Settings and start a new run (it rebuilds the table).'],
  ['The run shows Interrupted', 'The server or pm2 was restarted. Open the run and press Resume: it continues where it stopped.'],
  ['“Oracle’s undo no longer reaches the run’s snapshot” (ORA-01555)', 'Press “Resume without snapshot” (keep the application stopped), or ask the DBA to raise UNDO_RETENTION and start a new run.'],
  ['“No progress … stopped as hung”', 'Usually the network. The table or chunk is retried automatically; check the network if it keeps happening.'],
  ['Row count or checksum mismatch', 'The table is marked failed with the column that differs. Usually a type mapping issue: check Settings.'],
  ['A foreign key is “NOT VALID”', 'Some rows point to a parent that does not exist (often in Oracle too). The key is in place and checks new rows; the run lists the reason.'],
  ['Resume is refused: decisions changed', 'Settings that shape the tables changed after the run started. Start a new run.'],
];

const GLOSSARY: [string, string][] = [
  ['Snapshot (SCN)', 'A moment in Oracle’s history. With Consistent snapshot on, every table is read as it was at that moment.'],
  ['Undo', 'Oracle keeps the old version of changed rows for a while. That lets the app read a table “as it was” earlier. How long it is kept is the DBA’s UNDO_RETENTION setting.'],
  ['FLASHBACK', 'The Oracle privilege needed to read a table as it was at an earlier moment.'],
  ['Chunk', 'A piece of a huge table (a range of keys or of ROWIDs) loaded and checked on its own.'],
  ['ROWID', 'Oracle’s physical address of a row. Used to cut tables that have no numeric key.'],
  ['LOB', 'Large object columns: BLOB, CLOB, NCLOB and similar. They make tables slow to copy.'],
  ['Checksum', 'A sum computed over a column on both sides. If the sums differ, the data differs.'],
  ['WAL', 'PostgreSQL’s transaction log. Every write goes to it first; it is what makes data crash-safe.'],
  ['Unlogged table', 'A PostgreSQL table written without WAL: faster, but emptied by a crash. The app makes each table permanent after its checks.'],
  ['NOT VALID foreign key', 'A key added without checking existing rows (instant); it is checked right after.'],
  ['ora2pg', 'The open-source tool that does the actual reading from Oracle and writing to PostgreSQL. The app drives it.'],
  ['Staging folder', 'The folder on the app server with projects, logs and (in file modes) data files.'],
];

function Section({ id, title, subtitle, children }: { id: string; title: string; subtitle?: ReactNode; children: ReactNode }) {
  return (
    <Box id={id} sx={{ scrollMarginTop: 90 }}>
      <SectionCard title={title} subtitle={subtitle}>{children}</SectionCard>
    </Box>
  );
}

const cellHead = { fontWeight: 700, color: brand.muted, fontSize: 12.5, textTransform: 'uppercase' as const, letterSpacing: 0.4 };

export default function GuidePage() {
  const { hash } = useLocation();
  const [q, setQ] = useState('');
  useEffect(() => {
    // After the page's own scroll-to-top on navigation, so the jump is not cut short.
    if (hash) { const t = setTimeout(() => document.getElementById(hash.slice(1))?.scrollIntoView({ block: 'start' }), 300); return () => clearTimeout(t); }
    return undefined;
  }, [hash]);

  const groups = useMemo(() => {
    const s = q.trim().toLowerCase();
    return OPTION_GROUPS.map((g) => ({ ...g, items: g.items.filter((o) => !s || `${o.name} ${o.what} ${o.when}`.toLowerCase().includes(s)) })).filter((g) => g.items.length);
  }, [q]);

  const sections = [{ title: 'Workspace', items: [
    { to: '/', label: 'Home', icon: <HomeRoundedIcon />, end: true },
    { to: '/projects', label: 'All projects', icon: <FolderCopyRoundedIcon />, end: true },
    { to: '/guide', label: 'Guide', icon: <MenuBookRoundedIcon />, end: true },
  ] }];

  return (
    <Shell sections={sections} crumbs={[{ label: 'Home', to: '/' }, { label: 'Guide' }]}>
      <PageHeader overline="Help" title="Guide" icon={<MenuBookRoundedIcon />}
        subtitle="What the Database Migration Accelerator does, what is new in v2, and every option in plain words. When in doubt: keep the defaults." />

      <Box sx={{ display: 'grid', gap: 3, gridTemplateColumns: { xs: '1fr', lg: '220px minmax(0,1fr)' }, alignItems: 'start' }}>
        <Box sx={{ position: { lg: 'sticky' }, top: { lg: 84 }, display: { xs: 'none', lg: 'block' } }}>
          <Typography variant="overline" color="text.secondary">On this page</Typography>
          <Stack spacing={0.25} sx={{ mt: 0.5 }}>
            {TOC.map(([id, label]) => (
              <Box key={id} component="a" href={`#${id}`} onClick={(e: any) => { e.preventDefault(); document.getElementById(id)?.scrollIntoView({ behavior: 'smooth', block: 'start' }); window.history.replaceState(null, '', `#${id}`); }}
                sx={{ px: 1.25, py: 0.75, borderRadius: 2, fontSize: 14, color: hash === `#${id}` ? brand.blue : brand.ink, fontWeight: hash === `#${id}` ? 700 : 500, textDecoration: 'none', '&:hover': { bgcolor: brand.sky } }}>
                {label}
              </Box>
            ))}
          </Stack>
        </Box>

        <Stack spacing={3} sx={{ minWidth: 0 }}>
          <Section id="what" title="What DMA does">
            <Typography sx={{ mb: 2 }}>
              The Database Migration Accelerator moves an Oracle schema to PostgreSQL: the table structure, the data, keys and indexes, sequences,
              and (with GenAI) the code. You follow the steps on the left of each project; the tool runs ora2pg for you, checks every table and tells you what happened.
            </Typography>
            <Box sx={{ display: 'grid', gap: 2, gridTemplateColumns: { xs: '1fr', md: 'repeat(3, 1fr)' } }}>
              {[
                ['Plan', 'Snapshot, assessment and pre-flight checks show what you are moving and what could stop it.'],
                ['Move', 'Tables load in parallel, huge tables in chunks, failures retried on their own, progress live.'],
                ['Prove', 'Every table is counted and checksummed; the Validation page compares both sides and exports to Excel.'],
              ].map(([t, d]) => (
                <Box key={t} sx={{ p: 2, borderRadius: 3, bgcolor: '#F5F9FF', border: `1px solid ${brand.border}` }}>
                  <Typography fontWeight={800} fontFamily={headingFont} sx={{ mb: 0.5 }}>{t}</Typography>
                  <Typography variant="body2" color="text.secondary">{d}</Typography>
                </Box>
              ))}
            </Box>
          </Section>

          <Section id="new" title="What is new in v2" subtitle="Same screens and deployment as v1; a much stronger engine underneath.">
            <Table size="small">
              <TableHead><TableRow><TableCell sx={cellHead}>Area</TableCell><TableCell sx={cellHead}>v1</TableCell><TableCell sx={cellHead}>v2</TableCell></TableRow></TableHead>
              <TableBody>
                {NEW_IN_V2.map(([a, v1, v2]) => (
                  <TableRow key={a}>
                    <TableCell sx={{ fontWeight: 700, whiteSpace: 'nowrap' }}>{a}</TableCell>
                    <TableCell sx={{ color: 'text.secondary' }}>{v1}</TableCell>
                    <TableCell><Stack direction="row" spacing={1} alignItems="flex-start"><CheckCircleRoundedIcon sx={{ fontSize: 18, color: brand.success, mt: 0.2 }} /><span>{v2}</span></Stack></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Section>

          <Section id="steps" title="The steps of a project" subtitle="The bar at the top of every project page shows where you are. Optional steps can be skipped. The Detailed report (left menu) is extra, for the DBA or architect.">
            <Box sx={{ display: 'grid', gap: 1.5, gridTemplateColumns: { xs: '1fr', md: '1fr 1fr' } }}>
              {STEPS.map(([name, todo, result, optional], i) => (
                <Stack key={name} direction="row" spacing={1.5} sx={{ p: 2, borderRadius: 3, border: `1px solid ${brand.border}` }}>
                  <Box sx={{ width: 30, height: 30, flexShrink: 0, borderRadius: 2, display: 'grid', placeItems: 'center', background: optional ? '#EEF2F8' : brand.accentGradient, color: optional ? brand.muted : '#fff', fontWeight: 800 }}>{i + 1}</Box>
                  <Box sx={{ minWidth: 0 }}>
                    <Stack direction="row" spacing={1} alignItems="center"><Typography fontWeight={750}>{name}</Typography>{optional && <Chip size="small" label="optional" sx={{ height: 20, fontSize: 11 }} />}</Stack>
                    <Typography variant="body2" sx={{ mt: 0.25 }}><b>You:</b> {todo}</Typography>
                    <Typography variant="body2" color="text.secondary"><b>You get:</b> {result}</Typography>
                  </Box>
                </Stack>
              ))}
            </Box>
          </Section>

          <Section id="recipe" title="Your first migration: the short version" subtitle="If you only read one part, read this.">
            <Stack component="ol" spacing={1.25} sx={{ pl: 2.5, m: 0, '& li': { pl: 0.5 } }}>
              <li><b>Connect</b> Oracle and PostgreSQL, then <b>take the snapshot</b> of the schema.</li>
              <li>Open <b>Settings</b>: agree the decisions with the application team (names, numbers, booleans, LOBs, target schema, roles). Fill in <b>Notifications</b> and press <i>Send a test</i>.</li>
              <li>Open <b>Migrate</b>, press <i>Select shown</i> to select all tables. <b>Leave the settings at their defaults</b>, with one exception:
                <Box component="ul" sx={{ mt: 0.5, pl: 2.5 }}>
                  <li>application <b>stopped</b> during the migration → turn <b>Consistent snapshot off</b>;</li>
                  <li>application <b>running</b> → keep it on and give the DBA the undo value from the checks.</li>
                </Box>
              </li>
              <li>Press <b>Run checks</b>. Red items must be fixed; amber items are worth sending to the DBA (they include the exact values).</li>
              <li>Press <b>Start migration</b>. You can close the browser: the run continues on the server, and you get a message when it ends.</li>
              <li>If tables failed: open the run, read the reason, fix it, press <b>Retry failed & resume</b>.</li>
              <li>Open <b>Validation</b> and press <b>Export all (Excel)</b> for the application team.</li>
            </Stack>
          </Section>

          <Section id="options" title="Every option explained" subtitle="What it does, its default, and when (if ever) to change it.">
            <TextField size="small" placeholder="Search options, e.g. snapshot, chunk, LOB" value={q} onChange={(e) => setQ(e.target.value)} sx={{ mb: 2, width: { xs: '100%', md: 420 } }}
              InputProps={{ startAdornment: <InputAdornment position="start"><SearchRoundedIcon fontSize="small" /></InputAdornment> }} />
            <Stack spacing={3}>
              {groups.map((g) => (
                <Box key={g.title}>
                  <Typography fontWeight={800} fontFamily={headingFont} fontSize={17}>{g.title}</Typography>
                  <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>{g.intro}</Typography>
                  <Box sx={{ overflowX: 'auto' }}>
                    <Table size="small" sx={{ minWidth: 760 }}>
                      <TableHead><TableRow>
                        <TableCell sx={{ ...cellHead, width: '20%' }}>Option</TableCell>
                        <TableCell sx={{ ...cellHead, width: '34%' }}>What it means</TableCell>
                        <TableCell sx={{ ...cellHead, width: '12%' }}>Default</TableCell>
                        <TableCell sx={cellHead}>When to change it</TableCell>
                      </TableRow></TableHead>
                      <TableBody>
                        {g.items.map((o) => (
                          <TableRow key={o.name} sx={{ verticalAlign: 'top' }}>
                            <TableCell sx={{ fontWeight: 700 }}>{o.name}<Typography variant="caption" color="text.secondary" sx={{ display: 'block' }}>{o.where}</Typography></TableCell>
                            <TableCell>{o.what}</TableCell>
                            <TableCell><Chip size="small" label={o.def} sx={{ bgcolor: '#ECFDF3', color: brand.success, fontWeight: 700, height: 'auto', '& .MuiChip-label': { whiteSpace: 'normal', py: 0.25 } }} /></TableCell>
                            <TableCell sx={{ color: 'text.secondary' }}>{o.when}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </Box>
                </Box>
              ))}
              {!groups.length && <Typography color="text.secondary">No option matches “{q}”.</Typography>}
            </Stack>
          </Section>

          <Section id="preflight" title="Pre-flight checks" subtitle="Migrate page → Run checks. Green = fine, amber = a risk to read, red = must be fixed before Start.">
            <Table size="small">
              <TableHead><TableRow><TableCell sx={cellHead}>Check</TableCell><TableCell sx={cellHead}>What it looks at</TableCell><TableCell sx={cellHead}>If it is amber or red</TableCell></TableRow></TableHead>
              <TableBody>
                {CHECKS.map(([c, what, fix]) => (
                  <TableRow key={c} sx={{ verticalAlign: 'top' }}>
                    <TableCell sx={{ fontWeight: 700, whiteSpace: 'nowrap' }}>{c}</TableCell>
                    <TableCell>{what}</TableCell>
                    <TableCell sx={{ color: 'text.secondary' }}>{fix}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </Section>

          <Section id="problems" title="When something goes wrong">
            <Stack spacing={1.5}>
              {PROBLEMS.map(([p, a]) => (
                <Box key={p} sx={{ p: 2, borderRadius: 3, border: `1px solid ${brand.border}` }}>
                  <Typography fontWeight={750}>{p}</Typography>
                  <Typography variant="body2" color="text.secondary">{a}</Typography>
                </Box>
              ))}
            </Stack>
          </Section>

          <Section id="glossary" title="Words used in the app">
            <Box sx={{ display: 'grid', gap: 1.5, gridTemplateColumns: { xs: '1fr', md: '1fr 1fr' } }}>
              {GLOSSARY.map(([w, d]) => (
                <Box key={w} sx={{ p: 1.75, borderRadius: 3, bgcolor: '#FAFBFD', border: `1px solid ${brand.border}` }}>
                  <Typography fontWeight={750}>{w}</Typography>
                  <Typography variant="body2" color="text.secondary">{d}</Typography>
                </Box>
              ))}
            </Box>
          </Section>
        </Stack>
      </Box>
    </Shell>
  );
}
