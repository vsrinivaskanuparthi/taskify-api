import { Box, Button, Card, Skeleton, Stack, Typography } from '@mui/material';
import HomeRoundedIcon from '@mui/icons-material/HomeRounded';
import FolderCopyRoundedIcon from '@mui/icons-material/FolderCopyRounded';
import MenuBookRoundedIcon from '@mui/icons-material/MenuBookRounded';
import RocketLaunchRoundedIcon from '@mui/icons-material/RocketLaunchRounded';
import ArrowForwardRoundedIcon from '@mui/icons-material/ArrowForwardRounded';
import CableRoundedIcon from '@mui/icons-material/CableRounded';
import AssessmentRoundedIcon from '@mui/icons-material/AssessmentRounded';
import TuneRoundedIcon from '@mui/icons-material/TuneRounded';
import AutoAwesomeRoundedIcon from '@mui/icons-material/AutoAwesomeRounded';
import FactCheckRoundedIcon from '@mui/icons-material/FactCheckRounded';
import StorageRoundedIcon from '@mui/icons-material/StorageRounded';
import MonitorHeartRoundedIcon from '@mui/icons-material/MonitorHeartRounded';
import ReplayRoundedIcon from '@mui/icons-material/ReplayRounded';
import LinkRoundedIcon from '@mui/icons-material/LinkRounded';
import VerifiedUserRoundedIcon from '@mui/icons-material/VerifiedUserRounded';
import WorkspacesRoundedIcon from '@mui/icons-material/WorkspacesRounded';
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../api';
import Shell from '../components/Shell';
import { StatusChip } from '../components/ui';
import { timeAgo } from '../format';
import { brand, headingFont } from '../theme';

type Project = { projectName: string; appName: string; appCode: string; migrationStatus: string; selectedSchema?: string; updatedAt?: string; createdAt: string; oracle: any; postgres: any };

const ORACLE = '#C74634';
const PG = '#336791';

/** A database drawn as a cylinder, for the hero illustration (generic shapes, no vendor logos). */
function Cylinder({ x, y, color, label, sub }: { x: number; y: number; color: string; label: string; sub: string }) {
  const w = 132;
  return (
    <g transform={`translate(${x} ${y})`}>
      <ellipse cx={w / 2} cy={150} rx={w / 2} ry={16} fill="rgba(0,0,0,.25)" />
      <path d={`M0 22 v112 a${w / 2} 18 0 0 0 ${w} 0 v-112`} fill={color} />
      <path d={`M0 60 a${w / 2} 18 0 0 0 ${w} 0`} fill="none" stroke="rgba(255,255,255,.28)" strokeWidth="2" />
      <path d={`M0 98 a${w / 2} 18 0 0 0 ${w} 0`} fill="none" stroke="rgba(255,255,255,.28)" strokeWidth="2" />
      <ellipse cx={w / 2} cy={22} rx={w / 2} ry={18} fill={color} />
      <ellipse cx={w / 2} cy={22} rx={w / 2} ry={18} fill="rgba(255,255,255,.22)" />
      <text x={w / 2} y={88} textAnchor="middle" fill="#fff" fontFamily={headingFont} fontWeight={800} fontSize={17}>{label}</text>
      <text x={w / 2} y={190} textAnchor="middle" fill="rgba(255,255,255,.75)" fontFamily={headingFont} fontWeight={600} fontSize={12}>{sub}</text>
    </g>
  );
}

function HeroArt() {
  const chips = [
    { y: 34, t: 'Schema & DDL' },
    { y: 84, t: 'Data · TB scale' },
    { y: 134, t: 'PL/SQL → PL/pgSQL' },
  ];
  return (
    <Box component="svg" viewBox="0 0 520 260" sx={{ width: '100%', maxWidth: 560, height: 'auto', display: 'block', overflow: 'visible',
      '& .flow': { strokeDasharray: '6 10', animation: 'dmaFlow 1.2s linear infinite' }, '@keyframes dmaFlow': { to: { strokeDashoffset: -32 } },
      '& .pulse': { animation: 'dmaPulse 2.4s ease-in-out infinite' }, '@keyframes dmaPulse': { '0%,100%': { opacity: 0.55 }, '50%': { opacity: 1 } } }}>
      <defs>
        <linearGradient id="dmaPath" gradientUnits="userSpaceOnUse" x1="148" y1="0" x2="372" y2="0"><stop offset="0" stopColor="#FF8A75" /><stop offset="1" stopColor="#7FB2FF" /></linearGradient>
      </defs>
      <Cylinder x={8} y={38} color={ORACLE} label="Oracle" sub="source" />
      <Cylinder x={380} y={38} color={PG} label="PostgreSQL" sub="target" />
      {chips.map((c) => (
        <g key={c.t}>
          <path className="flow" d={`M148 ${c.y + 50} C 210 ${c.y + 50}, 310 ${c.y + 50}, 372 ${c.y + 50}`} stroke="url(#dmaPath)" strokeWidth="3" fill="none" strokeLinecap="round" />
          <g transform={`translate(196 ${c.y + 34})`}>
            <rect width="128" height="32" rx="16" fill="#163A7A" stroke="rgba(255,255,255,.35)" />
            <text x="64" y="21" textAnchor="middle" fill="#fff" fontFamily={headingFont} fontWeight={700} fontSize={12}>{c.t}</text>
          </g>
        </g>
      ))}
      <g className="pulse" transform="translate(430 4)">
        <circle cx="16" cy="16" r="16" fill="#12B76A" />
        <path d="M9 16.5l4.5 4.5L23 11.5" stroke="#fff" strokeWidth="3" fill="none" strokeLinecap="round" strokeLinejoin="round" />
      </g>
    </Box>
  );
}

const STEPS = [
  { icon: <CableRoundedIcon />, title: 'Connect', text: 'Oracle source and PostgreSQL target, per project.' },
  { icon: <AssessmentRoundedIcon />, title: 'Assess', text: 'Snapshot, analysis report, complexity and effort.' },
  { icon: <TuneRoundedIcon />, title: 'Decide', text: 'Names, numbers, booleans, LOBs, access: agreed up front.' },
  { icon: <AutoAwesomeRoundedIcon />, title: 'Convert', text: 'Code objects out as one zip, GenAI-converted back in.' },
  { icon: <RocketLaunchRoundedIcon />, title: 'Migrate', text: 'Parallel, chunked, resumable, watched live.' },
  { icon: <FactCheckRoundedIcon />, title: 'Validate', text: 'Rows, keys, indexes and every code object by name.' },
];

const FEATURES = [
  { icon: <StorageRoundedIcon />, color: brand.blue, title: 'Terabyte-scale loading', text: 'Huge tables split into primary-key chunks loaded in parallel; each chunk verified by an exact row count.' },
  { icon: <ReplayRoundedIcon />, color: brand.success, title: 'Resume, never restart', text: 'Failed tables retry by themselves. After a crash or restart, Resume continues with only the unfinished chunks.' },
  { icon: <MonitorHeartRoundedIcon />, color: brand.cyan, title: 'Live monitor', text: 'Phases, tables, speed and time left pushed to the browser as they happen, with a chat-style activity feed.' },
  { icon: <AutoAwesomeRoundedIcon />, color: brand.violet, title: 'GenAI code round trip', text: 'Packages, procedures, functions, triggers and views exported per object with a conversion guide that carries your decisions.' },
  { icon: <LinkRoundedIcon />, color: brand.warning, title: 'DB links that work', text: 'Oracle DB links mapped to postgres_fdw or oracle_fdw, with access for the application roles.' },
  { icon: <VerifiedUserRoundedIcon />, color: '#0E9384', title: 'Lessons built in', text: 'Defaults and checks from real migrations: quoted reserved words, integer IDs, explicit booleans, code-object validation.' },
];

export default function HomePage() {
  const navigate = useNavigate();
  const [projects, setProjects] = useState<Project[] | null>(null);
  useEffect(() => { api<{ projects: Project[] }>('/projects').then((r) => setProjects(r.projects)).catch(() => setProjects([])); }, []);

  const list = projects || [];
  const count = (pred: (p: Project) => boolean) => list.filter(pred).length;
  const stats = [
    { label: 'Projects', value: list.length },
    { label: 'Migrations completed', value: count((p) => p.migrationStatus === 'COMPLETED') },
    { label: 'Running now', value: count((p) => ['RUNNING', 'IN_PROGRESS', 'QUEUED'].includes(p.migrationStatus)) },
    { label: 'Need attention', value: count((p) => ['FAILED', 'COMPLETED_WITH_ERRORS', 'INTERRUPTED'].includes(p.migrationStatus)) },
  ];
  const sections = [
    { title: 'Workspace', items: [
      { to: '/', label: 'Home', icon: <HomeRoundedIcon />, end: true },
      { to: '/projects', label: 'All projects', icon: <FolderCopyRoundedIcon />, end: true, badge: list.length || null },
      { to: '/guide', label: 'Guide', icon: <MenuBookRoundedIcon />, end: true },
    ] },
    ...(list.length ? [{ title: 'Recent projects', items: list.slice(0, 6).map((p) => ({ to: `/projects/${p.projectName}/connect`, label: p.projectName, icon: <WorkspacesRoundedIcon /> })) }] : []),
  ];

  return (
    <Shell sections={sections} crumbs={[{ label: 'Home' }]}>
      {/* Hero */}
      <Box sx={{ position: 'relative', overflow: 'clip', borderRadius: 5, color: '#fff', mb: 3,
        background: 'radial-gradient(1200px 400px at 85% -10%, rgba(34,166,242,.35), transparent 60%), radial-gradient(900px 380px at 0% 120%, rgba(199,70,52,.28), transparent 60%), linear-gradient(135deg, #061637 0%, #00205B 55%, #0A3F96 100%)' }}>
        <Box sx={{ position: 'absolute', inset: 0, opacity: 0.07, backgroundImage: 'linear-gradient(rgba(255,255,255,1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,1) 1px, transparent 1px)', backgroundSize: '36px 36px' }} />
        <Box sx={{ position: 'relative', display: 'grid', gap: { xs: 3, md: 4 }, gridTemplateColumns: { xs: '1fr', lg: '1.05fr 1fr' }, alignItems: 'center', p: { xs: 3, md: 5, xl: 6 } }}>
          <Box>
            <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 2 }}>
              <Box sx={{ px: 1.25, py: 0.4, borderRadius: 99, bgcolor: 'rgba(255,255,255,.12)', border: '1px solid rgba(255,255,255,.22)', fontSize: 12.5, fontWeight: 700, letterSpacing: '.04em' }}>
                <Box component="span" sx={{ color: '#FF9C8A' }}>ORACLE</Box> → <Box component="span" sx={{ color: '#8CC4FF' }}>POSTGRESQL</Box>
              </Box>
            </Stack>
            <Typography component="h1" sx={{ fontFamily: headingFont, fontWeight: 800, letterSpacing: '-0.03em', lineHeight: 1.05, fontSize: { xs: 34, md: 46, xl: 54 } }}>
              Database Migration Accelerator
            </Typography>
            <Typography sx={{ mt: 2, fontSize: { xs: 17, md: 20 }, color: 'rgba(255,255,255,.88)', maxWidth: 560, lineHeight: 1.5 }}>
              Your one-step path from Oracle to PostgreSQL: assess, decide, convert, migrate and validate, from gigabytes to terabytes, all watched live.
            </Typography>
            <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.5} sx={{ mt: 4 }}>
              <Button size="large" variant="contained" startIcon={<RocketLaunchRoundedIcon />} onClick={() => navigate('/projects?new=1')}
                sx={{ bgcolor: '#fff', backgroundImage: 'none', color: brand.navy, px: 3, boxShadow: '0 10px 30px -10px rgba(0,0,0,.5)', '&:hover': { bgcolor: brand.sky, backgroundImage: 'none' } }}>Start a migration</Button>
              <Button size="large" variant="outlined" endIcon={<ArrowForwardRoundedIcon />} onClick={() => navigate('/projects')}
                sx={{ color: '#fff', borderColor: 'rgba(255,255,255,.45)', bgcolor: 'rgba(255,255,255,.06)', px: 3, '&:hover': { bgcolor: 'rgba(255,255,255,.14)', borderColor: '#fff' } }}>Open projects</Button>
            </Stack>
          </Box>
          <Box sx={{ display: 'flex', justifyContent: 'center' }}><HeroArt /></Box>
        </Box>
        <Box sx={{ position: 'relative', display: 'grid', gridTemplateColumns: { xs: 'repeat(2, 1fr)', md: 'repeat(4, 1fr)' }, borderTop: '1px solid rgba(255,255,255,.14)', bgcolor: 'rgba(0,0,0,.12)' }}>
          {stats.map((s, i) => (
            <Box key={s.label} sx={{ px: { xs: 3, md: 5 }, py: 2.25, borderLeft: { md: i ? '1px solid rgba(255,255,255,.12)' : 'none' } }}>
              <Typography sx={{ fontFamily: headingFont, fontWeight: 800, fontSize: 28 }}>{projects ? s.value : <Skeleton width={40} sx={{ bgcolor: 'rgba(255,255,255,.2)' }} />}</Typography>
              <Typography sx={{ fontSize: 13, color: 'rgba(255,255,255,.72)' }}>{s.label}</Typography>
            </Box>
          ))}
        </Box>
      </Box>

      {/* How it works */}
      <Typography variant="overline" color="text.secondary">How it works</Typography>
      <Box sx={{ display: 'grid', gap: 1.5, gridTemplateColumns: { xs: '1fr 1fr', md: 'repeat(3, 1fr)', xl: 'repeat(6, 1fr)' }, mt: 1, mb: 4 }}>
        {STEPS.map((s, i) => (
          <Card key={s.title} sx={{ p: 2.25, position: 'relative' }}>
            <Stack direction="row" spacing={1.25} alignItems="center">
              <Box sx={{ width: 38, height: 38, borderRadius: 2.5, display: 'grid', placeItems: 'center', bgcolor: brand.sky, color: brand.blue, '& svg': { fontSize: 20 } }}>{s.icon}</Box>
              <Typography sx={{ fontFamily: headingFont, fontWeight: 800, fontSize: 13, color: 'text.disabled' }}>0{i + 1}</Typography>
            </Stack>
            <Typography sx={{ fontFamily: headingFont, fontWeight: 750, fontSize: 16, mt: 1.5 }}>{s.title}</Typography>
            <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5 }}>{s.text}</Typography>
          </Card>
        ))}
      </Box>

      <Box sx={{ display: 'grid', gap: 3, gridTemplateColumns: { xs: '1fr', xl: 'minmax(0, 2fr) minmax(0, 1fr)' }, alignItems: 'start' }}>
        <Box>
          <Typography variant="overline" color="text.secondary">Built for enterprise migrations</Typography>
          <Box sx={{ display: 'grid', gap: 2, gridTemplateColumns: { xs: '1fr', md: '1fr 1fr' }, mt: 1 }}>
            {FEATURES.map((f) => (
              <Card key={f.title} sx={{ p: 2.5, display: 'flex', gap: 2 }}>
                <Box sx={{ width: 44, height: 44, flexShrink: 0, borderRadius: 3, display: 'grid', placeItems: 'center', bgcolor: `${f.color}14`, color: f.color }}>{f.icon}</Box>
                <Box>
                  <Typography sx={{ fontFamily: headingFont, fontWeight: 750, fontSize: 16 }}>{f.title}</Typography>
                  <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5, lineHeight: 1.55 }}>{f.text}</Typography>
                </Box>
              </Card>
            ))}
          </Box>
        </Box>
        <Box>
          <Stack direction="row" alignItems="center" justifyContent="space-between">
            <Typography variant="overline" color="text.secondary">Recent projects</Typography>
            {list.length > 0 && <Button size="small" endIcon={<ArrowForwardRoundedIcon />} onClick={() => navigate('/projects')}>View all</Button>}
          </Stack>
          <Card sx={{ mt: 1 }}>
            {projects === null && <Box sx={{ p: 2 }}><Skeleton height={48} /><Skeleton height={48} /></Box>}
            {projects && list.length === 0 && (
              <Stack alignItems="center" spacing={1.5} sx={{ p: 4, textAlign: 'center' }}>
                <Box sx={{ width: 56, height: 56, borderRadius: '50%', display: 'grid', placeItems: 'center', bgcolor: brand.sky, color: brand.blue }}><FolderCopyRoundedIcon /></Box>
                <Typography fontWeight={700}>No projects yet</Typography>
                <Typography variant="body2" color="text.secondary">One project per application: it keeps connections, decisions, runs and reports together.</Typography>
                <Button variant="contained" startIcon={<RocketLaunchRoundedIcon />} onClick={() => navigate('/projects?new=1')}>Create the first project</Button>
              </Stack>
            )}
            {list.slice(0, 5).map((p, i) => (
              <Stack key={p.projectName} direction="row" spacing={1.5} alignItems="center" onClick={() => navigate(`/projects/${p.projectName}/connect`)}
                sx={{ px: 2, py: 1.5, cursor: 'pointer', borderTop: i ? `1px solid ${brand.border}` : 'none', '&:hover': { bgcolor: '#FAFBFD' } }}>
                <Box sx={{ width: 38, height: 38, borderRadius: 2.5, flexShrink: 0, display: 'grid', placeItems: 'center', background: brand.gradient, color: '#fff', fontFamily: headingFont, fontWeight: 800, fontSize: 13 }}>
                  {p.projectName.slice(0, 2).toUpperCase()}
                </Box>
                <Box sx={{ flex: 1, minWidth: 0 }}>
                  <Typography fontWeight={700} noWrap>{p.projectName}</Typography>
                  <Typography variant="caption" color="text.secondary" noWrap component="div">{p.appName} · {p.selectedSchema || 'no schema yet'} · {timeAgo(p.updatedAt || p.createdAt)}</Typography>
                </Box>
                <StatusChip status={p.migrationStatus} />
              </Stack>
            ))}
          </Card>
        </Box>
      </Box>

      <Typography variant="caption" color="text.disabled" sx={{ display: 'block', textAlign: 'center', mt: 5 }}>
        Database Migration Accelerator · v2.0 · conversion engine: ora2pg
      </Typography>
    </Shell>
  );
}
