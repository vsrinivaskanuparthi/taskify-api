import { Alert, Box, Button, Chip, FormControlLabel, InputAdornment, IconButton, Radio, RadioGroup, Stack, TextField, ToggleButton, ToggleButtonGroup, Typography } from '@mui/material';
import VisibilityRoundedIcon from '@mui/icons-material/VisibilityRounded';
import VisibilityOffRoundedIcon from '@mui/icons-material/VisibilityOffRounded';
import ArrowForwardRoundedIcon from '@mui/icons-material/ArrowForwardRounded';
import CableRoundedIcon from '@mui/icons-material/CableRounded';
import { ReactNode, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api, projectPath } from '../api';
import { useProject } from '../context/ProjectContext';
import { PageHeader, SectionCard, CheckIcon } from '../components/ui';
import { fmtDate } from '../format';
import { brand } from '../theme';

function PasswordField({ value, onChange, label = 'Password' }: { value: string; onChange: (v: string) => void; label?: string }) {
  const [show, setShow] = useState(false);
  return (
    <TextField label={label} type={show ? 'text' : 'password'} value={value} onChange={(e) => onChange(e.target.value)} fullWidth required autoComplete="new-password"
      InputProps={{ endAdornment: <InputAdornment position="end"><IconButton size="small" onClick={() => setShow(!show)} aria-label="Show password">{show ? <VisibilityOffRoundedIcon fontSize="small" /> : <VisibilityRoundedIcon fontSize="small" />}</IconButton></InputAdornment> }} />
  );
}

/** One-line "connected" summary shown when a connection card is folded. */
function CheckLine({ text }: { text: string }) {
  return <Stack direction="row" spacing={0.75} alignItems="center" component="span"><CheckIcon ok /><span style={{ overflowWrap: 'anywhere' }}>{text}</span></Stack>;
}

function Connected({ title, lines }: { title: string; lines: [string, ReactNode][] }) {
  return (
    <Box sx={{ p: 2, borderRadius: 2.5, bgcolor: '#EEF7F2', border: '1px solid #C6E6D5', mb: 2.5 }}>
      <Stack direction="row" spacing={1} alignItems="center" sx={{ mb: 1 }}>
        <Box sx={{ width: 9, height: 9, borderRadius: '50%', bgcolor: 'success.main', boxShadow: '0 0 0 4px rgba(18,128,92,.15)' }} />
        <Typography fontWeight={700} color="success.main">{title}</Typography>
      </Stack>
      {lines.map(([k, v]) => (
        <Stack key={k} direction="row" spacing={1.5} sx={{ minWidth: 0 }}>
          <Typography variant="body2" color="text.secondary" sx={{ width: 90, flexShrink: 0 }}>{k}</Typography>
          <Typography variant="body2" sx={{ minWidth: 0, overflowWrap: 'anywhere' }} className="mono">{v}</Typography>
        </Stack>
      ))}
    </Box>
  );
}

function OracleCard() {
  const { name, project, reload } = useProject();
  const [mode, setMode] = useState<'url' | 'host'>('host');
  const [url, setUrl] = useState('');
  const [host, setHost] = useState('');
  const [port, setPort] = useState('1521');
  const [idType, setIdType] = useState<'SERVICE_NAME' | 'SID'>('SERVICE_NAME');
  const [idName, setIdName] = useState('');
  const [user, setUser] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);

  useEffect(() => {
    if (project?.oracle) {
      setMode('url');
      setUrl(project.oracle.userUrl);
      setUser(project.oracle.userUsername);
    }
  }, [project?.oracle?.userUrl]);

  const userUrl = mode === 'url' ? url.trim() : `(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(HOST=${host})(PORT=${port}))(CONNECT_DATA=(${idType}=${idName})))`;
  const valid = user && password && (mode === 'url' ? url.trim() : host && port && idName);

  const connect = async () => {
    setBusy(true);
    setMsg(null);
    try {
      const r = await api<{ schemas: string[] }>(`${projectPath(name)}/oracle/connect`, { body: { userUrl, userUsername: user, userPassword: password } });
      setMsg({ ok: true, text: `Connected. ${r.schemas.length} schemas available.` });
      setPassword('');
      await reload();
    } catch (e: any) {
      setMsg({ ok: false, text: e.message });
    } finally {
      setBusy(false);
    }
  };

  return (
    <SectionCard key={project?.oracle ? 'ora-on' : 'ora-off'} collapsible defaultOpen={!project?.oracle} title="Oracle source" subtitle="The database you migrate from. A user with SELECT ANY DICTIONARY / DBA views is recommended."
      summary={project?.oracle ? <CheckLine text={`Connected as ${project.oracle.userUsername} · ${project.oracle.userUrl}`} /> : undefined}>
      {project?.oracle && (
        <Connected title="Connected" lines={[['User', project.oracle.userUsername], ['Database', project.oracle.userUrl], ['Since', fmtDate(project.oracle.connectedAt)]]} />
      )}
      <Stack spacing={2}>
        <ToggleButtonGroup size="small" exclusive value={mode} onChange={(_, v) => v && setMode(v)} color="primary">
          <ToggleButton value="host">Host / port</ToggleButton>
          <ToggleButton value="url">Connection string</ToggleButton>
        </ToggleButtonGroup>
        {mode === 'url' ? (
          <TextField label="Connection string" value={url} onChange={(e) => setUrl(e.target.value)} fullWidth required className="mono"
            placeholder="host:1521/SERVICE  or  (DESCRIPTION=(ADDRESS=…))"
            helperText="Accepts EZConnect (host:port/service), JDBC (host:port:SID) or a full TNS descriptor." />
        ) : (
          <>
            <Stack direction={{ xs: 'column', sm: 'row' }} spacing={2}>
              <TextField label="Host" value={host} onChange={(e) => setHost(e.target.value)} fullWidth required />
              <TextField label="Port" value={port} onChange={(e) => setPort(e.target.value.replace(/\D/g, ''))} required sx={{ width: { sm: 120 } }} />
            </Stack>
            <Stack direction={{ xs: 'column', sm: 'row' }} spacing={2} alignItems={{ sm: 'center' }}>
              <RadioGroup row value={idType} onChange={(e) => setIdType(e.target.value as any)} sx={{ flexShrink: 0 }}>
                <FormControlLabel value="SERVICE_NAME" control={<Radio size="small" />} label="Service name" />
                <FormControlLabel value="SID" control={<Radio size="small" />} label="SID" />
              </RadioGroup>
              <TextField label={idType === 'SID' ? 'SID' : 'Service name'} value={idName} onChange={(e) => setIdName(e.target.value)} fullWidth required />
            </Stack>
          </>
        )}
        <Stack direction={{ xs: 'column', sm: 'row' }} spacing={2}>
          <TextField label="User name" value={user} onChange={(e) => setUser(e.target.value)} fullWidth required />
          <PasswordField value={password} onChange={setPassword} />
        </Stack>
        {msg && <Alert severity={msg.ok ? 'success' : 'error'} sx={{ overflowWrap: 'anywhere' }}>{msg.text}</Alert>}
        <Box><Button variant="contained" onClick={connect} disabled={!valid || busy}>{busy ? 'Connecting…' : project?.oracle ? 'Reconnect' : 'Test & connect'}</Button></Box>
      </Stack>
    </SectionCard>
  );
}

function PostgresCard() {
  const { name, project, reload } = useProject();
  const [f, setF] = useState({ hostip: '', port: '5432', dbname: '', username: '' });
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);

  useEffect(() => {
    if (project?.postgres) setF({ hostip: project.postgres.hostip, port: project.postgres.port, dbname: project.postgres.dbname, username: project.postgres.username });
  }, [project?.postgres?.hostip, project?.postgres?.dbname]);

  const valid = f.hostip && f.port && f.dbname && f.username && password;
  const connect = async () => {
    setBusy(true);
    setMsg(null);
    try {
      await api(`${projectPath(name)}/postgres/connect`, { body: { ...f, password } });
      setMsg({ ok: true, text: 'Connected.' });
      setPassword('');
      await reload();
    } catch (e: any) {
      setMsg({ ok: false, text: e.message });
    } finally {
      setBusy(false);
    }
  };
  const disconnect = async () => {
    await api(`${projectPath(name)}/postgres/disconnect`, { body: {} });
    await reload();
  };
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement>) => setF({ ...f, [k]: e.target.value });

  return (
    <SectionCard key={project?.postgres ? 'pg-on' : 'pg-off'} collapsible defaultOpen={!project?.postgres} title="PostgreSQL target" subtitle="Where the schema is created. The user needs CREATE on the database."
      summary={project?.postgres ? <CheckLine text={`Connected as ${project.postgres.username} · ${project.postgres.hostip}:${project.postgres.port}/${project.postgres.dbname}`} /> : undefined}
      action={project?.postgres ? <Button size="small" color="inherit" onClick={disconnect}>Disconnect</Button> : undefined}>
      {project?.postgres && (
        <Connected title="Connected" lines={[
          ['User', project.postgres.username],
          ['Database', `${project.postgres.dbname} @ ${project.postgres.hostip}:${project.postgres.port}`],
          ['Version', (project.postgres.version || '').split(' on ')[0] || '—'],
        ]} />
      )}
      <Stack spacing={2}>
        <Stack direction={{ xs: 'column', sm: 'row' }} spacing={2}>
          <TextField label="Host" value={f.hostip} onChange={set('hostip')} fullWidth required />
          <TextField label="Port" value={f.port} onChange={set('port')} required sx={{ width: { sm: 120 } }} />
        </Stack>
        <TextField label="Database" value={f.dbname} onChange={set('dbname')} fullWidth required />
        <Stack direction={{ xs: 'column', sm: 'row' }} spacing={2}>
          <TextField label="User name" value={f.username} onChange={set('username')} fullWidth required />
          <PasswordField value={password} onChange={setPassword} />
        </Stack>
        {msg && <Alert severity={msg.ok ? 'success' : 'error'} sx={{ overflowWrap: 'anywhere' }}>{msg.text}</Alert>}
        <Box><Button variant="contained" onClick={connect} disabled={!valid || busy}>{busy ? 'Connecting…' : project?.postgres ? 'Reconnect' : 'Test & connect'}</Button></Box>
      </Stack>
    </SectionCard>
  );
}

export default function ConnectPage() {
  const { project } = useProject();
  const navigate = useNavigate();
  const ready = !!(project?.oracle && project?.postgres);
  return (
    <>
      <PageHeader overline="Step 1" title="Connections" icon={<CableRoundedIcon />}
        subtitle="Passwords are stored encrypted on the migration server, so you don't have to enter them again after a restart."
        actions={<Button variant="contained" endIcon={<ArrowForwardRoundedIcon />} disabled={!ready} onClick={() => navigate('../schema')}>Choose schema</Button>} />
      {ready && <Alert severity="success" sx={{ mb: 3 }} action={<Chip label="Next: choose schema" color="success" onClick={() => navigate('../schema')} />}>Both databases are connected.</Alert>}
      <Box sx={{ display: 'grid', gap: 3, gridTemplateColumns: { xs: '1fr', xl: '1fr 1fr' }, alignItems: 'start' }}>
        <OracleCard />
        <PostgresCard />
      </Box>
      <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 2, color: brand.muted }}>
        The connections belong to this project only; other projects and other users are not affected.
      </Typography>
    </>
  );
}
