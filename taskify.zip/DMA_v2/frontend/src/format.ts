export const fmtInt = (n: number | string | null | undefined) =>
  n === null || n === undefined || n === '' || Number.isNaN(Number(n)) ? '—' : Number(n).toLocaleString();

/** Megabytes to a readable size. */
export function fmtMb(mb: number | string | null | undefined) {
  const v = Number(mb);
  if (!Number.isFinite(v)) return '—';
  if (v >= 1024 * 1024) return `${(v / 1024 / 1024).toFixed(2)} TB`;
  if (v >= 1024) return `${(v / 1024).toFixed(2)} GB`;
  if (v >= 1) return `${v.toFixed(1)} MB`;
  return `${Math.round(v * 1024)} KB`;
}

export function fmtCompact(n: number) {
  if (!Number.isFinite(n)) return '—';
  return Intl.NumberFormat(undefined, { notation: 'compact', maximumFractionDigits: 1 }).format(n);
}

export function fmtDuration(ms: number) {
  if (!Number.isFinite(ms) || ms < 0) return '—';
  const s = Math.round(ms / 1000);
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  if (d) return `${d}d ${h}h ${m}m`;
  if (h) return `${h}h ${m}m`;
  if (m) return `${m}m ${sec}s`;
  return `${sec}s`;
}

export const fmtDate = (iso?: string | null) => (iso ? new Date(iso).toLocaleString() : '—');

export function timeAgo(iso?: string | null) {
  if (!iso) return '—';
  const diff = Date.now() - new Date(iso).getTime();
  if (diff < 60000) return 'just now';
  if (diff < 3600000) return `${Math.floor(diff / 60000)} min ago`;
  if (diff < 86400000) return `${Math.floor(diff / 3600000)} h ago`;
  return `${Math.floor(diff / 86400000)} d ago`;
}

export function fmtBytes(b: number) {
  if (!Number.isFinite(b)) return '—';
  if (b < 1024) return `${b} B`;
  return fmtMb(b / 1048576);
}
