import react from '@vitejs/plugin-react-swc';
import { defineConfig } from 'vite';
import { viteSingleFile } from 'vite-plugin-singlefile';

// https://vitejs.dev/config/
export default defineConfig({
  // Like v1: `npm run build` produces ONE file, dist/index.html (scripts, styles and fonts inlined),
  // so it replaces v1's index.html in the existing nginx folder with no other change.
  plugins: [react(), viteSingleFile()],
  server: {
    port: 5175,
    // Dev: the API runs on its own port.
    proxy: { '/api': { target: process.env.API_TARGET || 'http://localhost:5055', changeOrigin: true } },
  },
});
