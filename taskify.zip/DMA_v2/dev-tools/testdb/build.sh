#!/bin/bash
# Builds the local test database for the migration tool:
#   Oracle  (container ora2pg-studio-oracle-full, FREEPDB1): JAGUAR_APP (schema to migrate), ACMM_REMOTE (DB link target),
#           DMA_MIGRATOR (read-only login for the tool)
#   PostgreSQL (container ora2pg-postgres): database jaguar_target (login dma_target), roles jaguar_app_read / jaguar_app_rw,
#           database acmm_remote (the DB link's remote side)
# Usage: ./build.sh [scale]   scale 1 = about 2.6 GB of Oracle data. Passwords are generated once into ./credentials.env.
set -euo pipefail
cd "$(dirname "$0")"
SCALE="${1:-1}"
ORA=ora2pg-studio-oracle-full
PG=ora2pg-postgres

if [ ! -f credentials.env ]; then
  gen() { echo "$1$(openssl rand -hex 6)"; }
  umask 077
  cat > credentials.env <<EOF
ORACLE_REMOTE_PW=$(gen Rm)
ORACLE_APP_PW=$(gen Jg)
ORACLE_MIGRATOR_PW=$(gen Dm)
PG_TARGET_PW=$(gen Pt)
PG_REMOTE_PW=$(gen Pr)
EOF
fi
# shellcheck disable=SC1091
source credentials.env

step() { echo; echo "=== $(date +%H:%M:%S) $*"; }

docker exec "$ORA" rm -rf /tmp/testdb && docker cp "$PWD" "$ORA":/tmp/testdb
ora() { docker exec "$ORA" bash -lc "cd /tmp/testdb && sqlplus -s $1 @$2 ${3:-} ${4:-} ${5:-}"; }
CS="//localhost:1521/FREEPDB1"

step "Oracle users"
ora "/ as sysdba" 01_users.sql "$ORACLE_REMOTE_PW" "$ORACLE_APP_PW" "$ORACLE_MIGRATOR_PW"
step "Remote schema (ACMM_REMOTE)"
ora "acmm_remote/$ORACLE_REMOTE_PW@$CS" 02_remote.sql
step "JAGUAR_APP schema"
ora "jaguar_app/$ORACLE_APP_PW@$CS" 03_schema.sql "$ORACLE_REMOTE_PW"
step "JAGUAR_APP data (scale $SCALE)"
ora "jaguar_app/$ORACLE_APP_PW@$CS" 04_data.sql "$SCALE"
step "JAGUAR_APP indexes and code"
ora "jaguar_app/$ORACLE_APP_PW@$CS" 05_code.sql

step "PostgreSQL target and remote"
docker cp pg_setup.sql "$PG":/tmp/pg_setup.sql
PGUSER_NAME=$(docker exec "$PG" printenv POSTGRES_USER)
docker exec "$PG" psql -q -U "$PGUSER_NAME" -d postgres -v target_pw="$PG_TARGET_PW" -v remote_pw="$PG_REMOTE_PW" -f /tmp/pg_setup.sql

step "Done"
