-- Test database for the migration tool: users (run as SYSDBA).
-- &1 = ACMM_REMOTE password, &2 = JAGUAR_APP password, &3 = DMA_MIGRATOR password
whenever sqlerror exit failure
set echo off feedback on verify off
alter session set container=FREEPDB1;

begin
  for u in (select username from dba_users where username in ('JAGUAR_APP', 'ACMM_REMOTE', 'DMA_MIGRATOR')) loop
    execute immediate 'drop user ' || u.username || ' cascade';
  end loop;
end;
/

-- The "remote" database reached over a DB link (in the PoC: the ACMM validation database).
create user acmm_remote identified by "&1" default tablespace users quota unlimited on users;
grant create session, create table, create view, create sequence to acmm_remote;

-- The application schema to migrate.
create user jaguar_app identified by "&2" default tablespace users quota unlimited on users;
grant create session, create table, create view, create sequence, create procedure, create trigger,
      create type, create synonym, create materialized view, create database link, create job to jaguar_app;
grant ctxapp to jaguar_app;

-- The account the migration tool connects with: read-only, like a real project.
create user dma_migrator identified by "&3";
grant create session, select any dictionary, select_catalog_role, select any table, select any sequence, flashback any table, execute any type to dma_migrator;

exit
