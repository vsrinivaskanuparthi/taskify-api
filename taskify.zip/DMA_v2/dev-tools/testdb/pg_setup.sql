-- PostgreSQL side of the test (run as the container superuser).
-- :target_pw  password of DMA_TARGET (the login the tool uses)
-- :remote_pw  password of ACMM_READER (the DB link's remote login)
\set ON_ERROR_STOP on

DROP DATABASE IF EXISTS jaguar_target WITH (FORCE);
DROP DATABASE IF EXISTS acmm_remote WITH (FORCE);
DROP ROLE IF EXISTS dma_target;
DROP ROLE IF EXISTS acmm_reader;
DROP ROLE IF EXISTS jaguar_app_read;
DROP ROLE IF EXISTS jaguar_app_rw;

CREATE ROLE dma_target LOGIN PASSWORD :'target_pw';
CREATE ROLE acmm_reader LOGIN PASSWORD :'remote_pw';
-- The application's roles (Settings -> Migration decisions -> Application access).
CREATE ROLE jaguar_app_read NOLOGIN;
CREATE ROLE jaguar_app_rw NOLOGIN;

CREATE DATABASE jaguar_target OWNER dma_target;
CREATE DATABASE acmm_remote OWNER acmm_reader;

-- Target: postgres_fdw is installed by the superuser; the tool's login may create servers with it.
\c jaguar_target
CREATE EXTENSION IF NOT EXISTS postgres_fdw;
GRANT USAGE ON FOREIGN DATA WRAPPER postgres_fdw TO dma_target;

-- The DB link's remote side, already on PostgreSQL (same data as ACMM_REMOTE in Oracle).
\c acmm_remote
SET ROLE acmm_reader;
CREATE SCHEMA acmm_remote;
CREATE TABLE acmm_remote.operator_src (operator_id int PRIMARY KEY, operator_name varchar(60), role_code varchar(10), active smallint);
INSERT INTO acmm_remote.operator_src SELECT g, 'Operator ' || g, (ARRAY['LEAD','TECH','QA'])[g % 3 + 1], CASE WHEN g % 10 = 0 THEN 0 ELSE 1 END FROM generate_series(1, 200) g;
CREATE TABLE acmm_remote.customer_src (customer_code varchar(12) PRIMARY KEY, customer_name varchar(80), country varchar(2));
INSERT INTO acmm_remote.customer_src SELECT 'C' || lpad(g::text, 7, '0'), 'Remote customer ' || g, (ARRAY['FR','DE','ES','GB'])[g % 4 + 1] FROM generate_series(1, 5000) g;
CREATE TABLE acmm_remote.ss10_cin (cin_id int PRIMARY KEY, cin_code varchar(20), valid_from date, valid_to date);
INSERT INTO acmm_remote.ss10_cin SELECT g, 'CIN-' || lpad((g % 400)::text, 4, '0'), date '2024-01-01' + g % 365, date '2026-01-01' + g % 365 FROM generate_series(1, 3000) g;
CREATE VIEW acmm_remote.ss10_view_third AS
  SELECT c.cin_id, c.cin_code, c.valid_from, o.operator_name FROM acmm_remote.ss10_cin c JOIN acmm_remote.operator_src o ON o.operator_id = c.cin_id % 200 + 1;
