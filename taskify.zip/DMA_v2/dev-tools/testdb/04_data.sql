-- JAGUAR_APP data (run as JAGUAR_APP). &1 = scale (1 = about 2.6 GB).
whenever sqlerror exit failure
set echo off feedback on verify off timing on
define scale = &1

insert into plant select level, 'P' || lpad(level, 4, '0'), 'Plant ' || level,
  address_t('Street ' || level, 'City ' || mod(level, 20), lpad(level, 5, '0'), 'FR'), sysdate - level
  from dual connect by level <= 50;

insert into customer_master select level, 'C' || lpad(level, 7, '0'), 'Customer ' || level,
  case mod(level, 3) when 0 then 'AIRLINE' when 1 then 'MRO' else 'OEM' end, case when mod(level, 25) = 0 then 1 else 0 end, sysdate - mod(level, 2000)
  from dual connect by level <= 50000;

insert into station select level, mod(level, 50) + 1, 'Station ' || level, case mod(level, 2) when 0 then 'ASSEMBLY' else 'TEST' end,
  mod(level, 1000), mod(level, 2), mod(level, 120)
  from dual connect by level <= 3000;

insert into calendar_exception select level, mod(level, 3000) + 1, date '2024-01-01' + mod(level, 730),
  mod(level, 2), mod(level + 1, 2), case when mod(level, 7) = 0 then 1 else 0 end, 'Exception ' || level
  from dual connect by level <= 20000;

insert into spare_part (part_id, part_number, in_stock, is_active, qty, unit_price)
  select level, 'PN-' || lpad(level, 8, '0'), mod(level, 10), case when mod(level, 9) = 0 then 'N' else 'Y' end, mod(level, 500), round(mod(level, 9973) / 7, 2)
  from dual connect by level <= 30000;

insert into variable select level, 'VAR_' || level, 'value ' || level, mod(level, 100), case mod(level, 2) when 0 then 'STRING' else 'NUMBER' end
  from dual connect by level <= 2000;

insert into customized_rank select level, mod(level, 3000) + 1, mod(level, 1440), mod(level, 50), round(dbms_random.value(0, 1000), 4), 'Rank ' || level
  from dual connect by level <= 50000;

insert into setting select 'SETTING_' || level, to_clob(rpad('{"key":' || level || ',"data":"', 2000, 'x')) || '"}', sysdate
  from dual connect by level <= 500;

insert into login_info select level, 'user' || level, case when mod(level, 3) = 0 then 'sso=' || level end,
  systimestamp - numtodsinterval(level, 'MINUTE'), numtodsinterval(mod(level, 7200), 'SECOND')
  from dual connect by level <= 5000;

insert into xml_config select level, xmltype('<config id="' || level || '"><station>' || level || '</station><enabled>true</enabled></config>')
  from dual connect by level <= 100;
commit;

-- Plans: a tree (every 10th plan is a root), spread over ~24 monthly interval partitions.
insert /*+ append */ into plan_pe
  select n, case when mod(n, 10) = 1 then null else n - mod(n - 1, 10) end, mod(n, 50000), mod(n, 1440), mod(n, 5) + 1,
         case mod(n, 3) when 0 then 'BASE' when 1 then 'SHIFT' else 'EXTRA' end, round(mod(n, 10000) / 100, 2),
         date '2024-01-01' + mod(n, 700), date '2024-01-01' + mod(n, 700), mod(n, 3000) + 1
    from (select (a.n - 1) * 1000 + b.n n from (select level n from dual connect by level <= 1000 * &scale) a, (select level n from dual connect by level <= 1000) b);
commit;

-- Orders: the big numeric-keyed table (chunked by the tool).
insert /*+ append */ into orders_big
  select n, mod(n, 50000) + 1, mod(n, 50) + 1, date '2022-01-01' + mod(n, 1400),
         case mod(n, 5) when 0 then 'NEW' when 1 then 'PLANNED' when 2 then 'SHIPPED' when 3 then 'INVOICED' else 'CLOSED' end,
         round(mod(n * 7, 100000) / 3, 2), mod(n, 40) + 1, 'Order ' || n || ' for plant ' || (mod(n, 50) + 1)
    from (select (a.n - 1) * 2000 + b.n n from (select level n from dual connect by level <= 3000 * &scale) a, (select level n from dual connect by level <= 2000) b);
commit;

insert /*+ append */ into audit_trail
  select rawtohex(sys_guid()), case mod(n, 4) when 0 then 'INSERT' when 1 then 'UPDATE' when 2 then 'DELETE' else 'LOGIN' end,
         case mod(n, 3) when 0 then 'ORDER' when 1 then 'PLAN' else 'STATION' end, rpad('payload ' || n || ' ', 200, 'abcdefghij'),
         systimestamp - numtodsinterval(mod(n, 5000000), 'SECOND')
    from (select (a.n - 1) * 1000 + b.n n from (select level n from dual connect by level <= 1500 * &scale) a, (select level n from dual connect by level <= 1000) b);
commit;

insert /*+ append */ into event_log
  select systimestamp - numtodsinterval(n, 'SECOND'), case mod(n, 10) when 0 then 'ERROR' when 1 then 'WARN' else 'INFO' end,
         'job_' || mod(n, 30), 'Event ' || n || ' processed in ' || mod(n, 997) || ' ms'
    from (select (a.n - 1) * 1000 + b.n n from (select level n from dual connect by level <= 2000 * &scale) a, (select level n from dual connect by level <= 1000) b);
commit;

insert /*+ append */ into notes
  select n, mod(n * 31, 6000000) + 1, 'Note ' || n || ' about order ' || (mod(n * 31, 6000000) + 1),
         to_clob(rpad('Note ' || n || ': ', 3000, 'lorem ipsum dolor sit amet consectetur adipiscing elit ')), sysdate - mod(n, 900)
    from (select (a.n - 1) * 1000 + b.n n from (select level n from dual connect by level <= 120 * &scale) a, (select level n from dual connect by level <= 1000) b);
commit;

-- Documents: BLOBs of 128 KB, every 500th 1 MB.
declare
  b blob;
  chunk raw(32767);
begin
  chunk := utl_raw.cast_to_raw(dbms_random.string('x', 32767));
  for i in 1 .. 6000 * &scale loop
    insert into documents values (i, mod(i * 997, 6000000) + 1, 'doc_' || i || '.pdf', 'application/pdf', empty_blob(), sysdate - mod(i, 900))
      returning content into b;
    for k in 1 .. case when mod(i, 500) = 0 then 32 else 4 end loop
      dbms_lob.writeappend(b, utl_raw.length(chunk), chunk);
    end loop;
    if mod(i, 200) = 0 then
      commit;
      chunk := utl_raw.cast_to_raw(dbms_random.string('x', 32767));
    end if;
  end loop;
  commit;
end;
/

exit
