-- Remote side of the DB link (run as ACMM_REMOTE).
whenever sqlerror exit failure
set echo off feedback on verify off

create table operator_src (operator_id number(6) primary key, operator_name varchar2(60), role_code varchar2(10), active number(1));
insert into operator_src select level, 'Operator ' || level, case mod(level, 3) when 0 then 'LEAD' when 1 then 'TECH' else 'QA' end, case when mod(level, 10) = 0 then 0 else 1 end
  from dual connect by level <= 200;

create table customer_src (customer_code varchar2(12) primary key, customer_name varchar2(80), country varchar2(2));
insert into customer_src select 'C' || lpad(level, 7, '0'), 'Remote customer ' || level, case mod(level, 4) when 0 then 'FR' when 1 then 'DE' when 2 then 'ES' else 'GB' end
  from dual connect by level <= 5000;

create table ss10_cin (cin_id number primary key, cin_code varchar2(20), valid_from date, valid_to date);
insert into ss10_cin select level, 'CIN-' || lpad(mod(level, 400), 4, '0'), date '2024-01-01' + mod(level, 365), date '2026-01-01' + mod(level, 365)
  from dual connect by level <= 3000;

create view ss10_view_third as
  select c.cin_id, c.cin_code, c.valid_from, o.operator_name
    from ss10_cin c join operator_src o on o.operator_id = mod(c.cin_id, 200) + 1;

commit;
exit
