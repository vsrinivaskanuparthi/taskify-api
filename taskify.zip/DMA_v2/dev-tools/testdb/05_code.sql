-- JAGUAR_APP indexes, sequences, code objects (run as JAGUAR_APP, after the data).
-- Covers: package with state, autonomous transaction, pipelined function, CONNECT BY, BULK COLLECT/FORALL,
-- dynamic SQL, MERGE, (+) joins; standalone functions/procedures (one INVALID); row, compound,
-- INSTEAD OF and schema DDL triggers; views over a DB link and over a synonym on a DB link; complete
-- and fast-refresh materialized views; a scheduler job; bitmap, function-based, reverse and Oracle Text indexes.
whenever sqlerror exit failure
set echo off feedback on verify off timing on

create sequence seq_officialise start with 1000;
create sequence order_seq start with 20000001 cache 100;
create sequence plan_seq start with 3000001 cache 100;
create sequence doc_seq start with 100001;

create index ix_orders_customer on orders_big (customer_id) parallel 2;
alter index ix_orders_customer noparallel;
create bitmap index bx_orders_status on orders_big (status);
create index ix_orders_date on orders_big (order_date);
create index ix_station_upper_name on station (upper(station_name));
create index ix_audit_entity on audit_trail (entity) reverse;
create index ix_plan_pe_date on plan_pe (plan_date) local;
create index ix_plan_pe_parent on plan_pe (parent_plan_id);
create index ix_calendar_station on calendar_exception (station_id, exception_date);
create index ix_notes_title_txt on notes (title) indextype is ctxsys.context;
alter table plan_pe add constraint fk_plan_station foreign key (station_id) references station;
alter table customized_rank add constraint uq_rank_station_pos unique (station_id, rank_id);

create synonym ss10_third for ss10_view_third@acmm_link;

create or replace view operator as
  select operator_id, operator_name, role_code from operator_src@acmm_link where active = 1;

create or replace view customer as
  select c.customer_id, c.customer_name, r.country
    from customer_master c left join customer_src@acmm_link r on r.customer_code = c.customer_code;

create or replace view comac as select * from ss10_third;

create or replace view station_v as
  select s.station_id, s.station_name, p.plant_name, s.is_shown_in_curve
    from station s join plant p on p.plant_id = s.plant_id;

create or replace view v_order_status as
  select status, count(*) cnt, (select sysdate from dual) as_of from orders_big group by status;

create materialized view third_mv build immediate refresh complete on demand as select * from ss10_third;
create materialized view third_mv2 build immediate refresh complete on demand as
  select cin_code, count(*) cnt from third_mv group by cin_code;
create materialized view log on station with primary key;
create materialized view station_fast_mv build immediate refresh fast on demand as
  select station_id, station_name, plant_id from station;

create or replace package pb18_planning as
  g_last_plan_id number;
  procedure log_msg(p_msg varchar2);
  function duplicate_plan(p_plan_id number) return number;
  function plan_tree(p_root number) return number_tab pipelined;
  procedure recalc_station(p_station_id number);
  function station_rank_total(p_station_id number) return number;
end pb18_planning;
/

create or replace package body pb18_planning as
  procedure log_msg(p_msg varchar2) is
    pragma autonomous_transaction;
  begin
    insert into event_log (log_level, source, message) values ('INFO', 'PB18', substr(p_msg, 1, 400));
    commit;
  end;

  function duplicate_plan(p_plan_id number) return number is
    v_new number;
  begin
    v_new := plan_seq.nextval;
    insert into plan_pe (plan_id, parent_plan_id, planning_event_id, "OFFSET", version, "TYPE", percent, principle_date, plan_date, station_id)
      select v_new, parent_plan_id, planning_event_id, "OFFSET", version + 1, "TYPE", percent, principle_date, plan_date, station_id
        from plan_pe where plan_id = p_plan_id;
    g_last_plan_id := v_new;
    log_msg('plan ' || p_plan_id || ' duplicated to ' || v_new);
    return v_new;
  end;

  function plan_tree(p_root number) return number_tab pipelined is
  begin
    for r in (select plan_id from plan_pe start with plan_id = p_root connect by prior plan_id = parent_plan_id) loop
      pipe row (r.plan_id);
    end loop;
    return;
  end;

  procedure recalc_station(p_station_id number) is
    type t_rank is table of customized_rank%rowtype;
    l_ranks t_rank;
    v_sql varchar2(400);
  begin
    select * bulk collect into l_ranks from customized_rank where station_id = p_station_id and rownum <= 1000;
    forall i in 1 .. l_ranks.count
      update customized_rank set "POSITION" = l_ranks(i)."POSITION" + 1 where rank_id = l_ranks(i).rank_id;
    v_sql := 'update station set "VALUE" = :1 where station_id = :2';
    execute immediate v_sql using l_ranks.count, p_station_id;
    merge into spare_part sp using (select p_station_id id from dual) s on (sp.part_id = s.id)
      when matched then update set sp.qty = nvl(sp.qty, 0) + 1;
    dbms_output.put_line('recalculated ' || case l_ranks.count when 0 then 'nothing' else l_ranks.count || ' ranks' end);
  end;

  function station_rank_total(p_station_id number) return number is
    v number;
  begin
    select nvl(sum(r."VALUE"), 0) into v
      from station s, customized_rank r
     where r.station_id(+) = s.station_id and s.station_id = p_station_id;
    return v;
  end;
end pb18_planning;
/

create or replace function annual_order_total(p_customer_id number) return number is
  v number;
begin
  select nvl(sum(amount), 0) into v from orders_big
   where customer_id = p_customer_id and order_date >= add_months(trunc(sysdate, 'YYYY'), -12);
  return v;
end;
/

-- Compares NUMBER(1) flags with 1: breaks if these columns become boolean and the code is not converted too.
create or replace function pb18_func_pcalweek_exception(p_station_id number, p_date date) return number is
  v number;
begin
  select count(*) into v from calendar_exception
   where station_id = p_station_id and exception_date = trunc(p_date)
     and (holiday_shift_1 = 1 or holiday_shift_2 = 1 or holiday_shift_3 = 1);
  return v;
end;
/

create or replace procedure adjust_stock(p_part_id number, p_delta number) is
begin
  update spare_part set qty = qty + p_delta, in_stock = case when qty + p_delta > 0 then least(9, qty + p_delta) else 0 end
   where part_id = p_part_id;
  if sql%rowcount = 0 then
    raise_application_error(-20001, 'part ' || p_part_id || ' not found');
  end if;
end;
/

begin
  dbms_scheduler.create_job(job_name => 'NIGHTLY_RECALC', job_type => 'PLSQL_BLOCK',
    job_action => 'begin pb18_planning.recalc_station(1); end;', repeat_interval => 'FREQ=DAILY;BYHOUR=2', enabled => false);
end;
/

create or replace trigger trg_plan_pe_bi before insert on plan_pe for each row
begin
  if :new.plan_id is null then
    :new.plan_id := plan_seq.nextval;
  end if;
  :new.version := nvl(:new.version, 1);
end;
/

create or replace trigger trg_orders_compound for update of status on orders_big compound trigger
  type t_ids is table of number index by pls_integer;
  g_ids t_ids;
  after each row is
  begin
    g_ids(g_ids.count + 1) := :new.order_id;
  end after each row;
  after statement is
  begin
    pb18_planning.log_msg('orders updated: ' || g_ids.count);
  end after statement;
end trg_orders_compound;
/

create or replace trigger trg_station_v_io instead of update on station_v for each row
begin
  update station set station_name = :new.station_name, is_shown_in_curve = :new.is_shown_in_curve
   where station_id = :old.station_id;
end;
/

-- INVALID on purpose: the table it writes to does not exist (like FILL_SHARED_SCENARIO_DATA in the PoC).
whenever sqlerror continue
create or replace procedure fill_shared_scenario_data(p_plan_id number, p_station_id number, p_offset number) is
begin
  insert into shared_scenario (plan_id, station_id, offset_val) values (p_plan_id, p_station_id, p_offset);
end;
/
whenever sqlerror exit failure

create or replace trigger trg_schema_ddl after ddl on schema
begin
  null;
end;
/

exec dbms_stats.gather_schema_stats('JAGUAR_APP', degree => 2, cascade => true);

select object_type, status, count(*) from user_objects group by object_type, status order by 1, 2;
select round(sum(bytes) / 1024 / 1024 / 1024, 2) as gb from user_segments;
exit
