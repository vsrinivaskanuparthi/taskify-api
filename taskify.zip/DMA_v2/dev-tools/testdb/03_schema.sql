-- JAGUAR_APP tables, types, sequences, DB link (run as JAGUAR_APP).
-- Mirrors what made the Jaguar PoC hard: reserved-word columns (OFFSET, TYPE, VALUE, POSITION, a VARIABLE
-- table), NUMBER(1) flags (some booleans, one not), NUMBER without precision, interval partitioning,
-- LOBs, an object type column, a global temporary table, a virtual column, a large table keyed by a GUID.
-- &1 = ACMM_REMOTE password (for the DB link)
whenever sqlerror exit failure
set echo off feedback on verify off

create database link acmm_link connect to acmm_remote identified by "&1" using '//localhost:1521/FREEPDB1';

create or replace type address_t as object (street varchar2(80), city varchar2(40), zip varchar2(10), country varchar2(2));
/
create or replace type number_tab as table of number;
/

create table plant (
  plant_id number(6) primary key, plant_code varchar2(10) not null unique, plant_name varchar2(80),
  address address_t, created_on date default sysdate);

create table customer_master (
  customer_id number(10) primary key, customer_code varchar2(12) not null, customer_name varchar2(100),
  "TYPE" varchar2(10), is_vip number(1) default 0 check (is_vip in (0, 1)), created_on date);

create table station (
  station_id number(8) primary key, plant_id number(6) not null references plant, station_name varchar2(60),
  "TYPE" varchar2(20), "VALUE" number, is_shown_in_curve number(1) default 0 not null, "POSITION" number(4));

create table calendar_exception (
  exception_id number primary key, station_id number(8) references station, exception_date date not null,
  holiday_shift_1 number(1) default 0, holiday_shift_2 number(1) default 0, holiday_shift_3 number(1) default 0,
  reason varchar2(100));

-- in_stock is NUMBER(1) but holds 0..9: NOT a boolean (the SPARE_PART trap).
create table spare_part (
  part_id number(10) primary key, part_number varchar2(30) not null, in_stock number(1) default 0,
  is_active char(1) default 'Y' check (is_active in ('Y', 'N')), qty number(8), unit_price number(12, 2),
  total_value as (qty * unit_price) virtual);

create table variable (variable_id number primary key, "NAME" varchar2(60), "VALUE" varchar2(200), "POSITION" number(4), "TYPE" varchar2(20));

create table customized_rank (
  rank_id number primary key, station_id number(8) references station, "OFFSET" number(6), "POSITION" number(4),
  "VALUE" number(12, 4), rank_label varchar2(40));

create table plan_pe (
  plan_id number primary key, parent_plan_id number, planning_event_id number, "OFFSET" number, version number(3) default 1,
  "TYPE" varchar2(10), percent number(5, 2), principle_date date, plan_date date not null, station_id number(8))
  partition by range (plan_date) interval (numtoyminterval(1, 'MONTH'))
  (partition p_start values less than (date '2024-01-01'));

create table orders_big (
  order_id number primary key, customer_id number(10) not null references customer_master, plant_id number(6) references plant,
  order_date date not null, status varchar2(12) not null, amount number(12, 2), qty number, description varchar2(80));

-- Large table without a numeric key: cannot be chunked.
create table audit_trail (
  audit_id varchar2(32) primary key, event_type varchar2(40), entity varchar2(40), payload varchar2(240),
  created_at timestamp(6) default systimestamp);

-- No primary key at all.
create table event_log (log_ts timestamp default systimestamp, log_level varchar2(10), source varchar2(60), message varchar2(400));

create table documents (
  doc_id number primary key, order_id number, file_name varchar2(120), mime_type varchar2(60), content blob, uploaded_at date)
  lob (content) store as securefile;

create table notes (note_id number primary key, order_id number, title varchar2(200), body clob, created_at date);

create table setting (setting_key varchar2(60) primary key, "VALUE" clob, updated_at date);

create table login_info (
  login_id number primary key, user_name varchar2(30), login_info_additional varchar2(200),
  last_login timestamp with local time zone, session_length interval day to second);

create table xml_config (config_id number primary key, config xmltype);

create global temporary table tmp_calc (calc_id number, result number) on commit delete rows;

comment on table plan_pe is 'Production plans (one row per plan version)';
comment on column plan_pe."OFFSET" is 'Offset in minutes from the planning event';
comment on table spare_part is 'Spare parts; IN_STOCK is a count 0-9, not a flag';

exit
