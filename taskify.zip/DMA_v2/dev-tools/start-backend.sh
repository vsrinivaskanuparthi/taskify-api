#!/bin/bash
# Starts the dma-v2 backend on this Mac with the local dev tools on PATH:
# ora2pg (Docker wrapper), psql (Homebrew libpq), GNU bash 5 and GNU sed.
DIR="$(cd "$(dirname "$0")" && pwd)"
export PATH="$DIR:/opt/homebrew/opt/libpq/bin:/opt/homebrew/opt/gnu-sed/libexec/gnubin:/opt/homebrew/bin:$PATH"
export MIGRATION_STAGING_DIR="${MIGRATION_STAGING_DIR:-/Users/Shri/ora2pg_staging_v2}"
cd "$DIR/../backend" && exec node server.js
