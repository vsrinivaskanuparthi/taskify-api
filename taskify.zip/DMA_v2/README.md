# Database Migration Accelerator v2

> **Upgrading from v1?** Follow [deploy/UPGRADE_V1_TO_V2.md](deploy/UPGRADE_V1_TO_V2.md).

The same application as v1, on the same technology: **Node.js + Express (JavaScript)** for the API,
**React + Vite + TypeScript + MUI** for the UI, **ora2pg + psql** for the migration,
`node-oracledb`, `pg`, `node-cache` and `winston` as before. No new frameworks, no new services
(no Redis, no extra database). The flow is unchanged: create a project, connect Oracle and
PostgreSQL, pick the schema, take the snapshot, migrate, validate.

## Run it

**Windows and Red Hat:** see [deploy/HOW_TO_RUN_AND_DEPLOY.md](deploy/HOW_TO_RUN_AND_DEPLOY.md) (settings: `backend/.env.windows`, `backend/.env.redhat`).


```bash
# API (port from backend/.env, default 5000)
cd backend && npm install && node server.js

# UI in development (proxies /api to the API)
cd frontend && npm install && npm run dev

# UI in production: build once, then the API serves it on the same port
cd frontend && npm run build        # creates frontend/dist, picked up by server.js
```

`ora2pg` and `psql` must be on the server's PATH (or set `ORA2PG_BIN` / `PSQL_BIN`).
For direct loading ora2pg needs the `DBD::Pg` Perl module (the pre-flight check tells you).
Without it, choose **Through files** in the run settings.

On this Mac the dev setup is `dev-tools/start-backend.sh` (ora2pg runs from a Docker image).
On the Red Hat server follow `deploy/RHEL_INSTALL.md` (systemd unit in `deploy/dma.service`).

### backend/.env

| Variable | Meaning |
|---|---|
| `PORT` | API port |
| `MIGRATION_STAGING_DIR` | Folder for projects, snapshots, runs and logs |
| `ORACLE_CLIENT_LIB_DIR` | Instant Client folder for Thick mode; empty = Thin mode |
| `PG_SSL` | `false` for a PostgreSQL without SSL |
| `SECRET_KEY` | Key used to encrypt saved passwords (if empty a random key file is created in the staging folder) |
| `CORS_ORIGIN` | Comma-separated UI origins when the UI is served from another host |
| `LOAD_MODE`, `PARALLEL_TABLES`, `HUGE_TABLE_ROWS`, `CHUNK_ROWS`, `ORACLE_COPIES`, `PG_JOBS`, `MAX_ATTEMPTS`, `DATA_LIMIT`, `BLOB_LIMIT`, `DDL_PARALLEL`, `MAINTENANCE_WORK_MEM`, `VERIFY_ROW_COUNTS` | Engine defaults; each can be changed per run in the UI |
| `ORA2PG_ORACLE_HOST`, `ORA2PG_PG_HOST` (+ `_PORT`) | Dev only: host that ora2pg uses when it runs in Docker |

Corporate SSO: add your passport/session middleware in `server.js` where the comment says so.

## What changed from v1, and why

### Projects (multi-user)
- Everything is scoped by project in the URL (`/api/projects/:name/...`). v1 kept one global
  "selected project / schema / connection" in the cache, so two users overwrote each other.
- Each project stores its connections (passwords AES-256-GCM encrypted), selected schema and
  snapshot on disk under `MIGRATION_STAGING_DIR/<project>/`. A restart loses nothing; pages can
  be reloaded at any time.
- One Oracle pool and one PostgreSQL pool per project.

### Snapshot
- The same 18 metadata queries, plus "tables with LOB columns". They run in the background (4 at a
  time) with live progress, and the result is saved, so the assessment opens instantly afterwards.
- Table size now includes LOB segments (v1 counted only the table segment, so LOB-heavy schemas
  looked much smaller). Recycle-bin, Oracle Text (`DR$…`) and materialized-view tables are left
  out, as ora2pg leaves them out.

### Migration engine (`services/migrate.js`): built for 1 TB
| v1 | v2 |
|---|---|
| Every table exported to a `.sql` file, then loaded with psql (needs the full schema size in free disk, reads everything twice) | ora2pg streams rows straight into PostgreSQL (`--pg_dsn`). No data files. File mode is still available and deletes each file once it is loaded |
| One table at a time | `PARALLEL_TABLES` tables at once, biggest first; huge tables use several Oracle readers (`-J`) and PostgreSQL writers (`-j`); LOB tables use small batches (`BLOB_LIMIT`) to keep memory bounded |
| One shared `ora2pg.conf` rewritten per table (no parallelism possible) | One config per run; the table is passed on the command line |
| Shell command strings with passwords inside | Commands run without a shell, with arguments as a list; passwords through env / a 0600 config file |
| A failed step was logged and the run was still reported COMPLETED | Each table has its own status, attempts, rows and log. Failures retry automatically (`MAX_ATTEMPTS`); the target table is truncated first, so a retry never duplicates rows |
| No verification during the run | After loading, every table's exact row count is compared in Oracle and PostgreSQL; a mismatch fails the table and it is reloaded |
| Indexes and FKs mixed with the load | Data first, then constraints and indexes (in parallel, with `maintenance_work_mem`), then foreign keys |
| Sequences not reset | Sequence values are exported from Oracle after the load and applied |
| A server restart lost the run | The run state is saved continuously (`runs/<id>/state.json`). After a restart the run shows INTERRUPTED, leftover ora2pg/psql processes are stopped, and **Resume** continues with only the unfinished work |
| One global `<SCHEMA>_MasterLogfile.log` | Per run: `master.log`, `error.log`, `success.log`, plus one log per table, viewable in the UI |

Phases: prepare → export DDL → create schema/types/sequences/tables → load data → constraints &
indexes → foreign keys → sequence values → ANALYZE. Views, functions, procedures, packages,
triggers, grants, DB links and synonyms are exported to the run folder for the manual
conversion, as in v1. They are not applied automatically.

### Huge tables: chunked loading
A huge table with a single-column numeric primary key is split into PK ranges of `CHUNK_ROWS`
rows (default 5,000,000).
- **Loading:** each chunk is a separate ora2pg run (`-W "PK >= lo AND PK <= hi"`). Several chunks load at once.
- **Verification:** every chunk is checked against an Oracle count of its range.
- **Failure or crash:** a failed or interrupted chunk is deleted and reloaded on its own. Chunks already done are never reloaded.
- **Snapshot too old:** short Oracle queries avoid ORA-01555 on long reads.
- **No numeric PK:** tables without one load in one piece with parallel readers (`-J`).

### Code objects & GenAI (Code objects page)
1. **Export & build zip:** ora2pg exports views, materialized views, functions, procedures, packages, triggers, types, DB links, synonyms and grants. Where ora2pg supports it, each object goes to its own file. Everything is zipped as `<SCHEMA>_genai_candidates_<timestamp>.zip`, with `CONVERSION_GUIDE.md` and a manifest.
2. **Convert with your GenAI assistant**, keeping the folders (`packages/`, `procedures/`, `functions/`, `views/`, …).
3. **Upload the converted zip.**
   - The structure is checked; unknown files are listed and ignored.
   - Entries that try to escape the folder (`../`) are rejected.
4. **Apply:**
   - **When:** when a migration starts, the app asks whether converted code is ready and which package to apply, after data, keys and sequences. You can also press **Apply now** at any time.
   - **Order:** files run in dependency order (types → DB links → functions → procedures → packages → views → materialized views → triggers → synonyms → grants).
   - **Transactions:** each file runs in its own transaction.
   - **Retries:** a file that needs an object not created yet is retried in a later pass.
   - **Results:** shown per file.

### DB links
PostgreSQL has no DB links. Each Oracle DB link (read by the snapshot from `DBA_DB_LINKS`, with
how many objects use it) is mapped to one of:
- `postgres_fdw`: the remote database is, or will be, on PostgreSQL.
- `oracle_fdw`: the remote database stays on Oracle.
- Skip.

When the converted code is applied, the engine:
1. Creates the foreign server and the user mapping (passwords encrypted at rest, never left on disk).
2. Creates a local schema `link_<name>`.
3. Runs `IMPORT FOREIGN SCHEMA` for the remote tables.

Converted code then uses `link_<name>.table` instead of `table@LINK`. This rule is also in the conversion guide.

### Settings (left menu → Settings)
Per project. Each run copies the base `ora2pg.conf` and applies them:
- **Naming:** target schema name, preserve case, quoting of reserved words.
- **Data types:** numeric type mapping, `DEFAULT_NUMERIC`, `DATA_TYPE` / `MODIFY_TYPE` overrides, boolean columns.
- **Other ora2pg options:** empty-string handling, comments, invalid objects, skipping constraint types, PostgreSQL version, encodings.
- **Extra directives:** free `KEY value` lines (engine-managed keys such as connections, output and parallelism are rejected).
- **LOB storage:**
  - BLOB → `bytea` (default).
  - BLOB → large object (`oid`): loaded as bytea, then converted with `lo_from_bytea`, so the v1 `lo_import` scripts aren't needed. Oracle Text indexes then use v1's `fts_oid.sh`.
  - CLOB always becomes `text`.
- **Engine defaults** for the Migrate page.
- **Preview ora2pg.conf:** shows the exact config the next run uses, with passwords masked.

### Query review (snapshot and validation)
- **Oracle:**
  - `DBA_*` views replace `ALL_*`. They have no per-row privilege checks, which is much faster on large dictionaries.
  - Owner-correct joins for FKs and Oracle Text indexes.
  - `DISTINCT` where rows were duplicated per column.
  - Oracle Text (`DR$`) and materialized-view tables are excluded from key and index checks.
  - The reserved-word scan covers only the selected schema (v1 scanned every schema), using the real PostgreSQL reserved list (v1's had broken entries).
- **PostgreSQL:** the comparisons use `pg_catalog` instead of `information_schema`, which is slow on big catalogs. Debug output removed.
- **Row counts:** one row per snapshot table, with a source:
  - "verified at load": exact counts from the run, merged across all runs of the schema.
  - "counted now": the table exists in PostgreSQL but no run loaded it.
  - "not migrated".

### Live migration status
- No more `setInterval` polling. The browser keeps one **Server-Sent Events** connection per
  project (`/api/projects/:name/events`) and the server pushes run status, phase progress,
  per-table rows/speed and log lines as they happen. It reconnects by itself and works through
  proxies (heartbeat every 20 s).
- The monitor shows overall progress (weighted by table size), elapsed time, ETA, rows/s, each
  phase with its timing, a filterable table board (loading / waiting / done / failed) with
  progress bars, retry counts and a ✓ when Oracle and PostgreSQL counts match, the activity feed,
  failed DDL statements, and buttons for Cancel, Resume / Retry failed, logs and validation.

### UI
- MUI with an Airbus-blue enterprise theme (no `@airbus` packages). There is a left side menu as in v1 (collapsible, remembered), a top bar with breadcrumbs, and bundled Inter / Plus Jakarta Sans fonts (no Google Fonts calls from the corporate network). Layout bugs from
  v1 (text running out of cards, labels running into values, unformatted sizes) are gone: cards
  wrap or truncate with a tooltip, and sizes are formatted (KB/MB/GB/TB).
- Assessment: KPI cards, object-type chart, largest tables, findings (no PK, stale statistics,
  reserved words, LOBs, duplicate sequences, code objects), an estimate that shows how each number
  is derived (adjustable speed and parallelism), and the v1 tabs (tables, reserved words with
  rename, duplicate sequences, FK dependencies).
- v1 bugs fixed on the way: missing `/schemas`, `/sequence` and `/validforeign` endpoints;
  reserved-word renames posted a body the API ignored; validation cached forever; validation
  compared exact PostgreSQL counts with Oracle *statistics*; SID vs service name in the ora2pg
  DSN; `ALTER SCHEMA … OWNER` failures; `FDW_SERVER` silently switching data copy to oracle_fdw.

## Fixes from the full end-to-end test (Nov 1)

A full run of the 3 GB test schema (`dev-tools/testdb`, every object type) found and fixed:

- **Partitioned tables**: partitions are exported (`-t PARTITION`) and created after the tables, a DEFAULT
  partition catches periods Oracle INTERVAL partitioning had not created yet, data is loaded through the parent
  (`DISABLE_PARTITION 1` in data configs), and tables are emptied with `TRUNCATE` (not `ONLY`, refused on
  partitioned tables). PLAN_PE: 1,000,000 rows, 24 partitions, verified.
- **Object-type columns** (e.g. ADDRESS_T): ora2pg writes them in a format PostgreSQL misreads and exports every
  VARCHAR2 attribute with the last attribute's length. Such tables are read by the engine (node-oracledb) and
  written as composite literals; attribute lengths are corrected from `DBA_TYPE_ATTRS` (also on resume). The
  migration user needs `EXECUTE ANY TYPE` (pre-flight check "object types").
- **LOB speed**: LOBs are fetched inline when the largest one is ≤ 16 MB (`USE_LOB_LOCATOR 0`, LONGREADLEN sized
  to it, batch sized to 128 MB); bigger ones keep locators. LOB tables over 1 GB are chunked. NOTES (1.1 GB of
  CLOBs): ~12 min → 2 min 13 s on this Mac.
- **Bitmap indexes** are created as btree (`BITMAP_AS_GIN 0`): GIN on varchar needs the btree_gin extension.
- **Not tables**: global temporary tables and materialized view log tables (`MLOG$_…`) are left out of the
  snapshot and of runs.
- **Live updates** survive server restarts and proxies that keep a dead stream open: the server pings every 15 s,
  the browser replaces a silent stream after 45 s, reloads its data on reconnect, and stops for deleted projects.

## Robustness for very large migrations (P1)

- **ora2pg 24 and 25.** The run detects the version (`ora2pg --version`, kept in the run state): `--no_start_scn` is only passed to 25, and the analysis reads ora2pg's text report when its JSON is missing or invalid (24.x). See `utils/ora2pgVersion.js`.
- **Consistent snapshot.** ora2pg 25 reads data `AS OF SCN` by default (24 when given `--scn`, which the app always passes when it has FLASHBACK), which needs FLASHBACK. With it, the run captures one
  SCN and passes `--scn` to every table, chunk, retry and resume; Oracle row counts and checksums use the same SCN.
  Without it the engine uses `--no_start_scn` (current data, application must be stopped) and says so. Pre-flight
  check "snapshot".
- **Chunk any big table.** Tables with ≥ *Huge table from* rows **or** ≥ *Chunk tables bigger than (MB)* (LOB tables)
  are split: key ranges on a single numeric primary key, otherwise **ROWID ranges** built from `DBA_EXTENTS` (GUID
  keys, no key). ROWID chunks always go through a per-chunk file loaded in one transaction, so a failed chunk leaves
  nothing behind. Each chunk is verified against Oracle's count of its range.
- **Hung-load watchdog.** An ora2pg process with no output for *Stop a hung load after (min)* (default 20) is stopped
  and retried; for chunked tables only the hung chunks.
- **Reusable export files.** Through files: ora2pg writes one `BEGIN … COMMIT` file per table/chunk plus a
  `.done.json` marker. If the load fails, the file is kept and the retry re-imports it without reading Oracle again.
  Files are only reused for the same snapshot and the same migration decisions.
- **Export only.** Load mode *Export only* exports and verifies every table into files and ends as `EXPORTED`;
  *Import exported files* on the run loads them (same run, same SCN) and then runs indexes, keys, sequences, code.
- **Data checksums.** After the row count, per column: `SUM(number)`, `SUM(LENGTH(string))`, `SUM(LOB length)` on
  both sides (CHAR, dates and floats excluded). A difference fails the table at once with the column and both values
  (e.g. decimals rounded by a narrower type), because reloading cannot fix a mapping problem.
- **Errors that retrying cannot fix** (invalid input syntax, out of range, too long, constraint violations, checksum
  differences) fail the table immediately with what to change, instead of retrying 3 times.
- **Decisions guard.** Each run stores a fingerprint of the migration decisions. If they change, Resume is refused
  (409): start a new run, which rebuilds the tables with the new mapping.

Tested on the local test schema (`dev-tools/testdb`): export-only → import with kept-file re-import; ROWID chunks
(1.5M-row GUID table, 2M-row table without key); Oracle container frozen for 80 s mid-load (watchdog → only the hung
chunks reloaded); a `numeric(12,2)` override caught by checksums with equal row counts; NUMBER(1) holding 0–9 marked
boolean rejected with a clear message; Resume refused after a decision change.

## Lessons from the Jaguar PoC (docs/MIGRATION_LESSONS.md)

The PoC team chat was reviewed end to end; what it taught is now built in:

- **Settings → Migration decisions** replaces the long option list: 6 decisions to agree with the application team
  before the first run (name case, reserved-word columns, NUMBER mapping, boolean columns, LOBs, target schema &
  application access), plus who agreed and when. Everything else is under *Advanced*. Changing a structural decision
  after a migration shows a "rebuild the target" warning.
- **Reserved-word columns are kept and quoted** by default (`USE_RESERVED_WORDS 1`): renames (offset_value / _val)
  broke the application.
- **Application access**: read-only / read-write roles get schema, table, sequence and function grants (plus default
  privileges) in the finalize phase and after code is applied; DB link foreign servers get USAGE and a user mapping
  per role; optional `dual` view.
- **GenAI conversion guide** now carries the decisions: case, quoted reserved words, renames, number mapping, the
  boolean column list, LOBs, DUAL.
- **Analysis** lists boolean candidates (NUMBER(1), CHAR(1)); Settings picks from them.
- **Validation → Code objects**: every Oracle view, materialized view, function, procedure, trigger, type and
  package routine is looked up by name in PostgreSQL. All validation checks now use the configured target schema.

## Migration analysis report (Analysis report page)

`POST /api/projects/:p/analysis` runs in the background (progress over SSE, event `analysis`):

1. **ora2pg `SHOW_REPORT --estimate_cost`**: JSON for the findings, plus ora2pg's own HTML report.
2. **Oracle dictionary checks** (`queries/oracle/getMigrationComplexity.js`, all `DBA_*`, owner-filtered, each check independent):
   data types, risky columns (LONG, BFILE, XMLTYPE, SDO_GEOMETRY, object types, ROWID, NUMBER without precision),
   virtual columns, GTT/IOT, partitioning (INTERVAL/REFERENCE), special indexes, primary-key shape (chunkable or not),
   invalid objects, one pass over `DBA_SOURCE` for risky PL/SQL features (autonomous transactions, UTL_FILE/HTTP/SMTP,
   DBMS_AQ, DBMS_SCHEDULER, dynamic SQL, CONNECT BY, BULK COLLECT, PIPELINED, MERGE…), triggers, jobs, mviews,
   cross-schema dependencies, synonyms, DB links, character set.
3. **Findings** (`services/analysis.js`): severity, affected objects, how the tool handles it, recommended action;
   readiness score, load-time estimate (measured speed of earlier runs ≥ 1 GB, plus 15/40/100 MB/s), target disk, checklist.

Saved in `<project>/analysis/<id>/` as `report.json`, `analysis_report.html` (self-contained, printable) and `ora2pg_report.html`.

## Delete project

Project card (bin icon) or Settings → Danger zone. Typing the project name confirms it. The server removes
`<STAGING>/<project>` recursively (same as `rm -rf`, but with `fs.rm`: no shell, path must be a direct child of the
staging folder). Refused while a run, snapshot, code export/apply or analysis is running. Oracle and PostgreSQL are
not touched. If ora2pg ever ran as another OS user (e.g. root), the error says to remove leftovers with `sudo rm -rf`.

## Large-run safety (items 1–5)

- **Pre-flight capacity checks** (`services/preflight.js`, `POST /runs/preflight`): estimate, snapshot vs Oracle undo
  (`V$PARAMETER`, `V$UNDOSTAT`, undo tablespace), staging disk for the load mode, PostgreSQL connections, `max_wal_size` /
  `checkpoint_timeout`, space needed, replicas, Oracle `PROCESSES`, network round trip and throughput. `block` checks
  also stop `POST /runs` on the server.
- **Snapshot switch** (`options.snapshot` on/off). ORA-01555 during a load is not retried (same SCN) and the run page
  offers *Resume without snapshot*; `chooseSnapshot()` runs again on every resume.
- **Bulk-load mode:** autovacuum paused per table during its load (`bulkPrepare` / `bulkFinish`), `synchronous_commit=off`
  for psql loads (ora2pg already does it), optional `bulkLoad: 'unlogged'`: plain tables are `SET UNLOGGED` on the empty
  table and `SET LOGGED` after verification, before the table is marked done. Partitioned tables stay logged.
  `phase_finalize` re-checks that nothing is left unlogged.
- **Foreign keys** `ADD ... NOT VALID`, then `VALIDATE CONSTRAINT` in parallel (`phase_fkeys`). Mismatching keys stay
  NOT VALID and are reported.
- **Notifications** (`services/notify.js`): email (nodemailer, `SMTP_*` in .env) and Google Chat (cardsV2 message to a
  space's incoming webhook, one thread per run, URL stored encrypted). Start / attention (grouped, max one per 10 min) / finish.

## Tuning for a 1 TB schema
- **Server running ora2pg**: 2 vCPU per parallel table plus 2 spare; RAM roughly 2 GB per parallel table, more for LOB tables.
- **Start with** `PARALLEL_TABLES=4`, `ORACLE_COPIES=4`, `PG_JOBS=4`, then raise them while watching rows/s on the monitor and the load on both databases.
- **Target PostgreSQL during the load:**
  - Raise `max_wal_size` (for example 16 GB or more) and `checkpoint_timeout` (30 min).
  - Make `maintenance_work_mem` 1–4 GB (also a run setting).
  - Keep `max_connections` at least (parallel tables × writers) + 20.
  - `synchronous_commit` is already turned off by ora2pg for its sessions.
- **Oracle:** gather statistics first (the pre-flight check warns). Sizes and ETAs come from them, and stale `num_rows` makes progress percentages wrong.
- **Recount:** the Validation page's *Recount all rows* counts every table again in parallel. Normally not needed, because each table was already verified when it was loaded.

## Tested here (round 2)
- **Chunked loading:** ORDERS (2.5 M rows) in 5 chunks, 3 loading in parallel.
  - The server was stopped with 3 chunks done.
  - Resume removed the partial rows and reloaded only chunks 3–4.
  - Result: 2,500,000 rows, 2,500,000 distinct keys.
- **GenAI round trip on HR:**
  - Exported the zip (14 objects in 10 folders), uploaded a converted zip, applied it on demand and during a run (7 applied, 1 already present).
  - A zip with `../` paths was rejected.
- **DB link:** `HR_LOOPBACK` → `postgres_fdw`; `link_hr_loopback.employees` returns the rows.
- **Settings:** an engine-managed directive was rejected; the preview masks passwords.
- **Snapshot:** all snapshot queries run without errors on the `DBA_*` versions.

## Tested here (round 1)
- **HR schema:**
  - Direct load and file load.
  - A re-run into existing tables (no duplicates).
  - Failure, then automatic retries, then Resume.
  - All validation categories.
- **`CV2_BENCH` (2.5 M-row table, 20 k LOB rows, parent/child FK):**
  - The huge-table path with parallel readers and writers.
  - Live progress over SSE.
  - The server stopped mid-load, then Resume. All 2,570,000 rows verified, Oracle = PostgreSQL.

**Not tested here:** a real 1 TB database, Thick mode, Windows hosting, and your corporate SSO.
