'use strict';

const { Pool } = require('pg');
const { currentProject } = require('./context');
const logger = require('./logger');

// v2: one pool per project (each project can point at a different PostgreSQL target).
const pools = new Map();

const poolKey = (key) => key || currentProject() || '_default';

// SSL is on unless PG_SSL=false (e.g. a local PostgreSQL without SSL)
const sslOption = () => (process.env.PG_SSL === 'false' ? false : { rejectUnauthorized: false });

function createPool(payload) {
  const pool = new Pool({
    user: payload.username,
    host: payload.hostip,
    database: payload.dbname,
    password: payload.password,
    port: Number(payload.port),
    max: 20,
    idleTimeoutMillis: 30000,
    connectionTimeoutMillis: 10000,
    keepAlive: true,
    ssl: sslOption(),
  });
  // An idle client losing its connection must never crash the server.
  pool.on('error', (err) => logger.warn(`PostgreSQL idle client error: ${err.message}`));
  return pool;
}

/** Tests the credentials and (re)creates the project's pool. */
async function initPostgres(payload, key) {
  const k = poolKey(key);
  const pool = createPool(payload);
  let client;
  try {
    client = await pool.connect();
    const { rows } = await client.query('SELECT version() AS version, current_user AS usr');
    client.release();
    client = null;
    const old = pools.get(k);
    pools.set(k, pool);
    if (old) old.end().catch(() => {});
    logger.info(`PostgreSQL connection pool created for ${k}.`);
    return { isConnected: true, version: rows[0].version, user: rows[0].usr };
  } catch (err) {
    logger.error(`Error creating PostgreSQL connection pool for ${k}: ${err.message}`);
    if (client) client.release();
    await pool.end().catch(() => {});
    throw err;
  }
}

async function ensurePostgresPool(payload, key) {
  const k = poolKey(key);
  if (pools.has(k)) return;
  if (!payload) throw new Error('PostgreSQL target is not connected for this project.');
  pools.set(k, createPool(payload));
}

async function getPostgresConnection(key) {
  const pool = pools.get(poolKey(key));
  if (pool) {
    return pool.connect();
  }
  logger.error('PostgreSQL DB Connection pool not initialized.');
  throw new Error('PostgreSQL DB Connection pool not initialized.');
}

/** Runs one query on a pooled client and always releases it. */
async function pgQuery(sql, params, key) {
  const client = await getPostgresConnection(key);
  try {
    return await client.query(sql, params);
  } finally {
    client.release();
  }
}

async function closePostgresPool(key) {
  const k = poolKey(key);
  const pool = pools.get(k);
  if (pool) {
    pools.delete(k);
    await pool.end().catch(() => {});
    logger.info(`PostgreSQL connection pool for ${k} closed.`);
  }
}

module.exports = { initPostgres, ensurePostgresPool, getPostgresConnection, pgQuery, closePostgresPool };
