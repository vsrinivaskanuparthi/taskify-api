'use strict';

const { AsyncLocalStorage } = require('async_hooks');

/**
 * Request / job context. Every API call and every background job runs inside
 * `runWithProject(projectName, fn)`, so code deep in the call stack (the cache,
 * the Oracle/Postgres pools, the query files) knows which project it is working
 * for without passing the name through every function. This is what lets several
 * users work on different projects at the same time.
 */
const storage = new AsyncLocalStorage();

function runWithProject(projectName, fn) {
  return storage.run({ projectName }, fn);
}

function currentProject() {
  const store = storage.getStore();
  return store ? store.projectName : null;
}

module.exports = { runWithProject, currentProject };
