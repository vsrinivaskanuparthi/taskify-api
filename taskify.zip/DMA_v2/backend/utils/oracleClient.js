const fs = require("fs");
const oracledb = require("oracledb");
const { getDBSchema } = require("../queries/oracle/getDBSchema");
const { currentProject } = require("./context");
const logger = require("./logger");

// OPTIMIZATION: Reduce network round-trips for large metadata queries
oracledb.fetchArraySize = 1000;

// Load environment variables from .env file
require("dotenv").config();

// Get the library directory from the environment variables
const oracleClientLibDir = process.env.ORACLE_CLIENT_LIB_DIR;

// Use Thick mode only when ORACLE_CLIENT_LIB_DIR points to an existing Instant Client folder.
// Otherwise node-oracledb runs in Thin mode, which needs no Oracle Client libraries
// (supports Oracle Database 12.1 and later).
if (oracleClientLibDir && fs.existsSync(oracleClientLibDir)) {
  try {
    logger.info(`Initializing Oracle Client (Thick mode) with libDir: ${oracleClientLibDir}`);
    oracledb.initOracleClient({ libDir: oracleClientLibDir });
  } catch (err) {
    logger.error(`Error initializing Oracle Client, falling back to Thin mode: ${err.message}`);
  }
} else {
  logger.info("Using node-oracledb Thin mode (no Oracle Client libraries needed).");
}

// v2: one pool per project (each project can point at a different Oracle database).
const pools = new Map();

const poolKey = (key) => key || currentProject() || "_default";

async function createPool(payload, key) {
  return oracledb.createPool({
    user: payload.userUsername,
    password: payload.userPassword,
    connectString: payload.userUrl,
    poolMin: 0,
    poolMax: 20,
    poolIncrement: 1,
    poolTimeout: 60,
    poolPingInterval: 60,
    queueTimeout: 120000,
    poolAlias: `dma_${key}_${Date.now()}`,
  });
}

/**
 * Tests the credentials, (re)creates the project's pool and returns the schema list.
 * The old pool is only replaced after the new credentials work.
 */
async function initOracle(payload, key) {
  const k = poolKey(key);
  let pool;
  let connection;
  try {
    pool = await createPool(payload, k);
    connection = await pool.getConnection();
    const response = await getDBSchema(connection);
    await connection.close();
    connection = null;

    const old = pools.get(k);
    pools.set(k, pool);
    if (old) old.close(10).catch(() => {});
    return { isConnected: true, schema: response };
  } catch (err) {
    logger.error(`Error creating Oracle connection pool for ${k}: ${err.message}`);
    if (connection) await connection.close().catch(() => {});
    if (pool) await pool.close(0).catch(() => {});
    throw err;
  }
}

/** Makes sure the project's pool exists, creating it from saved credentials after a restart. */
async function ensureOraclePool(payload, key) {
  const k = poolKey(key);
  if (pools.has(k)) return;
  if (!payload) throw new Error("Oracle source is not connected for this project.");
  pools.set(k, await createPool(payload, k));
}

async function getOracleConnection(key) {
  const pool = pools.get(poolKey(key));
  if (pool) {
    return pool.getConnection();
  }
  logger.error("Oracle DB Connection pool not initialized.");
  throw new Error("Oracle DB Connection pool not initialized.");
}

async function closeOraclePool(key) {
  const k = poolKey(key);
  const pool = pools.get(k);
  if (pool) {
    pools.delete(k);
    try {
      await pool.close(0); // 0 means force close all active connections
      logger.info(`Oracle connection pool for ${k} closed.`);
    } catch (err) {
      logger.error("Error closing Oracle pool:", err);
    }
  }
}

module.exports = { initOracle, ensureOraclePool, getOracleConnection, closeOraclePool };
