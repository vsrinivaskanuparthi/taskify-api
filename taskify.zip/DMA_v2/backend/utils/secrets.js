'use strict';

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { CONSTANTS } = require('./constants');

/**
 * Database passwords are saved in project_meta.json encrypted with AES-256-GCM.
 * The key comes from SECRET_KEY (any string) or, if not set, from a random key
 * file created once in the staging folder (readable by the service user only).
 */
let key = null;

function getKey() {
  if (key) return key;
  if (process.env.SECRET_KEY) {
    key = crypto.createHash('sha256').update(process.env.SECRET_KEY).digest();
    return key;
  }
  const keyFile = path.join(CONSTANTS.STAGING_DIR, '.dma_secret');
  if (!fs.existsSync(keyFile)) {
    fs.mkdirSync(CONSTANTS.STAGING_DIR, { recursive: true });
    fs.writeFileSync(keyFile, crypto.randomBytes(32).toString('hex'), { mode: 0o600 });
  }
  key = Buffer.from(fs.readFileSync(keyFile, 'utf8').trim(), 'hex');
  return key;
}

function encrypt(text) {
  if (text === undefined || text === null) return null;
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', getKey(), iv);
  const enc = Buffer.concat([cipher.update(String(text), 'utf8'), cipher.final()]);
  return `v1:${iv.toString('base64')}:${cipher.getAuthTag().toString('base64')}:${enc.toString('base64')}`;
}

function decrypt(payload) {
  if (!payload) return null;
  const [, iv, tag, data] = payload.split(':');
  const decipher = crypto.createDecipheriv('aes-256-gcm', getKey(), Buffer.from(iv, 'base64'));
  decipher.setAuthTag(Buffer.from(tag, 'base64'));
  return Buffer.concat([decipher.update(Buffer.from(data, 'base64')), decipher.final()]).toString('utf8');
}

module.exports = { encrypt, decrypt };
