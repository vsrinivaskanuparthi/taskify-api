/**
 * Differences between the ora2pg versions the app supports (24.x and 25.x).
 *  - 25 reads data AS OF the current SCN by default and has --no_start_scn; 24 has neither.
 *  - --dump_as_json exists from 24.1; 24.x writes JSON that is not always valid (unquoted strings,
 *    raw new lines), so the plain-text report is parsed as a fallback.
 */

/** Major version from `ora2pg --version` output ("Ora2Pg v24.3"), or null if unknown. */
function ora2pgMajor(text) {
  const m = /v(\d+)\.\d+/.exec(String(text || ''));
  return m ? Number(m[1]) : null;
}

/**
 * The plain-text SHOW_REPORT --estimate_cost output, in the same shape as --dump_as_json:
 * { objects: [{ object, number, invalid, 'cost value', comment, details }], 'total number', ... }.
 * Rows are tab separated: Object, Number, Invalid, Estimated cost, Comments, Details.
 */
function parseTextReport(text) {
  const lines = String(text || '').split('\n');
  const head = lines.findIndex((l) => /^Object\tNumber\tInvalid/.test(l));
  if (head < 0) return null;
  const report = { objects: [] };
  let last = null;
  for (const line of lines.slice(head + 1)) {
    if (/^-{20,}/.test(line)) continue;
    const total = /^Total\t(\d+)\t(\d+)\t([\d.]+)\t(.*)$/.exec(line);
    if (total) {
      report['total number'] = Number(total[1]);
      report['total invalid'] = Number(total[2]);
      report['total cost'] = Number(total[3]);
      const days = /approximatively (.+?)\. The migration unit/.exec(total[4]);
      report['human days cost'] = days ? days[1] : '';
      last = null;
      continue;
    }
    const level = /^Migration level : (.*)$/.exec(line);
    if (level) { report['migration level'] = level[1].trim(); break; }
    const row = /^([^\t]+)\t(\d+)\t(\d+)\t([\d.]+)\t([^\t]*)(?:\t(.*))?$/.exec(line);
    if (row) {
      last = { object: row[1], number: Number(row[2]), invalid: Number(row[3]), 'cost value': Number(row[4]), comment: row[5], details: row[6] || '' };
      report.objects.push(last);
    } else if (last && line.trim() && !('total number' in report)) {
      // Comments may span several lines.
      last.comment += `\n${line}`;
    }
  }
  return report.objects.length ? report : null;
}

module.exports = { ora2pgMajor, parseTextReport };
