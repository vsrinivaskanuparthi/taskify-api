const NodeCache = require("node-cache");
const { currentProject } = require('./context');

/**
 * A single, shared cache instance for the entire application.
 *
 * v2: keys are namespaced by the current project (see utils/context.js), so two
 * projects that use the same Oracle schema name never read each other's metadata.
 * The query files keep calling get/set exactly as before.
 */
const cache = new NodeCache({ stdTTL: 0, checkperiod: 3600, useClones: false });

const ns = (key) => `${currentProject() || '_global'}::${key}`;

function set(key, value, ttl) {
  cache.set(ns(key), value, ttl);
}

function get(key) {
  return cache.get(ns(key));
}

function del(key) {
  cache.del(ns(key));
}

/** Deletes every key of the current project (used before a fresh snapshot). */
function clearProject() {
  const prefix = ns('');
  cache.del(cache.keys().filter((k) => k.startsWith(prefix)));
}

function flush() {
  cache.flushAll();
}

module.exports = {
  set,
  get,
  del,
  clearProject,
  flush,
};
