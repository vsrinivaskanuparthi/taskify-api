'use strict';

const cacheService = require('../../utils/cache');
const logger = require('../../utils/logger');

async function compareNormalIndexes(connection, schemaName) {
    logger.info(`compareNormalIndexes execution started`);

    // OPTIMIZATION: Replaced triple-nested IN clause with efficient LEFT JOIN
    // We want indexes that are NOT constraints (Primary/Unique keys)
    const queryText = `
      SELECT
          i.relname AS indexname,
          t.relname AS tablename
      FROM
          pg_class t
      JOIN
          pg_namespace n ON n.oid = t.relnamespace
      JOIN
          pg_index ix ON t.oid = ix.indrelid
      JOIN
          pg_class i ON i.oid = ix.indexrelid
      LEFT JOIN
          pg_constraint c ON c.conindid = i.oid
      WHERE
          n.nspname = $1
          AND c.conname IS NULL -- This ensures it is NOT a constraint
          AND i.relname NOT LIKE '%_pkey' -- Extra safety check
          AND i.relname NOT LIKE '%_ukey'
          AND NOT (pg_get_indexdef(ix.indexrelid) ILIKE '%to_tsvector%') -- Exclude FTS
      ORDER BY
          i.relname
    `;

    try {
        const { rows } = await connection.query(queryText, [(connection.pgSchema || schemaName.toLowerCase())]);

        const postgresIndexSet = new Set(
            rows.map(row => `${row.indexname.toLowerCase()}:${row.tablename.toLowerCase()}`)
        );

        const cachedIndexes = cacheService.get(`getNormalIndexes:${schemaName}`);

        if (!cachedIndexes || !Array.isArray(cachedIndexes)) {
            // Return empty array instead of throwing if cache is missing (fails gracefully)
            logger.warn("Normal Indexes not found in cache. Returning empty comparison.");
            return [];
        }

        const comparisonResults = cachedIndexes.map(index => {
            // Check if index is array or object (Oracle driver format varies based on version)
            const indexName = Array.isArray(index) ? index[0] : index.INDEX_NAME || index.index_name;
            const tableName = Array.isArray(index) ? index[1] : index.TABLE_NAME || index.table_name;

            if (!indexName || !tableName) return null;

            const lookupKey = `${indexName.toLowerCase()}:${tableName.toLowerCase()}`;
            const existsInPostgres = postgresIndexSet.has(lookupKey);

            return [indexName, tableName, existsInPostgres ? "YES" : "NO"];
        }).filter(Boolean); // Remove nulls

        logger.info(`compareNormalIndexes execution completed`);
        return comparisonResults;
    } catch (error) {
        logger.error(`compareNormalIndexes execution failed`, error);
        throw error;
    }
}

module.exports = { compareNormalIndexes };
