'use strict';

const cacheService = require('../../utils/cache');
const logger = require('../../utils/logger');

async function compareCheckConstraints(connection, schemaName) {
  logger.info('compareCheckConstraints execution started');

  const queryText = `
        SELECT con.conname AS constraint_name, c.relname AS table_name, 'CHECK' AS constraint_type
        FROM pg_constraint con
        JOIN pg_class c ON c.oid = con.conrelid
        JOIN pg_namespace n ON n.oid = c.relnamespace
        WHERE con.contype = 'c'
          AND n.nspname = $1
          AND pg_get_constraintdef(con.oid) NOT LIKE '%IS NOT NULL%';
  `;

  try {
    const { rows } = await connection.query(queryText, [(connection.pgSchema || schemaName.toLowerCase())]);

    const postgresConstraints = new Set(
      rows.map(row => row.constraint_name.toLowerCase())
    );

    const cachedConstraints = cacheService.get(`getCheckConstraints:${schemaName}`);

    if (!cachedConstraints || !Array.isArray(cachedConstraints)) {
      throw new Error("Contstraints not found in cache.");
    }

    const comparisonResults = cachedConstraints
    .filter(constraint => constraint && constraint.constraintName) // Optional: guard against bad data
    .map(constraint => {

      // Use object properties instead of array indexes
      const constraintName = constraint.constraintName;
      const tableName = constraint.tableName;

      const existsInPostgres = postgresConstraints.has(constraintName.toLowerCase());

      return [constraintName, tableName, existsInPostgres ? "YES" : "NO"];
    });

    logger.info(`compareCheckConstraints execution completed`);
    return comparisonResults;
  } catch (error) {
    logger.error(`compareCheckConstraints execution failed with exception`, error);
    throw error;
  }
}

module.exports = { compareCheckConstraints };
