const logger = require("../../utils/logger");

/**
 * Code objects by name: every Oracle view, materialized view, function, procedure, trigger, type
 * and package routine must exist in PostgreSQL (sequences have their own check). In the Jaguar PoC
 * missing views, materialized views, a function and a skipped (invalid) procedure were only found
 * by testers, one at a time.
 *
 * Rows: [Type, Oracle name, Note, YES/NO]. Packages: ora2pg creates a schema per package
 * (PACKAGE_AS_SCHEMA), so pkg.routine is looked up as function routine in schema pkg, or as
 * pkg_routine in the target schema.
 */
async function compareCodeObjects(oracle, pg, owner, pgSchema, preserveCase) {
  logger.info('compareCodeObjects execution started');
  const norm = (n) => (preserveCase ? n : String(n).toLowerCase());

  const ora = await oracle.execute(
    `SELECT object_type, object_name, status FROM dba_objects
      WHERE owner = :owner
        AND object_type IN ('VIEW','MATERIALIZED VIEW','FUNCTION','PROCEDURE','TRIGGER','TYPE')
        AND object_name NOT LIKE 'BIN$%' AND object_name NOT LIKE 'DR$%' AND object_name NOT LIKE 'ISEQ$$%'
        AND object_name NOT LIKE 'SYS\\_%' ESCAPE '\\'
      ORDER BY object_type, object_name`, { owner });
  const pkgRoutines = await oracle.execute(
    `SELECT p.object_name, p.procedure_name FROM dba_procedures p
      WHERE p.owner = :owner AND p.object_type = 'PACKAGE' AND p.procedure_name IS NOT NULL
      GROUP BY p.object_name, p.procedure_name ORDER BY 1, 2`, { owner });

  const pgObjs = await pg.query(
    `SELECT 'rel' AS k, n.nspname, c.relname AS name, c.relkind::text AS kind FROM pg_class c JOIN pg_namespace n ON n.oid = c.relnamespace
      WHERE n.nspname = $1 AND c.relkind IN ('v','m','S')
     UNION ALL
     SELECT 'proc', n.nspname, p.proname, p.prokind::text FROM pg_proc p JOIN pg_namespace n ON n.oid = p.pronamespace
      WHERE n.nspname NOT IN ('pg_catalog','information_schema') AND n.nspname NOT LIKE 'pg\\_%'
     UNION ALL
     SELECT 'trg', n.nspname, t.tgname, '' FROM pg_trigger t JOIN pg_class c ON c.oid = t.tgrelid JOIN pg_namespace n ON n.oid = c.relnamespace
      WHERE n.nspname = $1 AND NOT t.tgisinternal
     UNION ALL
     SELECT 'type', n.nspname, ty.typname, ty.typtype::text FROM pg_type ty JOIN pg_namespace n ON n.oid = ty.typnamespace
      LEFT JOIN pg_class c ON c.oid = ty.typrelid
      WHERE n.nspname = $1 AND ty.typtype IN ('c','e','d') AND (ty.typrelid = 0 OR c.relkind = 'c')`, [pgSchema]);

  const has = new Set();
  const procsAnySchema = new Set();
  for (const r of pgObjs.rows) {
    if (r.k === 'rel') has.add(`${{ v: 'VIEW', m: 'MATERIALIZED VIEW', S: 'SEQUENCE' }[r.kind]}:${r.name}`);
    if (r.k === 'trg') has.add(`TRIGGER:${r.name}`);
    if (r.k === 'type') has.add(`TYPE:${r.name}`);
    if (r.k === 'proc') {
      procsAnySchema.add(`${r.nspname}.${r.name}`);
      // ora2pg turns trigger bodies into trigger_fct_<name>() functions; both kinds count as routines here.
      if (r.nspname === pgSchema) has.add(`ROUTINE:${r.name}`);
    }
  }

  const rows = [];
  for (const [type, name, status] of ora.rows) {
    const key = ['FUNCTION', 'PROCEDURE'].includes(type) ? `ROUTINE:${norm(name)}` : `${type}:${norm(name)}`;
    const found = has.has(key);
    rows.push([type, name, status === 'INVALID' ? 'invalid in Oracle' : '', found ? 'YES' : 'NO']);
  }
  for (const [pkg, routine] of pkgRoutines.rows) {
    const found = procsAnySchema.has(`${norm(pkg)}.${norm(routine)}`) || has.has(`ROUTINE:${norm(`${pkg}_${routine}`)}`);
    rows.push(['PACKAGE ROUTINE', `${pkg}.${routine}`, '', found ? 'YES' : 'NO']);
  }
  return rows;
}

module.exports = { compareCodeObjects };
