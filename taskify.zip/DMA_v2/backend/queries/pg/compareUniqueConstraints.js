'use strict';

const cacheService = require('../../utils/cache');
const logger = require('../../utils/logger');

async function compareUniqueConstraints(connection, schemaName) {
  logger.info('compareUniqueConstraints execution started');

  const queryText = `
        SELECT c.relname AS table_name, a.attname AS column_name
        FROM pg_constraint con
        JOIN pg_class c ON c.oid = con.conrelid
        JOIN pg_namespace n ON n.oid = c.relnamespace
        CROSS JOIN LATERAL unnest(con.conkey) AS k(attnum)
        JOIN pg_attribute a ON a.attrelid = c.oid AND a.attnum = k.attnum
        WHERE con.contype = 'u'
          AND n.nspname = $1;
  `;

  try {
    const { rows } = await connection.query(queryText, [(connection.pgSchema || schemaName.toLowerCase())]);

    const postgresUniqueSet = new Set(
      rows.map(row => `${row.table_name.toLowerCase()}:${row.column_name.toLowerCase()}`)
    );

    const cachedConstraints = cacheService.get(`fetchUniqueConstraints:${schemaName}`);

    if (!cachedConstraints || !Array.isArray(cachedConstraints)) {
      throw new Error("Unique Contstraints not found in cache.");
    }

    const comparisonResults = cachedConstraints
      .filter(constraint => constraint && constraint.table_name && constraint.column_name) // Good practice to prevent errors // TODO(video): end of this comment ran off-screen
      .map(constraint => {
        // Use object properties instead of array indexes
        const tableName = constraint.table_name;
        const columnName = constraint.column_name;

        const lookupKey = `${tableName.toLowerCase()}:${columnName.toLowerCase()}`;
        const existsInPostgres = postgresUniqueSet.has(lookupKey);

        return [columnName, tableName, existsInPostgres ? "YES" : "NO"];
      });


    logger.info(`compareUniqueConstraints execution completed`);
    return comparisonResults;
  } catch (error) {
    logger.error(`compareUniqueConstraints execution failed with exception`, error);
    throw error;
  }
}



module.exports = { compareUniqueConstraints };
