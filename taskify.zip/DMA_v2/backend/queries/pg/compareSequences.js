'use strict';

const cacheService = require('../../utils/cache');
const logger = require('../../utils/logger');

async function compareSequences(connection, schemaName) {
  logger.info('compareSequences execution started');

  const queryText = `
        SELECT c.relname AS sequence_name
        FROM pg_class c
        JOIN pg_namespace n ON n.oid = c.relnamespace
        WHERE c.relkind = 'S' AND n.nspname = $1
        ORDER BY c.relname;
  `;

  try {
    const { rows } = await connection.query(queryText, [(connection.pgSchema || schemaName.toLowerCase())]);

    const postgresSequences = new Set(
      rows.map(row => row.sequence_name.toLowerCase())
    );

    const cachedSequences = cacheService.get(`getSequences:${schemaName}`);

    if (!cachedSequences || !Array.isArray(cachedSequences.allSequences)) {
      throw new Error("Sequences not found in cache.");
    }

    const comparisonResults = cachedSequences.allSequences.map(sequence => {
      const existsInPostgres = postgresSequences.has(sequence.toLowerCase());

      return [sequence, existsInPostgres ? "YES" : "NO"];
    });

    logger.info(`compareSequences execution completed`);
    return comparisonResults;
  } catch (error) {
    logger.error(`compareSequences execution failed with exception`, error);
    throw error;
  }
}

module.exports = { compareSequences };
