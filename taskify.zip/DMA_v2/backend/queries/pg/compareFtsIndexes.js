'use strict';

const cacheService = require('../../utils/cache');
const logger = require('../../utils/logger');

async function compareFtsIndexes(connection, schemaName) {
  logger.info(`compareFtsIndexes execution started`);

  const queryText = `
        SELECT
            idx.indexname AS index_name,
            idx.tablename AS table_name
        FROM
            pg_indexes idx
        WHERE
            idx.schemaname = $1
            AND (
                idx.indexdef ILIKE '%USING gin%'
                OR idx.indexdef ILIKE '%USING gist%'
            )
            AND idx.indexdef ILIKE '%to_tsvector%';
  `;

  try {
    const { rows } = await connection.query(queryText, [(connection.pgSchema || schemaName.toLowerCase())]);

    const postgresFtsSet = new Set(
      rows.map(row => `${row.index_name.toLowerCase()}:${row.table_name.toLowerCase()}`)
    );

    const cachedIndexes = cacheService.get(`getOracleFTSIndexes:${schemaName}`);

    if (!cachedIndexes || !Array.isArray(cachedIndexes)) {
      throw new Error("Fts Indexes not found in cache.");
    }

    const comparisonResults = cachedIndexes.map(index => {
      const indexName = index[0];
      const tableName = index[1];
      const lookupKey = `${indexName.toLowerCase()}:${tableName.toLowerCase()}`;
      const existsInPostgres = postgresFtsSet.has(lookupKey);

      return [indexName, tableName, existsInPostgres ? "YES" : "NO"];
    });

    logger.info(`compareFtsIndexes execution completed`);
    return comparisonResults;
  } catch (error) {
    logger.error(`compareFtsIndexes execution failed with exception`, error);
    throw error;
  }
}

module.exports = { compareFtsIndexes };
