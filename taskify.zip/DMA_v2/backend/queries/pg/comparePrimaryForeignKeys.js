'use strict';

const cacheService = require(`../../utils/cache`);
const logger = require(`../../utils/logger`);

async function comparePrimaryForeignKeys(connection, schemaName) {
    logger.info(`comparePrimaryForeignKeys execution started`);

    // Improved Query:
    // 1. Gets Constraints (PK and FK)
    // 2. Uses unnest() for robust composite key handling
    // 3. Joins cleanly on pg_attribute to get real column names
    const pkFkQuery = `
        WITH keys AS (
            -- Get standard Constraints (PK and FK)
            SELECT
                c.relname AS table_name,
                a.attname AS column_name,
                con.contype
            FROM pg_constraint con
            JOIN pg_class c ON c.oid = con.conrelid
            JOIN pg_namespace n ON n.oid = c.relnamespace
            CROSS JOIN LATERAL unnest(con.conkey) AS col_idx
            JOIN pg_attribute a ON a.attnum = col_idx AND a.attrelid = c.oid
            WHERE n.nspname = $1
              AND con.contype IN ('p', 'f')

            UNION ALL

            -- Fallback: Get Primary Keys directly from Indexes
            -- (Sometimes PKs exist as unique indexes marked 'primary' but miss constraint entries)
            SELECT
                c.relname AS table_name,
                a.attname AS column_name,
                'p' AS contype
            FROM pg_index i
            JOIN pg_class c ON c.oid = i.indrelid
            JOIN pg_namespace n ON n.oid = c.relnamespace
            CROSS JOIN LATERAL unnest(i.indkey) AS col_idx
            JOIN pg_attribute a ON a.attnum = col_idx AND a.attrelid = c.oid
            WHERE n.nspname = $1
              AND i.indisprimary = true
        )
        SELECT DISTINCT table_name, column_name
        FROM keys;
    `;

    try {
        const { rows } = await connection.query(pkFkQuery, [(connection.pgSchema || schemaName.toLowerCase())]);

        // Create a set of "tablename:columnname" present in Postgres
        // We strictly lowercase both to ensure case-insensitive matching
        const postgresPkFkSet = new Set(
            rows.map(row => `${row.table_name.toLowerCase()}:${row.column_name.toLowerCase()}`)
        );

        const cachedKeys = cacheService.get(`getPrimaryForeignKeys:${schemaName}`);

        if (!cachedKeys || !Array.isArray(cachedKeys)) {
            throw new Error("Primary, Foreign Keys not found in cache.");
        }

        const comparisonResults = cachedKeys.map(item => {
            const lookupKey = `${item.tableName.toLowerCase()}:${item.columnName.toLowerCase()}`;

            const isMatch = postgresPkFkSet.has(lookupKey);

            return [
                item.tableName,
                item.columnName,
                isMatch ? "YES" : "NO",
            ];
        });

        logger.info(`comparePrimaryForeignKeys execution completed`);
        return comparisonResults;
    } catch (error) {
        logger.error(`comparePrimaryForeignKeys execution failed with exception`, error);
        throw error;
    }
}


module.exports = { comparePrimaryForeignKeys };
