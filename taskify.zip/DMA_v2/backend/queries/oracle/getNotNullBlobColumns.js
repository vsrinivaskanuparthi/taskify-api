const logger = require('../../utils/logger');
const cacheService = require('../../utils/cache');

/**
 * Fetches all NOT NULL BLOB columns with check constraints for the given schema.
 * @param {object} connection - Oracle DB connection.
 * @returns {Promise<Array>} List of objects with owner, tableName, and columnName.
 */
async function getNotNullBlobColumns(connection, schemaName) {
  // 1. Create a schema-specific cache key
  const cacheKey = `getNotNullBlobColumns:${schemaName}`;

  // 2. Check the cache first
  const cachedResult = cacheService.get(cacheKey);
  if (cachedResult) {
    logger.info(`Returning non blob columns '${schemaName}' from cache.`);
    return cachedResult;
  }

  logger.info('getNotNullBlobColumn execution started');
  const notNullBlobColumns = [];
  const query = `
    SELECT
      c.owner,
      c.table_name,
      c.column_name
    FROM
      dba_tab_columns c
      JOIN dba_cons_columns cc
        ON c.owner = cc.owner
        AND c.table_name = cc.table_name
        AND c.column_name = cc.column_name
      JOIN dba_constraints cons
        ON cc.owner = cons.owner
        AND cc.constraint_name = cons.constraint_name
    WHERE
      c.data_type = 'BLOB'
      AND cons.constraint_type = 'C'
      AND c.nullable = 'N'
      AND c.owner = :schemaName
    ORDER BY
      c.owner,
      c.table_name,
      c.column_name
  `;

  try {
    const result = await connection.execute(query, [schemaName]);

    for (const row of result.rows) {
      notNullBlobColumns.push({
        owner: row[0],
        table_name: row[1],
        column_name: row[2],
      });
    }
  } catch (error) {
    logger.error('getNotNullBlobColumns execution error:', error);
    throw error;
  }
  cacheService.set(cacheKey, notNullBlobColumns);
  logger.info('getNotNullBlobColumns execution completed');
  return notNullBlobColumns;
}

module.exports = { getNotNullBlobColumns }
