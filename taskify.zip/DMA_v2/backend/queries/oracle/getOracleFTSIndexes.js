const cacheService = require('../../utils/cache');
const logger = require('../../utils/logger');

/**
 * Fetches Oracle Full Text Search (FTS) indexes for the given schema.
 * @param {object} connection - Oracle DB connection.
 * @returns {Promise<Array>} Array of FTS index objects.
 */
async function getOracleFTSIndexes(connection, schemaName) {
  // 1. Create a schema-specific cache key
  const cacheKey = `getOracleFTSIndexes:${schemaName}`;

  // 2. Check the cache first
  const cachedResult = cacheService.get(cacheKey);
  if (cachedResult) {
    logger.info(`Returning oracle fts indexes '${schemaName}' from cache.`);
    return cachedResult;
  }

  const ftsIndexes = [];
  const query = `
    SELECT DISTINCT
      idx.index_name,
      idx.table_name
    FROM
      dba_indexes idx
    JOIN
      dba_ind_columns col
      ON idx.index_name = col.index_name
      AND idx.owner = col.index_owner
    WHERE
      idx.index_type = 'DOMAIN'
      AND idx.owner = :owner
      AND idx.ityp_owner = 'CTXSYS'
      AND idx.ityp_name = 'CONTEXT'
  `;

  try {
    const result = await connection.execute(
      query,
      { owner: schemaName }
    );

    for (const row of result.rows) {
      ftsIndexes.push(row);
    }
    cacheService.set(cacheKey, ftsIndexes)
    return ftsIndexes;
  } catch (error) {
    throw error;
  }
}

module.exports = { getOracleFTSIndexes };
