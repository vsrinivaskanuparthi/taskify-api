const { getForeignKeys } = require("../oracle/getForeignKeys.js");
const logger = require("../../utils/logger.js");
const cacheService = require("../../utils/cache.js");

async function getTableMetadata(connection, schemaName) {
  const cacheKey = `getTableMetadata:${schemaName}`;
  const cachedResult = cacheService.get(cacheKey);
  if (cachedResult) {
    logger.info(`Returning table metadata '${schemaName}' from cache.`);
    return cachedResult;
  }

  logger.info("getTableMetadata execution started");
  try {
    const tables = [];

    // OPTIMIZATION: Use 't.num_rows' (statistics) instead of 'SELECT COUNT(*)' (Live Count).
    // Live counting is too slow for dashboards.
    // Also, removed DBMS_XMLGEN entirely.
    // v2: size = table segments + LOB segments (v1 counted only the table segment, so LOB-heavy
    // schemas looked far smaller than the data that has to be moved). Recycle-bin and secondary
    // tables, and the storage tables of materialized views, are left out, as ora2pg leaves them out.
    const query = `
      SELECT
        t.table_name,
        NVL(t.num_rows, 0) AS estimated_row_count,
        ROUND((NVL(ts.bytes, 0) + NVL(ls.bytes, 0)) / 1024 / 1024, 2) AS table_size_mb,
        ROUND(NVL(ls.bytes, 0) / 1024 / 1024, 2) AS lob_size_mb,
        TO_CHAR(t.last_analyzed, 'YYYY-MM-DD') AS last_analyzed,
        t.partitioned
      FROM dba_tables t
      LEFT JOIN (
        SELECT segment_name, SUM(bytes) AS bytes
        FROM dba_segments
        WHERE owner = :owner
        GROUP BY segment_name
      ) ts ON ts.segment_name = t.table_name
      LEFT JOIN (
        SELECT l.table_name, SUM(s.bytes) AS bytes
        FROM dba_lobs l
        JOIN dba_segments s ON s.owner = l.owner AND s.segment_name = l.segment_name
        WHERE l.owner = :owner
        GROUP BY l.table_name
      ) ls ON ls.table_name = t.table_name
      WHERE t.owner = :owner
        AND t.dropped = 'NO'
        AND t.secondary = 'N'
        -- Global temporary tables hold no data; MLOG$/RUPD$ are Oracle's materialized view log tables.
        AND t.temporary = 'N'
        AND t.table_name NOT LIKE 'MLOG$%' AND t.table_name NOT LIKE 'RUPD$%'
        AND NOT EXISTS (SELECT 1 FROM dba_mviews m WHERE m.owner = t.owner AND m.mview_name = t.table_name)
      ORDER BY t.table_name
    `;

    const result = await connection.execute(query, { owner: schemaName }, {
      resultSet: true,
    });

    const resultSet = result.resultSet;
    const [foreignKeysList, foreignKeyPresence] = await getForeignKeys(connection, schemaName);

    for await (const row of resultSet) {
      const [tableName, rowCount, tableSizeMb, lobSizeMb, lastAnalyzed, partitioned] = row;
      tables.push({
        name: tableName,
        sizeMb: tableSizeMb || "0",
        lobSizeMb: lobSizeMb || 0,
        lastAnalyzed,
        partitioned: partitioned === 'YES',
        rowCount: rowCount || "0", // This is now instant
        hasForeignKey: foreignKeyPresence[tableName] !== undefined ? "Yes" : "No",
        parentTable: foreignKeyPresence[tableName] !== undefined
          ? foreignKeysList[foreignKeyPresence[tableName]]
          : "",
      });
    }
    await resultSet.close();
    cacheService.set(cacheKey, tables);
    logger.info("getTableMetadata execution completed");
    return tables;
  } catch (error) {
    logger.error("getTableMetadata error occurred", error);
    throw error;
  }
}

module.exports = { getTableMetadata };
