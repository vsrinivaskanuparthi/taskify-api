const logger = require("../../utils/logger");
const cacheService = require('../../utils/cache');

// Thresholds
const MAX_SAFE_SIZE = 629145600; // 600MB
const MAX_ROWS_FOR_SCAN = 5000;  // If > 5000 rows, assume BLOBs are heavy to avoid slow scan

async function getBlobColumns(connection, schemaName) {
  const cacheKey = `getBlobColumns:${schemaName}`;
  const cachedResult = cacheService.get(cacheKey);
  if (cachedResult) {
    logger.info(`Returning blob columns '${schemaName}' from cache.`);
    return cachedResult;
  }

  logger.info("getBlobColumns execution started");
  try {
    // OPTIMIZATION: Join with ALL_TABLES to get NUM_ROWS statistic immediately
    const query = `
      SELECT c.owner, c.table_name, c.column_name, t.num_rows
      FROM dba_tab_columns c
      JOIN dba_tables t ON c.owner = t.owner AND c.table_name = t.table_name
      WHERE c.owner = :owner
        AND c.data_type IN ('BLOB', 'CLOB')
      ORDER BY c.table_name, c.column_name
    `;

    const result = await connection.execute(
      query,
      [schemaName],
      { outFormat: require('oracledb').OUT_FORMAT_OBJECT }
    );

    const rows = Array.isArray(result.rows) ? result.rows : [];
    const blobColumns = [];
    const tableIndexMap = {};
    let idx = 0;

    if (rows.length === 0) {
      cacheService.set(cacheKey, blobColumns);
      return blobColumns;
    }

    for (const row of rows) {
      const OWNER = row.OWNER || row.owner;
      const TABLE_NAME = row.TABLE_NAME || row.table_name;
      const COLUMN_NAME = row.COLUMN_NAME || row.column_name;
      const NUM_ROWS = row.NUM_ROWS || 0;

      let isHeavyBlob = false;

      // OPTIMIZATION: Skip scan for large tables
      if (NUM_ROWS > MAX_ROWS_FOR_SCAN) {
        logger.info(`Table ${TABLE_NAME} has ${NUM_ROWS} rows. Skipping scan, assuming heavy BLOB.`);
        isHeavyBlob = true;
      } else {
        // Only scan small tables
        try {
          const sizeQuery = `SELECT MAX(DBMS_LOB.GETLENGTH("${COLUMN_NAME}")) AS MAX_SIZE FROM "${OWNER}"."${TABLE_NAME}"`; // TODO(video): end of this line ran off-screen; table reference inferred
          const sizeResult = await connection.execute(sizeQuery);
          const maxSize = (sizeResult.rows && sizeResult.rows[0]) ? sizeResult.rows[0][0] : 0;
          if (maxSize > MAX_SAFE_SIZE) isHeavyBlob = true;
        } catch (e) {
          isHeavyBlob = true; // Default to safe mode on error
        }
      }

      if (isHeavyBlob) {
        if (tableIndexMap[TABLE_NAME] === undefined) {
          blobColumns.push({ tableName: TABLE_NAME, columns: [COLUMN_NAME] });
          tableIndexMap[TABLE_NAME] = idx;
          idx += 1;
        } else {
          blobColumns[tableIndexMap[TABLE_NAME]].columns.push(COLUMN_NAME);
        }
      }
    }

    cacheService.set(cacheKey, blobColumns);
    logger.info(`getBlobColumns found ${blobColumns.length} tables.`);
    return blobColumns;
  } catch (error) {
    logger.error('getBlobColumns error:', error);
    throw error;
  }
}

module.exports = { getBlobColumns };
