const logger = require('../../utils/logger');
const cacheService = require('../../utils/cache');

// Store the table count result
let tableCount = 0;

/**
 * Queries the database for the number of tables owned by the specified schema.
 * @param {object} connection - Oracle DB connection object.
 * @returns {Promise<number>} - The count of tables for the schema.
 */
async function getTableCountBySchema(connection, schemaName) {
  // 1. Create a schema-specific cache key
  const cacheKey = `getTableCountBySchema:${schemaName}`;

  // 2. Check the cache first
  const cachedResult = cacheService.get(cacheKey);
  if (cachedResult) {
    logger.info(`Returning table count '${schemaName}' from cache.`);
    return cachedResult;
  }

  logger.info('getTableCountBySchema execution started');
  try {
    const query = `
    SELECT COUNT(*) AS TABLE_COUNT
    FROM DBA_TABLES t
    WHERE t.OWNER = :owner
    AND t.DROPPED = 'NO' AND t.SECONDARY = 'N' AND t.TEMPORARY = 'N'
    AND t.TABLE_NAME NOT LIKE 'MLOG$%' AND t.TABLE_NAME NOT LIKE 'RUPD$%'
    AND NOT EXISTS (SELECT 1 FROM DBA_MVIEWS m WHERE m.OWNER = t.OWNER AND m.MVIEW_NAME = t.TABLE_NAME)`;
    // Same tables as getTableMetadata (no temporary, Oracle Text, MV log or MV container tables).

    // Use bind variables for security and performance
    const result = await connection.execute(query, { owner: schemaName });

    // Extract count from result
    tableCount = result.rows[0][0] || 0;
    cacheService.set(cacheKey, tableCount);
    logger.info('getTableCountBySchema execution completed');
    return tableCount;
  } catch (error) {
    logger.error('getTableCountBySchema error occurred', error);
    // Log and rethrow error for upstream handling
    throw error;
  }
}

module.exports = { getTableCountBySchema };
