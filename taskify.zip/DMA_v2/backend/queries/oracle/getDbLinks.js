const logger = require("../../utils/logger");

/**
 * DB links the schema owns or can use (PUBLIC), with how many of its objects reference each one.
 * Used by the DB link mapping on the Code objects page.
 */
async function getDbLinks(connection, schemaName) {
  logger.info("getDbLinks execution started");
  const links = await connection.execute(
    `SELECT owner, db_link, username, host
       FROM dba_db_links
      WHERE owner IN (:owner, 'PUBLIC')
      ORDER BY owner, db_link`,
    { owner: schemaName }
  );
  const usage = await connection.execute(
    `SELECT referenced_link_name, COUNT(DISTINCT name)
       FROM dba_dependencies
      WHERE owner = :owner AND referenced_link_name IS NOT NULL
      GROUP BY referenced_link_name`,
    { owner: schemaName }
  );
  const used = new Map(usage.rows.map((r) => [String(r[0]).split('.')[0].toUpperCase(), Number(r[1])]));
  return links.rows.map(([owner, name, username, host]) => ({
    owner,
    name,
    username,
    host,
    usedBy: used.get(String(name).split('.')[0].toUpperCase()) || 0,
  }));
}

module.exports = { getDbLinks };
