const logger = require('../../utils/logger');
const cacheService = require('../../utils/cache');

/**
 * Fetches instance details from the database and returns them as an array.
 * @param {object} connection - The Oracle DB connection object.
 * @returns {Promise<Array>} Array of instance details.
 */
async function getDbInstanceDetails(connection, schemaName) {
    // 1. Create a schema-specific cache key
    const cacheKey = `getDbInstanceDetails:${schemaName}`;

    // 2. Check the cache first
    const cachedResult = cacheService.get(cacheKey);
    if (cachedResult) {
        logger.info(`Returning oracle instance details '${schemaName}' from cache.`);
        return cachedResult;
    }

    logger.info('getDbInstanceDetails execution started');
    const instances = [];
    const query = `SELECT INSTANCE_NAME, VERSION, HOST_NAME FROM v$instance`;

    try {
        const result = await connection.execute(query, [], { resultSet: true });
        const resultSet = result.resultSet;

        for await (const row of resultSet) {
            instances.push(row);
        }

        await resultSet.close();
        cacheService.set(cacheKey, instances);
        logger.info('getDbInstanceDetails execution completed');
        return instances;
    } catch (error) {
        logger.error('getDbInstanceDetails error occurred', error);
        throw error;
    }
}

module.exports = { getDbInstanceDetails };
