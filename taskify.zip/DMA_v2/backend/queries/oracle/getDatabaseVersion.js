const logger = require('../../utils/logger');
const cacheService = require('../../utils/cache');

/**
 * Retrieves the database version from the Oracle instance.
 * @param {object} connection - The Oracle DB connection object.
 * @returns {Promise<Array>} - A promise that resolves to an array of version strings.
 */
async function getDatabaseVersion(connection, schemaName) {
  // 1. Create a schema-specific cache key
  const cacheKey = `getDatabaseVersion:${schemaName}`;

  // 2. Check the cache first
  const cachedResult = cacheService.get(cacheKey);
  if (cachedResult) {
    logger.info(`Returning table version for schema '${schemaName}' from cache.`);
    return cachedResult;
  }

  logger.info('getDatabaseVersion execution started');
  try {
    // Execute the query to get the version from v$instance
    const result = await connection.execute(
      `SELECT version FROM v$instance`,
      [],
      { resultSet: true }
    );
    const resultSet = result.resultSet;
    const versions = [];

    // Iterate over the result set and collect version values
    for await (const row of resultSet) {
      versions.push(row[0]);
    }

    // Always close the result set to avoid resource leaks
    await resultSet.close();
    cacheService.set(cacheKey, versions);
    logger.info('getDatabaseVersion execution completed');
    return versions;
  } catch (error) {
    logger.error('getDatabaseVersion error occurred', error);
    throw error;
  }
}

module.exports = { getDatabaseVersion };
