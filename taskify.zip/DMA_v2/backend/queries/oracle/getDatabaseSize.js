const logger = require('../../utils/logger');
const cacheService = require('../../utils/cache');

async function getDatabaseSize(connection, schemaName) {
  const cacheKey = `getDatabaseSize:${schemaName}`;
  const cachedResult = cacheService.get(cacheKey);
  if (cachedResult) {
    logger.info(`Returning database size '${schemaName}' from cache.`);
    return cachedResult;
  }

  logger.info('getDatabaseSize execution started');
  try {
    const query = `
      SELECT SUM(bytes) / 1024 / 1024 / 1024 AS size_gb
      FROM dba_segments
      WHERE OWNER = :owner
    `;

    // Execute without resultSet (since we expect only 1 row)
    const result = await connection.execute(query, [schemaName]);

    let sizeGb = 0;
    if (result.rows && result.rows.length > 0 && result.rows[0][0] != null) {
      sizeGb = result.rows[0][0];
    }

    // Return as an array to match your frontend expectation
    const response = [sizeGb];

    cacheService.set(cacheKey, response);
    logger.info('getDatabaseSize execution completed');
    return response;
  } catch (error) {
    logger.error('getDatabaseSize error occurred', error);
    throw error;
  }
}

module.exports = { getDatabaseSize };
