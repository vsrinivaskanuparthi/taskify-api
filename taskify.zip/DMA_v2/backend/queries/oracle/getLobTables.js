const logger = require("../../utils/logger");

/**
 * Every table with a LOB column (v2). getBlobColumns only reports the "heavy" ones; the
 * migration engine loads all LOB tables with a smaller batch size (BLOB_LIMIT) to bound memory.
 */
async function getLobTables(connection, schemaName) {
  logger.info("getLobTables execution started");
  const result = await connection.execute(
    `SELECT DISTINCT table_name
       FROM dba_tab_columns
      WHERE owner = :owner
        AND data_type IN ('BLOB', 'CLOB', 'NCLOB', 'LONG', 'LONG RAW', 'BFILE', 'XMLTYPE')
      ORDER BY table_name`,
    { owner: schemaName }
  );
  return result.rows.map((r) => r[0]);
}

module.exports = { getLobTables };
