const cacheService = require('../../utils/cache');
const logger = require('../../utils/logger');

/**
 * Retrieves primary and foreign key columns for all tables in the specified schema.
 * @param {object} connection - Oracle DB connection object.
 * @returns {Promise<Array<{tableName: string, columnName: string, constraintType: string}>>}
 */
async function getPrimaryForeignKeys(connection, schemaName) {
  // 1. Create a schema-specific cache key
  const cacheKey = `getPrimaryForeignKeys:${schemaName}`;

  // 2. Check the cache first
  const cachedResult = cacheService.get(cacheKey);
  if (cachedResult) {
    logger.info(`Returning primiary foreign keys '${schemaName}' from cache.`);
    return cachedResult;
  }

  const keyList = [];
  const query = `
    SELECT
      cols.table_name,
      cols.column_name,
      cons.constraint_type
    FROM
      dba_constraints cons
    JOIN
      dba_cons_columns cols
      ON cons.constraint_name = cols.constraint_name
      AND cons.owner = cols.owner
    WHERE
      cons.constraint_type IN ('P', 'R')
      AND cons.owner = :schemaName
      AND cons.table_name NOT IN (SELECT table_name FROM dba_tables WHERE owner = :schemaName AND secondary = 'Y')
    ORDER BY
      cols.table_name, cons.constraint_type
  `;

  const result = await connection.execute(
    query,
    { schemaName },
    { resultSet: true }
  );

  const resultSet = result.resultSet;
  for await (const row of resultSet) {
    keyList.push({
      tableName: row[0],
      columnName: row[1],
      constraintType: row[2],
    });
  }
  await resultSet.close();
  cacheService.set(cacheKey, keyList);
  return keyList;
}

module.exports = { getPrimaryForeignKeys };
