const cacheService = require('../../utils/cache');
const logger = require('../../utils/logger');

/**
 * Fetches the count of primary keys in the specified schema.
 * @param {object} connection - Oracle DB connection object.
 * @returns {Promise<number>} - The count of primary keys.
 */
async function getPrimaryKeyCount(connection, schemaName) {
  // Use parameterized queries to prevent SQL injection
  // 1. Create a schema-specific cache key
  const cacheKey = `getPrimaryKeyCount:${schemaName}`;

  // 2. Check the cache first
  const cachedResult = cacheService.get(cacheKey);
  if (cachedResult) {
    logger.info(`Returning primiary key count '${schemaName}' from cache.`);
    return cachedResult;
  }

  const query = `
    SELECT COUNT(*) AS primary_key_count
    FROM dba_constraints
    WHERE constraint_type = 'P' AND owner = :owner
      AND table_name NOT IN (SELECT table_name FROM dba_tables WHERE owner = :owner AND secondary = 'Y')
  `;

  try {
    const result = await connection.execute(
      query,
      { owner: schemaName },
      { resultSet: true }
    );

    // Extract the count from the resultSet
    const resultSet = result.resultSet;
    const row = await resultSet.getRow();
    await resultSet.close();
    const primaryKeyCount = row ? row[0] : 0;
    cacheService.set(cacheKey, primaryKeyCount);
    return primaryKeyCount;
  } catch (error) {
    throw error;
  }
}

module.exports = { getPrimaryKeyCount };
