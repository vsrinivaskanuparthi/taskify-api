const cacheService = require("../../utils/cache");
const logger = require("../../utils/logger");

/**
 * Fetch all sequence names for the given schema from Oracle DB,
 * identifying any duplicates.
 * @param {object} connection - Oracle DB connection object
 * @param {string} schemaName - The name of the schema to query.
 * @returns {Promise<{allSequences: string[], duplicateSequences: string[]}>} - An object containing all sequences and duplicate sequences. // TODO(video): end of this comment ran off-screen
 */
async function getSequences(connection, schemaName) {
  // Create a schema-specific cache key
  const cacheKey = `getSequences:${schemaName}`;

  const cachedResult = cacheService.get(cacheKey);
  if (cachedResult) {
    logger.info(`Returning oracle all sequences '${schemaName}' from cache.`);
    return cachedResult;
  }

  const allSequences = [];
  // Use bind variables to prevent SQL injection and improve performance
  const query = `
  SELECT sequence_name
  FROM dba_sequences
  WHERE sequence_owner = :owner
  `;

  try {
    const result = await connection.execute(query, [schemaName], {
      resultSet: true,
    });

    const resultSet = result.resultSet;
    for await (const row of resultSet) {
      allSequences.push(row[0]);
    }
    await resultSet.close();

    // Create a frequency map to count occurrences of each sequence name
    const frequencyMap = allSequences.reduce((acc, name) => {
      acc[name] = (acc[name] || 0) + 1;
      return acc;
    }, {});

    // Filter the map to find names that appeared more than once
    const duplicateSequences = Object.keys(frequencyMap).filter(
      (name) => frequencyMap[name] > 1
    );
    const resultObject = {
      allSequences, // The full list, including duplicates
      duplicateSequences, // The list of names that are duplicated
    };

    cacheService.set(cacheKey, resultObject);

    return resultObject;
  } catch (error) {
    logger.error("getSequences function execution error", error);
    throw error;
  }
}

module.exports = { getSequences };
