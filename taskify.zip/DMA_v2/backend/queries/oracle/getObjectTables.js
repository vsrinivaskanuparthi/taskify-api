'use strict';

const logger = require("../../utils/logger");
const cacheService = require('../../utils/cache');

/**
 * Detects Oracle Object Tables (tables based on User-Defined Types)
 * and stores them in the cache layer to facilitate customized routing.
 * @param {Object} connection - Active node-oracledb connection instance
 * @param {string} schemaName - Target Oracle Schema owner to analyze
 * @returns {Promise<Array>} Array of objects containing tableName properties
 */
async function getObjectTables(connection, schemaName) {
    // Normalize key name to match migrate.js implementation requirements
    const cacheKey = `getObjectTables:${schemaName}`;
    const cachedResult = cacheService.get(cacheKey);

    if (cachedResult) {
        logger.info(`Returning object tables for '${schemaName}' from cache.`);
        return cachedResult;
    }

    logger.info(`getObjectTables execution initiated for schema: ${schemaName}`);

    try {
        // Shivanand's discovery query adapted for oracledb parameters safely
        const query = `
      SELECT table_name, table_type
      FROM dba_object_tables
      WHERE owner = :owner
      ORDER BY table_name
    `;

        const result = await connection.execute(
            query,
            [schemaName.toUpperCase()], // Oracle data dictionaries store schemas in UPPERCASE
            { outFormat: require('oracledb').OUT_FORMAT_OBJECT }
        );

        const rows = Array.isArray(result.rows) ? result.rows : [];
        const objectTables = [];

        for (const row of rows) {
            // Map properties securely handling both uppercase/lowercase driver properties
            const TABLE_NAME = row.TABLE_NAME || row.table_name;

            if (TABLE_NAME) {
                objectTables.push({ tableName: TABLE_NAME });
            }
        }

        // Set value to cache to prevent redundant structural scans
        cacheService.set(cacheKey, objectTables);
        logger.info(`getObjectTables analysis finished. Identified ${objectTables.length} Object Tables.`);

        return objectTables;

    } catch (error) {
        logger.error('Critical failure encountered in getObjectTables execution:', error);
        throw error;
    }
}

module.exports = { getObjectTables };
