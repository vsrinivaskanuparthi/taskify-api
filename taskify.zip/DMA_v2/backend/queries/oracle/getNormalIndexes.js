'use strict';

const cacheService = require('../../utils/cache');
const logger = require('../../utils/logger');

/**
 * Fetches all non-constraint normal indexes for the given schema with optimized catalog scans.
 * @param {object} connection - Oracle DB connection.
 * @param {string} schemaName - Target schema owner.
 * @returns {Promise<Array>} Array of index objects.
 */
async function getNormalIndexes(connection, schemaName) {
  const cacheKey = `getNormalIndexes:${schemaName}`;

  const cachedResult = cacheService.get(cacheKey);
  if (cachedResult) {
    logger.info(`Returning oracle normal indexes '${schemaName}' from cache.`);
    return cachedResult;
  }

  logger.info(`getNormalIndexes view scan initiated for schema: ${schemaName}`);

  try {
    // OPTIMIZATION: Dropped the nested all_constraints subquery join.
    // Filtering i.generated = 'N' bypasses system-backed primary/unique key indexes instantly.
    const query = `
      WITH filtered_constraints AS (
        SELECT /*+ MATERIALIZE */ constraint_name
        FROM dba_constraints
        WHERE owner = :owner
      )
      SELECT
        i.index_name,
        i.table_name
      FROM
          dba_indexes i
      WHERE
        i.owner = :owner
        AND i.index_type = 'NORMAL'
        AND i.table_name NOT IN (SELECT table_name FROM dba_tables WHERE owner = :owner AND secondary = 'Y')
        AND NOT EXISTS (
          SELECT 1
          FROM filtered_constraints c
          WHERE c.constraint_name = i.index_name
        )
      ORDER BY
        i.index_name
    `;

    const result = await connection.execute(
      query,
      { owner: schemaName.toUpperCase() }, // Securely pass schema binding using absolute upper-casing
      {
        // FIX: Ensure object structure matches the rest of the application ecosystem
        outFormat: require('oracledb').OUT_FORMAT_OBJECT,
        // Drastically improves buffer sizes for high-volume metadata ingestion rows
        maxRows: 150000
      }
    );

    const indexes = Array.isArray(result.rows) ? result.rows : [];

    cacheService.set(cacheKey, indexes);
    logger.info(`getNormalIndexes execution completed. Found ${indexes.length} custom normal indexes.`);
    return indexes;

  } catch (error) {
    logger.error(`Critical error encountered within getNormalIndexes catalog lookup:`, error);
    throw error;
  }
}

module.exports = { getNormalIndexes };
