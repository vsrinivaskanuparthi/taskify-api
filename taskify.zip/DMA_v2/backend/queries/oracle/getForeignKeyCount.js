const cacheService = require('../../utils/cache');
const logger = require('../../utils/logger');

/**
 * Retrieves the count of foreign key constraints for the specified schema.
 * @param {object} connection - Oracle DB connection object.
 * @returns {Promise<number>} - The count of foreign key constraints.
 */
async function getForeignKeyCount(connection, schemaName) {
  // Use parameterized queries to prevent SQL injection
  const cacheKey = `getForeignKeyCount:${schemaName}`;

  // 2. Check the cache first
  const cachedResult = cacheService.get(cacheKey);
  if (cachedResult) {
    logger.info(`Returning primiary key count '${schemaName}' from cache.`);
    return cachedResult;
  }

  const query = `
    SELECT COUNT(*) AS foreign_key_count
    FROM dba_constraints
    WHERE constraint_type = 'R' AND owner = :owner
  `;

  try {
    const result = await connection.execute(
      query,
      [schemaName],
      { resultSet: true }
    );

    // Extract the count from the resultSet
    const resultSet = result.resultSet;
    const row = await resultSet.getRow();
    await resultSet.close();
    const foreignKeyCount = row ? row[0] : 0;
    cacheService.set(cacheKey, foreignKeyCount)
    return foreignKeyCount;
  } catch (error) {
    throw error;
  }
}

module.exports = { getForeignKeyCount };
