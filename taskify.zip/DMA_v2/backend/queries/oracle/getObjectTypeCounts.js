const logger = require("../../utils/logger");
const cacheService = require('../../utils/cache');

/**
 * Queries the database for object type counts for a specific schema.
 * @param {object} connection - The database connection object.
 * @returns {Promise<void>}
 */
async function getObjectTypeCounts(connection, schemaName) {
    // 1. Create a schema-specific cache key
    const cacheKey = `getObjectTypeCounts:${schemaName}`;

    // 2. Check the cache first
    const cachedResult = cacheService.get(cacheKey);
    if (cachedResult) {
        logger.info(`Returning oracle object type counts '${schemaName}' from cache.`);
        return cachedResult;
    }

    logger.info("getObjectTypeCounts execution started");
    const objectTypeCounts = [];
    const query = `
        SELECT object_type, COUNT(*)
        FROM dba_objects
        WHERE OWNER = :owner
        GROUP BY object_type
    `;

    let resultSet;
    try {
        const result = await connection.execute(
            query,
            [schemaName],
            { resultSet: true }
        );

        resultSet = result.resultSet;
        for await (const row of resultSet) {
            objectTypeCounts.push(row);
        }

        await resultSet.close();
        cacheService.set(cacheKey, objectTypeCounts);
        logger.info("getObjectTypeCounts execution completed");
        return objectTypeCounts;
    } catch (error) {
        logger.error("getObjectTypeCounts error occurred", error);
        throw error;
    }
}

module.exports = { getObjectTypeCounts };
