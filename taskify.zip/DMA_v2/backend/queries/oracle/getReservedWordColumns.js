const { CONSTANTS } = require('../../utils/constants.js');
const logger = require('../../utils/logger.js');
const cacheService = require('../../utils/cache.js');

/**
 * Columns of the schema whose name is a PostgreSQL reserved word.
 * v2: limited to the selected schema (v1 scanned the columns of every schema in the database),
 * and the word list is the real PostgreSQL reserved list (v1's list had entries with trailing
 * spaces that never matched). Result rows: [table, column, owner, id] as in v1.
 */
async function getReservedWordColumns(connection, schemaName) {
  const cacheKey = `getReservedWordColumns:${schemaName}`;
  const cachedResult = cacheService.get(cacheKey);
  if (cachedResult) {
    return cachedResult;
  }

  logger.info('getReservedWordColumns execution started');
  const words = CONSTANTS.RESERVED_WORDS.map((w) => w.trim().toUpperCase());
  const binds = { owner: schemaName };
  words.forEach((w, i) => { binds[`w${i}`] = w; });

  const result = await connection.execute(
    `SELECT c.table_name, c.column_name, c.owner
       FROM dba_tab_columns c
       JOIN dba_tables t ON t.owner = c.owner AND t.table_name = c.table_name
      WHERE c.owner = :owner
        AND t.secondary = 'N'
        AND UPPER(c.column_name) IN (${words.map((_, i) => `:w${i}`).join(', ')})
      ORDER BY c.table_name, c.column_id`,
    binds,
  );
  const reservedColumns = result.rows.map((r, i) => [r[0], r[1], r[2], i + 1]);

  cacheService.set(cacheKey, reservedColumns);
  logger.info('getReservedWordColumns execution completed');
  return reservedColumns;
}

module.exports = { getReservedWordColumns };
