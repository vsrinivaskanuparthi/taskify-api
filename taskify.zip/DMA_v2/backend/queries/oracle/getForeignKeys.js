const logger = require("../../utils/logger");
const cacheService = require('../../utils/cache');

// Function to fetch foreign key relationships for a given schema
async function getForeignKeys(connection, schemaName) {
  // 1. Create a schema-specific cache key
  const cacheKey = `getForeignKeys:${schemaName}`;

  // 2. Check the cache first
  const cachedResult = cacheService.get(cacheKey);
  if (cachedResult) {
    logger.info(`Returning foreign keys for schema '${schemaName}' from cache.`);
    return cachedResult;
  }

  const fkeysMap = new Map();

  const query = `
    SELECT
      pk.table_name AS primary_table,
      fk.table_name AS foreign_table
    FROM
      dba_constraints pk
      JOIN dba_constraints fk ON pk.constraint_name = fk.r_constraint_name AND pk.owner = fk.r_owner
    WHERE
      pk.constraint_type = 'P'
      AND fk.constraint_type = 'R'
      AND pk.owner = :schemaName
      AND fk.owner = :schemaName
  `;

  logger.info("getForeignKeys execution started");

  try {
    const result = await connection.execute(
      query,
      { schemaName },
      { resultSet: true }
    );
    const resultSet = result.resultSet;

    for await (const row of resultSet) {
      const primaryTable = row[0];
      const foreignTable = row[1];

      if (!fkeysMap.has(primaryTable)) {
        fkeysMap.set(primaryTable, []);
      }
      fkeysMap.get(primaryTable).push(foreignTable);
    }
    await resultSet.close();

    // Convert Map to array and index mapping for compatibility
    const fkeys_list = Array.from(fkeysMap.values());
    const present = {};
    Array.from(fkeysMap.keys()).forEach((table, idx) => {
      present[table] = idx;
    });

    const response = [fkeys_list, present];
    cacheService.set(cacheKey, response);

    logger.info("getForeignKeys execution completed");
    return response;
  } catch (err) {
    logger.error("getForeignKeys execution error:", err);
    throw err;
  }
}

module.exports = { getForeignKeys };
