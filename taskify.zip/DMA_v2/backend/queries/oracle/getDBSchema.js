const logger = require('../../utils/logger');

async function getDBSchema(connection) {
  logger.info('getDBSchema execution started');
  try {
    const result = await connection.execute(
      `SELECT USERNAME
       FROM ALL_USERS
       WHERE USERNAME NOT IN ('SYSTEM','CTXSYS','DBSNMP','EXFSYS','LBACSYS','MDSYS','MGMT_VIEW',
        'OLAPSYS','ORDDATA','OWBSYS','ORDPLUGINS','ORDSYS','OUTLN',
        'SI_INFORMTN_SCHEMA','SYS','SYSMAN','WK_TEST','WKSYS','WKPROXY',
        'WMSYS','XDB','APEX_PUBLIC_USER','DIP','FLOWS_020100','FLOWS_030000',
        'FLOWS_040100','FLOWS_010600','FLOWS_FILES','MDDATA','ORACLE_OCM',
        'SPATIAL_CSW_ADMIN_USR','SPATIAL_WFS_ADMIN_USR','SYSDG','SYSKM','SYSRAC','SYS$UMF','SYSBACKUP','GSMUSER','GSMCATUSER','GGSYS','REMOTE_SCHEDULER_AGENT','XS$NULL','PERFSTAT','SQLTXPLAIN','DMSYS','TSMSYS',
        'DVSYS','OJVMSYS','GSMADMIN_INTERNAL','APPQOSSYS','DVSYS','DVF',
        'AUDSYS','APEX_030200','MGMT_VIEW','ODM','ODM_MTR','TRACESRV','MTMSYS',
        'OWBSYS_AUDIT','WEBSYS','WK_PROXY','OSE$HTTP$ADMIN','AURORA$JIS$UTILITY$','AURORA$ORB$UNAUTHENTICATED','DBMS_PRIVILEGE_CAPTURE','CSMIG','MGDSYS','SDE','DBSFWUSER','PING','ANONYMOUS','OPS$ORACLE','RDSADMIN','ADMIN')
        ORDER BY USERNAME`,
      [],
      {
        resultSet: true,
      }
    );

    const rs = result.resultSet;
    const databaseSchema = [];
    if (databaseSchema.length == 0) {
      for await (const row of rs) {
        databaseSchema.push(row);
      }
    }
    logger.info('getDBSchema execution completed');
    return databaseSchema;
  } catch (error) {
    logger.error('getDBSchema error occurred', error);
    throw error;
  }
}
module.exports = { getDBSchema };
