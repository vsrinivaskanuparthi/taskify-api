const logger = require("../../utils/logger");
const { getDbLinks } = require("./getDbLinks");

/**
 * Deeper checks for the migration analysis report (on top of the snapshot).
 * Every check is independent: a missing privilege on one dictionary view only drops that check.
 * All queries filter on the owner and use DBA_* views, like the snapshot queries.
 */

// PL/SQL features that need attention in PostgreSQL. `like` is matched on UPPER(text) of DBA_SOURCE.
// Real application tables only: no Oracle Text (DR$) tables, recycle bin or materialized view containers.
const notMview = (alias, col = 'table_name') => `NOT EXISTS (SELECT 1 FROM dba_mviews mv WHERE mv.owner = ${alias}.owner AND mv.mview_name = ${alias}.${col})`;

const PLSQL_FEATURES = [
  { key: 'AUTONOMOUS_TRANSACTION', like: '%AUTONOMOUS_TRANSACTION%' },
  { key: 'UTL_FILE', like: '%UTL_FILE%' },
  { key: 'UTL_HTTP', like: '%UTL_HTTP%' },
  { key: 'UTL_MAIL_SMTP', like: '%UTL_SMTP%', or: '%UTL_MAIL%' },
  { key: 'DBMS_SCHEDULER_JOB', like: '%DBMS_SCHEDULER%', or: '%DBMS_JOB%' },
  { key: 'DBMS_AQ', like: '%DBMS_AQ%' },
  { key: 'DBMS_SQL', like: '%DBMS_SQL%' },
  { key: 'EXECUTE_IMMEDIATE', like: '%EXECUTE IMMEDIATE%' },
  { key: 'CONNECT_BY', like: '%CONNECT BY%' },
  { key: 'BULK_COLLECT', like: '%BULK COLLECT%', or: '%FORALL %' },
  { key: 'PIPELINED', like: '%PIPELINED%' },
  { key: 'MERGE', like: '%MERGE INTO%' },
  { key: 'OUTER_JOIN_PLUS', like: '%(+)%' },
  { key: 'ROWNUM', like: '%ROWNUM%' },
  { key: 'DBMS_LOB', like: '%DBMS_LOB%' },
  { key: 'DBMS_CRYPTO', like: '%DBMS_CRYPTO%', or: '%DBMS_OBFUSCATION%' },
  { key: 'DBMS_OUTPUT', like: '%DBMS_OUTPUT%' },
  { key: 'REF_CURSOR', like: '%SYS_REFCURSOR%', or: '%REF CURSOR%' },
  { key: 'GLOBAL_TEMP_USE', like: '%GLOBAL TEMPORARY%' },
];

const checks = {
  async charset(c) {
    const r = await c.execute(`SELECT parameter, value FROM nls_database_parameters WHERE parameter IN ('NLS_CHARACTERSET','NLS_NCHAR_CHARACTERSET')`);
    return Object.fromEntries(r.rows);
  },

  async dataTypes(c, owner) {
    const r = await c.execute(
      `SELECT c.data_type, COUNT(*), COUNT(DISTINCT c.table_name)
         FROM dba_tab_columns c
         JOIN dba_tables t ON t.owner = c.owner AND t.table_name = c.table_name
        WHERE c.owner = :owner AND t.secondary = 'N' AND t.table_name NOT LIKE 'DR$%' AND ${notMview('t')}
        GROUP BY c.data_type ORDER BY 2 DESC`, { owner });
    return r.rows.map(([type, columns, tables]) => ({ type, columns, tables }));
  },

  /** Columns whose type needs a decision (LONG, BFILE, XMLTYPE, spatial, object types, ROWID, NUMBER without precision…). */
  async riskyColumns(c, owner) {
    const r = await c.execute(
      `SELECT c.table_name, c.column_name, c.data_type, c.data_type_owner, c.data_precision, c.data_scale
         FROM dba_tab_columns c
         JOIN dba_tables t ON t.owner = c.owner AND t.table_name = c.table_name
        WHERE c.owner = :owner AND t.secondary = 'N' AND t.table_name NOT LIKE 'DR$%' AND ${notMview('t')}
          AND (c.data_type IN ('LONG','LONG RAW','BFILE','XMLTYPE','SDO_GEOMETRY','ANYDATA','URITYPE','ROWID','UROWID','RAW')
               OR c.data_type LIKE 'TIMESTAMP%LOCAL TIME ZONE' OR c.data_type LIKE 'INTERVAL%'
               OR (c.data_type = 'NUMBER' AND c.data_precision IS NULL AND c.data_scale IS NULL)
               OR (c.data_type_owner IS NOT NULL AND c.data_type_owner NOT IN ('SYS','PUBLIC','MDSYS')))
        ORDER BY c.table_name, c.column_id`, { owner });
    return r.rows.map(([table, column, type, typeOwner, precision, scale]) => ({ table, column, type, typeOwner, precision, scale }));
  },

  /** Flag columns that may be booleans in the application: NUMBER(1) and 1-character strings. */
  async booleanCandidates(c, owner) {
    const r = await c.execute(
      `SELECT c.table_name, c.column_name, c.data_type
         FROM dba_tab_columns c
         JOIN dba_tables t ON t.owner = c.owner AND t.table_name = c.table_name
        WHERE c.owner = :owner AND t.secondary = 'N' AND t.table_name NOT LIKE 'DR$%' AND ${notMview('t')}
          AND ((c.data_type = 'NUMBER' AND c.data_precision = 1 AND NVL(c.data_scale, 0) = 0)
               OR (c.data_type IN ('CHAR', 'VARCHAR2', 'NCHAR', 'NVARCHAR2') AND c.char_length = 1))
        ORDER BY c.table_name, c.column_id`, { owner });
    return r.rows.map(([table, column, type]) => ({ table, column, type: type === 'NUMBER' ? 'NUMBER(1)' : `${type}(1)` }));
  },

  async virtualColumns(c, owner) {
    const r = await c.execute(
      `SELECT table_name, column_name FROM dba_tab_cols
        WHERE owner = :owner AND virtual_column = 'YES' AND hidden_column = 'NO' AND table_name NOT LIKE 'BIN$%' AND ${notMview('dba_tab_cols')}
        ORDER BY table_name`, { owner });
    return r.rows.map(([table, column]) => ({ table, column }));
  },

  async tableFeatures(c, owner) {
    const r = await c.execute(
      `SELECT table_name, temporary, iot_type, NVL(compression,'DISABLED'), partitioned, NVL(cluster_name,'-')
         FROM dba_tables
        WHERE owner = :owner AND secondary = 'N' AND table_name NOT LIKE 'DR$%' AND table_name NOT LIKE 'BIN$%' AND ${notMview('dba_tables')}
          AND (temporary = 'Y' OR iot_type IS NOT NULL OR compression = 'ENABLED' OR cluster_name IS NOT NULL)`, { owner });
    return r.rows.map(([table, temporary, iot, compression, partitioned, cluster]) => ({ table, temporary: temporary === 'Y', iot, compression, partitioned, cluster }));
  },

  async partitions(c, owner) {
    const r = await c.execute(
      `SELECT p.table_name, p.partitioning_type, p.subpartitioning_type, p.partition_count, NVL(p.interval,'-'),
              (SELECT COUNT(*) FROM dba_tab_partitions tp WHERE tp.table_owner = p.owner AND tp.table_name = p.table_name)
         FROM dba_part_tables p WHERE p.owner = :owner ORDER BY p.table_name`, { owner });
    return r.rows.map(([table, type, subType, declared, interval, partitions]) => ({ table, type, subType, interval: interval === '-' ? null : interval, partitions: partitions || declared }));
  },

  async indexTypes(c, owner) {
    const r = await c.execute(
      `SELECT index_type, COUNT(*)
         FROM dba_indexes i WHERE i.owner = :owner AND i.table_name NOT LIKE 'DR$%' AND i.index_type <> 'LOB' AND ${notMview('i')} GROUP BY index_type`, { owner });
    const list = await c.execute(
      `SELECT index_type, table_name, index_name FROM dba_indexes i
        WHERE i.owner = :owner AND i.table_name NOT LIKE 'DR$%' AND ${notMview('i')}
          AND index_type IN ('BITMAP','FUNCTION-BASED BITMAP','NORMAL/REV','DOMAIN','FUNCTION-BASED NORMAL','IOT - TOP','CLUSTER')
        ORDER BY index_type, table_name`, { owner });
    return {
      counts: r.rows.map(([type, n]) => ({ type, count: n })),
      special: list.rows.map(([type, table, index]) => ({ type, table, index })),
    };
  },

  /** Primary key shape per table: huge tables are chunked only on a single numeric key. */
  async primaryKeys(c, owner) {
    const r = await c.execute(
      `SELECT k.table_name, COUNT(*), MAX(tc.data_type)
         FROM dba_constraints k
         JOIN dba_cons_columns cc ON cc.owner = k.owner AND cc.constraint_name = k.constraint_name
         JOIN dba_tab_columns tc ON tc.owner = cc.owner AND tc.table_name = cc.table_name AND tc.column_name = cc.column_name
        WHERE k.owner = :owner AND k.constraint_type = 'P' AND k.table_name NOT LIKE 'DR$%' AND k.table_name NOT LIKE 'BIN$%' AND ${notMview('k')}
        GROUP BY k.table_name`, { owner });
    return r.rows.map(([table, columns, type]) => ({ table, columns, type }));
  },

  async invalidObjects(c, owner) {
    const r = await c.execute(
      `SELECT object_type, object_name FROM dba_objects
        WHERE owner = :owner AND status = 'INVALID' ORDER BY object_type, object_name`, { owner });
    return r.rows.map(([type, name]) => ({ type, name }));
  },

  /** One pass over DBA_SOURCE: lines per object and which risky features each object uses. */
  async plsql(c, owner) {
    const cols = PLSQL_FEATURES.map((f, i) =>
      `MAX(CASE WHEN UPPER(text) LIKE '${f.like}'${f.or ? ` OR UPPER(text) LIKE '${f.or}'` : ''} THEN 1 ELSE 0 END) f${i}`).join(',\n              ');
    const r = await c.execute(
      `SELECT type, name, COUNT(*) lines,
              ${cols}
         FROM dba_source
        WHERE owner = :owner AND type IN ('PACKAGE','PACKAGE BODY','PROCEDURE','FUNCTION','TRIGGER','TYPE BODY')
        GROUP BY type, name`, { owner });
    return r.rows.map(([type, name, lines, ...flags]) => ({
      type, name, lines,
      features: PLSQL_FEATURES.filter((_, i) => flags[i] === 1).map((f) => f.key),
    }));
  },

  async triggers(c, owner) {
    const r = await c.execute(
      `SELECT trigger_name, trigger_type, triggering_event, base_object_type, NVL(table_name,'-')
         FROM dba_triggers WHERE owner = :owner ORDER BY trigger_name`, { owner });
    return r.rows.map(([name, type, event, baseType, table]) => ({ name, type, event, baseType, table }));
  },

  async jobs(c, owner) {
    const out = [];
    const s = await c.execute(
      `SELECT job_name, job_type, NVL(repeat_interval,'-'), enabled FROM dba_scheduler_jobs WHERE owner = :owner`, { owner });
    s.rows.forEach(([name, type, interval, enabled]) => out.push({ name, kind: 'SCHEDULER', type, interval, enabled }));
    try {
      const j = await c.execute(`SELECT TO_CHAR(job), SUBSTR(what,1,200), NVL(interval,'-'), broken FROM dba_jobs WHERE schema_user = :owner`, { owner });
      j.rows.forEach(([name, what, interval, broken]) => out.push({ name: `JOB ${name}`, kind: 'DBMS_JOB', type: what, interval, enabled: broken === 'N' ? 'TRUE' : 'FALSE' }));
    } catch { /* DBA_JOBS is gone in 23ai */ }
    return out;
  },

  async mviews(c, owner) {
    const r = await c.execute(
      `SELECT mview_name, refresh_mode, refresh_method, NVL(TO_CHAR(last_refresh_date,'YYYY-MM-DD'),'-')
         FROM dba_mviews WHERE owner = :owner ORDER BY mview_name`, { owner });
    return r.rows.map(([name, mode, method, lastRefresh]) => ({ name, mode, method, lastRefresh }));
  },

  async crossSchema(c, owner) {
    const r = await c.execute(
      `SELECT referenced_owner, referenced_type, COUNT(DISTINCT name), COUNT(DISTINCT referenced_name)
         FROM dba_dependencies
        WHERE owner = :owner AND referenced_owner NOT IN (:owner, 'SYS', 'PUBLIC', 'SYSTEM', 'MDSYS', 'CTXSYS', 'XDB')
          AND referenced_link_name IS NULL
        GROUP BY referenced_owner, referenced_type ORDER BY 3 DESC`, { owner });
    return r.rows.map(([refOwner, refType, objects, referenced]) => ({ refOwner, refType, objects, referenced }));
  },

  dbLinks: (c, owner) => getDbLinks(c, owner),

  async synonyms(c, owner) {
    const r = await c.execute(
      `SELECT owner, synonym_name, table_owner, table_name, NVL(db_link,'-') FROM dba_synonyms
        WHERE owner = :owner OR (owner = 'PUBLIC' AND table_owner = :owner) ORDER BY owner, synonym_name`, { owner });
    return r.rows.map(([synOwner, name, tableOwner, table, link]) => ({ owner: synOwner, name, tableOwner, table, dbLink: link === '-' ? null : link }));
  },
};

async function getMigrationComplexity(connection, owner, onStep) {
  logger.info('getMigrationComplexity execution started');
  const result = { failed: [] };
  for (const [key, fn] of Object.entries(checks)) {
    const t0 = Date.now();
    try {
      result[key] = await fn(connection, owner);
    } catch (err) {
      logger.warn(`Analysis check ${key} failed: ${err.message}`);
      result[key] = null;
      result.failed.push({ check: key, error: err.message });
    }
    if (onStep) onStep(key, Date.now() - t0);
  }
  return result;
}

module.exports = { getMigrationComplexity, PLSQL_FEATURES, CHECK_KEYS: Object.keys(checks) };
