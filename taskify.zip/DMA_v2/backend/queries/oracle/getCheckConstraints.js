const cacheService = require('../../utils/cache');
const logger = require('../../utils/logger');

/**
 * Fetches all check constraints for nullable columns in the specified schema.
 * @param {object} connection - Oracle DB connection object.
 * @returns {Promise<Array>} Array of check constraint objects.
 */
async function getCheckConstraints(connection, schemaName) {
  // 1. Create a schema-specific cache key
  const cacheKey = `getCheckConstraints:${schemaName}`;

  // 2. Check the cache first
  const cachedResult = cacheService.get(cacheKey);
  if (cachedResult) {
    logger.info(`Returning check constraints '${schemaName}' from cache.`);
    return cachedResult;
  }

  const checkConstraints = [];
  const query = `
    SELECT DISTINCT
      ac.constraint_name,
      ac.table_name,
      'CHECK' AS constraint_type
    FROM
      dba_constraints ac
      JOIN dba_cons_columns acc
        ON ac.constraint_name = acc.constraint_name
        AND ac.owner = acc.owner
      JOIN dba_tab_columns tc
        ON acc.table_name = tc.table_name
        AND ac.owner = tc.owner
        AND acc.column_name = tc.column_name
    WHERE
      ac.constraint_type = 'C'
      AND ac.owner = :owner
      AND tc.nullable = 'Y'
      AND ac.constraint_name NOT LIKE 'SYS_C%'
      AND ac.generated <> 'GENERATED NAME'
      AND NOT EXISTS (
        SELECT 1
        FROM dba_cons_columns acc_inner
        WHERE acc_inner.constraint_name = acc.constraint_name
          AND acc_inner.owner = acc.owner
          AND acc_inner.position = 1
          AND acc_inner.column_name IS NULL
      )
  `;

  try {
    const result = await connection.execute(
      query,
      { owner: schemaName },
      { resultSet: true }
    );
    const resultSet = result.resultSet;
    for await (const row of resultSet) {
      checkConstraints.push({
        constraintName: row[0],
        tableName: row[1],
        constraintType: row[2],
      });
    }
    await resultSet.close();
    cacheService.set(cacheKey, checkConstraints);
    return checkConstraints;
  } catch (error) {
    throw error;
  }
}

module.exports = { getCheckConstraints };
