const cacheService = require('../../utils/cache');
const logger = require('../../utils/logger');

/**
 * Fetches all unique constraints and their columns for the given schema.
 * @param {object} connection - Oracle DB connection.
 * @returns {Promise<Array>} Array of objects with table_name, column_name, and constraint_type.
 */
async function fetchUniqueConstraints(connection, schemaName) {
  // 1. Create a schema-specific cache key
  const cacheKey = `fetchUniqueConstraints:${schemaName}`;

  // 2. Check the cache first
  const cachedResult = cacheService.get(cacheKey);
  if (cachedResult) {
    logger.info(`Returning unique constraints '${schemaName}' from cache.`);
    return cachedResult;
  }

  const uniqueConstraints = [];
  const query = `
    SELECT DISTINCT
      ac.table_name,
      acc.column_name,
      'UNIQUE' AS constraint_type
    FROM
      dba_constraints ac
    JOIN
      dba_cons_columns acc
      ON ac.constraint_name = acc.constraint_name
      AND ac.owner = acc.owner
    WHERE
      ac.constraint_type = 'U'
      AND ac.owner = :schemaName
  `;

  try {
    const result = await connection.execute(
      query,
      [schemaName],
      { resultSet: true }
    );

    const resultSet = result.resultSet;
    for await (const row of resultSet) {
      uniqueConstraints.push({
        table_name: row[0],
        column_name: row[1],
        constraint_type: row[2]
      });
    }
    await resultSet.close(); // Close resultSet immediately after use
    cacheService.set(cacheKey, uniqueConstraints)
    return uniqueConstraints;
  } catch (error) {
    throw error;
  }
}

module.exports = { fetchUniqueConstraints };
