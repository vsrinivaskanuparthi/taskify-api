#!/bin/bash

# Input file
input_file="$1"
output_file="modified_$input_file"

# Make sure the input file exists
if [[ ! -f "$input_file" ]]; then
  echo "Input file does not exist!"
  exit 1
fi

# Clear output file if it exists
> "$output_file"

# Process the file and replace the relevant lines
while IFS= read -r line; do
  if [[ "$line" =~ CREATE\ INDEX.*USING\ gin.*to_tsvector ]]; then
    # Extract index name, table name, and column name
    index_name=$(echo "$line" | sed -n 's/.*CREATE INDEX \([^ ]*\) ON.*/\1/p')
    table_name=$(echo "$line" | sed -n 's/.*ON \([^ ]*\) USING.*/\1/p')
    column_name=$(echo "$line" | sed -n "s/.*to_tsvector('english', \([^)]*\)).*/\1/p")

    # Add the ALTER, UPDATE, and CREATE INDEX lines
    echo "ALTER TABLE $table_name ADD COLUMN ${column_name}_text text;" >> "$output_file"
    echo "UPDATE $table_name SET ${column_name}_text = encode(lo_get($column_name), 'escape');" >> "$output_file"
    echo "CREATE INDEX $index_name ON $table_name USING gin(to_tsvector('english', ${column_name}_text));" >> "$output_file"
  else
    # Copy all other lines unchanged to the output file
    echo "$line" >> "$output_file"
  fi
done < "$input_file"

# Output message
echo "The SQL file has been modified and saved as: $output_file"
