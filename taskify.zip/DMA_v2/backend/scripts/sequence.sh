#!/bin/bash

# --- Argument Validation ---
if [[ $# -ne 2 ]]; then
  echo "Error: Incorrect number of arguments."
  echo "Usage: $0 <input_file> <output_file>"
  exit 1
fi

# --- Variable Assignments ---
INPUT_FILE=$1
OUTPUT_FILE=$2

# --- File Validation ---
# Check if the input file exists and is readable
if [[ ! -f "$INPUT_FILE" ]]; then
  echo "Error: Input file '$INPUT_FILE' not found!"
  exit 1
fi

# --- Script Execution ---

# Create or clear the output file to ensure it's fresh
> "$OUTPUT_FILE"

# Declare an associative array to track sequence names that have already been processed
declare -A sequence_seen

echo "Processing '$INPUT_FILE' to remove duplicate sequences..."

# --- 1. SETTING CHANGES ---
# Turn on case-insensitive matching, as intended by the script's original comment.
shopt -s nocasematch
# Store the complex regex in a variable to avoid quoting issues.
regex='^CREATE SEQUENCE ([a-zA-Z0-9_."]+)'

# Read the input file line by line
while IFS= read -r line; do
  # --- 2. MODIFIED IF STATEMENT ---
  # Check if the line matches the regex stored in the variable.
  if [[ "$line" =~ $regex ]]; then
    # Extract the sequence name from the line using the BASH_REMATCH array
    sequence_name="${BASH_REMATCH[1]}"

    # Check if this sequence name has already been seen
    if [[ -z "${sequence_seen[$sequence_name]}" ]]; then
      # If not seen, write the line to the output file
      echo "$line" >> "$OUTPUT_FILE"
      # Mark this sequence name as seen to prevent future duplicates
      sequence_seen["$sequence_name"]=1
    else
      # If it's a duplicate, print a message and skip writing the line
      echo "Duplicate sequence found and removed: $sequence_name"
    fi
  else
    # If the line is not a "CREATE SEQUENCE" statement, write it directly to the output file
    echo "$line" >> "$OUTPUT_FILE"
  fi
done < "$INPUT_FILE"

# --- 3. REVERTING CHANGES ---
# It's good practice to turn off the shell option when you're done.
shopt -u nocasematch

echo "Processing complete. Cleaned file is saved as '$OUTPUT_FILE'."
