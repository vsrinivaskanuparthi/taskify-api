#!/bin/bash
find $1 -type f -name 'lo_import*.sh' -exec basename \{} .po \; | while read fname; do
  echo "$fname"
  ### Make a copy of the original files ####
  cp $1/$fname $1/$fname.copy
  mv $1/$fname $1/$fname.txt
  # Remove duplicate lines
  awk '!a[$0]++' $1/$fname.txt > $1/$fname
  # Remove specific lines
  sed -i '/NULL/d' $1/$fname
  sed -i '/${ret}a"/d'  $1/$fname
  # Update SQL commands and add conditionals
  sed -i "/UPDATE/s/\= /='/2" $1/$fname
  sed -i "/UPDATE/s/.$/'/" $1/$fname
  sed -i '/UPDATE/s/$/"/' $1/$fname
  # Insert 'if' condition and 'fi' around the ret commands without printing the if condition
  sed -i '/ret=`psql/ {
    N;  # Read the next line into the pattern space
    s/\(.*\)\n\(.*\)/\1\nif [ "${ret}a" != "a" ]; then\n\2\nfi/
  }' $1/$fname
  # Modify PostgreSQL connection commands
  sed -i 's/psql/PGPASSWORD=$1 psql -U $2 -d $3 -h $4 -p $5/g'  $1/$fname
  sed -i '2 i PGDATABASE=$3' $1/$fname
  # Uncomment to remove the temporary .txt file after processing
  #rm $1/$fname.txt
done
