#!/bin/bash

# --- 1. Argument Validation ---
# Check for exactly two arguments: input file and output file.
if [[ $# -ne 2 ]]; then
  echo "Error: Incorrect number of arguments."
  echo "Usage: $0 <input_sql_file> <output_sql_file>"
  exit 1
fi

# --- 2. Variable Assignments ---
# Assign arguments to variables for clarity.
input_file="$1"
output_file="$2"

# Make sure the input file exists
if [[ ! -f "$input_file" ]]; then
  echo "Error: Input file '$input_file' does not exist!"
  exit 1
fi

# Clear output file if it exists
> "$output_file"

echo "Processing '$input_file'..."

# Define the regular expression in a variable to avoid syntax errors
regex="CREATE INDEX ([^ ]+) ON ([^ ]+) USING gin\(to_tsvector\('english', ([^)]+)\)\)"

# Process the file and replace the relevant lines
while IFS= read -r line; do

  # Use the variable in the conditional statement
  if [[ "$line" =~ $regex ]]; then

    # BASH_REMATCH is an array that holds the captured groups from the regex
    index_name="${BASH_REMATCH[1]}"
    table_name="${BASH_REMATCH[2]}"
    column_name="${BASH_REMATCH[3]}"

    # Add the ALTER, UPDATE, and CREATE INDEX lines
    echo "ALTER TABLE $table_name ADD COLUMN ${column_name}_text text;" >> "$output_file"
    echo "UPDATE $table_name SET ${column_name}_text = encode($column_name, 'escape');" >> "$output_file"
    echo "CREATE INDEX $index_name ON $table_name USING gin(to_tsvector('english', ${column_name}_text));" >> "$output_file"
  else
    # Copy all other lines unchanged to the output file
    echo "$line" >> "$output_file"
  fi
done < "$input_file"

# Output message
echo "Processing complete. Modified SQL saved to: $output_file"
