'use strict';

const fs = require('fs').promises;
const path = require('path');
const logger = require('../utils/logger');
const { CONSTANTS } = require('../utils/constants');

/**
 * Accepts the connection formats users paste:
 *   (DESCRIPTION=...(HOST=h)(PORT=p)...(SID=x))   or (SERVICE_NAME=x)
 *   jdbc:oracle:thin:@host:port:SID               -> SID
 *   jdbc:oracle:thin:@//host:port/SERVICE          -> service name
 *   host:port/SERVICE  |  host/SERVICE            -> service name (port 1521)
 * v1 always wrote "sid=" for the short forms, which broke service names.
 */
function parseConnectionString(connectionString) {
  const s = String(connectionString || '').trim();
  if (s.startsWith('(')) {
    const host = s.match(/\(HOST\s*=\s*([^)]+)\)/i);
    const port = s.match(/\(PORT\s*=\s*([^)]+)\)/i);
    const sid = s.match(/\(SID\s*=\s*([^)]+)\)/i);
    const service = s.match(/\(SERVICE_NAME\s*=\s*([^)]+)\)/i);
    if (host && (sid || service)) {
      return { host: host[1].trim(), port: port ? port[1].trim() : '1521', type: sid ? 'sid' : 'service_name', name: (sid || service)[1].trim() };
    }
    throw new Error(`Could not parse TNS style connection string: ${s}`);
  }
  const clean = s.replace(/^jdbc:oracle:thin:@/i, '').replace(/^\/\//, '');
  let m = clean.match(/^([^:/]+):(\d+)\/(.+)$/);
  if (m) return { host: m[1], port: m[2], type: 'service_name', name: m[3] };
  m = clean.match(/^([^:/]+):(\d+):(.+)$/);
  if (m) return { host: m[1], port: m[2], type: 'sid', name: m[3] };
  m = clean.match(/^([^:/]+)\/(.+)$/);
  if (m) return { host: m[1], port: '1521', type: 'service_name', name: m[2] };
  throw new Error(`Invalid connection string format: "${s}".`);
}

function setDirective(content, key, value) {
  const re = new RegExp(`^#?\\s*${key}(\\s.*)?$`, 'gm');
  const line = `${key}\t${value}`;
  if (re.test(content)) return content.replace(re, line);
  return `${content}\n${line}\n`;
}

/**
 * Builds the ora2pg.conf for one migration run from the template in scripts/ora2pg.conf.
 * v1 rewrote one shared config file (and its ALLOW line) per table, which made parallel
 * loading impossible. v2 writes one config per run; the table list is passed with -a.
 *
 * @param {object} p
 * @param {string} p.outFile     where to write the config
 * @param {string} p.outputDir   ora2pg OUTPUT_DIR
 * @param {object} p.oracle      { userUrl, userUsername, userPassword }
 * @param {string} p.schema      Oracle schema
 * @param {object} [p.postgres]  { hostip, port, dbname, username, password } enables direct load
 * @param {object} [p.options]   { dataLimit, blobLimit, replaceCols, forData, pgSchema, directives, extra }
 *                               directives: project settings (Settings page), applied before the
 *                               engine's own settings; extra: per-export additions
 */
async function buildConfig({ outFile, outputDir, oracle, schema, postgres, options = {} }) {
  const directives = options.directives || { PRESERVE_CASE: 0 };
  const templatePath = path.join(CONSTANTS.SCRIPTS_DIR, 'ora2pg.conf');
  const parsed = parseConnectionString(oracle.userUrl);
  const host = CONSTANTS.ORA2PG_ORACLE_HOST || parsed.host;
  const port = CONSTANTS.ORA2PG_ORACLE_PORT || parsed.port;
  const { type, name } = parsed;
  let c = await fs.readFile(templatePath, 'utf8');

  c = c
    .replace(/inputvaluehost/g, host)
    .replace(/sid=inputvaluesid/g, `${type}=${name}`)
    .replace(/inputvalueport/g, port)
    .replace(/inputvalueuser/g, oracle.userUsername)
    .replace(/inputvaluepwd/g, oracle.userPassword)
    .replace(/inputvalueschema/g, schema)
    .replace(/inputlocation/g, outputDir)
    .replace(/SET search_path = inputvaluesearchpath, public;/g, '')
    .replace(/^#?\s*OWNER\s.*$/gm, '');

  const pgSchema = options.pgSchema || schema.toLowerCase();
  const settings = {
    // Schema
    EXPORT_SCHEMA: 1,
    CREATE_SCHEMA: 0, // the engine creates the schema itself
    PG_SCHEMA: pgSchema,
    FORCE_OWNER: 0,
    // Separate files for indexes, constraints and foreign keys: they are applied after the data load
    FILE_PER_INDEX: 1,
    FILE_PER_CONSTRAINT: 1,
    FILE_PER_FKEYS: 1,
    FILE_PER_TABLE: 0,
    DROP_FKEY: 0,
    // Data
    DATA_LIMIT: options.dataLimit || CONSTANTS.DATA_LIMIT,
    BLOB_LIMIT: options.blobLimit || CONSTANTS.BLOB_LIMIT,
    LONGREADLEN: 524288000,
    LOB_CHUNK_SIZE: 4194304,
    ENABLE_BLOB_EXPORT: 1,
    USE_LOB_LOCATOR: 1, // safe default: big LOBs streamed piece by piece; the engine switches to inline per table when the LOBs are small
    // Bitmap indexes as btree: GIN on a varchar needs the btree_gin extension, which the target may not allow.
    BITMAP_AS_GIN: 0,
    TRUNCATE_TABLE: 0, // the engine truncates before each (re)load
    STANDARD_CONFORMING_STRINGS: 1,
    TRANSACTION: 'readonly',
    // Errors must stop the table load so the engine sees them and retries
    STOP_ON_ERROR: 1,
    LOG_ON_ERROR: 0,
    COMMIT_ROLLBACK_ON_ERROR: 0,
    // Parallelism is passed per table on the command line (-j / -J)
    JOBS: 1,
    ORACLE_COPIES: 1,
    PARALLEL_TABLES: 1,
  };
  // DB links point at a placeholder FDW server in the exported DDL. It must NOT be set for data
  // export: ora2pg 24+ then copies the data through oracle_fdw instead of its own Oracle reader.
  if (!options.forData) settings.FDW_SERVER = 'orcl_link';
  // Data goes into the partitioned parent table and PostgreSQL routes each row to its partition,
  // instead of ora2pg writing to each partition by its Oracle name (which may not exist in PostgreSQL).
  if (options.forData) settings.DISABLE_PARTITION = 1;

  if (postgres) {
    const pgHost = CONSTANTS.ORA2PG_PG_HOST || postgres.hostip;
    const sslmode = process.env.PG_SSL === 'false' ? 'disable' : 'require';
    settings.PG_DSN = `dbi:Pg:dbname=${postgres.dbname};host=${pgHost};port=${CONSTANTS.ORA2PG_PG_PORT || postgres.port};sslmode=${sslmode}`;
    settings.PG_USER = postgres.username;
    settings.PG_PWD = postgres.password;
  }

  // The Oracle client on this server (backend/.env), instead of the template's ORACLE_HOME.
  if (process.env.ORACLE_HOME) settings.ORACLE_HOME = process.env.ORACLE_HOME;

  // Project settings first, then the engine's required settings (these always win).
  for (const [k, v] of Object.entries(directives)) c = setDirective(c, k, v);
  for (const [k, v] of Object.entries({ ...settings, ...(options.extra || {}) })) c = setDirective(c, k, v);
  if (options.forData) c = c.replace(/^\s*FDW_SERVER\s.*$/gm, '#FDW_SERVER');

  if (options.replaceCols) c = setDirective(c, 'REPLACE_COLS', options.replaceCols);

  await fs.mkdir(path.dirname(outFile), { recursive: true });
  // The config holds passwords: readable by the service user only.
  await fs.writeFile(outFile, c, { encoding: 'utf8', mode: 0o600 });
  logger.info(`config_modify: wrote run config ${outFile}`);
  return outFile;
}

module.exports = { buildConfig, parseConnectionString };
