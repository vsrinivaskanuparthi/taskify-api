'use strict';

const { EventEmitter } = require('events');

/**
 * Live updates for the browser (Server-Sent Events).
 * The migration engine and the snapshot job publish events per project; every browser tab
 * that has the project open keeps one EventSource connection to /api/projects/:p/events and
 * receives them as they happen. No polling, no intervals.
 */
const bus = new EventEmitter();
bus.setMaxListeners(0);

function publish(projectName, type, data) {
  bus.emit(projectName, { type, data, at: Date.now() });
}

/** Express handler body: keeps the response open and streams the project's events. */
function stream(req, res, projectName, initialEvents = []) {
  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache, no-transform',
    Connection: 'keep-alive',
    'X-Accel-Buffering': 'no', // stop nginx / IIS proxies from buffering the stream
  });
  res.write('retry: 3000\n\n');

  const send = (evt) => {
    res.write(`event: ${evt.type}\ndata: ${JSON.stringify(evt.data)}\n\n`);
  };
  initialEvents.forEach(send);

  bus.on(projectName, send);
  // A ping event every 15 s: keeps proxies from closing an idle stream, and lets the browser notice a
  // dead stream (a proxy can keep its side open after the server restarted) and reconnect.
  const heartbeat = setInterval(() => res.write(`event: ping\ndata: ${Date.now()}\n\n`), 15000);

  req.on('close', () => {
    clearInterval(heartbeat);
    bus.off(projectName, send);
  });
}

module.exports = { publish, stream };
