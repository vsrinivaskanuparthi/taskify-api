'use strict';

/**
 * Renders the analysis report as one self-contained HTML file (no external fonts or scripts),
 * so it can be emailed, attached to a change request or printed to PDF.
 */

const esc = (v) => String(v ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const mb = (v) => (v >= 1024 * 1024 ? `${(v / 1048576).toFixed(2)} TB` : v >= 1024 ? `${(v / 1024).toFixed(1)} GB` : `${Number(v || 0).toFixed(1)} MB`);
const int = (v) => Number(v || 0).toLocaleString('en-US');
function dur(ms) {
  const m = Math.round(ms / 60000);
  if (m < 60) return `${Math.max(m, 1)} min`;
  const h = Math.floor(m / 60);
  return h < 48 ? `${h} h ${m % 60} min` : `${(h / 24).toFixed(1)} days`;
}

const SEV = {
  critical: ['Critical', '#B42318', '#FEF3F2'],
  high: ['High', '#C4320A', '#FFF4ED'],
  medium: ['Medium', '#B54708', '#FFFAEB'],
  low: ['Low', '#175CD3', '#EFF8FF'],
  info: ['Info', '#475467', '#F2F4F7'],
};

const pill = (sev) => `<span class="pill" style="color:${SEV[sev][1]};background:${SEV[sev][2]}">${SEV[sev][0]}</span>`;

function renderHtml(r) {
  const s = r.summary;
  const scoreColor = s.score >= 80 ? '#0E9F6E' : s.score >= 55 ? '#D97706' : '#DC2626';
  const circ = 2 * Math.PI * 52;
  const findings = r.findings.map((f, i) => `
    <details class="finding" ${f.severity === 'critical' || f.severity === 'high' ? 'open' : ''}>
      <summary>
        ${pill(f.severity)}<span class="cat">${esc(f.category)}</span>
        <span class="ftitle">${esc(f.title)}</span>
        <span class="num">#${i + 1}</span>
      </summary>
      <div class="fbody">
        <p>${esc(f.detail)}</p>
        <div class="grid2">
          <div><h5>How the tool handles it</h5><p>${esc(f.handling || '—')}</p></div>
          <div><h5>Recommended action</h5><p>${esc(f.recommendation || '—')}</p></div>
        </div>
        ${f.objects.length ? `<h5>Affected objects (${int(f.objects.length)})</h5><div class="objs">${f.objects.slice(0, 200).map((o) => `<code>${esc(o)}</code>`).join('')}${f.objects.length > 200 ? `<em>… and ${int(f.objects.length - 200)} more (see report.json)</em>` : ''}</div>` : ''}
      </div>
    </details>`).join('');

  const maxTable = Math.max(...r.topTables.map((t) => t.sizeMb), 1);
  return `<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Migration analysis · ${esc(r.schema)}</title>
<style>
  :root{--ink:#101828;--muted:#5D6B82;--line:#E3E8F0;--blue:#0B57D0;--navy:#00205B;--bg:#F4F6FB}
  *{box-sizing:border-box} body{margin:0;font:14px/1.55 "Segoe UI",system-ui,-apple-system,Roboto,Arial,sans-serif;color:var(--ink);background:var(--bg)}
  .wrap{max-width:1120px;margin:0 auto;padding:32px 24px 64px}
  .hero{background:linear-gradient(135deg,#00205B 0%,#0A3F96 55%,#0B57D0 100%);color:#fff;border-radius:20px;padding:32px;display:flex;gap:32px;align-items:center;flex-wrap:wrap}
  .hero h1{margin:0 0 4px;font-size:28px;letter-spacing:-.01em} .hero .sub{opacity:.8}
  .hero .meta{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:16px;margin-top:20px;flex:1}
  .hero .k{font-size:11px;text-transform:uppercase;letter-spacing:.07em;opacity:.7} .hero .v{font-size:18px;font-weight:700}
  .ring text{font-weight:800}
  section{background:#fff;border:1px solid var(--line);border-radius:16px;padding:24px;margin-top:20px}
  h2{font-size:18px;margin:0 0 4px} .lead{color:var(--muted);margin:0 0 16px}
  h5{margin:14px 0 6px;font-size:12px;text-transform:uppercase;letter-spacing:.06em;color:var(--muted)}
  .cards{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:12px}
  .card{border:1px solid var(--line);border-radius:12px;padding:14px} .card .v{font-size:22px;font-weight:800} .card .k{color:var(--muted);font-size:12px}
  .sev{display:flex;gap:8px;flex-wrap:wrap} .sev div{border-radius:10px;padding:10px 14px;min-width:110px} .sev b{display:block;font-size:22px}
  .pill{display:inline-block;font-size:11px;font-weight:700;border-radius:99px;padding:2px 10px;text-transform:uppercase;letter-spacing:.04em}
  .finding{border:1px solid var(--line);border-radius:12px;margin-bottom:10px;overflow:hidden}
  .finding summary{cursor:pointer;list-style:none;display:flex;gap:10px;align-items:center;padding:12px 16px}
  .finding summary::-webkit-details-marker{display:none} .finding[open] summary{border-bottom:1px solid var(--line);background:#FAFBFD}
  .ftitle{font-weight:650;flex:1} .cat{font-size:12px;color:var(--muted);min-width:90px} .num{color:#98A2B3;font-size:12px}
  .fbody{padding:4px 16px 16px} .fbody p{margin:6px 0}
  .grid2{display:grid;grid-template-columns:1fr 1fr;gap:16px} @media(max-width:700px){.grid2{grid-template-columns:1fr}}
  .objs{display:flex;flex-wrap:wrap;gap:6px;max-height:220px;overflow:auto} code{font:12px/1.4 Consolas,"SFMono-Regular",monospace;background:#F2F4F7;border-radius:6px;padding:3px 7px}
  table{width:100%;border-collapse:collapse} th,td{text-align:left;padding:8px 10px;border-bottom:1px solid var(--line);vertical-align:top} th{font-size:12px;color:var(--muted);text-transform:uppercase;letter-spacing:.05em}
  td.n{text-align:right;font-variant-numeric:tabular-nums} .bar{height:8px;border-radius:4px;background:#DCE7FB;overflow:hidden} .bar i{display:block;height:100%;background:linear-gradient(90deg,#0B57D0,#22A6F2)}
  .check h4{margin:12px 0 6px} .check li{margin:4px 0}
  .muted{color:var(--muted)} footer{color:var(--muted);font-size:12px;margin-top:24px;text-align:center}
  @media print{body{background:#fff}.wrap{padding:0}section,.hero{break-inside:avoid}.finding{break-inside:avoid}details{display:block}details>*{display:block}}
</style></head><body><div class="wrap">

<div class="hero">
  <svg class="ring" width="132" height="132" viewBox="0 0 132 132">
    <circle cx="66" cy="66" r="52" fill="none" stroke="rgba(255,255,255,.18)" stroke-width="12"/>
    <circle cx="66" cy="66" r="52" fill="none" stroke="${scoreColor === '#DC2626' ? '#FF8A80' : scoreColor === '#D97706' ? '#FFD27A' : '#6EE7B7'}" stroke-width="12" stroke-linecap="round"
      stroke-dasharray="${(circ * s.score) / 100} ${circ}" transform="rotate(-90 66 66)"/>
    <text x="66" y="66" text-anchor="middle" fill="#fff" font-size="30">${s.score}</text>
    <text x="66" y="88" text-anchor="middle" fill="rgba(255,255,255,.8)" font-size="11">READINESS</text>
  </svg>
  <div style="flex:1;min-width:260px">
    <div class="sub">Oracle → PostgreSQL migration analysis</div>
    <h1>${esc(r.schema)} · ${esc(s.rating)}</h1>
    <div class="sub">Generated ${esc(new Date(r.createdAt).toLocaleString('en-GB'))} · Oracle ${esc(r.source.version || '')}${r.source.charset ? ` · ${esc(r.source.charset)}` : ''}</div>
    <div class="meta">
      <div><div class="k">Schema size</div><div class="v">${mb(s.sizeMb)}</div></div>
      <div><div class="k">Tables / rows</div><div class="v">${int(s.tables)} / ${int(s.rows)}</div></div>
      <div><div class="k">Code objects</div><div class="v">${int(s.codeObjects)} · ${int(s.codeLines)} lines</div></div>
      <div><div class="k">ora2pg level</div><div class="v">${esc(s.ora2pg?.level || 'n/a')}</div></div>
      <div><div class="k">Code effort (ora2pg)</div><div class="v">${esc(s.ora2pg?.days || 'n/a')}</div></div>
    </div>
  </div>
</div>

<section>
  <h2>Executive summary</h2>
  <p class="lead">${s.ora2pg?.levelText ? `ora2pg rates this schema <b>${esc(s.ora2pg.level)}</b>: ${esc(s.ora2pg.levelText)}. ` : ''}${int(r.findings.length)} findings; the readiness score starts at 100 and drops with each finding's severity.</p>
  <div class="sev">
    ${Object.keys(SEV).map((k) => `<div style="background:${SEV[k][2]};color:${SEV[k][1]}"><b>${s.counts[k] || 0}</b>${SEV[k][0]}</div>`).join('')}
  </div>
  <h5>Estimated data load time (${mb(s.sizeMb)})</h5>
  <div class="cards">
    ${s.load.estimates.map((e) => `<div class="card"><div class="v">${dur(e.ms)}</div><div class="k">${esc(e.label)}</div></div>`).join('')}
    <div class="card"><div class="v">~${int(s.load.targetDiskGb)} GB</div><div class="k">PostgreSQL disk needed (data + indexes, excl. WAL)</div></div>
  </div>
  <p class="muted" style="margin-top:10px">Load time excludes index creation and code conversion. ${s.load.measuredMbps ? 'Based on the throughput of earlier runs in this project.' : 'No completed run yet: run a trial migration to measure the real speed.'}</p>
</section>

<section>
  <h2>Findings</h2>
  <p class="lead">Ordered by severity. Each finding lists what the tool does automatically and what the team must decide or do.</p>
  ${findings || '<p>No findings.</p>'}
</section>

${r.inventory.length ? `<section>
  <h2>Object inventory &amp; ora2pg cost</h2>
  <p class="lead">From ora2pg SHOW_REPORT --estimate_cost (1 cost unit ≈ 5 minutes of a PostgreSQL expert's time).</p>
  <table><tr><th>Object</th><th class="n">Count</th><th class="n">Invalid</th><th class="n">Cost</th><th>ora2pg comment</th></tr>
  ${r.inventory.map((o) => `<tr><td><b>${esc(o.object)}</b>${o.details ? `<div class="muted" style="font-size:12px">${esc(o.details).slice(0, 300)}</div>` : ''}</td><td class="n">${int(o.number)}</td><td class="n">${int(o.invalid)}</td><td class="n">${Number(o.cost).toFixed(1)}</td><td class="muted" style="font-size:12px">${esc(o.comment)}</td></tr>`).join('')}
  </table>
  <p class="muted">Total cost ${esc(s.ora2pg?.cost)} units · ${esc(s.ora2pg?.days)}</p>
</section>` : ''}

<section>
  <h2>Data profile</h2>
  <p class="lead">Largest tables (they set the migration window).</p>
  <table><tr><th>Table</th><th class="n">Size</th><th class="n">LOB</th><th class="n">Rows</th><th style="width:30%"></th></tr>
  ${r.topTables.map((t) => `<tr><td><code>${esc(t.name)}</code>${t.partitioned ? ' <span class="pill" style="background:#EEF4FF;color:#3538CD">partitioned</span>' : ''}</td><td class="n">${mb(t.sizeMb)}</td><td class="n">${t.lobSizeMb ? mb(t.lobSizeMb) : '—'}</td><td class="n">${int(t.rowCount)}</td><td><div class="bar"><i style="width:${Math.max(2, (t.sizeMb / maxTable) * 100)}%"></i></div></td></tr>`).join('')}
  </table>
  <h5>Column data types</h5>
  <div class="objs">${r.dataTypes.map((d) => `<code>${esc(d.type)} · ${int(d.columns)} cols / ${int(d.tables)} tables</code>`).join('')}</div>
</section>

${r.plsqlTop.length ? `<section>
  <h2>Largest code objects</h2>
  <p class="lead">Where the conversion effort is concentrated.</p>
  <table><tr><th>Object</th><th class="n">Lines</th><th>Features needing attention</th></tr>
  ${r.plsqlTop.map((o) => `<tr><td><code>${esc(o.type)} ${esc(o.name)}</code></td><td class="n">${int(o.lines)}</td><td>${o.features.map((f) => `<code>${esc(f)}</code>`).join(' ') || '<span class="muted">—</span>'}</td></tr>`).join('')}
  </table>
</section>` : ''}

<section class="check">
  <h2>Migration checklist</h2>
  ${r.checklist.map((g) => `<h4>${esc(g.phase)} the migration</h4><ul>${g.items.map((i) => `<li>${esc(i)}</li>`).join('')}</ul>`).join('')}
</section>

${r.failedChecks.length ? `<section><h2>Checks not run</h2><p class="lead">These dictionary checks failed (usually a missing SELECT privilege on a DBA_ view); grant SELECT_CATALOG_ROLE and run the analysis again.</p>
<ul>${r.failedChecks.map((f) => `<li><b>${esc(f.check)}</b>: <span class="muted">${esc(f.error)}</span></li>`).join('')}</ul></section>` : ''}

<footer>Database Migration Accelerator · report ${esc(r.id)} · ora2pg's original report is attached as ora2pg_report.html</footer>
</div></body></html>`;
}

module.exports = { renderHtml };
