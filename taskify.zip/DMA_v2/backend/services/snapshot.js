'use strict';

const { getDatabaseVersion } = require("../queries/oracle/getDatabaseVersion");
const { getDatabaseSize } = require("../queries/oracle/getDatabaseSize");
const { getTableMetadata } = require("../queries/oracle/getTableMetadata");
const { getTableCountBySchema } = require("../queries/oracle/getTableCountBySchema");
const { getReservedWordColumns } = require("../queries/oracle/getReservedWordColumns");
const { getBlobColumns } = require("../queries/oracle/getBlobColumns");
const { getNotNullBlobColumns } = require("../queries/oracle/getNotNullBlobColumns");
const { getPrimaryKeyCount } = require("../queries/oracle/getPrimaryKeyCount");
const { getForeignKeyCount } = require("../queries/oracle/getForeignKeyCount");
const { getPrimaryForeignKeys } = require("../queries/oracle/getPrimaryForeignKeys");
const { getCheckConstraints } = require("../queries/oracle/getCheckConstraints");
const { fetchUniqueConstraints } = require("../queries/oracle/fetchUniqueConstraints");
const { getOracleFTSIndexes } = require("../queries/oracle/getOracleFTSIndexes");
const { getNormalIndexes } = require("../queries/oracle/getNormalIndexes");
const { getSequences } = require("../queries/oracle/getSequences");
const { getDbInstanceDetails } = require("../queries/oracle/getDbInstanceDetails");
const { getObjectTypeCounts } = require('../queries/oracle/getObjectTypeCounts');
const { getObjectTables } = require('../queries/oracle/getObjectTables');
const { getLobTables } = require('../queries/oracle/getLobTables');
const { getDbLinks } = require('../queries/oracle/getDbLinks');
const { getOracleConnection } = require('../utils/oracleClient');
const { runWithProject } = require('../utils/context');
const cacheService = require('../utils/cache');
const logger = require('../utils/logger');
const store = require('./projectStore');
const events = require('./events');

// The same metadata queries as v1 (plus LOB tables and DB links), in the order they are shown while the snapshot runs.
const QUERIES = [
  ['dbVersion', 'Database version', getDatabaseVersion],
  ['instances', 'Instance details', getDbInstanceDetails],
  ['dbSize', 'Schema size', getDatabaseSize],
  ['tableMetadata', 'Tables, sizes & row counts', getTableMetadata],
  ['tableCountBySchema', 'Table count', getTableCountBySchema],
  ['objects', 'Object type counts', getObjectTypeCounts],
  ['reservedWordColumns', 'Reserved-word columns', getReservedWordColumns],
  ['blobColumns', 'Large BLOB / CLOB columns', getBlobColumns],
  ['notNullBlobColumns', 'NOT NULL LOB columns', getNotNullBlobColumns],
  ['lobTables', 'Tables with LOB columns', getLobTables],
  ['primaryKeyCount', 'Primary keys', getPrimaryKeyCount],
  ['foreignKeyCount', 'Foreign keys', getForeignKeyCount],
  ['primaryForeignKeys', 'Key relationships', getPrimaryForeignKeys],
  ['checkConstraints', 'Check constraints', getCheckConstraints],
  ['uniqueConstraints', 'Unique constraints', fetchUniqueConstraints],
  ['oracleFTSIndexes', 'Oracle Text indexes', getOracleFTSIndexes],
  ['normalIndexes', 'Indexes', getNormalIndexes],
  ['sequences', 'Sequences', getSequences],
  ['objectTables', 'Object tables', getObjectTables],
  ['dbLinks', 'Database links', getDbLinks],
];

const running = new Map(); // projectName -> progress state

function status(projectName) {
  return running.get(projectName) || null;
}

/**
 * Starts the snapshot in the background (a 1 TB schema can take minutes; v1 held the HTTP request
 * open for all of it). Progress goes to the browser over SSE; the result is saved to disk.
 */
function start(projectName, schemaName) {
  if (running.has(projectName)) return running.get(projectName);
  const state = {
    schema: schemaName,
    status: 'RUNNING',
    startedAt: new Date().toISOString(),
    steps: QUERIES.map(([key, label]) => ({ key, label, status: 'pending', ms: null })),
  };
  running.set(projectName, state);
  const emit = () => events.publish(projectName, 'snapshot', state);
  emit();

  runWithProject(projectName, async () => {
    cacheService.clearProject();
    const data = { schemaName };
    let failed = 0;
    // 4 queries at a time: fast, without flooding a production Oracle with 19 sessions.
    const queue = [...QUERIES];
    const worker = async () => {
      while (queue.length) {
        const [key, , fn] = queue.shift();
        const step = state.steps.find((s) => s.key === key);
        step.status = 'running';
        emit();
        const t0 = Date.now();
        let connection;
        try {
          connection = await getOracleConnection();
          data[key] = await fn(connection, schemaName);
          step.status = 'done';
        } catch (err) {
          failed += 1;
          data[key] = null;
          step.status = 'failed';
          step.error = err.message;
          logger.error(`Snapshot query ${key} failed: ${err.message}`);
        } finally {
          step.ms = Date.now() - t0;
          if (connection) await connection.close().catch(() => {});
          emit();
        }
      }
    };
    await Promise.all([worker(), worker(), worker(), worker()]);

    data.snapshotAt = new Date().toISOString();
    data.failedQueries = state.steps.filter((s) => s.status === 'failed').map((s) => ({ key: s.key, error: s.error }));
    await store.saveSnapshot(projectName, schemaName, data);
    await store.updateMeta(projectName, (m) => ({ ...m, snapshotAt: data.snapshotAt, snapshotSchema: schemaName }));

    state.status = data.tableMetadata ? (failed ? 'COMPLETED_WITH_ERRORS' : 'COMPLETED') : 'FAILED';
    state.finishedAt = data.snapshotAt;
    emit();
  }).catch((err) => {
    logger.error(`Snapshot failed: ${err.stack}`);
    state.status = 'FAILED';
    state.error = err.message;
    emit();
  }).finally(() => {
    setTimeout(() => running.delete(projectName), 1000);
  });
  return state;
}

module.exports = { start, status };
