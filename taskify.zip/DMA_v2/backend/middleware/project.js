'use strict';

const store = require('../services/projectStore');
const { runWithProject } = require('../utils/context');

/**
 * Loads the project named in the URL (/api/projects/:projectName/...) and runs the rest of the
 * request inside that project's context. Replaces v1's single global "selected project" in
 * the cache, which made two users overwrite each other.
 */
async function loadProject(req, res, next) {
  const name = req.params.projectName;
  if (!store.isValidName(name)) return res.status(400).json({ message: 'Invalid project name.' });
  const meta = await store.readMeta(name);
  if (!meta) return res.status(404).json({ message: `Project ${name} not found.` });
  req.projectName = name;
  req.project = meta;
  runWithProject(name, () => next());
}

module.exports = { loadProject };
