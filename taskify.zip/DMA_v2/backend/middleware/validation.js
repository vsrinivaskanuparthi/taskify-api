'use strict';


const validateCreateRequest = (req, res, next) => {
    const { userUsername, userPassword, userUrl } = req.body;

    const missingFields = [];
    if (!userUsername) {
        missingFields.push('userUsername');
    }
    if (!userPassword) {
        missingFields.push('userPassword');
    }
    if (!userUrl) {
        missingFields.push('userUrl');
    }

    if (missingFields.length > 0) {
        return res.status(400).send({
            status: 400,
            message: `Missing required fields: ${missingFields.join(', ')}`
        });
    }

    next();
};

const validatePgRequest = (req, res, next) => {
    const { username, hostip, dbname, password, port } = req.body;

    const missingFields = [];
    if (!username) {
        missingFields.push('username');
    }
    if (!hostip) {
        missingFields.push('hostip');
    }
    if (!dbname) {
        missingFields.push('dbname');
    }
    if (!password) {
        missingFields.push('password');
    }
    if (!port) {
        missingFields.push('port');
    }

    if (missingFields.length > 0) {
        return res.status(400).send({
            status: 400,
            message: `Missing required fields: ${missingFields.join(', ')}`
        });
    }

    next();
};

const validateSchemaSelectRequest = (req, res, next) => {
    const { name } = req.body;
    if (!name) {
        return res.status(400).send({ status: 400, message: 'name is required in request body' })
    }
    next();
}

const validateSetupProjectRequest = (req, res, next) => {
    const { projectName, appName, appCode } = req.body;

    const missingFields = [];
    if (!projectName) {
        missingFields.push('projectName');
    }
    if (!appName) {
        missingFields.push('appName');
    }
    if (!appCode) {
        missingFields.push('appCode');
    }

    if (missingFields.length > 0) {
        return res.status(400).send({
            status: 400,
            message: `Missing required fields: ${missingFields.join(', ')}`
        });
    }

    next();
};

module.exports = {
    validateCreateRequest,
    validateSchemaSelectRequest,
    validateSetupProjectRequest,
    validatePgRequest
};
