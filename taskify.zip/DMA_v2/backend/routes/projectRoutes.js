const express = require("express");
const projectController = require('../controllers/projectController');
const oracleController = require('../controllers/oracleController');
const pgController = require('../controllers/pgController');
const runController = require('../controllers/runController');
const settingsController = require('../controllers/settingsController');
const codeController = require('../controllers/codeController');
const analysisController = require('../controllers/analysisController');
const { loadProject } = require('../middleware/project');
const {
  validateSetupProjectRequest,
  validateCreateRequest,
  validatePgRequest,
  validateSchemaSelectRequest,
} = require('../middleware/validation');

const router = express.Router();

// ---- Projects ----
router.get("/projects", projectController.getMyProjects);
router.post("/projects", validateSetupProjectRequest, projectController.projectSetup);

// Everything below works on one project: /api/projects/:projectName/...
const p = express.Router({ mergeParams: true });
router.use("/projects/:projectName", loadProject, p);

p.get("/", projectController.getProject);
p.patch("/", projectController.updateProject);
p.delete("/", projectController.deleteProject);              // removes the project folder (all ora2pg files, runs, logs)
p.get("/events", projectController.projectEvents);          // live updates (Server-Sent Events)
p.post("/columns", projectController.dbColUpdate);          // reserved-word column renames

// Source (Oracle)
p.post("/oracle/connect", validateCreateRequest, oracleController.create);
p.get("/oracle/schemas", oracleController.listSchemas);
p.post("/schema", validateSchemaSelectRequest, oracleController.selectSchema);
p.post("/snapshot", oracleController.startSnapshot);
p.get("/snapshot", oracleController.getSnapshot);
p.get("/prerequisites", oracleController.analyzePrerequisites);

// Target (PostgreSQL)
p.post("/postgres/connect", validatePgRequest, pgController.connectPg);
p.post("/postgres/disconnect", pgController.disconnectPg);
p.get("/postgres/checks", pgController.targetChecks);
p.get("/validation", pgController.executePg);

// Project settings (ora2pg options, LOB storage, engine defaults)
p.get("/settings", settingsController.getSettings);
p.put("/settings", settingsController.saveSettings);
p.get("/settings/preview", settingsController.previewConfig);
p.post("/settings/notifications/test", settingsController.testNotification);

// Code objects: GenAI export zip, converted package upload / apply, DB link mapping
p.get("/code", codeController.overview);
p.post("/code/exports", codeController.startExport);
p.get("/code/exports/:id/download", codeController.downloadExport);
// Uploaded in pieces of < 1 MB, so proxies with default body limits (nginx: 1 MB) need no change.
p.post("/code/packages/part", express.raw({ type: () => true, limit: '2mb' }), codeController.uploadPart);
p.post("/code/packages", express.raw({ type: ['application/zip', 'application/x-zip-compressed', 'application/octet-stream'], limit: '500mb' }), codeController.uploadPackage);
p.get("/code/packages/:id", codeController.getPackage);
p.delete("/code/packages/:id", codeController.deletePackage);
p.post("/code/packages/:id/apply", codeController.applyPackage);
p.put("/code/dblinks", codeController.saveDbLinks);

// Migration analysis report (ora2pg SHOW_REPORT + complexity checks)
p.get("/analysis", analysisController.overview);
p.post("/analysis", analysisController.start);
p.get("/analysis/:id", analysisController.getReport);
p.get("/analysis/:id/download/:kind", analysisController.download);

// Migration runs
p.get("/runs", runController.listRuns);
p.get("/sizing", runController.sizingInfo);              // migration server: cores, RAM, staging disk vs needs
p.post("/runs/preflight", runController.preflightRun);  // capacity checks for the planned run
p.post("/runs", runController.startRun);
p.get("/runs/:runId", runController.getRun);
p.post("/runs/:runId/resume", runController.resumeRun);
p.post("/runs/:runId/cancel", runController.cancelRun);
p.get("/runs/:runId/logs/:kind", runController.downloadLog);

module.exports = router;
