require('dotenv').config();

const fs = require('fs');
const path = require('path');
const express = require("express");
const cors = require("cors");
const morgan = require("morgan");
const projectRoutes = require("./routes/projectRoutes");
const migrate = require('./services/migrate');
const logger = require("./utils/logger");

const PORT = process.env.PORT || 5000;

const app = express();
app.set('trust proxy', 1);

// Live event streams are long requests; keep them out of the access log.
app.use(morgan("tiny", {
  skip: (req) => req.path.endsWith('/events'),
  stream: { write: (message) => logger.http(message.trim()) },
}));

// Cookies (corporate SSO) need an explicit origin, not "*". CORS_ORIGIN=https://a,https://b pins it.
app.use(cors({
  origin: process.env.CORS_ORIGIN ? process.env.CORS_ORIGIN.split(',').map((o) => o.trim()) : true,
  credentials: true,
}));
app.use(express.json({ limit: '5mb' }));
app.use(express.urlencoded({ extended: false }));

// ============================================================================================
// Corporate SSO (SAML), same setup as v1. Commented out: to switch it on
//   1. paste the IdP certificate into IDP_CERT below (one line, without BEGIN/END lines)
//   2. set SESSION_SECRET in backend/.env (any long random string)
//   3. uncomment this block, the two app.use(session/passport) lines and the auth routes,
//      and use the protected line for the API routes at the bottom of this block
//   4. npm install (passport, @node-saml/passport-saml and express-session are in package.json)
// The callback path (/auth/callback) and the entity id must stay as registered with the IdP.
// ============================================================================================
// const session = require('express-session');
// const passport = require('passport');
// const { Strategy: SamlStrategy } = require('@node-saml/passport-saml');
//
// const APP_BASE_URL = 'https://fr0-viaas-10703.eu-v.airbus-v.corp/';
// const APP_ENTITY_ID = '3BA5_DMA_LAN_VAL_TECH';
// const IDP_ISSUER = 'https://umssosptlsval.intra.corp/1S14';
// const IDP_ENTRY_POINT = 'https://umssosptlsval.intra.corp/1S14/idp/SSO.saml2';
// const IDP_CERT = '<PASTE THE IDP CERTIFICATE HERE>';
//
// const samlStrategy = new SamlStrategy(
//   {
//     callbackUrl: `${APP_BASE_URL}auth/callback`,
//     entryPoint: IDP_ENTRY_POINT,
//     issuer: APP_ENTITY_ID,
//     idpIssuer: IDP_ISSUER,
//     idpCert: IDP_CERT, // @node-saml/passport-saml 5.x
//     cert: IDP_CERT,    // older passport-saml versions
//     disableRequestedAuthnContext: true,
//     identifierFormat: 'urn:oasis:names:tc:SAML:1.1:nameid-format:unspecified',
//   },
//   (profile, done) => {
//     try {
//       const user = {
//         id: profile?.nameID || 'unknown_user',
//         email: profile?.contact_email || 'no_email@provided.com',
//         companyId: profile?.company_id || 'unknown_company',
//       };
//       logger.info(`SSO login: ${user.email} (ID: ${user.id})`);
//       return done(null, user);
//     } catch (err) {
//       logger.error(`Error parsing SSO profile: ${err.message}`);
//       return done(err);
//     }
//   },
//   (profile, done) => done(null, profile), // logout verify (required by 5.x)
// );
// passport.use(samlStrategy);
// passport.serializeUser((user, done) => done(null, user));
// passport.deserializeUser((user, done) => done(null, user));
//
// // Session and passport BEFORE the routes
// app.use(session({
//   secret: process.env.SESSION_SECRET,
//   resave: false,
//   saveUninitialized: false,
//   cookie: { secure: process.env.NODE_ENV === 'production', httpOnly: true, sameSite: 'lax' },
// }));
// app.use(passport.initialize());
// app.use(passport.session());
//
// // Auth routes (same paths as v1)
// app.get('/api/auth/login', passport.authenticate('saml', { successRedirect: '/', failureRedirect: '/api/auth/error' }));
// app.post('/auth/callback', passport.authenticate('saml', { failureRedirect: '/api/auth/error' }), (req, res) => res.redirect('/'));
// app.get('/api/auth/error', (req, res) => res.status(500).json({ success: false, message: 'Authentication error.' }));
// app.get('/api/auth/logout', (req, res, next) => {
//   // Unlike v1, the database pools are NOT closed here: in v2 they are shared by migrations
//   // running in the background, and one user's logout must not stop another user's run.
//   req.logout((err) => {
//     if (err) return next(err);
//     req.session.destroy((e) => {
//       if (e) { logger.error(`Session destruction error: ${e.message}`); return res.status(500).send('Error during logout'); }
//       res.clearCookie('connect.sid', { path: '/' });
//       res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
//       res.status(200).json({ success: true, message: 'Logged out.' });
//     });
//   });
// });
//
// const isAuthenticated = (req, res, next) => {
//   if (req.isAuthenticated()) return next();
//   if (req.originalUrl.startsWith('/api')) return res.status(401).json({ message: 'Unauthorized' });
//   return res.redirect('/api/auth/login');
// };
// app.get('/api/auth/me', isAuthenticated, (req, res) => res.status(200).json({ success: true, user: req.user }));
// ============================================================================================

app.get('/api/health', (req, res) => res.json({ status: 'ok', time: new Date().toISOString() }));

// API routes. With SSO on, use the protected line instead (health and /api/auth/* stay open).
app.use("/api", projectRoutes);
// app.use("/api", isAuthenticated, projectRoutes);

// Serves the built frontend (frontend/dist) when present, so one Node process runs everything.
const webDir = process.env.WEB_DIR || path.join(__dirname, '..', 'frontend', 'dist');
if (fs.existsSync(webDir)) {
  app.use(express.static(webDir));
  app.get(/^\/(?!api\/).*/, (req, res) => res.sendFile(path.join(webDir, 'index.html')));
}

// Error Handler
app.use((err, req, res, next) => {
  logger.error(err.stack);
  res.status(500).json({ success: false, message: "Something went wrong on the server." });
});

// Background work must never take the whole API down.
process.on('unhandledRejection', (err) => logger.error(`Unhandled rejection: ${err && err.stack ? err.stack : err}`));
process.on('uncaughtException', (err) => logger.error(`Uncaught exception: ${err.stack}`));

const shutdown = (signal) => {
  logger.warn(`${signal} received: stopping running migrations (they can be resumed after restart).`);
  migrate.shutdown();
  setTimeout(() => process.exit(0), 1500);
};
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

migrate.recoverInterruptedRuns()
  .catch((err) => logger.error(`Run recovery failed: ${err.message}`))
  .finally(() => {
    app.listen(PORT, () => logger.info(`DMA Server is running on port ${PORT}`));
  });
