'use strict';

const fs = require('fs').promises;
const path = require('path');
const logger = require('../utils/logger');
const store = require('../services/projectStore');
const migrate = require('../services/migrate');
const snapshot = require('../services/snapshot');
const events = require('../services/events');
const code = require('../services/code');
const analysis = require('../services/analysis');
const cacheService = require('../utils/cache');
const { closeOraclePool } = require('../utils/oracleClient');
const { closePostgresPool } = require('../utils/postgreClient');
const { executeAndLog } = require('../errorHandling/error');
const { CONSTANTS } = require('../utils/constants');

/**
 * Creates a new project (ora2pg --init_project, as in v1) and saves its metadata.
 */
async function projectSetup(req, res) {
  const { projectName, appName, appCode, description } = req.body;
  logger.info(`projectSetup called for ${projectName}`);

  if (!store.isValidName(projectName)) {
    return res.status(400).send({ message: 'Project name may contain letters, numbers, "-" and "_" only (max 64).' });
  }
  if (await store.readMeta(projectName)) {
    return res.status(409).send({ message: `Project ${projectName} already exists.` });
  }

  try {
    await fs.mkdir(CONSTANTS.STAGING_DIR, { recursive: true });
    const r = await executeAndLog({ cmd: CONSTANTS.ORA2PG_BIN, args: ['--init_project', projectName], cwd: CONSTANTS.STAGING_DIR, label: `init project ${projectName}` });
    if (r.code !== 0) {
      // ora2pg missing on this machine: the project still works, folders are created by the engine.
      logger.warn(`ora2pg --init_project failed (${r.errorTail}); creating the project folder only.`);
      await fs.mkdir(store.projectDir(projectName), { recursive: true });
    }
    const metadata = {
      projectName,
      appName,
      appCode,
      description: description || '',
      createdAt: new Date().toISOString(),
      migrationStatus: 'READY',
      lastMigrationDate: null,
      currentMigrationId: null,
    };
    await store.updateMeta(projectName, metadata);
    res.status(200).send({ status: 200, message: 'Project created successfully', project: store.publicMeta(metadata) });
  } catch (err) {
    logger.error('projectSetup method error:', err);
    res.status(500).send({ message: 'Project setup failed.', error: err.message });
  }
}

async function getMyProjects(req, res) {
  try {
    const projects = await store.listProjects();
    res.status(200).json({ status: 200, projects });
  } catch (error) {
    logger.error('Error fetching projects:', error);
    res.status(500).json({ message: 'Failed to fetch projects' });
  }
}

async function getProject(req, res) {
  res.json({
    project: store.publicMeta(req.project),
    activeRun: migrate.activeRunSummary(req.projectName) ? { runId: migrate.activeRunSummary(req.projectName).runId } : null,
    snapshot: snapshot.status(req.projectName),
  });
}

async function updateProject(req, res) {
  const { appName, appCode, description } = req.body;
  const meta = await store.updateMeta(req.projectName, (m) => ({
    ...m,
    ...(appName !== undefined && { appName }),
    ...(appCode !== undefined && { appCode }),
    ...(description !== undefined && { description }),
  }));
  res.json({ project: store.publicMeta(meta) });
}

/**
 * Saves column renames (applied as REPLACE_COLS in the run's ora2pg.conf).
 * v1 wrote them into the shared config, which every new migration then overwrote.
 */
async function dbColUpdate(req, res) {
  const columnsToRename = req.body.name;
  if (!Array.isArray(columnsToRename)) {
    return res.status(400).send({ message: `Invalid input format. 'name' must be an array.` });
  }
  const clean = columnsToRename
    .filter((c) => c && c.tableName && c.oldName && c.name)
    .map((c) => ({ tableName: String(c.tableName), oldName: String(c.oldName), name: String(c.name).replace(/[^A-Za-z0-9_$#]/g, '') }));
  await store.updateMeta(req.projectName, (m) => ({ ...m, columnRenames: clean }));
  res.status(200).send({ status: 200, message: 'Column renames saved. They are applied in the next migration run.', columnRenames: clean });
}

/**
 * Deletes the project: its whole folder under the staging directory (ora2pg project tree, config,
 * snapshots, runs, logs, exported SQL, uploaded packages), the same as rm -rf on that folder.
 * PostgreSQL and Oracle are not touched. Refused while anything is still running for the project.
 */
async function deleteProject(req, res) {
  const name = req.projectName;
  if ((req.body && req.body.confirm) !== name) {
    return res.status(400).json({ message: `Type the project name (${name}) to confirm.` });
  }
  const busy = [
    migrate.activeRunSummary(name) && 'a migration run',
    snapshot.status(name)?.status === 'RUNNING' && 'a snapshot',
    code.exportStatus(name)?.status === 'RUNNING' && 'a code export',
    code.applyStatus(name)?.status === 'RUNNING' && 'a code apply',
    analysis.status(name)?.status === 'RUNNING' && 'an analysis',
  ].filter(Boolean);
  if (busy.length) return res.status(409).json({ message: `${busy.join(', ')} is still running. Cancel it or wait for it to finish.` });

  // Only ever a direct child of the staging directory.
  const staging = await fs.realpath(CONSTANTS.STAGING_DIR);
  const dir = path.join(staging, name);
  if (path.dirname(dir) !== staging || path.basename(dir) !== name) {
    return res.status(400).json({ message: 'Invalid project folder.' });
  }
  try {
    await closeOraclePool(name).catch(() => {});
    await closePostgresPool(name).catch(() => {});
    cacheService.clearProject();
    await fs.rm(dir, { recursive: true, force: true, maxRetries: 3 });
    logger.info(`Project ${name} deleted (${dir} removed).`);
    events.publish(name, 'projectDeleted', { projectName: name });
    res.json({ message: `Project ${name} deleted. Folder ${dir} removed.` });
  } catch (err) {
    logger.error(`Delete project ${name} failed: ${err.message}`);
    const hint = err.code === 'EACCES' || err.code === 'EPERM' ? ' Some files belong to another OS user (e.g. created by ora2pg run as root); remove them with sudo rm -rf.' : '';
    res.status(500).json({ message: `Could not remove ${dir}: ${err.message}.${hint}` });
  }
}

/** One SSE stream per browser tab: snapshot progress, run status, table progress, log lines. */
function projectEvents(req, res) {
  const initial = [];
  const snap = snapshot.status(req.projectName);
  if (snap) initial.push({ type: 'snapshot', data: snap });
  const run = migrate.activeRunSummary(req.projectName);
  if (run) initial.push({ type: 'runFull', data: run });
  const exp = code.exportStatus(req.projectName);
  if (exp) initial.push({ type: 'codeExport', data: exp });
  const app = code.applyStatus(req.projectName);
  if (app) initial.push({ type: 'codeApply', data: app });
  const an = analysis.status(req.projectName);
  if (an) initial.push({ type: 'analysis', data: an });
  events.stream(req, res, req.projectName, initial);
}

module.exports = {
  projectSetup,
  getMyProjects,
  getProject,
  updateProject,
  deleteProject,
  dbColUpdate,
  projectEvents,
};
