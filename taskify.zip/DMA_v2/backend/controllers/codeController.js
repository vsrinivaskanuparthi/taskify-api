'use strict';

const fs = require('fs');
const path = require('path');
const code = require('../services/code');
const store = require('../services/projectStore');
const secrets = require('../utils/secrets');
const logger = require('../utils/logger');

const fail = (res, err) => {
  if (!err.status) logger.error(err.stack || err.message);
  res.status(err.status || 500).json({ message: err.message });
};

async function overview(req, res) {
  const snap = await store.readSnapshot(req.projectName, req.project.selectedSchema);
  const mappings = Object.fromEntries(Object.entries(req.project.dbLinkMappings || {}).map(([k, m]) => [k, { ...m, password: undefined, hasPassword: !!m.password }]));
  res.json({
    folders: code.FOLDERS,
    exports: await code.listExports(req.projectName),
    exportJob: code.exportStatus(req.projectName),
    packages: (await code.listPackages(req.projectName)).map(({ files, ...p }) => ({ ...p, fileCount: files.length })),
    applyJob: code.applyStatus(req.projectName),
    objectCounts: (snap && snap.objects) || [],
    dbLinks: (snap && snap.dbLinks) || [],
    dbLinkMappings: mappings,
  });
}

async function startExport(req, res) {
  try { res.status(202).json(await code.startExport(req.projectName)); } catch (err) { fail(res, err); }
}

async function downloadExport(req, res) {
  if (!/^[0-9-]+$/.test(req.params.id)) return res.status(400).end();
  const file = await code.exportZipPath(req.projectName, req.params.id);
  if (!file || !fs.existsSync(file)) return res.status(404).json({ message: 'Export not found.' });
  res.download(file);
}

async function uploadPackage(req, res) {
  try {
    if (!Buffer.isBuffer(req.body) || !req.body.length) return res.status(400).json({ message: 'Send the zip file as the request body.' });
    const manifest = await code.uploadPackage(req.projectName, req.body, req.get('x-file-name'));
    res.status(201).json(manifest);
  } catch (err) { fail(res, err); }
}

/**
 * One piece of a converted zip: ?upload=<id>&index=<n>&last=1&name=<file name>. Pieces are appended
 * in order to a temporary file; the last one turns it into a package like a direct upload.
 */
async function uploadPart(req, res) {
  const { upload, index, last, name } = req.query;
  try {
    if (!/^[A-Za-z0-9-]{8,64}$/.test(String(upload || '')) || !/^\d+$/.test(String(index || ''))) {
      return res.status(400).json({ message: 'Invalid upload piece.' });
    }
    if (!Buffer.isBuffer(req.body)) return res.status(400).json({ message: 'Send the piece as the request body.' });
    const dir = path.join(store.projectDir(req.projectName), 'code', 'uploads');
    await fs.promises.mkdir(dir, { recursive: true });
    const file = path.join(dir, `${upload}.part`);
    const size = fs.existsSync(file) ? fs.statSync(file).size : 0;
    if (Number(index) === 0 && size) await fs.promises.unlink(file);
    else if (Number(index) > 0 && !size) return res.status(409).json({ message: 'Upload interrupted: choose the file again.' });
    if (size + req.body.length > 500 * 1024 * 1024) {
      await fs.promises.unlink(file).catch(() => {});
      return res.status(413).json({ message: 'The zip is larger than 500 MB.' });
    }
    await fs.promises.appendFile(file, req.body);
    if (last !== '1') return res.json({ received: Number(index) });
    try {
      const manifest = await code.uploadPackage(req.projectName, await fs.promises.readFile(file), String(name || 'converted.zip'));
      res.status(201).json(manifest);
    } finally {
      await fs.promises.unlink(file).catch(() => {});
    }
  } catch (err) { fail(res, err); }
}

async function getPackage(req, res) {
  const m = await code.readPackage(req.projectName, req.params.id);
  if (!m) return res.status(404).json({ message: 'Package not found.' });
  res.json(m);
}

async function deletePackage(req, res) {
  await code.deletePackage(req.projectName, req.params.id);
  res.json({ message: 'Deleted' });
}

async function applyPackage(req, res) {
  try { res.status(202).json(await code.startApply(req.projectName, req.params.id)); } catch (err) { fail(res, err); }
}

/** Saves the DB link → FDW mapping. Passwords are encrypted; an empty password keeps the saved one. */
async function saveDbLinks(req, res) {
  const input = req.body && req.body.mappings;
  if (!input || typeof input !== 'object') return res.status(400).json({ message: 'mappings is required.' });
  const meta = await store.updateMeta(req.projectName, (m) => {
    const prev = m.dbLinkMappings || {};
    const next = {};
    for (const [name, v] of Object.entries(input)) {
      const mode = ['postgres_fdw', 'oracle_fdw', 'skip'].includes(v.mode) ? v.mode : 'skip';
      next[name] = {
        mode,
        host: String(v.host || ''),
        port: String(v.port || ''),
        dbname: String(v.dbname || ''),
        remoteSchema: String(v.remoteSchema || ''),
        user: String(v.user || ''),
        localSchema: /^[a-z_][a-z0-9_]{0,62}$/.test(v.localSchema || '') ? v.localSchema : `link_${name.toLowerCase().split('.')[0].replace(/[^a-z0-9_]/g, '_')}`,
        password: v.password ? secrets.encrypt(v.password) : (prev[name] && prev[name].password) || null,
      };
    }
    return { ...m, dbLinkMappings: next };
  });
  res.json({ message: 'DB link mapping saved.', count: Object.keys(meta.dbLinkMappings).length });
}

module.exports = {
  uploadPart, overview, startExport, downloadExport, uploadPackage, getPackage, deletePackage, applyPackage, saveDbLinks };
