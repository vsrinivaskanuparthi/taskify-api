'use strict';

const fs = require('fs');
const analysis = require('../services/analysis');

/** Latest report, the list of earlier ones and the job in progress (if any). */
async function overview(req, res) {
  const reports = await analysis.listReports(req.projectName);
  const latest = reports[0] ? await analysis.readReport(req.projectName, reports[0].id) : null;
  res.json({ reports, latest, job: analysis.status(req.projectName) });
}

async function start(req, res) {
  const meta = req.project;
  if (!meta.selectedSchema) return res.status(400).json({ message: 'Select a schema first.' });
  if (!meta.oracle) return res.status(400).json({ message: 'Connect the Oracle source first.' });
  res.status(202).json({ job: analysis.start(req.projectName) });
}

async function getReport(req, res) {
  const r = await analysis.readReport(req.projectName, req.params.id);
  if (!r) return res.status(404).json({ message: 'Report not found.' });
  res.json({ report: r });
}

/** kind: html (our report), ora2pg (ora2pg's own HTML report), json */
async function download(req, res) {
  const { id, kind } = req.params;
  const file = analysis.reportFile(req.projectName, id, kind);
  if (!file || !fs.existsSync(file)) return res.status(404).json({ message: 'File not found.' });
  const r = await analysis.readReport(req.projectName, id);
  const base = `${(r && r.schema) || 'schema'}_migration_analysis_${id}`;
  const name = { html: `${base}.html`, ora2pg: `${base}_ora2pg.html`, json: `${base}.json` }[kind];
  if (req.query.view === '1' && kind !== 'json') return res.type('html').sendFile(file);
  res.download(file, name);
}

module.exports = { overview, start, getReport, download };
