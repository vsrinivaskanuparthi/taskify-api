# Lessons learned: Jaguar DMA PoC (Aug–Oct 2026)

Source: the project's team chat (Aug 3 → Oct 30, 2026), read end to end. Hostnames, credentials and
people are left out on purpose. Each lesson ends with what the migration tool now does about it.

## Timeline in one paragraph

Access and network took most of August (DB users, firewall request for the PostgreSQL port from the
VDI, read-only vs admin roles). The schema was first migrated **in UPPER case with OID mapping** at
the client's request, then **again in lower case** with CLOB → text / BLOB → bytea. Two target
databases existed side by side (upper case and lower case) for weeks. Functional testing on the
heavy client and web services ran from late September; most blockers came from naming, data types
and code objects that went missing when switching between the two databases. By Oct 29 boolean
columns were converted, functions fixed and "all tests pass"; performance and a wrongly converted
boolean column were still open on Oct 30.

## 1. Object name case: decide once, before the first migration

- Requested UPPER case first, then lower case. The switch left two databases, and the DB link setup
  and the GenAI code upload were only done on one of them. Result: missing views (operator, customer,
  comac), missing materialized views (THIRD_MV, THIRD_MV2), a missing function (duplicate_plan) and a
  skipped procedure (FILL_SHARED_SCENARIO_DATA).
- The "OID mapping completed" line in the decision sheet referred to the upper-case database only,
  which confused the app team later.

**Tool:** case, LOB storage and the other naming/type choices are now *migration decisions* agreed
with the application team and recorded with who agreed and when. Changing one after a completed run
shows a warning that the target must be rebuilt and code objects and DB links re-applied.

## 2. Reserved-word columns: keep the original names (quoted), never rename

- Columns named OFFSET, TYPE, VALUE, POSITION, PERCENT, HOUR and a table named VARIABLE are reserved
  words in PostgreSQL. Three different conventions ended up in play: some tables had `offset_value`
  (renamed by the old tool), the GenAI-converted functions used `offset_val`, `type_val`,
  `value_val`, `position_val` and `variable_table`, and other tables kept `"OFFSET"`.
- The Java (Hibernate 3.6) application uses the **legacy names**. Every rename broke a function or
  query ("column offset of relation customized_rank does not exist", "principle_date_val").
- Fix that worked: keep the original names and quote them ("OFFSET"), and make the functions match
  the tables.

**Tool:** "Keep original names, quote reserved words" is now the default. Renaming is still possible
but marked "only if the application changes too", and the rename list is written into the GenAI
conversion guide so converted code uses the same names as the tables.

## 3. NUMBER mapping: integers for whole numbers, decided before the load

- The first migration mapped NUMBER to NUMERIC everywhere. Java expects Integer/Long, so function
  signatures broke: `procedure fill_shared_scenario_data(numeric, numeric, numeric) does not exist`
  when the caller passed int8.
- Agreed rule (decision sheet): IDs, sequences, ranks, primary and foreign keys → BIGINT; NUMERIC only
  where decimals are real. For function parameters called from Java, INTEGER (Hibernate maps BIGINT
  to Long).
- Converting columns to BIGINT *after* the load failed: the ALTER rewrote the tables, ran out of disk
  space and rolled back. The schema stayed on NUMERIC for the PoC.

**Tool:** NUMBER(p,0) → smallint/integer/bigint by precision, NUMBER without precision → BIGINT by
default (INTEGER selectable for Java Integer code), decimals stay NUMERIC. The analysis report lists
NUMBER columns without precision that are not keys, so decimals are checked before the load. The
GenAI guide states that function parameters and return types must use the same types as the columns.

## 4. Booleans: an explicit column list agreed with the application team

- Oracle NUMBER(1) flags were migrated as numeric; Hibernate sends booleans → errors everywhere.
- The app team produced an inventory; 102 columns were converted with ALTER TABLE, 3 listed columns
  did not exist, and 99 dependent views had to be dropped and recreated.
- Four functions then failed (`holiday_shift_X = 1` → `operator does not exist: boolean = integer`),
  and one column (AC.SPARE_PART) turned out not to be a boolean and had to be reverted.

**Tool:** the analysis lists boolean *candidates* (NUMBER(1), CHAR(1) flags). Only the columns the
team ticks are converted (REPLACE_AS_BOOLEAN) during the first load, and the GenAI guide lists them so
functions compare with true/false.

## 5. Code objects must be validated by name, not assumed

- Missing objects were found by testers, one at a time, over several weeks (views, materialized
  views, functions, a procedure skipped because it was INVALID in Oracle, a missing column
  login_info_additional).

**Tool:** the Validation page now compares Oracle and PostgreSQL by object name for views,
materialized views, functions, procedures, triggers, sequences and types, and lists what is missing.

## 6. DB links and synonyms over DB links

- Views and materialized views depended on synonyms pointing over a DB link to a remote Oracle
  database. The link was set up with oracle_fdw (`IMPORT FOREIGN SCHEMA ... LIMIT TO (...) FROM
  SERVER oracle_db INTO pb00`).
- The remote environment matters: the validation remote only had 3 of the needed views; production
  was deliberately not used.
- The application user got `permission denied for foreign server oracle_db`: it needs USAGE on the
  foreign server and its own user mapping.

**Tool:** DB link mapping grants USAGE on the foreign server to the application roles. The analysis
report flags synonyms over DB links and the objects that depend on them.

## 7. Application users and permissions

- The application connected with a read-only user. Each new object type hit a new error: schema
  usage, views, sequences (`permission denied for sequence seq_officialise`), function execute,
  foreign server, then write access for insert/update tests.

**Tool:** new "Application access" decision: read-only and read-write roles. After the load the tool
grants schema usage, tables/views, sequences and function execute (plus default privileges for
objects created later).

## 8. Oracle-isms the application still uses

- `FROM dual` in application SQL → "dual table missing". Options were changing the app or creating a
  compatibility view.

**Tool:** optional "Create DUAL compatibility view".

## 9. Operations

- A maintenance VACUUM FULL by a system account locked tables for 1.5 h and blocked the application.
  Schedule maintenance outside test windows; never VACUUM FULL during tests.
- The application left sessions *idle in transaction* holding locks, which blocked DDL fixes.
- After structural changes (booleans, types) statistics were stale and a use case went from < 1 min
  to > 10 min. ANALYZE helped partly; the rest was per-row round trips in the application loop
  (N+1 queries over each MSN).
- Network: the PostgreSQL port was not open from the VDI; a firewall request was needed (weeks).
- Disk: plan space for table rewrites (type changes rewrite the whole table).

**Tool:** the finalize phase runs ANALYZE; the checklist covers firewall, maintenance windows and disk
headroom.

## 10. Process

- A decision sheet (naming, OID, NUMBER → BIGINT, booleans) was created mid-project, after several
  changes. The sponsor's conclusion: before the next full migration, run a technical deep dive with
  the business/app team on **column names, boolean conversions, CLOB/BLOB and number mapping**.

**Tool:** the Settings page is now that decision sheet, filled in and agreed before the first run,
and included in the analysis report and the GenAI conversion guide.
