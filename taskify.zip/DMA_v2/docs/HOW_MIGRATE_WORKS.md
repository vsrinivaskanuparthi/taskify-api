# How the v2 migration engine works (`backend/services/migrate.js`)

## The idea in one paragraph

In v1 you wrote one function per kind of table: `processNormalTables`, `processHugeTables`,
`processBlobTables`, `processObjectTables`. Each one ran the tables of its kind one after
another, wrote each to a `.sql` file, and `uploadArtifactsToDb` loaded the files at the end.

v2 has **one pipeline for every table**. The kind of a table (normal / huge / LOB / object) is no
longer a separate function. It is a **label on the table** that changes a few options when that
table is loaded. Every table is its own small job with a status, attempts, row count, speed and
log, and up to N tables run at the same time. If one fails, only that table is retried. If the
server stops, the run continues where it stopped.

```
v1:  normal tables ──▶ huge tables ──▶ blob tables ──▶ object tables ──▶ load all files
     (one by one)      (one by one)     (one by one)     (one by one)       (at the end)

v2:  ┌─ table A ─┐
     ├─ table B ─┤   N at a time, biggest first, each one:
     ├─ table C ─┤   empty target → copy → count check → checksum check → done
     └─   …     ─┘   (failed? retried on its own; the others keep going)
```

---

## 1. v1 → v2: where your functions went

| v1 | v2 | What changed |
|---|---|---|
| `migrateTables()` (main flow) | `Run.execute()` | Runs the 9 phases below in order and saves progress after each step |
| classification into `normalTables`, `hugeTables`, `blobTablesInSelection`, `objectTablesInSelection` | `buildTables()` | Same rules: each table gets `kind: 'normal' \| 'huge' \| 'lob' \| 'object'` |
| `processNormalTables()` | `loadTableWithRetry()` → `loadTable()` → `copyTable()` | Same `ora2pg -t COPY -a TABLE`, but streamed into PostgreSQL (no file), several tables at once |
| `processHugeTables()` | same functions + `loadChunked()` | Huge tables are cut into **chunks** (key or ROWID ranges); chunks run in parallel and are retried one by one |
| `processBlobTables()` + `blob.sh` | same functions + `planLobs()` | LOB tables get small batches (`-L`); LOBs up to 16 MB are fetched inline (about 5× faster). `blob.sh` is replaced by `convertBlobsToOid()` (only if BLOB → large object is chosen) |
| `processObjectTables()` | `loadObjectTable()` | Oracle object tables / object-type columns are read by the engine itself and written as PostgreSQL composite values |
| `uploadArtifactsToDb()` | phases `tables`, `indexes`, `fkeys`, `sequences` (`runDdlPhase()` + `sqlRunner.js`) | DDL statements run in parallel; one failing statement is reported, not fatal |
| `sequence.sh` | still used in `phase_tables()` | Removes duplicate sequences, as before |
| `fts_bytea.sh` / `fts_oid.sh` | still used in `phase_tables()` | Full-text index helpers, as before |
| (none) | `verifyTable()`, `verifyData()` | New: every table is checked (row count + column checksums) before it is marked done |
| (none) | `state.json`, `resumeRun()`, `recoverInterruptedRuns()` | New: crash-safe progress and resume |

---

## 2. The 9 phases of a run

`execute()` walks through `PHASES` in order. A phase that is already `done` is skipped (that is
how Resume works).

| # | Phase | Method | What it does |
|---|---|---|---|
| 1 | prepare | `phase_prepare()` | Connects to both databases, writes the ora2pg config files, checks ora2pg (version 24 or 25) and psql, chooses the snapshot (`chooseSnapshot()`) |
| 2 | ddl | `phase_ddl()` | `ora2pg -t TABLE / SEQUENCE / TYPE / PARTITION …` exports the definitions to `schema/` |
| 3 | tables | `phase_tables()` | Creates schema, types, sequences, tables and partitions in PostgreSQL (fixes ora2pg's type-length bug, adds default partitions) |
| 4 | data | `phase_data()` | **Loads every table** (see section 3) |
| 5 | indexes | `phase_indexes()` | Primary keys, unique and check constraints, indexes, in parallel (after the data: much faster) |
| 6 | fkeys | `phase_fkeys()` | Foreign keys added `NOT VALID` (instant), then validated in parallel |
| 7 | sequences | `phase_sequences()` | Reads the sequence values from Oracle *after* the load and sets them |
| 8 | code | `phase_code()` | Applies the GenAI-converted package, if one was chosen |
| 9 | finalize | `phase_finalize()` | ANALYZE, grants for the application roles, run summary |

"Export only" runs stop after phase 4 (status `EXPORTED`). "Import exported files" resumes
the same run, which loads the files and runs phases 5–9.

---

## 3. The life of one table (phase 4)

`phase_data()` sorts the tables biggest first and starts `parallelTables` of them at once
(`p-limit`). For each table:

```
loadTableWithRetry(name)
 ├─ first time only:
 │   ├─ object-type columns?  → t.udt = true        (loaded by loadObjectTable)
 │   ├─ LOB table?            → planLobs(t)          (inline fetch or LOB locators, batch size)
 │   └─ big enough to split?  → planChunks(t)        (key ranges or ROWID ranges)
 │
 └─ attempt 1..maxAttempts:
     ├─ chunked?  loadChunked(t)   else  loadTable(t)
     │     ├─ prepareTarget()  → drop FKs pointing at it, TRUNCATE, bulkPrepare()
     │     ├─ copyTable()      → ora2pg -t COPY (streamed, or through a file)
     │     ├─ verifyTable()    → exact COUNT(*) in Oracle and PostgreSQL must match
     │     └─ verifyData()     → per-column sums / lengths / LOB sizes must match
     ├─ bulkFinish(t)          → table made permanent again, autovacuum back on
     └─ status = done          (or: error → wait 10 s, 20 s… → next attempt)
```

### How the kind changes the load

| Kind (`t.kind`) | Set when | Effect in `copyTable()` |
|---|---|---|
| `normal` | everything else | one ora2pg process, batch `dataLimit` rows |
| `huge` | rows ≥ `hugeTableRows` | `-J oracleCopies` readers and `-j pgJobs` writers; split into chunks by `planChunks()` |
| `lob` | has BLOB / CLOB / NCLOB / LONG / LONG RAW / BFILE / XMLTYPE columns | batch `-L` (small); inline LOB fetch when the biggest LOB ≤ 16 MB (`planLobs()`) |
| `object` | Oracle object table | not ora2pg: `loadObjectTable()` |
| `t.udt` (flag) | columns of user-defined types | not ora2pg: `loadObjectTable()` |

### Chunks (huge tables): `planChunks()` and `loadChunked()`

A table is chunked when it has ≥ `hugeTableRows` rows or is ≥ `chunkMb` MB (`shouldChunk()`).

- **Single numeric primary key:** ranges like `WHERE id BETWEEN 1 AND 5000000`.
- **Anything else** (no key, text key, LOB tables): **ROWID ranges** built from the table's
  extents in `DBA_EXTENTS`, so every table can be split.

Each chunk is a separate ora2pg run with `-W "where…"`. `oracleCopies` chunks run at the same
time. After each chunk, the Oracle row count of that range is compared with what was loaded.
A failed chunk is reloaded alone: a network drop at 90 % of a 300 GB table costs one chunk,
not the whole table.

- Key-range chunks: a chunk that was started before is deleted with
  `DELETE … WHERE <range>` before it is loaded again.
- ROWID chunks always go through a small file that is loaded in one transaction. It is all or
  nothing, so there is never anything to delete.

### Load modes: `copyTable()`

| `loadMode` | What happens |
|---|---|
| `direct` (default) | ora2pg writes straight into PostgreSQL. No data files, no extra disk. |
| `file` | ora2pg writes a file, psql loads it in one transaction, the file is deleted. If the load fails, the file is kept and the retry re-imports it without reading Oracle again. |
| `export` | Files only, checked against Oracle counts. Loaded later by "Import exported files". |

A finished export file gets a `.done.json` marker with the snapshot it belongs to, so it is
only reused for the same data.

---

## 4. What keeps a long run safe

| Problem | Where it is handled |
|---|---|
| Tables read at different moments while the app writes | `chooseSnapshot()`: one Oracle SCN for every table, chunk and count (`--scn`, `AS OF SCN`). Switch: `options.snapshot` |
| Oracle undo too short for the snapshot (ORA-01555) | Pre-flight warns (`services/preflight.js`). During the run: no retry, "Resume without snapshot" |
| A table or chunk fails | `loadTableWithRetry()`: up to `maxAttempts`, with waits. Data errors (value does not fit) are not retried: they need a mapping fix |
| ora2pg hangs (network) | `stallMinutes`: no output for N minutes → the process is killed and the table or chunk retried |
| Duplicate rows on retry | target is `TRUNCATE`d (or the chunk range deleted) before every load |
| Wrong data that still has the right row count | `verifyData()`: column checksums |
| Server stops / pm2 restart | Every change is saved in `runs/<id>/state.json`. At start-up `recoverInterruptedRuns()` stops leftover ora2pg/psql processes and marks the run `INTERRUPTED`. Resume continues with what is not done |
| Settings changed between run and resume | `decisionsHash`: resume is refused if the type mapping, names or target changed (the tables would not match) |
| Slow bulk load | `bulkPrepare()` / `bulkFinish()`: autovacuum paused while a table loads; optional unlogged load |
| Problems found 6 hours in | Pre-flight checks before the start (disk, connections, processes, WAL, network, undo) |
| Nobody watching overnight | `RunNotifier` (`services/notify.js`): email / Google Chat on attention and on finish |

---

## 5. Where things are on disk

```
<MIGRATION_STAGING_DIR>/<project>/
  project_meta.json            project, connections (passwords encrypted), settings
  snapshot/<SCHEMA>.json       the schema snapshot (tables, sizes, rows, LOBs, …)
  runs/<runId>/
    state.json                 the whole run: phases, tables, chunks, attempts, events
    config/*.conf              the ora2pg configs this run used
    schema/                    DDL exported by ora2pg (tables/, sequences/, types/, …)
    data/                      only in file / export mode, and ROWID chunks in progress
    logs/master.log            everything, with timestamps
    logs/error.log             errors only
    logs/tables/<TABLE>.log    the ora2pg output of each table
```

---

## 6. Reading the code: suggested order

1. `PHASES`, `startRun()`, `buildTables()`, `normalizeOptions()`: what a run is and its options.
2. `execute()`: the phase loop, the final status, notifications.
3. `phase_data()` → `loadTableWithRetry()` → `loadTable()` → `copyTable()`: one table.
4. `verifyTable()`, `verifyData()`: the checks.
5. `shouldChunk()`, `planChunks()`, `loadChunked()`: huge tables.
6. `planLobs()`, `inlineLobConf()`: LOB tables.
7. `chooseSnapshot()`, `snapshotArgs()`, `asOf()`: the consistent snapshot.
8. `resumeRun()`, `recoverInterruptedRuns()`: resume and crash recovery.

## 7. Common changes and where to make them

| I want to… | Change |
|---|---|
| change a default (parallel tables, attempts, chunk size…) | `backend/.env` (see `utils/constants.js`), or per project in Settings → Advanced |
| change when a table counts as huge / LOB / object | `buildTables()` |
| change the ora2pg options used for data | `services/config_modify.js` (`forData`) |
| add a check after each table | after `verifyData()` in `loadTable()` and `loadChunked()` |
| add a phase | add it to `PHASES` and write `phase_<key>()` |
| change notification texts | `RunNotifier` in `services/notify.js` |
