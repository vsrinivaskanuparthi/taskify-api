# DMA v2 flow map (text version)

Printable copy of the interactive flow map (`docs/flow-map/index.html`). Generated from the same data. Paths are under `/api`; `:name` is the project name.

## 1. User journey: screens and buttons

### Home & projects

Route: `/  ·  /projects`  

Start page and the list of migration projects. One project per application/schema.

| Button / action | API | Backend | Next |
|---|---|---|---|
| **Open Home / All projects**<br>Lists the projects with their status (running, completed, needs attention). | `GET /api/projects` | `projectController.getMyProjects`<br>`projectStore.listProjects()`<br>_Reads project_meta.json of every folder in MIGRATION_STAGING_DIR_ |  |
| **New project → Create project**<br>Creates the project folder with its name, application name and code. | `POST /api/projects` | `middleware validateSetupProjectRequest`<br>`projectController.projectSetup`<br>`projectStore.updateMeta()`<br>_Creates <staging>/<project>/project_meta.json_ | Connections |
| **Open a project**<br>Loads the project (connections without passwords, status, active run) and opens the live-updates stream. Every project page does this. | `GET /api/projects/:name`, `GET /api/projects/:name/snapshot`, `GET /api/projects/:name/events` | `projectController.getProject → store.publicMeta(), migrate.activeRunSummary(), snapshot.status()`<br>`oracleController.getSnapshot`<br>`projectController.projectEvents (live updates)` | Connections |

Then: Connections

### Connections

Route: `/projects/:name/connect`  

Connect the Oracle source and the PostgreSQL target. Both are tested before they are saved.

| Button / action | API | Backend | Next |
|---|---|---|---|
| **Oracle: Test & connect**<br>Tests the connection (host/port/service or a connection string) and saves it. Reconnect replaces it. | `POST /api/projects/:name/oracle/connect` | `middleware validateCreateRequest`<br>`oracleController.create`<br>`utils/oracleClient.initOracle() — node-oracledb Thin pool + test`<br>`projectStore.updateMeta()`<br>_project_meta.json: oracle connection, password encrypted (AES-256-GCM, utils/secrets); Returns the schema list_ |  |
| **PostgreSQL: Test & connect**<br>Tests the target database and saves the connection. | `POST /api/projects/:name/postgres/connect` | `middleware validatePgRequest`<br>`pgController.connectPg`<br>`utils/postgreClient.initPostgres() — pg pool + version`<br>`projectStore.updateMeta()`<br>_project_meta.json: postgres connection, password encrypted_ |  |
| **PostgreSQL: Disconnect**<br>Forgets the saved PostgreSQL connection. | `POST /api/projects/:name/postgres/disconnect` | `pgController.disconnectPg`<br>`projectStore.updateMeta() → postgres: null` |  |

Then: Schema & snapshot

### Schema & snapshot

Route: `/projects/:name/schema`  

Pick the Oracle schema and take the snapshot: the inventory every later step uses (tables, sizes, rows, LOBs, keys, code, DB links).

| Button / action | API | Backend | Next |
|---|---|---|---|
| **Page opens: list schemas**<br>Fills the schema drop-down from Oracle. | `GET /api/projects/:name/oracle/schemas` | `oracleController.listSchemas`<br>`ensureSource() (Oracle pool)`<br>`queries/oracle/getDBSchema` |  |
| **Choose schema**<br>Sets the schema this project migrates. | `POST /api/projects/:name/schema` | `middleware validateSchemaSelectRequest`<br>`oracleController.selectSchema`<br>`projectStore.updateMeta() → selectedSchema` |  |
| **Take snapshot / Refresh snapshot**<br>Takes the inventory of the schema. Every query shows as a step with a spinner; the result unlocks Assessment and Migrate. | `POST /api/projects/:name/snapshot`, `GET /api/projects/:name/snapshot` | `oracleController.startSnapshot`<br>`services/snapshot.start() — runs in the background`<br>`queries/oracle/*: version, size, tables (sizes, rows), object counts, reserved-word columns, LOB columns and tables, keys, constraints, indexes, sequences, code objects, DB links, object tables`<br>_Writes snapshot/<SCHEMA>.json; Progress pushed as live “snapshot” events_ | Assessment |
| **View assessment**<br>Goes to the Assessment page. | none (browser) |  | Assessment |

Then: Assessment

### Assessment

Route: `/projects/:name/assessment`  

Readiness, sizing estimate, largest tables, reserved-word columns and the foreign key map. Computed in the browser from the snapshot.

| Button / action | API | Backend | Next |
|---|---|---|---|
| **Read the assessment**<br>Readiness, estimate (RAM = 8 + GB/25×2, CPU = 6 + GB/25, storage = GB×1.7, time), largest tables, reserved words and the foreign key map, all from the snapshot. No API call. | none (browser) | `pages/AssessmentPage.tsx (browser only)` |  |
| **Save renames (reserved words)**<br>Saves new names for columns whose name is an SQL reserved word (e.g. OFFSET → OFFSET_VALUE). | `POST /api/projects/:name/columns` | `projectController.dbColUpdate`<br>`projectStore.updateMeta() → columnRenames`<br>_Applied by the next run through ora2pg REPLACE_COLS_ |  |
| **Plan migration**<br>Goes to Migrate. The optional steps (Analysis, Settings, Code) can be done first. | none (browser) |  | Migrate |

Then: Analysis report / Settings / Code objects (GenAI) / Migrate

### Analysis report (optional)

Route: `/projects/:name/analysis`  

ora2pg’s cost assessment plus extra dictionary checks, turned into findings with recommendations.

| Button / action | API | Backend | Next |
|---|---|---|---|
| **Page opens**<br>Shows the latest report and earlier ones. | `GET /api/projects/:name/analysis`, `GET /api/projects/:name/analysis/:id` | `analysisController.overview → analysis.listReports(), analysis.readReport()`<br>`analysisController.getReport` |  |
| **Run analysis**<br>Builds the migration analysis report: ora2pg migration level and cost, plus findings grouped as automatic / decide / manual. | `POST /api/projects/:name/analysis` | `analysisController.start`<br>`services/analysis.start() — background job`<br>`1. ora2pg -t SHOW_REPORT --estimate_cost --dump_as_json (ora2pg 24: text report parsed, utils/ora2pgVersion) and --dump_as_html`<br>`2. getMigrationComplexity(): Oracle dictionary checks`<br>`3. buildReport() → findings, actions, checklist`<br>_analysis/<id>/report.json, analysis_report.html, ora2pg_report.html; Progress pushed as live events_ |  |
| **Download / Open full report / ora2pg report**<br>Downloads or opens the report. | `GET /api/projects/:name/analysis/:id/download/:kind` | `analysisController.download → analysis.reportFile()`<br>_:kind = html \| ora2pg \| json; ?view=1 opens it in the browser_ |  |

Then: Migrate

### Settings (optional)

Route: `/projects/:name/settings`  

The migration decisions (names, number types, booleans, LOBs, target schema, roles), notifications and engine defaults. Agreed once per project.

| Button / action | API | Backend | Next |
|---|---|---|---|
| **Page opens**<br>Loads the saved settings, the defaults and the option catalogue. | `GET /api/projects/:name/settings`, `GET /api/projects/:name/analysis` | `settingsController.getSettings → settings.resolve(), notify.publicView() (webhook masked), notify.channels()`<br>`analysis overview (boolean column candidates)` |  |
| **Save settings**<br>Saves decisions, notifications and engine defaults. | `PUT /api/projects/:name/settings` | `settingsController.saveSettings`<br>`services/settings.validate()`<br>`services/notify.validate() (webhook encrypted)`<br>`projectStore.updateMeta() → settings`<br>_Used by the next run; each run stores a hash of the decisions so a resume cannot mix old and new ones_ |  |
| **Preview ora2pg.conf**<br>Shows the ora2pg configuration the next run will use, passwords hidden. | `GET /api/projects/:name/settings/preview` | `settingsController.previewConfig`<br>`services/config_modify.buildConfig() into a temp file` |  |
| **Send a test (notifications)**<br>Sends a test email and Google Chat message with the values on screen, saved or not, and shows the result per channel. | `POST /api/projects/:name/settings/notifications/test` | `settingsController.testNotification`<br>`services/notify.test()`<br>`email: nodemailer via SMTP_* in backend/.env`<br>`Google Chat: cardsV2 message to the space webhook` |  |
| **What do these mean?**<br>Opens the Guide at “Every option explained”. | none (browser) |  | Guide |
| **Delete project (danger zone)**<br>Deletes the project after you type its name. | `DELETE /api/projects/:name` | `projectController.deleteProject`<br>`refused while a run, snapshot, code export, apply or analysis is running`<br>`closes the database pools`<br>`fs.rm(project folder, recursive)`<br>_Removes <staging>/<project> (ora2pg files, snapshots, runs, logs, exports). Oracle and PostgreSQL are not touched._ |  |

Then: Migrate

### Code objects (GenAI) (optional)

Route: `/projects/:name/code`  

Export the code objects for GenAI conversion, upload the converted zip and apply it, with DB link mapping.

| Button / action | API | Backend | Next |
|---|---|---|---|
| **Page opens**<br>Shows exports, uploaded packages, apply status and DB links. | `GET /api/projects/:name/code` | `codeController.overview → code.listExports(), exportStatus(), listPackages(), applyStatus(); DB links from the snapshot` |  |
| **Export & build zip**<br>Exports every code object as a zip to convert with GenAI. | `POST /api/projects/:name/code/exports`, `GET /api/projects/:name/code/exports/:id/download` | `codeController.startExport → code.startExport()`<br>`ora2pg -p -t VIEW / FUNCTION / PROCEDURE / PACKAGE / TRIGGER / TYPE …, one file per object`<br>`conversionGuide() → CONVERSION_GUIDE.md with the project decisions`<br>`zip; codeController.downloadExport → code.exportZipPath()`<br>_code/exports/<id>.zip; downloads automatically when ready_ |  |
| **Upload converted zip**<br>Uploads the converted zip in pieces. Old single-request endpoint POST /code/packages is kept but not used by the screen. | `POST /api/projects/:name/code/packages/part` | `codeController.uploadPart (768 KB pieces, fits nginx’s 1 MB default)`<br>`appended to code/uploads/<id>.part (max 500 MB)`<br>`last piece → code.uploadPackage(): unzip, check folders, manifest`<br>_code/packages/<id>/_ |  |
| **Apply now / Apply to PostgreSQL now**<br>Applies the converted code objects to PostgreSQL without touching the data. A migration run can also apply it (phase 8). | `POST /api/projects/:name/code/packages/:id/apply` | `codeController.applyPackage → code.startApply()`<br>`code.applyPackage(): DB link FDW servers, then each file with psql in dependency order`<br>`per-file status + grants for the application roles` |  |
| **Files and errors**<br>Shows each file of a package, grouped by object type, with its apply status and error. | `GET /api/projects/:name/code/packages/:id` | `codeController.getPackage → code.readPackage()` |  |
| **Delete package**<br>Removes an uploaded package. | `DELETE /api/projects/:name/code/packages/:id` | `codeController.deletePackage → code.deletePackage()` |  |
| **Save DB link mapping**<br>Maps each Oracle DB link to a postgres_fdw or oracle_fdw foreign server, created when code is applied. | `PUT /api/projects/:name/code/dblinks` | `codeController.saveDbLinks`<br>`projectStore.updateMeta() → dbLinks (passwords encrypted)` |  |

Then: Migrate

### Migrate

Route: `/projects/:name/migrate`  

Choose the tables and the run options, run the pre-flight checks, then start the migration.

| Button / action | API | Backend | Next |
|---|---|---|---|
| **Page opens**<br>Pre-fills the options from Settings and lists the converted packages. | `GET /api/projects/:name/settings`, `GET /api/projects/:name/code` | `settingsController.getSettings (engine defaults)`<br>`codeController.overview (packages for the start dialog)` |  |
| **Select tables & options**<br>Table selection, load mode (Direct / Through files / Export only), parallelism, chunking, snapshot on/off, unlogged load, verification. Browser only until Start. Changing them asks for the checks again. | none (browser) |  |  |
| **Run checks (pre-flight)**<br>Runs all checks for the selected tables and options. Red items block Start; amber items are risks with the value to give the DBA. | `GET /api/projects/:name/prerequisites`, `GET /api/projects/:name/postgres/checks`, `POST /api/projects/:name/runs/preflight` | `oracleController.analyzePrerequisites → queries/oracle/analyzePrerequisites: permissions, statistics, sessions/locks, FLASHBACK, object types`<br>`pgController.targetChecks: connection, CREATE privilege, ora2pg and psql installed`<br>`runController.preflightRun → services/preflight.preflight(): estimate, snapshot vs undo, staging disk, connections, WAL, space, Oracle processes, network` |  |
| **Start migration**<br>Asks whether the GenAI package is ready (apply it in this run, or later), then starts the run and opens the live monitor. | `POST /api/projects/:name/runs` | `runController.startRun: tables checked against the snapshot`<br>`preflight(quick) — blocking checks again on the server (400 if red)`<br>`migrate.startRun(): normalizeOptions(), buildTables() (kind per table), decisionsHash()`<br>`launch() → Run.execute() in the background`<br>_runs/<runId>/state.json; project_meta.json: migrationStatus RUNNING_ | Live monitor, Start / resume |

Then: Live monitor

### Live monitor

Route: `/projects/:name/runs  ·  /runs/:runId`  

The run while it happens: phases, tables, chunks, speed and the activity feed. Also where you cancel, resume and read logs.

| Button / action | API | Backend | Next |
|---|---|---|---|
| **Run list**<br>All runs of the project, newest first. | `GET /api/projects/:name/runs` | `runController.listRuns → migrate.listRuns()` |  |
| **Open a run**<br>Phases, tables, chunks, rows per second and the activity feed, updated live. | `GET /api/projects/:name/runs/:runId`, `GET /api/projects/:name/events` | `runController.getRun → migrate.readRunState()`<br>`live “run” (every 2 s), “table” and “log” events` |  |
| **Cancel run**<br>After a confirmation, stops the run. Status CANCELLED; it can be resumed. | `POST /api/projects/:name/runs/:runId/cancel` | `runController.cancelRun → migrate.cancelRun() → run.cancel()`<br>`kills the ora2pg / psql process groups` | Cancel |
| **Resume / Retry failed & resume**<br>Continues an interrupted, cancelled or failed run with only the work that is left. | `POST /api/projects/:name/runs/:runId/resume` | `runController.resumeRun → migrate.resumeRun()`<br>`refused if the decisions changed (decisionsHash)`<br>`failed and pending tables reset; done tables and chunks kept`<br>`launch() → Run.execute()` | Resume |
| **Resume without snapshot**<br>Shown only when a table failed with ORA-01555 (Oracle undo too short). Keep the application stopped. | `POST /api/projects/:name/runs/:runId/resume` | `body { options: { snapshot: "off" } }`<br>`migrate.resumeRun() → chooseSnapshot() reads current data` |  |
| **Import exported files**<br>After an “Export only” run: loads the exported files, then runs indexes, keys, sequences, code and finalize. | `POST /api/projects/:name/runs/:runId/resume` | `body { options: { loadMode: "file" } }`<br>`copyTable() re-uses each export file (.done.json marker) and loads it with psql` |  |
| **Logs menu**<br>Downloads the run’s logs. | `GET /api/projects/:name/runs/:runId/logs/:kind` | `runController.downloadLog → migrate.runLogPath()`<br>_:kind = master \| error \| success_ |  |
| **Click a table → its log**<br>The ora2pg output of one table; “Full log” drops the tail limit. | `GET /api/projects/:name/runs/:runId/logs/table?table=X&tail=96` | `runController.downloadLog (logs/tables/<TABLE>.log)` |  |

Then: Validation

### Validation

Route: `/projects/:name/validation`  

Oracle and PostgreSQL side by side: row counts, keys, constraints, indexes, sequences and code objects by type.

| Button / action | API | Backend | Next |
|---|---|---|---|
| **Page opens / Re-check**<br>Compares both sides. Code objects show as one card per type. | `GET /api/projects/:name/validation` | `pgController.executePg`<br>`row counts: exact counts from the runs, else counted now`<br>`queries/pg: key counts, compare PK/FK columns, check and unique constraints, indexes, sequences, full-text indexes`<br>`compareCodeObjects(): every Oracle code object by name (live Oracle)` |  |
| **Recount all rows**<br>Counts every table again. Normally not needed: each table was counted when it was loaded. | `GET /api/projects/:name/validation?recount=1` | `pgController.executePg → rowCountCheck(recount): COUNT(*) on both sides, 4 tables at a time` |  |
| **Export all (Excel) / CSV**<br>Built in the browser from what the page shows: one Excel file with a Summary sheet and a sheet per section, or a CSV per card. No API call, so no size limit. | none (browser) | `frontend/src/exportFile.ts: downloadXlsx(), downloadCsv()` |  |

### Guide (optional)

Route: `/guide`  

Static help: what v2 does, what is new, every option in plain words. Linked from Migrate and Settings.

| Button / action | API | Backend | Next |
|---|---|---|---|
| **Open the Guide**<br>Left menu → Guide, or the “What … mean?” links. Static page, no API call. | none (browser) |  |  |

### Live updates (optional)

Route: `/projects/:name/events`  

Background connection that every project page keeps open. The server pushes progress; nothing to click.

| Button / action | API | Backend | Next |
|---|---|---|---|
| **Live updates stream**<br>Pushes progress to every open project page. | `GET /api/projects/:name/events` | `projectController.projectEvents → services/events.stream() (Server-Sent Events)`<br>`named “ping” every 15 s keeps proxies from closing it`<br>`browser (hooks/useProjectEvents): reconnects with back-off, reloads after reconnecting`<br>_Events: snapshot progress, run / table / log, analysis and code export progress_ |  |

Then: Live monitor

## 2. Migration engine (what Start migration runs)

### Start / resume — `migrate.startRun() → Run.execute()`

Entry point. Start migration (POST /runs) or Resume (POST /runs/:id/resume) both end in Run.execute(), which walks the 9 phases in order and skips the ones already done.

- `Run.execute()`
- `for each PHASE: skip if done; export-only runs skip phases 5–9`
- `RunNotifier.started() → email / Google Chat (if “run starts” is on)`

Next: Prepare

### 1. Prepare — `phase_prepare()`

Connects to both databases and writes the ora2pg configuration files for this run.

- `oracleClient.ensureOraclePool(), postgreClient.ensurePostgresPool()`
- `config_modify.buildConfig() → config/ddl.conf, data.conf, data_file.conf, ddl_tables.conf (ALLOW list)`
- `ora2pg --version → state.ora2pgMajor (24 or 25), psql --version`
- `chooseSnapshot(): SCN from v$database + AS OF probe; or “off” (current data)`
- Writes: runs/<id>/config/*.conf; state.snapshot = { mode: scn | current }

Next: Export DDL

### 2. Export DDL — `phase_ddl()`

ora2pg exports the definitions of tables, sequences, types and partitions to files. Kept on resume.

- `ora2pg -p -t TABLE / SEQUENCE / TYPE / PARTITION … -b schema/<dir>`
- `TABLE and SEQUENCE are required; the others are warnings if they fail`
- Writes: runs/<id>/schema/

Next: Create tables

### 3. Create tables — `phase_tables()`

Creates the schema, types, sequences, tables and partitions in PostgreSQL.

- `fixTypeLengths() (ora2pg type-length bug)`
- `sequence.sh (duplicate sequences), fts_bytea.sh / fts_oid.sh (full-text indexes)`
- `ensureDefaultPartitions()`
- `runDdlPhase() → sqlRunner.runSqlFile() in parallel`
- `tables that cannot be created: failed, their load skipped`

Next: Load data

### 4. Load data — `phase_data()`

Loads every table: biggest first, several at once (Tables in parallel). Each table runs the per-table pipeline below.

- `tables sorted by size, pLimit(parallelTables)`
- `loadTableWithRetry(name) for each`
- `progress “N done, M loading, K failed”`

Next: Indexes, Plan the table

### 5. Indexes — `phase_indexes()`

Primary keys, unique and check constraints, then indexes, after the data (much faster than during the load).

- `convertBlobsToOid() if BLOB → large object`
- `CONSTRAINTS_table.sql, INDEXES_table.sql via runSqlFile(parallel = ddlParallel, maintenance_work_mem)`
- `a failing statement is reported, the others continue`

Next: Foreign keys

### 6. Foreign keys — `phase_fkeys()`

Foreign keys are added NOT VALID (instant), then validated in parallel. A key whose rows do not match stays NOT VALID and is reported.

- `FKEYS_table.sql with “NOT VALID” added (not on partitioned tables)`
- `ALTER TABLE … VALIDATE CONSTRAINT in parallel`
- `failures → ddlFailures “Validate foreign keys”`

Next: Sequence values

### 7. Sequence values — `phase_sequences()`

Reads the sequence values from Oracle after the load and sets them in PostgreSQL.

- `ora2pg -t SEQUENCE_VALUES`
- `runDdlPhase(sequence_value.sql)`

Next: Apply code

### 8. Apply code — `phase_code()`

Applies the converted GenAI package chosen at start. Skipped if “migrate the data only” was chosen.

- `code.applyPackage(): FDW servers for DB links, files with psql in dependency order`

Next: Finalize

### 9. Finalize — `phase_finalize()`

Statistics, grants and the run summary.

- `bulkFinish() safety net: no table left unlogged or without autovacuum`
- `ANALYZE every loaded table`
- `settings.accessSql(): grants for the application roles, optional DUAL view`
- `summary.json`

Next: Run status

### Run status — `execute() → setStatus()`

COMPLETED, COMPLETED_WITH_ERRORS (some tables failed: Retry failed & resume), EXPORTED (export only), FAILED, CANCELLED or INTERRUPTED.

- `totals(): done / failed tables`
- `RunNotifier.finished() → email + Google Chat`
- `project_meta.json: migrationStatus, lastMigrationDate`

Next: Notifications

### Plan the table — `loadTableWithRetry()`

Done once per table: decides how it will be loaded.

- `object-type columns? → t.udt (loaded by loadObjectTable)`
- `LOB table? planLobs(): MAX(DBMS_LOB.GETLENGTH) → inline fetch if ≤ 16 MB`
- `big? shouldChunk() → planChunks(): numeric key ranges, or ROWID ranges from DBA_EXTENTS`

Next: Empty target

### Empty target — `prepareTarget()`

Makes the PostgreSQL table empty so a load or retry never duplicates rows.

- `dropReferencingFks() (re-created in phase 6)`
- `TRUNCATE (partitions included)`
- `bulkPrepare(): autovacuum off; SET UNLOGGED if “Unlogged load”`
- `chunked table with chunks done: only the unfinished chunk ranges are deleted`

Next: Copy rows

### Copy rows — `copyTable() / loadChunked()`

ora2pg copies the rows. Direct: straight into PostgreSQL. Files: export, then psql in one transaction. Huge tables: chunks in parallel.

- `ora2pg -t COPY -a TABLE (--scn N | --no_start_scn on 25)`
- `huge: -J readers -j writers; chunk: -W "range"; LOB: -L batch`
- `loadChunked(): oracleCopies chunks at once, each counted against Oracle`
- `loadObjectTable(): node-oracledb reader → \copy (object types)`
- `watchdog: no output for stallMinutes → killed, retried`

Next: Count rows, Failed → retry

### Count rows — `verifyTable()`

Exact COUNT(*) in Oracle (at the run’s snapshot) and in PostgreSQL. A difference is a failure.

- `SELECT COUNT(*) … AS OF SCN in Oracle`
- `count(*) in PostgreSQL`

Next: Checksums, Failed → retry

### Checksums — `verifyData()`

Per column: sum of numbers, sum of text lengths, sum of LOB sizes, on both sides. A difference is a mapping problem: failed without retry.

- `SUM(col), SUM(LENGTH(col)), SUM(DBMS_LOB.GETLENGTH(col))`
- `decimals normalised; CHAR, dates and floats skipped`
- `mismatch → err.noRetry`

Next: Make permanent, Failed → retry

### Make permanent — `bulkFinish()`

Undoes the bulk-load settings: SET LOGGED (unlogged load) and autovacuum back on.

- `ALTER TABLE … SET LOGGED`
- `ALTER TABLE … RESET (autovacuum_enabled)`

Next: Table done

### Table done — `updateTable(status: done)`

Only now is the table marked done; the next table starts in its slot.

- `state.json saved`
- `live “table” event to the monitor`

### Failed → retry — `maxAttempts, wait 10 s × attempt`

Any error: wait, then try again from “Empty target”. Data that does not fit (and checksum mismatches, ORA-01555 with a snapshot) is not retried. After the last attempt the table is failed and an attention message is sent.

- `loadTableWithRetry() catch block`
- `isStalled() → attention “hung load stopped”`
- `last attempt → RunNotifier.attention()`

Next: Empty target

### Pre-flight — `services/preflight.js`

Before the start: estimate, undo, disk, connections, WAL, network. Red items block POST /runs on the server too.

- `preflight(projectName, { tables, options, quick })`

Next: Start / resume

### Resume — `migrate.resumeRun()`

Refused if decisions changed. Failed/pending tables reset; done tables and chunks kept; phase 2 kept; prepare runs again (chooseSnapshot keeps the SCN unless snapshot is off).

- `decisionsHash() check → 409`
- `state.attempt + 1`
- `launch() → execute()`

Next: Start / resume

### Server restart — `recoverInterruptedRuns()`

pm2 restart or crash: the run is marked INTERRUPTED; leftover ora2pg/psql processes are stopped before anything resumes.

- `shutdown(): runs → INTERRUPTED`
- `at boot: recoverInterruptedRuns() → stopLeftoverProcesses(pids)`

Next: Resume

### Cancel — `Run.cancel()`

Kills the running ora2pg/psql process groups; running tables go back to pending. Status CANCELLED, resumable.

- `killProcessTree(child) for each child`
- `resetRunningTables()`

Next: Resume

### Notifications — `RunNotifier`

Email and Google Chat: run started (optional), needs attention (at most one per 10 min), run finished. One Chat thread per run.

- `services/notify.js: started(), attention(), finished()`
- `nodemailer (SMTP_*), Google Chat cardsV2 webhook`

### Live updates — `services/events.js`

Every change is pushed to the monitor: run totals every 2 s, table changes, log lines.

- `events.publish(project, run | table | log)`
- `GET /events (Server-Sent Events)`

## 3. API index

| Method | Path | Backend | Used by |
|---|---|---|---|
| GET | `/health` | `server.js` | not used by the screens |
| GET | `/projects` | `projectController.getMyProjects → projectStore.listProjects` | Home & projects › Open Home / All projects |
| POST | `/projects` | `projectController.projectSetup → projectStore.updateMeta` | Home & projects › New project → Create project |
| GET | `/projects/:name` | `projectController.getProject` | Home & projects › Open a project |
| PATCH | `/projects/:name` | `projectController.updateProject (not used by the screens)` | not used by the screens |
| DELETE | `/projects/:name` | `projectController.deleteProject → fs.rm` | Settings › Delete project (danger zone) |
| GET | `/projects/:name/events` | `projectController.projectEvents → events.stream` | Live updates › Live updates stream<br>Live monitor › Open a run |
| POST | `/projects/:name/columns` | `projectController.dbColUpdate` | Assessment › Save renames (reserved words) |
| POST | `/projects/:name/oracle/connect` | `oracleController.create → initOracle` | Connections › Oracle: Test & connect |
| GET | `/projects/:name/oracle/schemas` | `oracleController.listSchemas → getDBSchema` | Schema & snapshot › Page opens: list schemas |
| POST | `/projects/:name/schema` | `oracleController.selectSchema` | Schema & snapshot › Choose schema |
| POST | `/projects/:name/snapshot` | `oracleController.startSnapshot → snapshot.start` | Schema & snapshot › Take snapshot / Refresh snapshot |
| GET | `/projects/:name/snapshot` | `oracleController.getSnapshot → snapshot.status` | Schema & snapshot › Take snapshot / Refresh snapshot<br>Home & projects › Open a project |
| GET | `/projects/:name/prerequisites` | `oracleController.analyzePrerequisites → runPrerequisiteAnalysis` | Migrate › Run checks (pre-flight) |
| POST | `/projects/:name/postgres/connect` | `pgController.connectPg → initPostgres` | Connections › PostgreSQL: Test & connect |
| POST | `/projects/:name/postgres/disconnect` | `pgController.disconnectPg` | Connections › PostgreSQL: Disconnect |
| GET | `/projects/:name/postgres/checks` | `pgController.targetChecks` | Migrate › Run checks (pre-flight) |
| GET | `/projects/:name/validation` | `pgController.executePg (?recount=1)` | Validation › Page opens / Re-check<br>Validation › Recount all rows |
| GET | `/projects/:name/settings` | `settingsController.getSettings` | Settings › Page opens<br>Migrate › Page opens |
| PUT | `/projects/:name/settings` | `settingsController.saveSettings → settings.validate, notify.validate` | Settings › Save settings |
| GET | `/projects/:name/settings/preview` | `settingsController.previewConfig → buildConfig` | Settings › Preview ora2pg.conf |
| POST | `/projects/:name/settings/notifications/test` | `settingsController.testNotification → notify.test` | Settings › Send a test (notifications) |
| GET | `/projects/:name/code` | `codeController.overview` | Code objects (GenAI) › Page opens<br>Migrate › Page opens |
| POST | `/projects/:name/code/exports` | `codeController.startExport → code.startExport` | Code objects (GenAI) › Export & build zip |
| GET | `/projects/:name/code/exports/:id/download` | `codeController.downloadExport → code.exportZipPath` | Code objects (GenAI) › Export & build zip |
| POST | `/projects/:name/code/packages/part` | `codeController.uploadPart → code.uploadPackage` | Code objects (GenAI) › Upload converted zip |
| POST | `/projects/:name/code/packages` | `codeController.uploadPackage (single request, not used by the screens)` | not used by the screens |
| GET | `/projects/:name/code/packages/:id` | `codeController.getPackage → code.readPackage` | Code objects (GenAI) › Files and errors |
| DELETE | `/projects/:name/code/packages/:id` | `codeController.deletePackage → code.deletePackage` | Code objects (GenAI) › Delete package |
| POST | `/projects/:name/code/packages/:id/apply` | `codeController.applyPackage → code.startApply` | Code objects (GenAI) › Apply now / Apply to PostgreSQL now |
| PUT | `/projects/:name/code/dblinks` | `codeController.saveDbLinks` | Code objects (GenAI) › Save DB link mapping |
| GET | `/projects/:name/analysis` | `analysisController.overview` | Analysis report › Page opens<br>Settings › Page opens |
| POST | `/projects/:name/analysis` | `analysisController.start → analysis.start` | Analysis report › Run analysis |
| GET | `/projects/:name/analysis/:id` | `analysisController.getReport` | Analysis report › Page opens |
| GET | `/projects/:name/analysis/:id/download/:kind` | `analysisController.download → analysis.reportFile` | Analysis report › Download / Open full report / ora2pg report |
| GET | `/projects/:name/runs` | `runController.listRuns → migrate.listRuns` | Live monitor › Run list |
| POST | `/projects/:name/runs/preflight` | `runController.preflightRun → preflight` | Migrate › Run checks (pre-flight) |
| POST | `/projects/:name/runs` | `runController.startRun → migrate.startRun` | Migrate › Start migration |
| GET | `/projects/:name/runs/:runId` | `runController.getRun → migrate.readRunState` | Live monitor › Open a run |
| POST | `/projects/:name/runs/:runId/resume` | `runController.resumeRun → migrate.resumeRun` | Live monitor › Resume / Retry failed & resume<br>Live monitor › Resume without snapshot<br>Live monitor › Import exported files |
| POST | `/projects/:name/runs/:runId/cancel` | `runController.cancelRun → migrate.cancelRun` | Live monitor › Cancel run |
| GET | `/projects/:name/runs/:runId/logs/:kind` | `runController.downloadLog → migrate.runLogPath` | Live monitor › Logs menu<br>Live monitor › Click a table → its log |
