# Installing on Red Hat

Moved to **[HOW_TO_RUN_AND_DEPLOY.md](HOW_TO_RUN_AND_DEPLOY.md)** (part B), with the ready settings file
`backend/.env.redhat`, the nginx site `deploy/nginx-dma.conf` and the pm2 file `deploy/ecosystem.config.js`.
`deploy/dma.service` is an alternative to pm2 (systemd).
