# How to run (Windows) and deploy (Red Hat)

The application has two parts:

| Part | Folder | What it is | Port |
|---|---|---|---|
| Backend | `backend/` | Node.js API (`server.js`). Runs `ora2pg` and `psql` for the migrations. | 5055 |
| Frontend | `frontend/` | React app. `npm run build` turns it into plain files in `frontend/dist/`. | — |

The backend needs these programs on the **same machine**:
**ora2pg**, **Perl DBD::Oracle** (+ Oracle Instant Client), **Perl DBD::Pg**, **psql**, **bash**.

Settings live in **`backend/.env`**. There is one ready file per place:

| File | Use it on |
|---|---|
| `backend/.env.windows` | Windows (inside WSL2), part A |
| `backend/.env.redhat` | the Red Hat server, part B |

Copy the right one to `backend/.env` and change the lines marked `<-- CHANGE` / `<-- CHECK`.

**Already running v1 on Red Hat? Go to part B: only the code changes, nginx and URLs stay as they are.**

---

## Part A: Run on Windows

ora2pg and the helper scripts need Linux (Perl modules, bash). On Windows the app therefore runs inside
**WSL2** (Ubuntu in Windows). You still use it from your Windows browser.

### A1. One-time setup

1. **Install WSL2 + Ubuntu** (PowerShell as Administrator, then restart Windows):
   ```powershell
   wsl --install -d Ubuntu-22.04
   ```
   Open **Ubuntu** from the Start menu and create a user when asked.

2. **Install the tools** (in the Ubuntu window):
   ```bash
   sudo apt update
   sudo apt install -y curl unzip build-essential libaio1 postgresql-client libdbi-perl libdbd-pg-perl
   curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
   sudo apt install -y nodejs
   ```

3. **Oracle Instant Client** (basic + sdk zip files, version 21, Linux x86-64) from oracle.com, then:
   ```bash
   sudo mkdir -p /opt/oracle && cd /opt/oracle
   sudo unzip ~/instantclient-basic-linux.x64-21.*.zip
   sudo unzip ~/instantclient-sdk-linux.x64-21.*.zip
   ls -d /opt/oracle/instantclient_*           # note the folder name for .env
   export ORACLE_HOME=/opt/oracle/instantclient_21_15 LD_LIBRARY_PATH=/opt/oracle/instantclient_21_15
   sudo -E cpan DBD::Oracle
   ```

4. **ora2pg**:
   ```bash
   cd ~ && curl -L -o ora2pg.tar.gz https://github.com/darold/ora2pg/archive/refs/tags/v25.0.tar.gz
   tar xzf ora2pg.tar.gz && cd ora2pg-25.0 && perl Makefile.PL && make && sudo make install
   ora2pg --version                             # v24.x or v25.x
   ```

5. **Copy the application into WSL** (Linux folder, not `/mnt/c`: much faster). From the Ubuntu window:
   ```bash
   mkdir -p ~/dma && cp -r /mnt/c/<where you keep it>/dma-v2/* ~/dma/
   rm -rf ~/dma/backend/node_modules ~/dma/frontend/node_modules     # never reuse node_modules from Windows
   mkdir -p ~/ora2pg_staging
   ```

6. **Settings**:
   ```bash
   cd ~/dma/backend && cp .env.windows .env && nano .env
   ```
   Check `MIGRATION_STAGING_DIR` (e.g. `/home/<your user>/ora2pg_staging`), `ORACLE_HOME` / `LD_LIBRARY_PATH`
   (the folder from step 3), `ORA2PG_BIN` (`which ora2pg`), `PSQL_BIN` (`which psql`).

7. **Install the packages**:
   ```bash
   cd ~/dma/backend  && npm ci
   cd ~/dma/frontend && npm ci && npm run build
   ```

### A2. Start it (every time)

```bash
cd ~/dma/backend && node server.js
```

Open **http://localhost:5055** in your Windows browser. The backend serves the built frontend itself, so this
one command is enough. Stop it with `Ctrl+C`.

To work on the frontend code with live reload instead: keep the backend running and, in a second Ubuntu window,
`cd ~/dma/frontend && npm run dev`, then open **http://localhost:5175**.

---

## Part B: Upgrade v1 to v2 on Red Hat (same server, same nginx, same URLs)

v2 is a drop-in replacement for v1: **no nginx change, no new URL, same port**. Only the code changes.

| | v1 | v2 |
|---|---|---|
| Backend | `pm2` + `server.js` on port from `backend/.env` | the same |
| Frontend | `npm run build` → one `dist/index.html` | the same (one file, everything inside) |
| API address | `VITE_API_HOST` in `frontend/.env` | the same setting, same value |
| nginx | existing config | unchanged |

v2 is built to work with nginx's default settings: the live monitor sends a no-buffering header and a ping
every 15 s (no `proxy_buffering` / timeout change needed), and GenAI zips are uploaded in pieces under 1 MB (no
`client_max_body_size` change needed). Tested behind a stock nginx with default settings.

### B1. One-time: what v2 needs that v1 did not

1. **Node 18 or newer** on the server (`node -v`). v1 may have run on older Node; upgrade if needed.
2. **ora2pg 24 or 25** (your v1 server's ora2pg 24.x is fine: v2 detects the version and adapts; tested with 24.3
   and 25.0) and **DBD::Pg** (Perl), for the direct load: `ora2pg --version`, `perl -MDBD::Pg -e1` (no output
   = installed). Install commands: see part C, steps 1–3.
3. **Oracle grants** for the migration user (part C, step 6): `FLASHBACK ANY TABLE`, and `EXECUTE ANY TYPE` if the
   schema has object-type columns. The pre-flight checks tell you if one is missing.

### B2. Backend

1. Stop v1: `pm2 stop ora2pg-service-prod` (or the name `pm2 list` shows).
2. Keep a copy of v1's backend folder and of its `.env`.
3. Copy the v2 `backend/` folder over (without `node_modules`).
4. Settings: `cp .env.redhat .env`, then edit:
   - `PORT` = **the same port as v1's `.env`** (so nginx and the frontend keep pointing to it)
   - `MIGRATION_STAGING_DIR`, `SECRET_KEY`, `ORA2PG_BIN`, `PSQL_BIN`, `ORACLE_HOME`, `PG_SSL`: see the comments in the file.
5. Install and start, with the same pm2 name as v1:
   ```bash
   cd <backend folder>
   npm ci --omit=dev
   npm run start:prod          # = pm2 start server.js --name ora2pg-service-prod  (no watch mode)
   pm2 save
   curl http://127.0.0.1:<PORT>/api/health          # {"status":"ok",...}
   ```
   Do not use `npm start` on the server: it runs pm2 in watch mode, which restarts the app when log files change.

### B3. Frontend

1. In v2's `frontend/.env`, set `VITE_API_HOST` to **exactly the value in v1's `frontend/.env`**.
2. Build and copy, as with v1:
   ```bash
   cd frontend
   npm ci
   npm run build                       # creates ONE file: dist/index.html
   ```
   Replace v1's `index.html` in the nginx html folder with `dist/index.html`. Nothing else to copy.

Open the usual URL. Ctrl+F5 once so the browser drops v1's cached page.

### B4. Going back to v1 (if ever needed)

`pm2 stop ora2pg-service-prod`, put v1's backend folder and `index.html` back, `npm run start:prod` in it.
v1 and v2 keep their projects in their own staging folders, so neither touches the other's data.

---

## Part C: New server from scratch (only when there is no v1 yet)


Final picture:

```
browser ──► nginx :80 ──► /            files of frontend/dist   (/usr/share/nginx/html/dma)
                    └──► /api/...      node backend :5055        (pm2, user "dma")
                                         └─► ora2pg, psql  ──► Oracle / PostgreSQL
```

### C1. One-time server setup (as root / sudo)

1. **Packages**:
   ```bash
   sudo dnf module enable -y nodejs:20 && sudo dnf install -y nodejs          # RHEL 9: sudo dnf install -y nodejs
   sudo dnf install -y https://dl.fedoraproject.org/pub/epel/epel-release-latest-$(rpm -E %rhel).noarch.rpm
   sudo dnf install -y postgresql perl perl-DBI perl-DBD-Pg perl-Time-HiRes perl-ExtUtils-MakeMaker gcc make bash sed nginx unzip
   sudo npm install -g pm2
   ```

2. **Oracle Instant Client + DBD::Oracle**:
   ```bash
   sudo dnf install -y oracle-instantclient-basic oracle-instantclient-devel      # Oracle's yum repo or the RPM files
   ls -d /usr/lib/oracle/*/client64                                               # note the folder for .env
   export ORACLE_HOME=/usr/lib/oracle/21/client64 LD_LIBRARY_PATH=/usr/lib/oracle/21/client64/lib
   sudo -E cpan DBD::Oracle
   ```

3. **ora2pg** (24.x or 25.x both work; 25.0 for a new server):
   ```bash
   curl -L -o ora2pg.tar.gz https://github.com/darold/ora2pg/archive/refs/tags/v25.0.tar.gz
   tar xzf ora2pg.tar.gz && cd ora2pg-25.0 && perl Makefile.PL && make && sudo make install
   ora2pg --version          # v25.0
   which ora2pg psql         # note both paths for .env
   ```

4. **User and folders**:
   ```bash
   sudo useradd -r -m -d /opt/dma dma
   sudo mkdir -p /data/ora2pg_staging /usr/share/nginx/html/dma
   sudo chown dma:dma /data/ora2pg_staging
   ```

### C2. Copy the code from Windows

Copy the `dma-v2` folder to the server (WinSCP, or `scp -r` from PowerShell) into **`/opt/dma`**,
**without** the `node_modules` folders. You need on the server:

```
/opt/dma/backend/     (all files, including .env.redhat and scripts/)
/opt/dma/frontend/
/opt/dma/deploy/
```

Then:
```bash
sudo chown -R dma:dma /opt/dma
```

### C3. Backend

```bash
sudo -iu dma
cd /opt/dma/backend
cp .env.redhat .env
vi .env                     # set SECRET_KEY, check MIGRATION_STAGING_DIR, ORA2PG_BIN, PSQL_BIN, ORACLE_HOME, PG_SSL
npm ci --omit=dev           # installs the Node packages on Linux (never copy them from Windows)

cd /opt/dma
pm2 start deploy/ecosystem.config.js
pm2 save
exit                        # back to your own user
sudo env PATH=$PATH pm2 startup systemd -u dma --hp /opt/dma    # start again after a server reboot
```

Check: `curl http://127.0.0.1:5055/api/health` must answer `{"status":"ok",...}`.

> Do **not** use `npm start` / `pm2 start server.js --watch` on the server: watch mode restarts the app every
> time a log file changes and interrupts running migrations. `deploy/ecosystem.config.js` has the right settings.

### C4. Frontend

Build it (on the server, or on Windows and copy the result):
```bash
cd /opt/dma/frontend
npm ci
npm run build                                   # creates /opt/dma/frontend/dist
sudo cp dist/index.html /usr/share/nginx/html/dma/    # one file
```

### C5. nginx (new server only; an existing v1 nginx needs no change)

```bash
sudo cp /opt/dma/deploy/nginx-dma.conf /etc/nginx/conf.d/dma.conf
sudo vi /etc/nginx/conf.d/dma.conf              # server_name = your host name
sudo setsebool -P httpd_can_network_connect 1   # SELinux: let nginx reach the backend on 5055
sudo nginx -t && sudo systemctl enable --now nginx && sudo systemctl reload nginx
sudo firewall-cmd --permanent --add-service=http && sudo firewall-cmd --reload
```

This config is a clean starting point for a new server. v2 also works with nginx defaults (see part B).

Open **http://&lt;server&gt;/**.

*No nginx?* The backend serves the UI itself when `frontend/dist` sits next to `backend/`: open
`http://<server>:5055` (open port 5055 in the firewall).

### C6. Oracle privileges for the migration user

Give the user the app connects with (read-only is fine):

```sql
GRANT CREATE SESSION, SELECT ANY DICTIONARY, SELECT_CATALOG_ROLE, SELECT ANY TABLE, SELECT ANY SEQUENCE TO <user>;
GRANT FLASHBACK ANY TABLE TO <user>;    -- consistent snapshot (recommended)
GRANT EXECUTE ANY TYPE TO <user>;       -- only if the schema has object-type columns
```

The **Pre-flight checks** on the Migrate page say if anything is missing.

---

## Before a big migration (500 GB – 1 TB)

1. **Migrate page → select the tables → Run checks.** Besides privileges, the pre-flight checks the planned run:

   | Check | What it means | If it is red / amber |
   |---|---|---|
   | Estimated duration | selected size ÷ speed (measured on this project, else 30 GB/h like v1) | – |
   | Snapshot vs undo | the run reads every table as of its start, so Oracle must keep undo that long | DBA raises `UNDO_RETENTION` (the check prints the value), or stop the application and switch *Consistent snapshot* off |
   | Staging disk | room for the files the load mode writes | free space, use Direct load, or fewer tables in parallel (**blocks the start**) |
   | PostgreSQL connections / Oracle processes | the parallel readers and writers fit | lower *Tables in parallel* or ask the DBA (**blocks the start**) |
   | WAL & checkpoints | `max_wal_size` below 4 GB slows a bulk load a lot | DBA sets `max_wal_size = 16GB`, `checkpoint_timeout = 15min` for the window |
   | Network to Oracle / PostgreSQL | round trip and MB/s from the app server | run the app close to both databases |

   Changing the tables or settings asks for the checks again before Start is allowed.
2. **Settings → Notifications:** email addresses and/or a Google Chat space webhook (space → Apps & integrations → Webhooks), then *Send a test*. You get a message when the run
   ends (with duration and failed tables) and when something needs attention (a table failed after all retries, a hung
   load was stopped). Email needs the `SMTP_*` lines in `backend/.env`.
3. **Optional, Migrate page → Performance & safety:** *Unlogged load* writes the rows without WAL and makes each table
   permanent once its row count and checksums pass. Faster when the WAL disk is the bottleneck; with streaming replicas
   the WAL is still sent once per table at the end.
4. If a run stops with *"Oracle's undo no longer reaches the run's snapshot"* (ORA-01555), the run page shows
   **Resume without snapshot**: the remaining tables are read as they are now (keep the application stopped).

Foreign keys are added `NOT VALID` (instant) and then validated in parallel. A key whose existing rows do not match
stays in place as NOT VALID and is listed with the reason in the run's DDL failures.

## Updating v2 to a newer v2 (Red Hat)

```bash
# 1. no migration running (Live monitor), then copy the new files over /opt/dma (keep backend/.env!)
sudo -iu dma
cd /opt/dma/backend && npm ci --omit=dev
cd /opt/dma/frontend && npm ci && npm run build && exit
sudo cp -r /opt/dma/frontend/dist/* /usr/share/nginx/html/dma/
sudo -iu dma pm2 restart dma
```

If a migration was running during a restart it shows **Interrupted**: open it and press **Resume**.

---

## Where to look when something is wrong

| What | Where |
|---|---|
| Backend running? | `sudo -iu dma pm2 status` · `curl http://127.0.0.1:5055/api/health` |
| Backend log | `sudo -iu dma pm2 logs dma` · `/opt/dma/backend/logs/` |
| One migration's logs | Live monitor → **Logs**, or `<MIGRATION_STAGING_DIR>/<project>/runs/<run>/logs/` |
| One table's log | Live monitor → table row → log icon |
| nginx | `/var/log/nginx/error.log` |

| Problem | Fix |
|---|---|
| Live monitor does not update | check `VITE_API_HOST` is the same as v1's and the backend is running; the page reconnects by itself |
| `502 Bad Gateway` | backend not running (`pm2 status`), or SELinux: `setsebool -P httpd_can_network_connect 1` |
| Upload of the GenAI zip fails | the zip is over 500 MB, or the backend log says why |
| `ora2pg is not available` | `ORA2PG_BIN` in `.env` (`which ora2pg`) |
| `Can't locate DBD/Oracle.pm` / `libclntsh.so` | DBD::Oracle not installed or `ORACLE_HOME` / `LD_LIBRARY_PATH` in `.env` wrong |
| `ORA-41900 missing FLASHBACK privilege` | `GRANT FLASHBACK ANY TABLE` (or the app reads current data: stop the application during the load) |
| `OCI-21700` on a table | `GRANT EXECUTE ANY TYPE` |
| All projects lost their passwords | `SECRET_KEY` changed: put the old one back, or reconnect each project |
