# Upgrade v1 → v2: step by step

Same server, same nginx, same URLs, same pm2 command. Only the code changes.

## What is in the zip

```
backend/    v2 backend (no node_modules, no .env)
frontend/   v2 frontend (no node_modules, no .env, no dist)
docs/       guides: HOW_MIGRATE_WORKS.md, FLOW_MAP.md, flow-map/index.html (open in a browser), MIGRATION_LESSONS.md
deploy/     this file, HOW_TO_RUN_AND_DEPLOY.md, optional nginx/pm2 files for a new server
dev-tools/  local test setup (test Oracle schema scripts); not needed on the server
README.md
```

Your own `.env` files are **not** in the zip on purpose: keep v1's.

---

## A. On Windows: new branch with the v2 code

1. In the v1 repository: `git checkout -b v2` (any branch name).
2. **Backend:** delete everything in v1's `backend/` **except `.env`** (and `node_modules` if you like), then copy the zip's
   `backend/` content in.
   Delete first, do not only copy over: v1 files that v2 no longer has (for example `routes/oracleRoutes.js`,
   `utils/rescue_upload.js`) would otherwise stay in the branch.
3. **Frontend:** same: delete everything in v1's `frontend/` **except `.env`**, copy the zip's `frontend/` in.
   `frontend/.env` keeps v1's `VITE_API_HOST` value: that is what keeps the URLs unchanged.
4. **backend/.env:** keep v1's values and add the new lines from `backend/.env.redhat`:
   - `PORT` = the same as v1 (do not change it)
   - `MIGRATION_STAGING_DIR`, `SECRET_KEY`, `ORA2PG_BIN`, `PSQL_BIN`, `ORACLE_HOME`, `LD_LIBRARY_PATH`, `PG_SSL`
   - optional: `SMTP_*`, `APP_URL` (email notifications), `SESSION_SECRET` (only when SSO is switched on)
5. Install and build:
   ```bash
   cd backend
   npm install
   cd ../frontend
   npm install
   npm run build
   ```
   `npm run build` creates **one file**: `frontend/dist/index.html`.
6. Optional check on Windows: `cd backend` then `npm run dev`, and open the app. Screens and connections work;
   migrations need ora2pg, which runs on the RHEL server (or in WSL, see HOW_TO_RUN_AND_DEPLOY.md part A).
   (`npm run start:prod` is for RHEL: its `NODE_ENV=production` syntax does not work in Windows cmd.)
7. Commit and push the branch. Check that `backend/.env` and `node_modules` are not in the commit
   (the zip has `.gitignore` files for both folders).

## B. On the RHEL server

1. Stop v1 (the name `pm2 list` shows):
   ```bash
   pm2 stop ora2pg-service-prod
   pm2 delete ora2pg-service-prod     # otherwise start:prod refuses: "already launched"
   ```
2. Switch to the branch:
   ```bash
   git fetch
   git checkout v2
   ```
3. Backend packages (v2 has new ones: nodemailer, passport, …):
   ```bash
   cd backend
   npm ci --omit=dev
   ```
4. Check `backend/.env` on the server: same `PORT` as v1, plus the new lines from `.env.redhat` (step A4).
5. Frontend: copy the `dist/index.html` you built on Windows over v1's `index.html` in the nginx html folder.
   Only that one file.
6. Start:
   ```bash
   npm run start:prod                 # = pm2 start server.js --name ora2pg-service-prod
   pm2 save
   curl http://127.0.0.1:<PORT>/api/health      # {"status":"ok",...}
   ```
7. Open the usual URL, press Ctrl+F5 once (the browser may hold v1's page).

## C. First checks in the app

1. Open a project → **Migrate** → the pre-flight checks run by themselves. All environment checks should be green
   (ora2pg 24 or 25, psql, DBD::Pg for direct load, Oracle grants).
2. **Settings → Notifications → Send a test** if SMTP or Google Chat is set.
3. Run the 150 GB test. Note the time, the warnings and any failed tables.

## D. Going back to v1

```bash
pm2 delete ora2pg-service-prod
git checkout <v1 branch>
cd backend && npm ci --omit=dev && npm run start:prod
```
and put v1's `index.html` back in the nginx folder. v1 and v2 keep their projects in their own staging folders.

## E. Corporate SSO (later)

The SAML code is in `backend/server.js`, commented out, with v1's IdP settings. To switch it on:

1. Paste the IdP certificate into `IDP_CERT` (one line, without the BEGIN/END lines).
2. Set `SESSION_SECRET` in `backend/.env`.
3. Uncomment the block, and use the line `app.use("/api", isAuthenticated, projectRoutes);` instead of the one above it.
4. `pm2 restart ora2pg-service-prod`.

The packages (`passport`, `@node-saml/passport-saml`, `express-session`) are already in `package.json`.
The routes stay as in v1 (`/api/auth/login`, `/auth/callback`, `/api/auth/logout`, `/api/auth/me`); nginx must keep
sending `/auth/callback` to the backend, as it does for v1. Tested here with a dummy certificate:
`/api/health` stays open, the API answers 401 without login, and `/api/auth/login` redirects to the IdP.
