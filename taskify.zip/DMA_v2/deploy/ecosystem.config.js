// pm2 configuration for the Database Migration Accelerator.
// Start:   pm2 start deploy/ecosystem.config.js        (from the project folder)
// Restart: pm2 restart dma      Logs: pm2 logs dma      Boot: pm2 save && pm2 startup
module.exports = {
  apps: [
    {
      name: 'dma',
      cwd: `${__dirname}/../backend`,
      script: 'server.js',
      // Never watch: the app writes logs and run files while migrating, and a watch restart would
      // interrupt running migrations.
      watch: false,
      instances: 1, // one process: it owns the running migrations
      autorestart: true,
      // On stop/restart the app stops its ora2pg/psql processes and marks runs INTERRUPTED (resumable).
      kill_timeout: 30000,
      max_memory_restart: '4G',
      env: { NODE_ENV: 'production' },
    },
  ],
};
