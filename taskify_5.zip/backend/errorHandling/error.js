'use strict';

const fs = require("fs");
const path = require("path");
const { spawn } = require('child_process');
const logger = require('../utils/logger');

/**
 * v2: every migration run has its own log folder (runs/<runId>/logs) instead of one global
 * <SCHEMA>_MasterLogfile.log shared by everybody:
 *   master.log         everything, in order
 *   error.log          only real errors
 *   success.log        completed steps
 *   tables/<T>.log     full ora2pg / psql output of one table
 */
const ERROR_RE = /(\bERROR:|\bFATAL:|ORA-\d{5}|DBD::\w+::\w+ \w+ failed|[Cc]ommand not found|No such file or directory|Aborting export)/;

const mask = (s) => String(s)
  .replace(/PGPASSWORD="[^"]*"/g, 'PGPASSWORD="****"')
  .replace(/(PG_PWD|ORACLE_PWD)\s+\S+/g, '$1 ****')
  .replace(/password=[^\s;]+/gi, 'password=****');

function createRunLogger(runDir) {
  const dir = path.join(runDir, 'logs');
  fs.mkdirSync(path.join(dir, 'tables'), { recursive: true });
  const open = (name) => fs.createWriteStream(path.join(dir, name), { flags: 'a' });
  const master = open('master.log');
  const error = open('error.log');
  const success = open('success.log');
  const ts = () => new Date().toISOString();

  return {
    dir,
    info(msg) {
      master.write(`[${ts()}] ${mask(msg)}\n`);
    },
    success(msg) {
      const line = `[${ts()}] *** ${mask(msg)}\n`;
      master.write(line);
      success.write(line);
    },
    error(msg) {
      const line = `[${ts()}] !!! ${mask(msg)}\n`;
      master.write(line);
      error.write(line);
    },
    tableLog(table) {
      return fs.createWriteStream(path.join(dir, 'tables', `${table.replace(/[^A-Za-z0-9_$#.-]/g, '_')}.log`), { flags: 'a' });
    },
    close() {
      [master, error, success].forEach((s) => s.end());
    },
  };
}

/**
 * Runs a command without a shell (arguments are passed as a list, so table names and passwords
 * can never be interpreted by a shell). Output is split into lines (ora2pg progress bars use \r)
 * and handed to onLine. Resolves with { code, errorTail }; never rejects.
 *
 * @param {object} p
 * @param {string} p.cmd
 * @param {string[]} p.args
 * @param {string} [p.cwd]
 * @param {object} [p.env]          extra environment variables (e.g. PGPASSWORD)
 * @param {object} [p.log]          a run logger (createRunLogger)
 * @param {fs.WriteStream} [p.out]  per-table log stream
 * @param {(line:string, stream:string)=>void} [p.onLine]
 * @param {Set} [p.children]        the run's process registry (used to cancel)
 * @param {string} p.label
 */
/**
 * idleTimeoutMs: watchdog. If the process prints nothing for this long it is considered hung (e.g. a
 * half-open network connection that never errors) and its process group is stopped; the result then
 * has stalled: true so the caller can retry.
 */
const fmtIdle = (ms) => (ms >= 60000 ? `${Math.round(ms / 60000)} min` : `${Math.round(ms / 1000)} s`);

/**
 * ora2pg checks its temporary folder (default /tmp) when it ends and exits with code 2, "an error
 * occurs during data export", if any tmp_ora2pg* file is there; and when it starts it deletes such
 * files. Several ora2pg processes sharing /tmp (parallel tables and chunks) therefore report false
 * errors and can break each other. Each ora2pg run gets its own folder (-T), removed afterwards.
 */
function isOra2pg(cmd) {
  return /^ora2pg(\.(pl|bat|cmd))?$/i.test(path.basename(String(cmd || '')));
}

function executeAndLog(opts) {
  const { cmd, args } = opts;
  if (!isOra2pg(cmd) || args.includes('-T') || args.includes('--temp_dir') || args.includes('--version')) return runProcess(opts);
  const { CONSTANTS } = require('../utils/constants');
  const dir = path.join(CONSTANTS.STAGING_DIR, '.ora2pg_tmp', `${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`);
  try {
    fs.mkdirSync(dir, { recursive: true });
  } catch {
    return runProcess(opts); // cannot create it: run as before
  }
  return runProcess({ ...opts, args: [...args, '-T', dir] })
    .finally(() => { try { fs.rmSync(dir, { recursive: true, force: true }); } catch { /* already gone */ } });
}

function runProcess({ cmd, args, cwd, env, log, out, onLine, children, label, captureStdout, idleTimeoutMs }) {
  const started = Date.now();
  log && log.info(`>>> START: ${label}\n    CMD: ${cmd} ${args.map((a) => (/\s/.test(a) ? `"${a}"` : a)).join(' ')}`);
  logger.info(`Starting ${label}`);

  return new Promise((resolve) => {
    let child;
    try {
      child = spawn(cmd, args, {
        cwd: cwd || process.cwd(),
        env: { ...process.env, ...(env || {}) },
        detached: process.platform !== 'win32', // own process group, so cancel can stop the whole tree
      });
    } catch (err) {
      log && log.error(`${label}: could not start ${cmd}: ${err.message}`);
      return resolve({ code: 1, errorTail: err.message });
    }
    if (children) children.add(child);

    let errorTail = '';
    let stalled = false;
    let idleTimer = null;
    const armWatchdog = () => {
      if (!idleTimeoutMs) return;
      clearTimeout(idleTimer);
      idleTimer = setTimeout(() => {
        stalled = true;
        log && log.error(`${label}: no output for ${fmtIdle(idleTimeoutMs)}, stopping it (hung connection?)`);
        killProcessTree(child);
      }, idleTimeoutMs);
    };
    armWatchdog();
    let stdout = ''; // whole stdout, only when the caller needs it (e.g. ora2pg --dump_as_json)
    const buffers = { stdout: '', stderr: '' };

    const handle = (streamName) => (data) => {
      const text = data.toString();
      armWatchdog();
      if (out) out.write(text);
      if (captureStdout && streamName === 'stdout') stdout += text;
      buffers[streamName] += text;
      const parts = buffers[streamName].split(/\r\n|\r|\n/);
      buffers[streamName] = parts.pop();
      for (const line of parts) {
        if (!line.trim()) continue;
        if (ERROR_RE.test(line)) {
          errorTail = (errorTail + line + '\n').slice(-2000);
          log && log.error(`${label}: ${line}`);
        }
        if (onLine) onLine(line, streamName);
      }
    };
    child.stdout.on('data', handle('stdout'));
    child.stderr.on('data', handle('stderr'));

    child.on('error', (err) => {
      errorTail += err.message;
      log && log.error(`${label}: spawn failed: ${err.message}`);
    });

    child.on('close', (code, signal) => {
      clearTimeout(idleTimer);
      if (children) children.delete(child);
      for (const s of ['stdout', 'stderr']) {
        if (buffers[s].trim() && onLine) onLine(buffers[s], s);
      }
      const secs = ((Date.now() - started) / 1000).toFixed(1);
      const exitCode = code === null ? 1 : code;
      if (exitCode === 0) log && log.success(`${label} finished in ${secs}s`);
      else log && log.error(`${label} FAILED (exit ${code}${signal ? `, signal ${signal}` : ''}) after ${secs}s`);
      resolve({ code: stalled ? 1 : exitCode, signal, stalled, errorTail: stalled ? `No output for ${fmtIdle(idleTimeoutMs)}: stopped as hung` : errorTail.trim(), ...(captureStdout && { stdout }) });
    });
  });
}

function killProcessTree(child) {
  try {
    if (process.platform !== 'win32') process.kill(-child.pid, 'SIGTERM');
    else child.kill('SIGTERM');
  } catch {
    try { child.kill('SIGKILL'); } catch { /* already gone */ }
  }
}

module.exports = {
  createRunLogger,
  executeAndLog,
  killProcessTree,
  mask,
};
