import { Box, Breadcrumbs, Drawer, IconButton, Link, Stack, Tooltip, Typography } from '@mui/material';
import MenuRoundedIcon from '@mui/icons-material/MenuRounded';
import KeyboardDoubleArrowLeftRoundedIcon from '@mui/icons-material/KeyboardDoubleArrowLeftRounded';
import KeyboardDoubleArrowRightRoundedIcon from '@mui/icons-material/KeyboardDoubleArrowRightRounded';
import { ReactNode, useState } from 'react';
import { Link as RouterLink, NavLink } from 'react-router-dom';
import { brand, headingFont } from '../theme';
import UserMenu from './UserMenu';

export interface NavItem {
  to: string;
  label: string;
  icon: ReactNode;
  end?: boolean;
  /** small indicator on the right: 'done' (check), 'live' (pulsing dot), or a number badge */
  badge?: 'done' | 'live' | number | null;
}
export interface NavSection {
  title?: string;
  header?: ReactNode;
  items: NavItem[];
}

const WIDE = 268;
const NARROW = 76;

function Logo({ collapsed }: { collapsed: boolean }) {
  return (
    <Stack component={RouterLink} to="/" direction="row" spacing={1.5} alignItems="center" sx={{ textDecoration: 'none', color: '#fff', px: collapsed ? 0 : 0.5, justifyContent: collapsed ? 'center' : 'flex-start' }}>
      <Box sx={{ width: 40, height: 40, borderRadius: 3, flexShrink: 0, background: brand.accentGradient, display: 'grid', placeItems: 'center', boxShadow: '0 8px 20px -6px rgba(34,166,242,.6)' }}>
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden>
          <ellipse cx="12" cy="5.5" rx="7" ry="2.8" stroke="#fff" strokeWidth="1.8" />
          <path d="M5 5.5v6c0 1.5 3.1 2.8 7 2.8s7-1.3 7-2.8v-6" stroke="#fff" strokeWidth="1.8" />
          <path d="M5 11.5v6c0 1.5 3.1 2.8 7 2.8" stroke="#fff" strokeWidth="1.8" />
          <path d="M15.5 17.5h5m0 0-2-2m2 2-2 2" stroke="#fff" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </Box>
      {!collapsed && (
        <Box sx={{ minWidth: 0 }}>
          <Typography sx={{ fontFamily: headingFont, fontWeight: 800, fontSize: 15.5, lineHeight: 1.15, letterSpacing: '-0.01em' }} noWrap>Migration Accelerator</Typography>
          <Typography sx={{ fontSize: 11.5, color: 'rgba(255,255,255,.6)' }} noWrap>Oracle → PostgreSQL</Typography>
        </Box>
      )}
    </Stack>
  );
}

function SideItem({ item, collapsed }: { item: NavItem; collapsed: boolean }) {
  const content = (
    <Box component={NavLink} to={item.to} end={item.end}
      sx={{
        display: 'flex', alignItems: 'center', gap: 1.5, px: collapsed ? 0 : 1.5, py: 1.05, mb: 0.5, borderRadius: 2.5,
        justifyContent: collapsed ? 'center' : 'flex-start',
        color: 'rgba(255,255,255,.72)', textDecoration: 'none', position: 'relative', transition: 'background .15s, color .15s',
        '& svg': { fontSize: 20 },
        '&:hover': { bgcolor: 'rgba(255,255,255,.07)', color: '#fff' },
        '&.active': {
          bgcolor: 'rgba(255,255,255,.12)', color: '#fff',
          boxShadow: 'inset 0 0 0 1px rgba(255,255,255,.08)',
          '&::before': { content: '""', position: 'absolute', left: collapsed ? 6 : -10, top: 10, bottom: 10, width: 3, borderRadius: 3, background: '#5EB4FF' },
        },
      }}>
      <Box sx={{ display: 'grid', placeItems: 'center', width: 22, flexShrink: 0 }}>{item.icon}</Box>
      {!collapsed && <Typography sx={{ fontSize: 14, fontWeight: 600, flex: 1, minWidth: 0 }} noWrap>{item.label}</Typography>}
      {!collapsed && item.badge === 'done' && <Box sx={{ width: 18, height: 18, borderRadius: '50%', bgcolor: 'rgba(14,159,110,.25)', color: '#5EE3B0', display: 'grid', placeItems: 'center', fontSize: 11, fontWeight: 900 }}>✓</Box>}
      {item.badge === 'live' && (
        <Box sx={{ width: 9, height: 9, borderRadius: '50%', bgcolor: '#5EB4FF', position: collapsed ? 'absolute' : 'static', top: 8, right: 14,
          animation: 'dmaPulse 1.6s ease-out infinite', '@keyframes dmaPulse': { '0%': { boxShadow: '0 0 0 0 rgba(94,180,255,.7)' }, '100%': { boxShadow: '0 0 0 10px rgba(94,180,255,0)' } } }} />
      )}
      {!collapsed && typeof item.badge === 'number' && item.badge > 0 && (
        <Box sx={{ px: 0.9, minWidth: 22, height: 20, borderRadius: 10, bgcolor: 'rgba(255,255,255,.14)', color: '#fff', fontSize: 11.5, fontWeight: 700, display: 'grid', placeItems: 'center' }}>{item.badge}</Box>
      )}
    </Box>
  );
  return collapsed ? <Tooltip title={item.label} placement="right">{content}</Tooltip> : content;
}

/**
 * Application frame: left navigation (collapsible, remembered per browser) and a top bar with
 * breadcrumbs. Every page uses it.
 */
export default function Shell({ sections, crumbs, topRight, children }: { sections: NavSection[]; crumbs: { label: string; to?: string }[]; topRight?: ReactNode; children: ReactNode }) {
  const [collapsed, setCollapsed] = useState(() => {
    try { return localStorage.getItem('dma.sidebar') === 'collapsed'; } catch { return false; }
  });
  const toggle = () => {
    setCollapsed((c) => {
      try { localStorage.setItem('dma.sidebar', c ? 'open' : 'collapsed'); } catch { /* private mode */ }
      return !c;
    });
  };
  const width = collapsed ? NARROW : WIDE;
  const [mobileOpen, setMobileOpen] = useState(false);

  const navContent = (collapsed: boolean, canCollapse: boolean) => (
    <>
        <Box sx={{ px: collapsed ? 1.5 : 2.5, pt: 2.5, pb: 2 }}><Logo collapsed={collapsed} /></Box>
        <Box sx={{ flex: 1, overflowY: 'auto', overflowX: 'hidden', px: collapsed ? 1.25 : 2, pb: 2 }}>
          {sections.map((sec, i) => (
            <Box key={i} sx={{ mt: i ? 2.5 : 0.5 }}>
              {!collapsed && sec.title && <Typography sx={{ fontSize: 11, fontWeight: 700, letterSpacing: '.12em', textTransform: 'uppercase', color: 'rgba(255,255,255,.42)', px: 1.5, mb: 1 }}>{sec.title}</Typography>}
              {collapsed && i > 0 && <Box sx={{ height: 1, bgcolor: 'rgba(255,255,255,.1)', mx: 1, mb: 1.5 }} />}
              {!collapsed && sec.header}
              {sec.items.map((it) => <SideItem key={it.to + it.label} item={it} collapsed={collapsed} />)}
            </Box>
          ))}
        </Box>
        <Stack direction="row" alignItems="center" justifyContent={collapsed ? 'center' : 'space-between'} sx={{ px: collapsed ? 1 : 2.5, py: 1.5, borderTop: '1px solid rgba(255,255,255,.08)' }}>
          {!collapsed && <Typography sx={{ fontSize: 11.5, color: 'rgba(255,255,255,.45)' }}>DMA v2.0 · ora2pg</Typography>}
          {canCollapse && (
          <Tooltip title={collapsed ? 'Expand menu' : 'Collapse menu'} placement="right">
            <IconButton size="small" onClick={toggle} sx={{ color: 'rgba(255,255,255,.7)', '&:hover': { bgcolor: 'rgba(255,255,255,.08)' } }}>
              {collapsed ? <KeyboardDoubleArrowRightRoundedIcon fontSize="small" /> : <KeyboardDoubleArrowLeftRoundedIcon fontSize="small" />}
            </IconButton>
          </Tooltip>
          )}
        </Stack>
    </>
  );


  return (
    <Box sx={{ minHeight: '100vh', display: 'flex' }}>
      <Box component="nav" sx={{
        width, flexShrink: 0, position: 'sticky', top: 0, height: '100vh', background: brand.sidebar, color: '#fff',
        display: { xs: 'none', md: 'flex' }, flexDirection: 'column', transition: 'width .2s ease', zIndex: 2,
        boxShadow: '1px 0 0 rgba(255,255,255,.04), 8px 0 30px -18px rgba(0,0,0,.5)',
      }}>
        {navContent(collapsed, true)}
      </Box>

      <Drawer open={mobileOpen} onClose={() => setMobileOpen(false)} sx={{ display: { md: 'none' } }}
        PaperProps={{ sx: { width: WIDE, background: brand.sidebar, color: '#fff', border: 'none' } }} onClick={() => setMobileOpen(false)}>
        {navContent(false, false)}
      </Drawer>

      <Box sx={{ flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column' }}>
        <Box component="header" sx={{
          position: 'sticky', top: 0, zIndex: 3, height: 64, px: { xs: 2, md: 4 }, display: 'flex', alignItems: 'center', gap: 2,
          bgcolor: 'rgba(255,255,255,.82)', backdropFilter: 'saturate(180%) blur(12px)', borderBottom: `1px solid ${brand.border}`,
        }}>
          <IconButton sx={{ display: { md: 'none' } }} onClick={() => setMobileOpen(true)} aria-label="Open menu"><MenuRoundedIcon /></IconButton>
          <Breadcrumbs separator="/" sx={{ flex: 1, minWidth: 0, '& .MuiBreadcrumbs-ol': { flexWrap: 'nowrap' }, '& li': { minWidth: 0 } }}>
            {crumbs.map((c, i) => (i < crumbs.length - 1 && c.to ? (
              <Link key={i} component={RouterLink} to={c.to} underline="hover" color="text.secondary" sx={{ fontWeight: 600, fontSize: 14 }} noWrap>{c.label}</Link>
            ) : (
              <Typography key={i} color="text.primary" sx={{ fontWeight: 700, fontSize: 14 }} noWrap>{c.label}</Typography>
            )))}
          </Breadcrumbs>
          {topRight}
          <UserMenu />
        </Box>
        <Box component="main" sx={{ flex: 1, px: { xs: 2, md: 4 }, py: { xs: 3, md: 4 }, width: '100%', maxWidth: 1680, mx: 'auto' }}>
          {children}
        </Box>
      </Box>
    </Box>
  );
}
