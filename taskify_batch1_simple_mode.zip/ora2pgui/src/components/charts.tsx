import { Box, Stack, Tooltip, Typography } from '@mui/material';
import { brand } from '../theme';
import { useState } from 'react';

export const SERIES = ['#0A5BC4', '#00205B', '#3D7FD6', '#12805C', '#7C8BA1', '#6FA8EC', '#B45309', '#8E44AD', '#0E9AA7', '#C62828'];

/** Donut chart (plain SVG, no chart library). */
export function Donut({ data, size = 200, centerLabel, centerValue }: { data: { label: string; value: number }[]; size?: number; centerLabel?: string; centerValue?: string }) {
  // Hovering a segment or a legend row shows that part in the centre ("Table · 35").
  const [hover, setHover] = useState<number | null>(null);
  const total = data.reduce((s, d) => s + d.value, 0) || 1;
  const r = size / 2 - 16;
  const c = 2 * Math.PI * r;
  let offset = 0;
  const h = hover !== null ? data[hover] : null;
  return (
    <Stack direction={{ xs: 'column', sm: 'row' }} spacing={3} alignItems="center" sx={{ height: '100%' }}>
      <Box sx={{ position: 'relative', width: size, height: size, flexShrink: 0 }} onMouseLeave={() => setHover(null)}>
        <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} role="img" aria-label="Object type distribution">
          <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={brand.sky} strokeWidth={24} />
          {data.map((d, i) => {
            const len = (d.value / total) * c;
            const el = (
              <circle key={d.label} cx={size / 2} cy={size / 2} r={r} fill="none" stroke={SERIES[i % SERIES.length]} strokeWidth={hover === i ? 32 : 24}
                opacity={hover === null || hover === i ? 1 : 0.35} style={{ cursor: 'pointer', transition: 'stroke-width .15s, opacity .15s' }}
                onMouseEnter={() => setHover(i)}
                strokeDasharray={`${Math.max(len - 2, 0.5)} ${c}`} strokeDashoffset={-offset} transform={`rotate(-90 ${size / 2} ${size / 2})`}>
                <title>{`${d.label}: ${d.value.toLocaleString()}`}</title>
              </circle>
            );
            offset += len;
            return el;
          })}
        </svg>
        <Stack sx={{ position: 'absolute', inset: 0, pointerEvents: 'none' }} alignItems="center" justifyContent="center">
          <Typography variant="h5" sx={{ color: h ? SERIES[hover! % SERIES.length] : brand.navy }}>{h ? h.value.toLocaleString() : centerValue ?? total.toLocaleString()}</Typography>
          <Typography variant="caption" color="text.secondary">{h ? h.label : centerLabel}</Typography>
        </Stack>
      </Box>
      <Box sx={{ display: 'grid', gridTemplateColumns: 'repeat(2, minmax(0, 1fr))', columnGap: 1.5, rowGap: 0.5, width: '100%' }}>
        {data.map((d, i) => (
          <Stack key={d.label} direction="row" spacing={1} alignItems="center" onMouseEnter={() => setHover(i)} onMouseLeave={() => setHover(null)}
            sx={{ minWidth: 0, px: 1, py: 0.75, borderRadius: 2, cursor: 'default', bgcolor: hover === i ? '#F2F6FC' : 'transparent', transition: 'background-color .15s' }}>
            <Box sx={{ width: 12, height: 12, borderRadius: '3px', bgcolor: SERIES[i % SERIES.length], flexShrink: 0 }} />
            <Typography variant="body2" noWrap title={d.label} sx={{ flex: 1, minWidth: 0 }}>{d.label}</Typography>
            <Typography variant="body2" fontWeight={700}>{d.value.toLocaleString()}</Typography>
          </Stack>
        ))}
      </Box>
    </Stack>
  );
}

/** Horizontal bar list, e.g. the largest tables. */
export function BarList({ data, format }: { data: { label: string; value: number; extra?: string }[]; format: (v: number) => string }) {
  const max = Math.max(...data.map((d) => d.value), 1);
  return (
    <Stack spacing={1.25}>
      {data.map((d, i) => (
        <Box key={d.label}>
          <Stack direction="row" justifyContent="space-between" spacing={2}>
            <Typography variant="body2" noWrap title={d.label} className="mono" sx={{ minWidth: 0, fontSize: 13 }}>{d.label}</Typography>
            <Typography variant="body2" fontWeight={700} sx={{ flexShrink: 0 }}>{format(d.value)}{d.extra ? <Typography component="span" variant="caption" color="text.secondary"> · {d.extra}</Typography> : null}</Typography>
          </Stack>
          <Tooltip title={`${d.label}: ${format(d.value)}`} placement="top">
            <Box sx={{ mt: 0.5, height: 8, borderRadius: 4, bgcolor: brand.sky, overflow: 'hidden' }}>
              <Box sx={{ height: '100%', width: `${Math.max((d.value / max) * 100, 1.5)}%`, borderRadius: 4, background: i === 0 ? brand.gradient : SERIES[0], opacity: 1 - i * 0.05 }} />
            </Box>
          </Tooltip>
        </Box>
      ))}
    </Stack>
  );
}

/** Circular progress ring with a value in the middle. */
export function Ring({ value, size = 132, stroke = 12, label, color = brand.blue }: { value: number; size?: number; stroke?: number; label?: string; color?: string }) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const v = Math.max(0, Math.min(100, value || 0));
  return (
    <Box sx={{ position: 'relative', width: size, height: size, flexShrink: 0 }}>
      <svg width={size} height={size}>
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke="rgba(255,255,255,.18)" strokeWidth={stroke} />
        <circle cx={size / 2} cy={size / 2} r={r} fill="none" stroke={color} strokeWidth={stroke} strokeLinecap="round"
          strokeDasharray={`${(v / 100) * c} ${c}`} transform={`rotate(-90 ${size / 2} ${size / 2})`} style={{ transition: 'stroke-dasharray .6s ease' }} />
      </svg>
      <Stack sx={{ position: 'absolute', inset: 0 }} alignItems="center" justifyContent="center">
        <Typography sx={{ fontSize: size / 4.6, fontWeight: 800, color: 'inherit', lineHeight: 1 }}>{Math.floor(v)}%</Typography>
        {label && <Typography sx={{ fontSize: 11, opacity: 0.8, mt: 0.5 }}>{label}</Typography>}
      </Stack>
    </Box>
  );
}
