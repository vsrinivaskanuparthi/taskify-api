import { useEffect, useState } from 'react';
import { api } from './api';

/**
 * Admins (DMA_ADMINS in the backend's .env, or everybody when the list is empty or SSO is off)
 * see Settings, the advanced run options and the detailed analysis. Asked once per page load.
 */
let rolePromise: Promise<boolean> | null = null;

export function useIsAdmin(): boolean | null {
  const [admin, setAdmin] = useState<boolean | null>(null);
  useEffect(() => {
    rolePromise = rolePromise || api<{ admin: boolean }>('/whoami').then((r) => !!r.admin).catch(() => true);
    rolePromise.then(setAdmin);
  }, []);
  return admin;
}
