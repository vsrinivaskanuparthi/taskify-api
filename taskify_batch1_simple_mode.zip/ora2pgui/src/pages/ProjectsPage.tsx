import { Alert, Box, Button, Card, CardActionArea, CardContent, Dialog, DialogActions, DialogContent, DialogTitle, Divider, IconButton, InputAdornment, Skeleton, Stack, TextField, ToggleButton, ToggleButtonGroup, Tooltip, Typography } from '@mui/material';
import FolderCopyRoundedIcon from '@mui/icons-material/FolderCopyRounded';
import MenuBookRoundedIcon from '@mui/icons-material/MenuBookRounded';
import WorkspacesRoundedIcon from '@mui/icons-material/WorkspacesRounded';
import PlayCircleRoundedIcon from '@mui/icons-material/PlayCircleRounded';
import TaskAltRoundedIcon from '@mui/icons-material/TaskAltRounded';
import ReportProblemRoundedIcon from '@mui/icons-material/ReportProblemRounded';
import AddRoundedIcon from '@mui/icons-material/AddRounded';
import SearchRoundedIcon from '@mui/icons-material/SearchRounded';
import FolderOpenRoundedIcon from '@mui/icons-material/FolderOpenRounded';
import StorageRoundedIcon from '@mui/icons-material/StorageRounded';
import ArrowForwardRoundedIcon from '@mui/icons-material/ArrowForwardRounded';
import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Shell from '../components/Shell';
import { EmptyState, PageHeader, StatCard, StatusChip } from '../components/ui';
import HomeRoundedIcon from '@mui/icons-material/HomeRounded';
import DeleteProjectDialog from '../components/DeleteProjectDialog';
import DeleteOutlineRoundedIcon from '@mui/icons-material/DeleteOutlineRounded';
import DriveFileRenameOutlineRoundedIcon from '@mui/icons-material/DriveFileRenameOutlineRounded';
import { useIsAdmin } from '../role';
import { api } from '../api';
import { Project } from '../context/ProjectContext';
import { fmtDate, timeAgo, shortDb } from '../format';
import { brand, headingFont } from '../theme';

export function CreateProjectDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const navigate = useNavigate();
  const [form, setForm] = useState({ projectName: '', appName: '', appCode: '', description: '' });
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const nameOk = /^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$/.test(form.projectName);
  const valid = nameOk && form.appName.trim() && form.appCode.trim();

  const submit = async () => {
    setBusy(true);
    setError(null);
    try {
      await api('/projects', { body: form });
      navigate(`/projects/${form.projectName}/connect`);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  };

  const set = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement>) => setForm({ ...form, [k]: e.target.value });

  return (
    <Dialog open={open} onClose={onClose} fullWidth maxWidth="sm">
      <DialogTitle sx={{ fontWeight: 700 }}>New migration project</DialogTitle>
      <DialogContent>
        <Stack spacing={2.25} sx={{ pt: 1 }}>
          {error && <Alert severity="error">{error}</Alert>}
          <TextField label="Project name" value={form.projectName} onChange={set('projectName')} required autoFocus
            error={!!form.projectName && !nameOk}
            helperText={form.projectName && !nameOk ? 'Letters, numbers, "-" and "_" only (no spaces)' : 'Used as the folder name on the migration server'} />
          <Stack direction={{ xs: 'column', sm: 'row' }} spacing={2}>
            <TextField label="Application name" value={form.appName} onChange={set('appName')} required fullWidth />
            <TextField label="Application code" value={form.appCode} onChange={set('appCode')} required sx={{ minWidth: { sm: 180 } }} />
          </Stack>
          <TextField label="Description (optional)" value={form.description} onChange={set('description')} multiline minRows={2} />
        </Stack>
      </DialogContent>
      <DialogActions sx={{ px: 3, pb: 2.5 }}>
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained" onClick={submit} disabled={!valid || busy}>{busy ? 'Creating…' : 'Create project'}</Button>
      </DialogActions>
    </Dialog>
  );
}

const initials = (name: string) => name.replace(/[^A-Za-z0-9]+/g, ' ').trim().split(' ').map((w) => w[0]).join('').slice(0, 2).toUpperCase();

/** Renames a project and its folder on the server (never rename the folder by hand). */
function RenameProjectDialog({ name, open, onClose, onDone }: { name: string; open: boolean; onClose: () => void; onDone: () => void }) {
  const [value, setValue] = useState(name);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const ok = /^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$/.test(value) && value !== name;
  const save = async () => {
    setBusy(true);
    setError(null);
    try {
      await api(`/projects/${encodeURIComponent(name)}/rename`, { body: { newName: value } });
      onDone();
    } catch (e: any) {
      setError(e.message);
    } finally {
      setBusy(false);
    }
  };
  return (
    <Dialog open={open} onClose={onClose} fullWidth maxWidth="xs">
      <DialogTitle sx={{ fontWeight: 700 }}>Rename project</DialogTitle>
      <DialogContent>
        <Stack spacing={2} sx={{ pt: 1 }}>
          {error && <Alert severity="error">{error}</Alert>}
          <TextField label="New name" value={value} onChange={(e) => setValue(e.target.value)} autoFocus
            helperText="Letters, numbers, - and _ only. The folder on the server is renamed too." />
        </Stack>
      </DialogContent>
      <DialogActions sx={{ px: 3, pb: 2.5 }}>
        <Button onClick={onClose}>Cancel</Button>
        <Button variant="contained" onClick={save} disabled={!ok || busy}>{busy ? 'Renaming…' : 'Rename'}</Button>
      </DialogActions>
    </Dialog>
  );
}

function ProjectCard({ p, onDeleted }: { p: Project; onDeleted: () => void }) {
  const navigate = useNavigate();
  const admin = useIsAdmin();
  const [del, setDel] = useState(false);
  const [ren, setRen] = useState(false);
  const target = !p.oracle || !p.postgres ? 'connect' : !p.snapshotAt ? 'schema' : p.currentMigrationId ? 'runs' : 'assessment';
  const steps = [
    { label: 'Connected', done: !!(p.oracle && p.postgres) },
    { label: 'Snapshot', done: !!p.snapshotAt },
    { label: 'Migrated', done: ['COMPLETED', 'COMPLETED_WITH_ERRORS'].includes(p.migrationStatus) },
  ];
  return (
    <Card sx={{ height: '100%', display: 'flex', flexDirection: 'column', transition: 'transform .18s, box-shadow .18s, border-color .18s', '&:hover': { transform: 'translateY(-3px)', borderColor: '#C9D8F2', boxShadow: '0 18px 40px -18px rgba(0,32,91,.35)' } }}>
      <CardActionArea onClick={() => navigate(`/projects/${p.projectName}/${target}`)} sx={{ flex: 1, alignItems: 'stretch', display: 'flex', minWidth: 0 }}>
        <CardContent sx={{ p: 2.75, pb: 1, flex: 1, minWidth: 0, display: 'flex', flexDirection: 'column' }}>
          <Stack direction="row" spacing={1.75} alignItems="center">
            <Box sx={{ width: 46, height: 46, borderRadius: 3, flexShrink: 0, display: 'grid', placeItems: 'center', background: brand.gradient, color: '#fff', fontFamily: headingFont, fontWeight: 800, fontSize: 16 }}>{initials(p.projectName)}</Box>
            <Box sx={{ minWidth: 0, flex: 1 }}>
              <Typography variant="h6" noWrap title={p.projectName} sx={{ color: brand.ink }}>{p.projectName}</Typography>
              <Typography variant="body2" color="text.secondary" noWrap title={p.appName}>{p.appName} · {p.appCode}</Typography>
            </Box>
            <StatusChip status={p.migrationStatus} />
          </Stack>
          {p.description && <Typography variant="body2" color="text.secondary" sx={{ mt: 1.75, display: '-webkit-box', WebkitLineClamp: 2, WebkitBoxOrient: 'vertical', overflow: 'hidden' }}>{p.description}</Typography>}
          <Stack direction="row" spacing={0.75} sx={{ mt: 2 }}>
            {steps.map((st) => (
              <Tooltip key={st.label} title={`${st.label}: ${st.done ? 'yes' : 'not yet'}`}>
                <Box sx={{ flex: 1 }}>
                  <Box sx={{ height: 5, borderRadius: 3, background: st.done ? brand.accentGradient : '#E7ECF4' }} />
                  <Typography sx={{ fontSize: 11, mt: 0.5, color: st.done ? brand.blue : 'text.disabled', fontWeight: 600 }}>{st.label}</Typography>
                </Box>
              </Tooltip>
            ))}
          </Stack>
          <Divider sx={{ my: 2 }} />
          <Stack spacing={0.9} sx={{ flex: 1 }}>
            <Row label="Source" value={p.oracle ? `${p.oracle.userUsername} @ ${shortDb(p.oracle.userUrl)}` : 'Not connected'} muted={!p.oracle} />
            <Row label="Target" value={p.postgres ? `${p.postgres.dbname} @ ${p.postgres.hostip}:${p.postgres.port}` : 'Not connected'} muted={!p.postgres} />
            <Row label="Schema" value={p.selectedSchema || '—'} muted={!p.selectedSchema} />
            <Row label="Last run" value={p.lastMigrationDate ? fmtDate(p.lastMigrationDate) : 'Never'} muted={!p.lastMigrationDate} />
            {p.createdBy && <Row label="Created by" value={p.createdBy.id} />}
          </Stack>
        </CardContent>
      </CardActionArea>
      <Stack direction="row" alignItems="center" spacing={1} sx={{ px: 2.75, pb: 2, pt: 0.5 }}>
        <Typography variant="caption" color="text.secondary" sx={{ flex: 1 }}>Updated {timeAgo(p.updatedAt || p.createdAt)}</Typography>
        {admin && <Tooltip title="Rename project"><IconButton size="small" onClick={() => setRen(true)} sx={{ color: 'text.disabled', '&:hover': { color: brand.blue, bgcolor: '#EFF4FF' } }}><DriveFileRenameOutlineRoundedIcon fontSize="small" /></IconButton></Tooltip>}
        <Tooltip title="Delete project"><IconButton size="small" onClick={() => setDel(true)} sx={{ color: 'text.disabled', '&:hover': { color: 'error.main', bgcolor: '#FEF3F2' } }}><DeleteOutlineRoundedIcon fontSize="small" /></IconButton></Tooltip>
        <Button size="small" endIcon={<ArrowForwardRoundedIcon />} onClick={() => navigate(`/projects/${p.projectName}/${target}`)} sx={{ fontWeight: 700 }}>Open</Button>
      </Stack>
      <DeleteProjectDialog name={p.projectName} open={del} onClose={() => setDel(false)} onDeleted={() => { setDel(false); onDeleted(); }} />
      {ren && <RenameProjectDialog name={p.projectName} open={ren} onClose={() => setRen(false)} onDone={() => { setRen(false); onDeleted(); }} />}
    </Card>
  );
}

function Row({ label, value, muted }: { label: string; value: string; muted?: boolean }) {
  return (
    <Stack direction="row" spacing={1.5} sx={{ minWidth: 0 }}>
      <Typography variant="body2" color="text.secondary" sx={{ width: 76, flexShrink: 0 }}>{label}</Typography>
      <Typography variant="body2" noWrap title={value} className={muted ? undefined : 'mono'} sx={{ minWidth: 0, color: muted ? 'text.disabled' : 'text.primary', fontWeight: muted ? 400 : 500 }}>{value}</Typography>
    </Stack>
  );
}

export default function ProjectsPage() {
  const [projects, setProjects] = useState<Project[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [q, setQ] = useState('');
  const [filter, setFilter] = useState('all');
  // /projects?new=1 (the home page's "Start a migration" button) opens the create dialog.
  const [open, setOpen] = useState(() => new URLSearchParams(window.location.search).get('new') === '1');

  const reload = () => api<{ projects: Project[] }>('/projects').then((r) => setProjects(r.projects)).catch((e) => setError(e.message));
  useEffect(() => { reload(); }, []);

  const groups: Record<string, (p: Project) => boolean> = {
    all: () => true,
    running: (p) => ['RUNNING', 'IN_PROGRESS', 'QUEUED'].includes(p.migrationStatus),
    done: (p) => p.migrationStatus === 'COMPLETED',
    attention: (p) => ['FAILED', 'COMPLETED_WITH_ERRORS', 'INTERRUPTED', 'CANCELLED'].includes(p.migrationStatus),
  };
  const list = projects || [];
  const filtered = useMemo(() => list.filter(groups[filter]).filter((p) =>
    `${p.projectName} ${p.appName} ${p.appCode} ${p.selectedSchema || ''}`.toLowerCase().includes(q.toLowerCase())), [projects, q, filter]);
  const count = (k: string) => list.filter(groups[k]).length;

  const recent = list.slice(0, 6);
  const sections = [
    { title: 'Workspace', items: [
      { to: '/', label: 'Home', icon: <HomeRoundedIcon />, end: true },
      { to: '/projects', label: 'All projects', icon: <FolderCopyRoundedIcon />, end: true, badge: list.length || null },
      { to: '/guide', label: 'Guide', icon: <MenuBookRoundedIcon />, end: true },
    ] },
    ...(recent.length ? [{ title: 'Recent projects', items: recent.map((p) => ({ to: `/projects/${p.projectName}/connect`, label: p.projectName, icon: <WorkspacesRoundedIcon />, badge: ['RUNNING', 'IN_PROGRESS'].includes(p.migrationStatus) ? 'live' as const : null })) }] : []),
  ];

  return (
    <Shell sections={sections} crumbs={[{ label: 'Home', to: '/' }, { label: 'Projects' }]}>
      <PageHeader overline="Workspace" title="Migration projects" icon={<FolderCopyRoundedIcon />}
        subtitle="One project per application: connect Oracle and PostgreSQL, snapshot the schema, convert code with GenAI, migrate and validate."
        actions={<Button size="large" variant="contained" startIcon={<AddRoundedIcon />} onClick={() => setOpen(true)}>New project</Button>} />

      <Box sx={{ display: 'grid', gap: 2, gridTemplateColumns: { xs: 'repeat(2, minmax(0, 1fr))', lg: 'repeat(4, minmax(0, 1fr))' }, mb: 3.5 }}>
        <StatCard label="Projects" value={projects ? list.length : <Skeleton width={40} />} icon={<FolderCopyRoundedIcon />} hint="in this workspace" />
        <StatCard label="Running now" value={projects ? count('running') : <Skeleton width={40} />} icon={<PlayCircleRoundedIcon />} accent={brand.cyan} hint="live migrations" />
        <StatCard label="Completed" value={projects ? count('done') : <Skeleton width={40} />} icon={<TaskAltRoundedIcon />} accent={brand.success} hint="last run fully verified" />
        <StatCard label="Need attention" value={projects ? count('attention') : <Skeleton width={40} />} icon={<ReportProblemRoundedIcon />} accent={brand.warning} hint="failed, interrupted or with errors" />
      </Box>

      <Stack direction={{ xs: 'column', md: 'row' }} spacing={2} justifyContent="space-between" alignItems={{ md: 'center' }} sx={{ mb: 2.5 }}>
        <ToggleButtonGroup size="small" exclusive value={filter} onChange={(_, v) => v && setFilter(v)} sx={{ bgcolor: '#fff', '& .MuiToggleButton-root': { px: 1.75, textTransform: 'none', fontWeight: 650 } }}>
          <ToggleButton value="all">All ({list.length})</ToggleButton>
          <ToggleButton value="running">Running ({count('running')})</ToggleButton>
          <ToggleButton value="done">Completed ({count('done')})</ToggleButton>
          <ToggleButton value="attention">Attention ({count('attention')})</ToggleButton>
        </ToggleButtonGroup>
        <TextField size="small" placeholder="Search projects, applications, schemas" value={q} onChange={(e) => setQ(e.target.value)} sx={{ width: { md: 360 } }}
          InputProps={{ startAdornment: <InputAdornment position="start"><SearchRoundedIcon fontSize="small" /></InputAdornment> }} />
      </Stack>

      {error && <Alert severity="error" sx={{ mb: 2 }}>{error}</Alert>}
      {!projects && !error && (
        <Box sx={{ display: 'grid', gap: 2.5, gridTemplateColumns: { xs: 'minmax(0, 1fr)', md: 'repeat(2, minmax(0, 1fr))', xl: 'repeat(3, minmax(0, 1fr))' } }}>
          {[0, 1, 2].map((i) => <Skeleton key={i} variant="rounded" height={300} sx={{ borderRadius: 4 }} />)}
        </Box>
      )}
      {projects && projects.length === 0 && (
        <Card><EmptyState icon={<StorageRoundedIcon />} title="No projects yet" text="Create your first migration project to connect an Oracle database and start assessing it."
          action={<Button variant="contained" startIcon={<AddRoundedIcon />} onClick={() => setOpen(true)}>New project</Button>} /></Card>
      )}
      {projects && projects.length > 0 && filtered.length === 0 && (
        <Card><EmptyState icon={<FolderOpenRoundedIcon />} title="No matching projects" text="Change the filter or the search text." /></Card>
      )}
      <Box sx={{ display: 'grid', gap: 2.5, gridTemplateColumns: { xs: 'minmax(0, 1fr)', md: 'repeat(2, minmax(0, 1fr))', xl: 'repeat(3, minmax(0, 1fr))' } }}>
        {filtered.map((p) => <ProjectCard key={p.projectName} p={p} onDeleted={reload} />)}
      </Box>
      <CreateProjectDialog open={open} onClose={() => setOpen(false)} />
    </Shell>
  );
}
