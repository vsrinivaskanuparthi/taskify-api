# Tests

## Unit tests (fast, no database)

```bash
npm test
```

They check single functions: Oracle type changes converted for PostgreSQL, the speed settings DMA
chooses, admins vs normal users, ora2pg 24/25 report parsing, the private temp folder per ora2pg run,
project rename, and the disk needed per load mode. Run them before every commit.

## End-to-end tests (real migrations, a few minutes)

```bash
npm run test:e2e
```

They migrate real tables through the running API and check the results: a normal and a document
table, a re-run, a big table split into parts, one part failing (the table must be emptied and the
part named), and a project rename. Before running them:

1. The API is running (`npm run dev` or pm2).
2. A **test** project is connected (Oracle + PostgreSQL) and has a snapshot. Never use a real project:
   the tests reload its tables.
3. Set these if they differ from the defaults:

| Variable | Default | |
|---|---|---|
| `DMA_E2E_URL` | `http://localhost:5055` | the API (on RHEL: `http://127.0.0.1:5000`) |
| `DMA_E2E_PROJECT` | `E2E_TEST` | the test project |
| `DMA_E2E_TABLES` | `CALENDAR_EXCEPTION,DOCUMENTS` | a normal table and a document table |
| `DMA_E2E_BIG` | `AUDIT_TRAIL` | a table with enough rows to split into parts |
| `DMA_E2E_SCHEMA` | `e2e_test` | the target schema in PostgreSQL |
| `DMA_E2E_PG_URL` | (none) | `postgres://user:password@host:port/db` of the target; without it the "one part fails" test is skipped |
