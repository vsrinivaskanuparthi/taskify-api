'use strict';

// Project folders in a temporary staging folder: rename, and a folder renamed by hand on the server.
const fs = require('fs');
const os = require('os');
const path = require('path');

const staging = fs.mkdtempSync(path.join(os.tmpdir(), 'dma-store-'));
process.env.MIGRATION_STAGING_DIR = staging;
const store = require('../../services/projectStore');

const writeProject = (folder, projectName) => {
  fs.mkdirSync(path.join(staging, folder, 'runs', '20261103-100000'), { recursive: true });
  fs.writeFileSync(path.join(staging, folder, 'project_meta.json'), JSON.stringify({ projectName, appName: 'App', appCode: 'A', createdAt: '2026-11-03T10:00:00Z' }));
  fs.writeFileSync(path.join(staging, folder, 'runs', '20261103-100000', 'state.json'), JSON.stringify({ runId: '20261103-100000', projectName, status: 'COMPLETED' }));
};
const read = (...p) => JSON.parse(fs.readFileSync(path.join(staging, ...p), 'utf8'));

afterAll(() => fs.rmSync(staging, { recursive: true, force: true }));

describe('renameProject', () => {
  test('moves the folder and updates the name inside it and inside its runs', async () => {
    writeProject('OLD_NAME', 'OLD_NAME');
    const meta = await store.renameProject('OLD_NAME', 'NEW_NAME');
    expect(meta.projectName).toBe('NEW_NAME');
    expect(fs.existsSync(path.join(staging, 'OLD_NAME'))).toBe(false);
    expect(read('NEW_NAME', 'runs', '20261103-100000', 'state.json').projectName).toBe('NEW_NAME');
  });

  test('refuses a name that exists or has spaces', async () => {
    writeProject('TAKEN', 'TAKEN');
    await expect(store.renameProject('NEW_NAME', 'TAKEN')).rejects.toMatchObject({ status: 409 });
    await expect(store.renameProject('NEW_NAME', 'with space')).rejects.toMatchObject({ status: 400 });
  });
});

describe('listProjects', () => {
  test('a folder renamed by hand takes over the folder name', async () => {
    writeProject('RENAMED_BY_HAND', 'ORIGINAL');
    const list = await store.listProjects();
    expect(list.map((p) => p.projectName)).toContain('RENAMED_BY_HAND');
    expect(list.map((p) => p.projectName)).not.toContain('ORIGINAL');
    expect(read('RENAMED_BY_HAND', 'project_meta.json').projectName).toBe('RENAMED_BY_HAND');
  });
});

describe('userOf', () => {
  test('signed-in user, or null without SSO', () => {
    expect(store.userOf({ user: { id: 'NG1234A', email: 'a@b.com' } })).toEqual({ id: 'NG1234A', email: 'a@b.com' });
    expect(store.userOf({ user: { id: 'NG1234A', email: 'no_email@provided.com' } })).toEqual({ id: 'NG1234A', email: null });
    expect(store.userOf({})).toBeNull();
  });
});
