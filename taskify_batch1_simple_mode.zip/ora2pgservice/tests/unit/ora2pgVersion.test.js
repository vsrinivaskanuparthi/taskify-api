'use strict';

// ora2pg 24 / 25 differences: version detection and the plain-text SHOW_REPORT parser.
const { ora2pgMajor, parseTextReport } = require('../../utils/ora2pgVersion');

describe('ora2pgMajor', () => {
  test('reads the major version', () => {
    expect(ora2pgMajor('Ora2Pg v24.3')).toBe(24);
    expect(ora2pgMajor('Ora2Pg v25.0\n')).toBe(25);
    expect(ora2pgMajor('command not found')).toBeNull();
  });
});

describe('parseTextReport', () => {
  test('reads objects, totals and the migration level', () => {
    const text = [
      'Object\tNumber\tInvalid\tEstimated cost\tComments\tDetails',
      '-------------------------------------------------------------',
      'TABLE\t35\t0\t3.5\tTables\t',
      'PROCEDURE\t31\t2\t90\tProcedures',
      'need a rewrite',
      'Total\t66\t2\t93.5\t93.5 cost migration units means approximatively 2 person-day(s). The migration unit was set to 5 minute(s)',
      'Migration level : B-5',
    ].join('\n');
    const r = parseTextReport(text);
    expect(r.objects).toHaveLength(2);
    expect(r.objects[1]).toMatchObject({ object: 'PROCEDURE', number: 31, invalid: 2, 'cost value': 90 });
    expect(r.objects[1].comment).toContain('need a rewrite');
    expect(r['total cost']).toBe(93.5);
    expect(r['human days cost']).toBe('2 person-day(s)');
    expect(r['migration level']).toBe('B-5');
  });

  test('not a report: null', () => {
    expect(parseTextReport('FATAL: cannot connect')).toBeNull();
  });
});
