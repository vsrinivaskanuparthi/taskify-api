'use strict';

// Disk needed in the staging folder per load mode (Assessment → Resource estimate).
const { stagingNeedMb } = require('../../services/preflight');

const opts = { chunkMb: 1024, hugeTableRows: 2000000, oracleCopies: 4, parallelTables: 4 };
const tables = [
  { mb: 132 * 1024, rows: 134150, lob: true }, // big document table
  { mb: 3 * 1024, rows: 105545677, lob: false },
  { mb: 100, rows: 1000, lob: false },
];

describe('stagingNeedMb', () => {
  test('Export only keeps every table in files (documents about 2.5×, other data 1.2×)', () => {
    expect(stagingNeedMb(opts, tables, 'export')).toBeCloseTo(132 * 1024 * 2.5 + 3 * 1024 * 1.2 + 100 * 1.2, 5);
  });

  // A big table holds at most 4 parts of ~1 GB in files at once; a smaller big table only its own file.
  const bigInFlight = 1024 * 1.2 * 4;
  const smallerBig = 3 * 1024 * 1.2;

  test('Direct load only needs files for parts of big tables in flight', () => {
    expect(stagingNeedMb(opts, tables, 'direct')).toBeCloseTo(bigInFlight + smallerBig, 5);
  });

  test('Through files holds the tables loading at the same time', () => {
    expect(stagingNeedMb(opts, tables, 'file')).toBeCloseTo(bigInFlight + smallerBig + 100 * 1.2, 5);
  });
});
