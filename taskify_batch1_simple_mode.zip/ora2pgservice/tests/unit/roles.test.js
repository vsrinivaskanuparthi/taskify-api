'use strict';

// Admins (DMA_ADMINS in .env) see Settings and advanced options; everyone else the simple path.
const { isAdmin, requireAdmin } = require('../../utils/roles');

const req = (id) => ({ user: id ? { id } : undefined });

describe('roles', () => {
  const saved = process.env.DMA_ADMINS;
  afterEach(() => { process.env.DMA_ADMINS = saved; });

  test('empty list: everybody is an admin (nothing locked until the list is filled in)', () => {
    process.env.DMA_ADMINS = '';
    expect(isAdmin(req('NG1234A'))).toBe(true);
  });

  test('no signed-in user (SSO off): admin', () => {
    process.env.DMA_ADMINS = 'NG1234A';
    expect(isAdmin(req(null))).toBe(true);
  });

  test('listed IDs are admins, case and @domain ignored', () => {
    process.env.DMA_ADMINS = 'ng1234a, DBA0001';
    expect(isAdmin(req('NG1234A'))).toBe(true);
    expect(isAdmin(req('dba0001@person.com'))).toBe(true);
  });

  test('other IDs are normal users', () => {
    process.env.DMA_ADMINS = 'NG1234A';
    expect(isAdmin(req('XY9999Z'))).toBe(false);
  });

  test('requireAdmin answers 403 to a normal user', () => {
    process.env.DMA_ADMINS = 'NG1234A';
    const res = { status: jest.fn(() => res), json: jest.fn() };
    const next = jest.fn();
    requireAdmin(req('XY9999Z'), res, next);
    expect(res.status).toHaveBeenCalledWith(403);
    expect(next).not.toHaveBeenCalled();
    requireAdmin(req('NG1234A'), res, next);
    expect(next).toHaveBeenCalled();
  });
});
