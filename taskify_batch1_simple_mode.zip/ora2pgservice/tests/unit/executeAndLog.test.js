'use strict';

// Every ora2pg run gets its own temp folder (-T), so parallel runs never report a false
// "an error occurs during data export" (first RHEL run). A fake ora2pg records what it was given.
const fs = require('fs');
const os = require('os');
const path = require('path');

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'dma-exec-'));
process.env.MIGRATION_STAGING_DIR = path.join(tmp, 'staging');
const { executeAndLog } = require('../../errorHandling/error');

const unix = process.platform !== 'win32';
const fake = path.join(tmp, 'ora2pg');
const record = path.join(tmp, 'seen.txt');

beforeAll(() => {
  if (!unix) return;
  // Writes its arguments, and whether the -T folder exists while it runs.
  fs.writeFileSync(fake, `#!/bin/sh
echo "$@" > "${record}"
while [ $# -gt 0 ]; do if [ "$1" = "-T" ]; then [ -d "$2" ] && echo "dir-exists" >> "${record}"; fi; shift; done
`, { mode: 0o755 });
});
afterAll(() => fs.rmSync(tmp, { recursive: true, force: true }));

(unix ? describe : describe.skip)('executeAndLog', () => {
  test('ora2pg gets its own -T folder, which exists during the run and is removed after', async () => {
    const r = await executeAndLog({ cmd: fake, args: ['-t', 'COPY', '-a', 'ORDERS'], label: 'test' });
    expect(r.code).toBe(0);
    const [argsLine, dirLine] = fs.readFileSync(record, 'utf8').trim().split('\n');
    const dir = argsLine.split(' -T ')[1];
    expect(argsLine).toMatch(/^-t COPY -a ORDERS -T /);
    expect(dir.startsWith(path.join(process.env.MIGRATION_STAGING_DIR, '.ora2pg_tmp'))).toBe(true);
    expect(dirLine).toBe('dir-exists');
    expect(fs.existsSync(dir)).toBe(false);
  });

  test('--version and other programs are left unchanged', async () => {
    await executeAndLog({ cmd: fake, args: ['--version'], label: 'version' });
    expect(fs.readFileSync(record, 'utf8').trim()).toBe('--version');
    const r = await executeAndLog({ cmd: 'sh', args: ['-c', 'exit 3'], label: 'not ora2pg' });
    expect(r.code).toBe(3);
  });
});
