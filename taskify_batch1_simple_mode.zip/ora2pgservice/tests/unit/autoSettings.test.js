'use strict';

// Settings DMA chooses by itself (tables at a time, parts of a big table at a time).
const { chooseRunSettings } = require('../../services/autoSettings');

const small = (i) => ({ name: `T${i}`, mb: 100 });

describe('chooseRunSettings', () => {
  test('one dominant table (E780: 132 of 140 GB): 2 tables, 8 parts of the big one', () => {
    const tables = [{ name: 'E780_IF_FILE_ATTACHMENT', mb: 132 * 1024, lob: true }, ...Array.from({ length: 32 }, (_, i) => small(i))];
    const r = chooseRunSettings({ tables, cpus: 16, ramGb: 62, maxOracleSessions: 16 });
    expect(r.options).toEqual({ parallelTables: 2, oracleCopies: 8, pgJobs: 4 });
    expect(r.reasons.join(' ')).toMatch(/E780_IF_FILE_ATTACHMENT/);
  });

  test('many tables of similar size: more tables at a time, sessions stay under the limit', () => {
    const tables = Array.from({ length: 40 }, (_, i) => ({ name: `T${i}`, mb: 2048 }));
    const r = chooseRunSettings({ tables, cpus: 16, ramGb: 62, maxOracleSessions: 16 });
    expect(r.options.parallelTables).toBe(7);
    expect(r.options.parallelTables * r.options.oracleCopies).toBeLessThanOrEqual(16);
  });

  test('a small server gets one table at a time', () => {
    const r = chooseRunSettings({ tables: [small(1), small(2), small(3)], cpus: 4, ramGb: 8 });
    expect(r.options.parallelTables).toBe(1);
  });

  test('never more tables at a time than tables selected', () => {
    const r = chooseRunSettings({ tables: [small(1), small(2)], cpus: 32, ramGb: 128 });
    expect(r.options.parallelTables).toBe(2);
  });

  test('a single big table gets the most parts', () => {
    const r = chooseRunSettings({ tables: [{ name: 'BIG', mb: 50 * 1024 }], cpus: 16, ramGb: 62, maxOracleSessions: 16 });
    expect(r.options).toEqual({ parallelTables: 1, oracleCopies: 8, pgJobs: 4 });
  });

  test('a lower session limit (set by the DBA) is respected', () => {
    const tables = [{ name: 'BIG', mb: 100 * 1024 }, small(1)];
    const r = chooseRunSettings({ tables, cpus: 16, ramGb: 62, maxOracleSessions: 6 });
    expect(r.options.parallelTables * r.options.oracleCopies).toBeLessThanOrEqual(6);
  });
});
