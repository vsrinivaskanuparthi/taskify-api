'use strict';

// Oracle type changes in type.sql, rewritten for PostgreSQL (first RHEL run: "syntax error at or near MODIFY").
const { pgTypeSql } = require('../../services/migrate');

describe('pgTypeSql', () => {
  test('MODIFY ATTRIBUTE becomes ALTER ATTRIBUTE ... TYPE (the E780 case)', () => {
    const out = pgTypeSql(`ALTER TYPE type_monitoring MODIFY ATTRIBUTE (
COMPANY         varchar(255),
NAME            varchar(255),
SERVER          varchar(255)
);`);
    expect(out).toBe('ALTER TYPE type_monitoring ALTER ATTRIBUTE COMPANY TYPE varchar(255), ALTER ATTRIBUTE NAME TYPE varchar(255), ALTER ATTRIBUTE SERVER TYPE varchar(255);');
  });

  test('ADD ATTRIBUTE keeps a type with a comma inside it, and CASCADE', () => {
    expect(pgTypeSql('ALTER TYPE t ADD ATTRIBUTE (AMOUNT numeric(10,2)) CASCADE;'))
      .toBe('ALTER TYPE t ADD ATTRIBUTE AMOUNT numeric(10,2) CASCADE;');
  });

  test('DROP ATTRIBUTE of several attributes; Oracle-only INVALIDATE is dropped', () => {
    expect(pgTypeSql('ALTER TYPE t DROP ATTRIBUTE (A, B) INVALIDATE;'))
      .toBe('ALTER TYPE t DROP ATTRIBUTE A, DROP ATTRIBUTE B;');
  });

  test('one attribute without parentheses', () => {
    expect(pgTypeSql('ALTER TYPE t MODIFY ATTRIBUTE NAME varchar(100);'))
      .toBe('ALTER TYPE t ALTER ATTRIBUTE NAME TYPE varchar(100);');
  });

  test('removes "stop at the first error" and leaves CREATE TYPE alone', () => {
    const src = "SET search_path = e780,public;\n\\set ON_ERROR_STOP ON\n\nCREATE TYPE t AS (\nID integer\n);\n";
    const out = pgTypeSql(src);
    expect(out).not.toMatch(/ON_ERROR_STOP/);
    expect(out).toContain('CREATE TYPE t AS (\nID integer\n);');
  });
});
