'use strict';

/**
 * Two kinds of users.
 *   Admins (the DBA team) see and change Settings, the advanced run options and the detailed analysis.
 *   Everyone else gets the simple path: connect, snapshot, code, migrate, with the settings DMA chooses.
 *
 * backend/.env:  DMA_ADMINS=ID1,ID2   (SSO IDs, the part before "@")
 *
 * Without SSO (no signed-in user, e.g. local testing) or with an empty list, everybody is an admin,
 * so nothing is locked until the list is filled in.
 */
function adminIds() {
  return String(process.env.DMA_ADMINS || '')
    .split(/[,;\s]+/)
    .map((s) => s.trim().toUpperCase())
    .filter(Boolean);
}

function isAdmin(req) {
  const ids = adminIds();
  const user = req && req.user;
  if (!ids.length || !user || !user.id) return true;
  return ids.includes(String(user.id).split('@')[0].toUpperCase());
}

/** Express middleware: only admins pass. */
function requireAdmin(req, res, next) {
  if (isAdmin(req)) return next();
  return res.status(403).json({ message: 'Only DMA administrators can change this. Ask your DBA team.' });
}

module.exports = { adminIds, isAdmin, requireAdmin };
