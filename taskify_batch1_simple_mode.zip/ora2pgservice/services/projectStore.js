'use strict';

const fs = require('fs');
const fsp = require('fs').promises;
const path = require('path');
const cacheService = require('../utils/cache');
const secrets = require('../utils/secrets');
const { CONSTANTS } = require('../utils/constants');

/**
 * Everything about a project lives in its own folder under the staging directory:
 *   <STAGING>/<project>/project_meta.json       project details, connections, selected schema
 *   <STAGING>/<project>/snapshot/<SCHEMA>.json  last Oracle snapshot (metadata)
 *   <STAGING>/<project>/runs/<runId>/           one folder per migration run (state, logs, DDL)
 * Nothing important is kept only in memory, so a server restart loses nothing.
 */

const NAME_RE = /^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$/;

const projectDir = (name) => path.join(CONSTANTS.STAGING_DIR, name);
const metaPath = (name) => path.join(projectDir(name), 'project_meta.json');
const snapshotDir = (name) => path.join(projectDir(name), 'snapshot');
const runsDir = (name) => path.join(projectDir(name), 'runs');

function isValidName(name) {
  return typeof name === 'string' && NAME_RE.test(name);
}

/** Writes JSON atomically (temp file + rename) so a crash never leaves half a file. */
async function writeJsonAtomic(file, data) {
  await fsp.mkdir(path.dirname(file), { recursive: true });
  const tmp = `${file}.${process.pid}.${Date.now()}.tmp`;
  await fsp.writeFile(tmp, JSON.stringify(data, null, 2), { mode: 0o600 });
  await fsp.rename(tmp, file);
}

function writeJsonAtomicSync(file, data) {
  fs.mkdirSync(path.dirname(file), { recursive: true });
  const tmp = `${file}.${process.pid}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(data), { mode: 0o600 });
  fs.renameSync(tmp, file);
}

async function readJson(file) {
  try {
    return JSON.parse(await fsp.readFile(file, 'utf8'));
  } catch {
    return null;
  }
}

async function readMeta(name) {
  if (!isValidName(name)) return null;
  return readJson(metaPath(name));
}

// Writes to one project's meta file are serialised, so concurrent requests never lose updates.
const locks = new Map();
async function updateMeta(name, updater) {
  const prev = locks.get(name) || Promise.resolve();
  let release;
  const next = new Promise((r) => { release = r; });
  locks.set(name, prev.then(() => next));
  await prev;
  try {
    const current = (await readMeta(name)) || {};
    const updated = typeof updater === 'function' ? await updater(current) : { ...current, ...updater };
    updated.updatedAt = new Date().toISOString();
    await writeJsonAtomic(metaPath(name), updated);
    return updated;
  } finally {
    release();
    if (locks.get(name) === next) locks.delete(name);
  }
}

/** Project details safe to send to the browser (no passwords). */
function publicMeta(meta) {
  if (!meta) return null;
  const { oracle, postgres, ...rest } = meta;
  return {
    ...rest,
    oracle: oracle ? { userUrl: oracle.userUrl, userUsername: oracle.userUsername, connectedAt: oracle.connectedAt, version: oracle.version } : null,
    postgres: postgres ? { hostip: postgres.hostip, port: postgres.port, dbname: postgres.dbname, username: postgres.username, connectedAt: postgres.connectedAt, version: postgres.version } : null,
  };
}

/** The signed-in user of a request (corporate SSO) as { id, email }, or null when SSO is off. */
function userOf(req) {
  const u = req && req.user;
  if (!u || !u.id) return null;
  return { id: String(u.id), email: u.email && !/^no_email@/.test(u.email) ? u.email : null };
}

/** Oracle credentials in the shape oracleClient.initOracle expects. */
function oracleCredentials(meta) {
  if (!meta || !meta.oracle) return null;
  return {
    userUrl: meta.oracle.userUrl,
    userUsername: meta.oracle.userUsername,
    userPassword: secrets.decrypt(meta.oracle.password),
    isIp: meta.oracle.isIp,
  };
}

/** PostgreSQL credentials in the shape postgreClient.initPostgres expects. */
function postgresCredentials(meta) {
  if (!meta || !meta.postgres) return null;
  return { ...meta.postgres, password: secrets.decrypt(meta.postgres.password) };
}

/**
 * After a project folder is renamed (by "Rename project", or by hand on the server), the name stored
 * inside it and inside its runs must follow, or the project shows the old name and does not open.
 */
async function adoptFolderName(name) {
  const meta = await updateMeta(name, (m) => ({ ...m, projectName: name }));
  const dir = runsDir(name);
  if (fs.existsSync(dir)) {
    for (const id of await fsp.readdir(dir)) {
      const file = path.join(dir, id, 'state.json');
      const state = await readJson(file);
      if (state && state.projectName !== name) await writeJsonAtomic(file, { ...state, projectName: name });
    }
  }
  return meta;
}

/** Renames a project folder (the caller checks that nothing is running in it). */
async function renameProject(oldName, newName) {
  if (!isValidName(newName)) throw Object.assign(new Error('Letters, numbers, "-" and "_" only (no spaces).'), { status: 400 });
  if (fs.existsSync(projectDir(newName))) throw Object.assign(new Error(`A project named ${newName} already exists.`), { status: 409 });
  await fsp.rename(projectDir(oldName), projectDir(newName));
  return adoptFolderName(newName);
}

async function listProjects() {
  await fsp.mkdir(CONSTANTS.STAGING_DIR, { recursive: true });
  const dirents = await fsp.readdir(CONSTANTS.STAGING_DIR, { withFileTypes: true });
  const projects = [];
  for (const d of dirents) {
    if (!d.isDirectory() || !isValidName(d.name)) continue;
    let meta = await readMeta(d.name);
    // Folder renamed by hand on the server: take over the folder's name.
    if (meta && meta.projectName !== d.name) meta = await adoptFolderName(d.name).catch(() => meta);
    if (meta) projects.push(publicMeta(meta));
  }
  projects.sort((a, b) => String(b.updatedAt || b.createdAt).localeCompare(String(a.updatedAt || a.createdAt)));
  return projects;
}

// ---- Snapshot ----

const snapshotFile = (name, schema) => path.join(snapshotDir(name), `${schema}.json`);

async function saveSnapshot(name, schema, data) {
  await writeJsonAtomic(snapshotFile(name, schema), data);
}

async function readSnapshot(name, schema) {
  if (!schema) return null;
  return readJson(snapshotFile(name, schema));
}

/**
 * The validation queries read the Oracle metadata from the cache under the same keys the
 * snapshot queries wrote (e.g. `getTableMetadata:HR`). After a restart the cache is empty, so
 * this puts the saved snapshot back. Must be called inside runWithProject().
 */
const SNAPSHOT_CACHE_KEYS = {
  tableMetadata: 'getTableMetadata',
  checkConstraints: 'getCheckConstraints',
  uniqueConstraints: 'fetchUniqueConstraints',
  oracleFTSIndexes: 'getOracleFTSIndexes',
  primaryForeignKeys: 'getPrimaryForeignKeys',
  normalIndexes: 'getNormalIndexes',
  sequences: 'getSequences',
  foreignKeyCount: 'getForeignKeyCount',
  primaryKeyCount: 'getPrimaryKeyCount',
  blobColumns: 'getBlobColumns',
  notNullBlobColumns: 'getNotNullBlobColumns',
  objectTables: 'getObjectTables',
};

async function hydrateCacheFromSnapshot(name, schema) {
  if (cacheService.get(`getTableMetadata:${schema}`)) return true;
  const snap = await readSnapshot(name, schema);
  if (!snap) return false;
  for (const [field, fn] of Object.entries(SNAPSHOT_CACHE_KEYS)) {
    if (snap[field] !== undefined && snap[field] !== null) cacheService.set(`${fn}:${schema}`, snap[field]);
  }
  return true;
}

module.exports = {
  isValidName,
  projectDir,
  runsDir,
  readMeta,
  updateMeta,
  publicMeta,
  userOf,
  renameProject,
  oracleCredentials,
  postgresCredentials,
  listProjects,
  saveSnapshot,
  readSnapshot,
  hydrateCacheFromSnapshot,
  writeJsonAtomic,
  writeJsonAtomicSync,
  readJson,
};
