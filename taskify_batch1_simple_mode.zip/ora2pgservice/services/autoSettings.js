'use strict';

const os = require('os');
const store = require('./projectStore');

/**
 * Run settings chosen by DMA, so nobody has to guess numbers:
 *   tables at a time   2 CPU cores and 2 GB RAM per table being loaded (an ora2pg reader + its
 *                      writer), keeping 2 cores / 2 GB for the app; never more than the tables selected
 *   parts at a time    how many pieces of one big table load together; the total of Oracle sessions
 *                      (tables × parts) stays under maxOracleSessions
 *   one dominant table (≥ 50 % of the data, e.g. a 132 GB document table): fewer tables at a time,
 *                      more parts of that table, because it decides the run's length
 * The result is a starting point: the pre-flight checks still compare it with Oracle's free
 * sessions and PostgreSQL's free connections before the run starts.
 */
function chooseRunSettings({ tables = [], cpus = 4, ramGb = 8, maxOracleSessions = 16 } = {}) {
  const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
  const n = Math.max(1, tables.length);
  const totalMb = tables.reduce((s, t) => s + (Number(t.mb) || 0), 0);
  const biggest = tables.reduce((b, t) => ((Number(t.mb) || 0) > (Number(b && b.mb) || 0) ? t : b), null);
  const share = totalMb > 0 && biggest ? (Number(biggest.mb) || 0) / totalMb : 0;
  const hasLob = tables.some((t) => t.lob);

  const byCpu = Math.floor((cpus - 2) / 2);
  const byRam = Math.floor((ramGb - 2 - (hasLob ? 2 : 0)) / 2);
  const fits = clamp(Math.min(byCpu, byRam), 1, 8);
  // Only a big table (≥ 1 GB) is worth more parts: small ones load in one go anyway.
  const dominant = share >= 0.5 && (Number(biggest && biggest.mb) || 0) >= 1024;

  const parallelTables = Math.min(n, dominant ? Math.min(2, fits) : fits);
  const oracleCopies = clamp(Math.floor(maxOracleSessions / parallelTables), 2, dominant ? 8 : 4);
  const pgJobs = Math.min(4, oracleCopies);

  const gb = (mb) => (mb >= 1024 ? `${(mb / 1024).toFixed(0)} GB` : `${Math.round(mb)} MB`);
  const reasons = [
    `${parallelTables} table${parallelTables === 1 ? '' : 's'} at a time: this server has ${cpus} CPU cores and ${Math.round(ramGb)} GB RAM${n < fits ? `, and ${n} table${n === 1 ? ' is' : 's are'} selected` : ''}.`,
    dominant
      ? `Up to ${oracleCopies} parts of ${biggest.name} at a time: it holds ${Math.round(share * 100)}% of the data (${gb(biggest.mb)}), so it decides how long the run takes.`
      : `Up to ${oracleCopies} parts of each big table at a time.`,
    `At most ${parallelTables * oracleCopies} Oracle sessions at once (limit ${maxOracleSessions}).`,
  ];
  return { options: { parallelTables, oracleCopies, pgJobs }, reasons };
}

/** chooseRunSettings for the selected tables of a project, on this server. */
async function autoSettingsFor(projectName, tableNames) {
  const meta = await store.readMeta(projectName);
  const snapshot = meta && meta.selectedSchema ? await store.readSnapshot(projectName, meta.selectedSchema) : null;
  const lob = new Set((snapshot && snapshot.lobTables) || []);
  const wanted = new Set(tableNames || []);
  const tables = ((snapshot && snapshot.tableMetadata) || [])
    .filter((t) => wanted.has(t.name))
    .map((t) => ({ name: t.name, mb: Number(t.sizeMb) || 0, lob: lob.has(t.name) }));
  return chooseRunSettings({
    tables,
    cpus: os.cpus().length,
    ramGb: os.totalmem() / 1024 ** 3,
    maxOracleSessions: Number(process.env.DMA_MAX_ORACLE_SESSIONS) || 16,
  });
}

module.exports = { chooseRunSettings, autoSettingsFor };
