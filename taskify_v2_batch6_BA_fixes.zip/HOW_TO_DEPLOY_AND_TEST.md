# DMA v2: batch 6 (fixes from the business acceptance test)

All 26 defects found in `DMA_BA_Test_Cases.xlsx` are fixed: 4 High, 7 Medium, 15 Low. One more High defect was found and fixed during the retest (TC-081). Every failed case was tested again: column K of the sheet says what was checked.
How to deploy is the same as before. What to test is in section 4.

---

## 1. What changed, in simple words

### The 4 High fixes (wrong data or no way out)

| TC | Before | Now |
|---|---|---|
| TC-023 | The **recommended** number setting turned decimal columns like `NUMBER(12,2)` (amounts) into **double precision** (floating point, can round) | Decimals stay **exact `numeric(12,2)`**. An old project still set to floating point shows a yellow warning in Settings with a "Keep decimals exact" button |
| TC-024 | The recommended "NUMBER without precision → **bigint**" cut decimals (SPARE_PART.TOTAL_VALUE failed) | New recommendation **numeric** (keeps decimals). Primary/foreign key columns and `NUMBER(*,0)` / `INTEGER` columns still become **bigint automatically** (your Jaguar rule: IDs are BIGINT) |
| TC-050 | Validation said "table missing" for **every table** when the project has its own target schema | Validation counts rows in the right target schema (and only from runs into that schema) |
| TC-058 | After changing a type setting, a new run **kept the old table** ("already exists") | A new run compares each existing table with the new definition (in a temporary scratch schema) and **rebuilds the tables that changed**. The log says "Table X is rebuilt…", and names any views that must be applied again |

| TC-081 | A second run into a schema that already had data failed on a table that a **partitioned** table points at ("cannot drop inherited constraint") | Only the parent foreign key is dropped before the reload (PostgreSQL drops its partition copies with it); it is re-created after the load |

### The 7 Medium fixes

- **Time estimate:** the Assessment and the Detailed report now use the same speed as the Migrate pre-flight. That's the speed measured on this project's earlier runs, else the v1 reference of 30 GB/h. No more "1 min" for a 5-minute run.
- **Report verdict:** says "Not yet: … change that in Settings first" when a setting would change values. It no longer says "Ready".
- **Migrate page:** shows the real target schema from Settings.
- **Live monitor, waiting tables:** shown as "Waiting" immediately, not only after a reload.
- **Auto-tune slots:** a big table takes the readers that are free at its turn (at least one), so it never blocks the tables queued behind it. All slots are used now ("100% busy" in the log), and the log gives the true reason when a slot is unused.
- **Project status:** a project is not shown as "Completed" while a table that failed earlier is still not loaded.
- **Bell:** refreshes when opened, so it shows renamed or deleted projects correctly.

### The 15 Low fixes

- **Schema list:** Oracle's own accounts are hidden (BAASSYS, VECSYS, PDBADMIN…; on Oracle 12c and newer, every Oracle-maintained account).
- **Project names:** names that differ only in upper/lower case are duplicates, on Linux too.
- **Assessment:** shows a yellow line in the green banner when the server is smaller than recommended. It now shows the resources DMA really uses on this server, and explains why Oracle's "Table" count can be higher than the migrated tables.
- **Wording:** "Projects completed" on Home; "PL/SQL objects" in the report; "objects in files" on the export; Oracle sessions explained the same way on the whole Migrate page; steps numbered 1, 2, 3; "1 table".
- **Statistics check:** doesn't count materialized-view tables.
- **Failed table advice:** for a type problem it says "change the mapping, then start a new run of this table". A refused Resume shows its message above the run instead of replacing the page.
- **After Cancel:** the open monitor shows the stopped tables immediately.
- **Validation:** Oracle's materialized-view logs and containers are no longer reported as missing. Partitioned tables count their keys once, and the check names are clearer. *(These two need a fresh Snapshot of the schema.)*
- **Code objects:**
  - synonyms over a DB link are explained under the DB link;
  - ora2pg's `packages.sql` index no longer has server paths;
  - uploading the original export by mistake shows a warning.
- **Guide:** a new table covering auto-tune, CPU safety, the worker, the time report, the number rules, My preferences and the bell.
- **Boolean suggestions:** Oracle's internal MLOG$ tables are no longer suggested.

**Important for existing projects:** saved Settings are **not** changed by the deploy, so a migration that is half done can still be resumed. Projects created after the deploy get the new recommendations. For an existing project:
1. open Settings → Migration decisions → Numbers;
2. if you see the yellow warning, or "NUMBER without precision" is bigint, choose the recommended options and save;
3. start a **new run**: the changed tables are rebuilt.

---

## 2. Files in the zip

**Backend: `ora2pgservice/`**

| Folder | Files |
|---|---|
| `services/` | `migrate.js`, `autoTune.js`, `settings.js`, `analysis.js`, `preflight.js`, `autoSettings.js`, `code.js`, `projectStore.js` |
| `controllers/` | `pgController.js`, `projectController.js` |
| `queries/oracle/` | `getDBSchema.js`, `getDbLinks.js`, `getNormalIndexes.js`, `getPrimaryForeignKeys.js`, `getPrimaryKeyCount.js`, `analyzePrerequisites.js`, `getMigrationComplexity.js` |
| `queries/pg/` | `getPrimaryKeyCount.js`, `getForeignKeyCount.js` |
| `tests/unit/` | `autoTune.test.js` (1 new test) |
| `tests/e2e/` | `decisions.e2e.test.js` (3 new tests) |

**Frontend: `ora2pgui/src/`**

| Folder | Files |
|---|---|
| `pages/` | `SettingsPage.tsx`, `AssessmentPage.tsx`, `AnalysisPage.tsx`, `MigratePage.tsx`, `RunPage.tsx`, `ValidationPage.tsx`, `HomePage.tsx`, `GuidePage.tsx`, `CodePage.tsx` |
| `components/` | `Bell.tsx` |

**Not in the zip:** `server.js` (not changed) and `.env` (nothing to add). **No new npm packages.**

---

## 3. Deploy (same as last time)

1. Unzip. Copy `ora2pgservice/` over your `ora2pgservice` folder, and `ora2pgui/` over your `ora2pgui` folder.
2. In `ora2pgservice`: `npm test`. It should end with **Tests: 73 passed**.
3. In `ora2pgui`: `npm run build`.
4. Push `ora2pgservice` to the repository.
5. On RHEL:
   ```bash
   curl -s http://127.0.0.1:5101/health        # "running":0 → no migration runs
   cd /path/to/ora2pgservice && git pull
   pm2 restart ora2pg-service-prod
   pm2 restart ora2pg-worker-prod              # only when no migration runs
   pm2 save
   ```
6. Copy the new `dist/index.html` to nginx, as before:
   ```bash
   sudo cp -p /usr/share/nginx/html/index.html /usr/share/nginx/html/index.html.previous
   sudo install -m 644 /tmp/dma_index.html /usr/share/nginx/html/index.html
   sudo restorecon /usr/share/nginx/html/index.html
   ```
   Then press **Ctrl+F5** in the browser.

---

## 4. What to test (the failed cases of the test sheet)

- [ ] **New project → Settings → Numbers:**
  - "Whole numbers as integers" is selected;
  - "NUMBER without precision" says **numeric (exact, keeps decimals): recommended**;
  - no yellow warning.
- [ ] **Migrate a table with amounts** (NUMBER(p,2)), then check in PostgreSQL:
  - the amount columns are `numeric(p,2)`;
  - ID/key columns are `bigint`.
- [ ] **Validation** on a project with its own target schema (Settings → Target schema): row counts are shown, not "table missing".
- [ ] **Rebuild after a type change:**
  1. migrate a table with "NUMBER without precision = bigint";
  2. switch it to numeric and save;
  3. start a new run of that table.

  The run log says **"Table … is rebuilt"**, and the data check is green.
- [ ] **Assessment / Detailed report:** the time matches the Migrate pre-flight estimate (both at 30 GB/h until a run measured the real speed).
- [ ] **Live monitor during a run with many tables:** waiting tables show **Waiting** without reloading the page.
- [ ] **Projects page:** a project with a failed table still shows "Completed with errors" after a later partial run.
- [ ] **Run the same tables twice into the same schema** (with a partitioned table, e.g. one with a foreign key to a reloaded table): the second run completes.
- [ ] **Take a new Snapshot** of existing projects, so the schema list, statistics and validation exclusions apply.

---

## 5. What to send me

Screenshots of anything red, and the run log line "Key and whole-number columns … become bigint" from your first run.
