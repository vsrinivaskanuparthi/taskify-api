'use strict';

const fs = require('fs');
const { CONSTANTS } = require('../utils/constants');
const oracleClient = require('../utils/oracleClient');
const pgClient = require('../utils/postgreClient');
const store = require('./projectStore');
const settingsSvc = require('./settings');

/**
 * Capacity pre-flight for a planned run (Migrate page → Pre-flight checks), so a run is stopped
 * before it starts instead of 6 hours in. Every check is
 *   { check, response, level: 'ok' | 'warn' | 'block', description }
 * 'block' stops the Start button (and startRun on the server); 'warn' is a risk to read.
 *
 *  - estimated load time, from this project's measured speed or LOAD_GB_PER_HOUR
 *  - consistent snapshot vs Oracle undo: the run reads AS OF one SCN for its whole duration
 *  - staging disk for the files the chosen load mode writes
 *  - PostgreSQL connections, WAL / checkpoint settings, space needed
 *  - Oracle processes for the parallel readers
 *  - network: round trip and throughput from this server to Oracle and to PostgreSQL
 */
async function preflight(projectName, { tables, options, quick = false } = {}) {
  const { normalizeOptions } = require('./migrate');
  const { measuredThroughput } = require('./analysis');
  const meta = await store.readMeta(projectName);
  const settings = settingsSvc.resolve(meta);
  const opts = normalizeOptions({ ...settings.engine, ...(options || {}) });
  const snapshot = meta && meta.selectedSchema ? await store.readSnapshot(projectName, meta.selectedSchema) : null;
  const all = (snapshot && snapshot.tableMetadata) || [];
  const wanted = new Set(tables || []);
  const lob = new Set(snapshot ? snapshot.lobTables || [] : []);
  const sel = all.filter((t) => wanted.has(t.name)).map((t) => ({ name: t.name, mb: Number(t.sizeMb) || 0, rows: Number(t.rowCount) || 0, lob: lob.has(t.name) }));
  const selMb = sel.reduce((a, t) => a + t.mb, 0);
  const selGb = selMb / 1024;

  const checks = [];
  const add = (check, level, description) => checks.push({ check, response: level !== 'block', level, description });

  // ---- estimate
  const measured = await measuredThroughput(projectName).catch(() => null); // MB/s
  const gbPerHour = measured ? (measured * 3600) / 1024 : CONSTANTS.LOAD_GB_PER_HOUR;
  const loadHours = selGb / gbPerHour;
  const verifyHours = opts.verifyData === 'all' ? loadHours * 0.2 : 0;
  const runHours = loadHours + verifyHours;
  add('Estimated duration', 'ok',
    `${fmtGb(selGb)} selected ≈ ${fmtH(loadHours)} of loading at ${gbPerHour.toFixed(0)} GB/h (${measured ? 'measured on this project' : 'v1 reference speed: 450 GB in 15 h'})`
    + `${verifyHours ? `, + ~${fmtH(verifyHours)} for the data checksums` : ''}. Indexes and keys come after.`);

  let ora = null;
  let pg = null;
  try {
    await oracleClient.ensureOraclePool(store.oracleCredentials(meta), projectName);
    ora = await oracleClient.getOracleConnection(projectName);
  } catch (err) {
    add('Oracle connection', 'block', `Cannot connect to Oracle: ${err.message.split('\n')[0]}`);
  }
  try {
    await pgClient.ensurePostgresPool(store.postgresCredentials(meta), projectName);
    pg = await pgClient.getPostgresConnection(projectName);
  } catch (err) {
    add('PostgreSQL connection', 'block', `Cannot connect to PostgreSQL: ${err.message.split('\n')[0]}`);
  }

  try {
    // ---- snapshot vs undo
    if (opts.snapshot === 'off') {
      add('Consistent snapshot', 'warn', 'Off: tables are read as they are now. Keep the application stopped (no writes) for the whole load, or tables loaded at different times will not match each other.');
    } else if (ora) {
      await undoCheck(ora, runHours, add);
    }

    // ---- staging disk
    stagingCheck(opts, sel, add);

    // ---- PostgreSQL
    if (pg) await pgChecks(pg, opts, selGb, add);

    // ---- Oracle processes
    if (ora) await oracleSessions(ora, opts, add);

    // ---- network
    if (!quick) {
      if (ora) await oracleNetwork(ora, meta.selectedSchema, sel, gbPerHour, add);
      if (pg) await pgNetwork(pg, add);
    }
  } finally {
    if (ora) await ora.close().catch(() => {});
    if (pg) pg.release();
  }
  return { checks, estimate: { selectedGb: selGb, gbPerHour, loadHours, runHours, measured: !!measured } };
}

/**
 * Space the export files need in the staging folder for a load mode (MB). Used by the pre-flight
 * check and by the Assessment sizing, so both show the same number.
 *   export  every table stays in files until the import
 *   file    the tables (or chunks) being loaded at the same time
 *   direct  only ROWID chunks of big tables without a numeric key go through files
 * Data files are text: about the Oracle size; LOBs (hex-escaped bytea) about 2.5x.
 */
function stagingNeedMb(opts, sel, mode) {
  const fileMb = (t) => t.mb * (t.lob ? 2.5 : 1.2);
  const chunked = (t) => t.mb > opts.chunkMb || t.rows >= opts.hugeTableRows;
  const inFlight = (t) => (chunked(t) ? Math.min(fileMb(t), opts.chunkMb * 1.2 * opts.oracleCopies) : fileMb(t));
  const topN = (list) => list.sort((a, b) => b - a).slice(0, opts.parallelTables).reduce((a, b) => a + b, 0);
  if (mode === 'export') return sel.reduce((a, t) => a + fileMb(t), 0);
  if (mode === 'file') return topN(sel.map(inFlight));
  return topN(sel.filter(chunked).map(inFlight));
}

/**
 * Assessment → Resource estimate, migration server part: what this server (the one running DMA and
 * ora2pg) has, and what migrating the whole schema needs from it.
 *   CPU  2 per table loaded in parallel (an ora2pg reader + its writer) + 2 for the app and psql
 *   RAM  2 GB per parallel table + 2 GB, + 2 GB when there are LOB tables (inline LOB batches)
 *   disk export files in the staging folder, per load mode (stagingNeedMb)
 */
async function sizing(projectName) {
  const os = require('os');
  const { normalizeOptions } = require('./migrate');
  const { measuredThroughput } = require('./analysis');
  const { chooseRunSettings } = require('./autoSettings');
  const meta = await store.readMeta(projectName);
  const engine = settingsSvc.resolve(meta).engine;
  const opts = normalizeOptions(engine);
  const snapshot = meta && meta.selectedSchema ? await store.readSnapshot(projectName, meta.selectedSchema) : null;
  const lob = new Set(snapshot ? snapshot.lobTables || [] : []);
  const sel = ((snapshot && snapshot.tableMetadata) || []).map((t) => ({ mb: Number(t.sizeMb) || 0, rows: Number(t.rowCount) || 0, lob: lob.has(t.name) }));
  let disk = null;
  try {
    fs.mkdirSync(CONSTANTS.STAGING_DIR, { recursive: true });
    const st = fs.statfsSync(CONSTANTS.STAGING_DIR);
    disk = { freeGb: (st.bavail * st.bsize) / 1024 ** 3, totalGb: (st.blocks * st.bsize) / 1024 ** 3 };
  } catch { /* not readable */ }
  const gb = (mb) => mb / 1024;
  // With "Let DMA choose the speed" the run uses what fits this server, so that is what it needs.
  if (engine.auto !== false && sel.length) {
    opts.parallelTables = chooseRunSettings({ tables: sel.map((t) => ({ mb: t.mb, lob: t.lob })), cpus: os.cpus().length, ramGb: os.totalmem() / 1024 ** 3,
      maxOracleSessions: Number(process.env.DMA_MAX_ORACLE_SESSIONS) || 16 }).options.parallelTables;
  }
  // The same speed as the pre-flight estimate: measured on this project's runs, else the v1 reference.
  const measured = await measuredThroughput(projectName).catch(() => null);
  return {
    speed: { mbps: measured || (CONSTANTS.LOAD_GB_PER_HOUR * 1024) / 3600, measured: !!measured },
    server: { cpus: os.cpus().length, ramGb: os.totalmem() / 1024 ** 3, freeRamGb: os.freemem() / 1024 ** 3, stagingDir: CONSTANTS.STAGING_DIR, disk },
    need: {
      parallelTables: opts.parallelTables,
      loadMode: opts.loadMode,
      cpus: opts.parallelTables * 2 + 2,
      ramGb: opts.parallelTables * 2 + 2 + (sel.some((t) => t.lob) ? 2 : 0),
      stagingGb: { direct: gb(stagingNeedMb(opts, sel, 'direct')), file: gb(stagingNeedMb(opts, sel, 'file')), export: gb(stagingNeedMb(opts, sel, 'export')) },
    },
  };
}

async function undoCheck(conn, runHours, add) {
  const one = async (sql) => {
    try { return (await conn.execute(sql)).rows; } catch { return null; }
  };
  const param = await one("SELECT value FROM v$parameter WHERE name = 'undo_retention'");
  const tuned = await one('SELECT MAX(tuned_undoretention) FROM v$undostat WHERE end_time > SYSDATE - 1');
  const space = await one(`SELECT t.tablespace_name, t.retention,
       SUM(CASE WHEN f.autoextensible = 'YES' THEN GREATEST(f.maxbytes, f.bytes) ELSE f.bytes END) / 1073741824
     FROM dba_tablespaces t JOIN dba_data_files f ON f.tablespace_name = t.tablespace_name
    WHERE t.contents = 'UNDO' GROUP BY t.tablespace_name, t.retention`);
  const retention = Math.max(param ? Number(param[0][0]) || 0 : 0, tuned && tuned[0][0] != null ? Number(tuned[0][0]) : 0);
  const need = Math.ceil(runHours * 3600 * 1.2); // seconds, with 20% margin
  const spaceText = space && space.length ? ` Undo tablespace ${space[0][0]}: up to ${Number(space[0][2]).toFixed(0)} GB, retention ${space[0][1]}.` : '';
  if (!param && !tuned) {
    add('Snapshot vs undo', 'warn', `Could not read Oracle's undo settings (needs SELECT on V$PARAMETER / V$UNDOSTAT). The run reads every table as of its start for about ${fmtH(runHours)}: ask the DBA for UNDO_RETENTION ≥ ${need} (${fmtH(need / 3600)}).`);
    return;
  }
  if (retention >= need) {
    add('Snapshot vs undo', 'ok', `Oracle keeps undo for ${fmtH(retention / 3600)}; the run needs about ${fmtH(need / 3600)} (one snapshot for all tables).${spaceText}`);
  } else {
    add('Snapshot vs undo', 'warn',
      `Oracle keeps undo for ${fmtH(retention / 3600)}, but the run reads every table as of its start for about ${fmtH(runHours)}. `
      + 'If the application keeps writing, the last tables can fail with ORA-01555 (snapshot too old). '
      + `Either the DBA sets UNDO_RETENTION = ${need} (${fmtH(need / 3600)}) with enough undo space, or stop the application and turn "Consistent snapshot" off.${spaceText}`);
  }
}

function stagingCheck(opts, sel, add) {
  let freeGb = null;
  try {
    fs.mkdirSync(CONSTANTS.STAGING_DIR, { recursive: true });
    fs.accessSync(CONSTANTS.STAGING_DIR, fs.constants.W_OK);
    const st = fs.statfsSync(CONSTANTS.STAGING_DIR);
    freeGb = (st.bavail * st.bsize) / 1024 ** 3;
  } catch (err) {
    add('Staging disk', 'block', `Staging folder ${CONSTANTS.STAGING_DIR} is not writable: ${err.message}`);
    return;
  }
  const needMb = stagingNeedMb(opts, sel, opts.loadMode);
  const why = {
    export: 'Export only keeps every table in files until the import',
    file: `Through files holds up to ${opts.parallelTables} tables (or their chunks) at once`,
    direct: 'Direct load writes files only for chunks of big tables without a numeric key',
  }[opts.loadMode];
  const needGb = needMb / 1024;
  const level = freeGb < needGb ? 'block' : freeGb < needGb * 1.5 ? 'warn' : 'ok';
  add('Staging disk', level, `${freeGb.toFixed(1)} GB free in ${CONSTANTS.STAGING_DIR}; this run needs up to ${fmtGb(needGb)}. ${why}.`
    + (level === 'block' ? ' Free space, choose Direct load, or lower the tables in parallel.' : ''));
}

async function pgChecks(pg, opts, selGb, add) {
  const { rows } = await pg.query(`SELECT name, setting, unit FROM pg_settings
     WHERE name IN ('max_connections', 'superuser_reserved_connections', 'max_wal_size', 'checkpoint_timeout', 'wal_level')`);
  const set = Object.fromEntries(rows.map((r) => [r.name, r]));
  const used = Number((await pg.query('SELECT count(*) AS n FROM pg_stat_activity')).rows[0].n);
  const max = Number(set.max_connections.setting);
  const free = max - Number(set.superuser_reserved_connections.setting) - used;
  const need = opts.parallelTables * Math.max(opts.pgJobs, opts.oracleCopies) + opts.ddlParallel + 5;
  add('PostgreSQL connections', free < need ? 'block' : free < need * 1.3 ? 'warn' : 'ok',
    `${free} of ${max} connections free; this run opens up to ${need} (${opts.parallelTables} tables × ${Math.max(opts.pgJobs, opts.oracleCopies)} writers + DDL).`
    + (free < need ? ' Lower "Tables in parallel" or ask the DBA to raise max_connections.' : ''));

  const walMb = Number(set.max_wal_size.setting) * (set.max_wal_size.unit === 'MB' ? 1 : set.max_wal_size.unit === 'kB' ? 1 / 1024 : 1);
  const ckSec = Number(set.checkpoint_timeout.setting);
  const walOk = walMb >= 4096;
  add('WAL & checkpoints', walOk ? 'ok' : 'warn',
    `max_wal_size = ${fmtGb(walMb / 1024)}, checkpoint_timeout = ${Math.round(ckSec / 60)} min.`
    + (walOk ? '' : ' A bulk load fills this in seconds and forces constant checkpoints (much slower). For the migration window ask the DBA for max_wal_size = 16GB or more and checkpoint_timeout = 15min.'));

  const dbMb = Number((await pg.query('SELECT pg_database_size(current_database()) / 1048576 AS mb')).rows[0].mb);
  let replicas = 0;
  try { replicas = Number((await pg.query('SELECT count(*) AS n FROM pg_stat_replication')).rows[0].n); } catch { /* no privilege */ }
  add('PostgreSQL space', 'ok',
    `Needs about ${fmtGb(selGb * 1.7)} on the PostgreSQL data disk (data + indexes, Oracle size × 1.7) plus WAL; the database is ${fmtGb(dbMb / 1024)} now. `
    + 'Free disk cannot be read over SQL: check with df -h on the database server.'
    + (replicas ? ` ${replicas} streaming replica(s): every row is sent to them too${opts.bulkLoad === 'unlogged' ? ' (unlogged tables are sent when each is made permanent)' : ''}.` : ''));
}

async function oracleSessions(conn, opts, add) {
  const need = opts.parallelTables * opts.oracleCopies + 5;
  try {
    const r = await conn.execute(`SELECT (SELECT TO_NUMBER(value) FROM v$parameter WHERE name = 'processes'), (SELECT COUNT(*) FROM v$process) FROM dual`);
    const [max, used] = r.rows[0].map(Number);
    const free = max - used;
    add('Oracle processes', free < need ? 'block' : free < need * 1.5 ? 'warn' : 'ok',
      `${free} of ${max} Oracle processes free; this run opens up to ${need} sessions (${opts.parallelTables} tables × ${opts.oracleCopies} readers for the loads + 5 for DMA's checks).`
      + (free < need ? ' Lower "Tables in parallel" / "Parallel chunks" or ask the DBA to raise PROCESSES.' : ''));
  } catch {
    add('Oracle processes', 'warn', `Could not read PROCESSES (needs SELECT on V$PARAMETER / V$PROCESS). This run opens up to ${need} Oracle sessions.`);
  }
}

/** Round trip, then one stream of rows from the biggest selected table for up to 4 seconds. */
async function oracleNetwork(conn, schema, sel, gbPerHour, add) {
  const rtt = await timeAvg(() => conn.execute('SELECT 1 FROM dual'), 10);
  const t = sel.filter((x) => !x.lob).sort((a, b) => b.mb - a.mb)[0] || sel[0];
  let mbs = null;
  if (t) {
    const started = Date.now();
    let bytes = 0;
    const rs = (await conn.execute(`SELECT * FROM "${schema.replace(/"/g, '""')}"."${t.name.replace(/"/g, '""')}"`, [], { resultSet: true, fetchArraySize: 2000 })).resultSet;
    try {
      while (Date.now() - started < 4000) {
        const rows = await rs.getRows(2000);
        if (!rows.length) break;
        for (const row of rows) for (const v of row) bytes += sizeOf(v);
      }
    } finally {
      await rs.close().catch(() => {});
    }
    const sec = (Date.now() - started) / 1000;
    if (bytes > 1024 * 1024 && sec > 0.2) mbs = bytes / 1048576 / sec;
  }
  const slow = rtt > 10 || (mbs !== null && mbs < 2);
  add('Network to Oracle', slow ? 'warn' : 'ok',
    `Round trip ${rtt.toFixed(1)} ms${mbs !== null ? `; one stream reads ≈ ${mbs.toFixed(1)} MB/s (${t.name}), the run uses several in parallel` : ''}.`
    + (slow ? ' Slow link: run the app on a server close to Oracle (same data centre), and expect the load to take longer than the estimate.' : ''));
}

/** Round trip, then 3 × 4 MB sent to PostgreSQL. */
async function pgNetwork(pg, add) {
  const rtt = await timeAvg(() => pg.query('SELECT 1'), 10);
  const payload = 'x'.repeat(4 * 1024 * 1024);
  const started = Date.now();
  for (let i = 0; i < 3; i += 1) await pg.query('SELECT length($1::text)', [payload]);
  const mbs = 12 / ((Date.now() - started) / 1000);
  const slow = rtt > 10 || mbs < 10;
  add('Network to PostgreSQL', slow ? 'warn' : 'ok', `Round trip ${rtt.toFixed(1)} ms; upload ≈ ${mbs.toFixed(0)} MB/s.`
    + (slow ? ' Slow link: run the app close to PostgreSQL, or the load is limited by the network.' : ''));
}

async function timeAvg(fn, n) {
  await fn();
  const started = process.hrtime.bigint();
  for (let i = 0; i < n; i += 1) await fn();
  return Number(process.hrtime.bigint() - started) / 1e6 / n;
}

function sizeOf(v) {
  if (v === null || v === undefined) return 1;
  if (typeof v === 'string') return v.length;
  if (Buffer.isBuffer(v)) return v.length;
  if (v instanceof Date || typeof v === 'number') return 8;
  return 16; // LOB locators, objects
}

const fmtGb = (gb) => (gb >= 100 ? `${gb.toFixed(0)} GB` : gb >= 1 ? `${gb.toFixed(1)} GB` : `${Math.max(1, Math.round(gb * 1024))} MB`);
const fmtH = (h) => (h >= 1 ? `${h.toFixed(1)} h` : `${Math.max(1, Math.round(h * 60))} min`);

module.exports = { preflight, sizing, stagingNeedMb };
