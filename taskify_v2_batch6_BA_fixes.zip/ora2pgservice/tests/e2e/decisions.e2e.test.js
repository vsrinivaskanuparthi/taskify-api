'use strict';

/**
 * End-to-end: the migration decisions on the Settings page really change what lands in PostgreSQL.
 * Each test saves decisions through the Settings API, migrates a few tables into a scratch target
 * schema (DMA_E2E_DECISIONS_SCHEMA, default e2e_decisions, dropped before every test) and reads the
 * column types and values back from PostgreSQL. The project's own settings are put back at the end.
 *
 * Uses the test schema's tables (dev-tools/testdb): SPARE_PART, CUSTOMER_MASTER, CUSTOMIZED_RANK,
 * DOCUMENTS, SETTING. Needs DMA_E2E_PG_URL (skipped without it). dev-tools/run-e2e.sh sets everything.
 */
const { Client } = require('pg');

const API = process.env.DMA_E2E_URL || 'http://localhost:5055';
const PROJECT = process.env.DMA_E2E_PROJECT || 'E2E_TEST';
const TARGET = process.env.DMA_E2E_DECISIONS_SCHEMA || 'e2e_decisions';
const PG_URL = process.env.DMA_E2E_PG_URL;
const P = `${API}/api/projects/${PROJECT}`;
const maybe = PG_URL ? describe : describe.skip;

jest.setTimeout(20 * 60 * 1000);

async function call(method, url, body) {
  const res = await fetch(url, { method, headers: body ? { 'Content-Type': 'application/json' } : {}, body: body ? JSON.stringify(body) : undefined });
  const text = await res.text();
  let data = null;
  try { data = text ? JSON.parse(text) : null; } catch { data = text; }
  return { status: res.status, data };
}

let saved = null;
let pg = null;

// Every test starts from these decisions and changes only what it tests. PG_NUMERIC_TYPE off and
// PG_INTEGER_TYPE on: whole numbers become smallint/integer/bigint, decimals stay exact numeric(p,s).
const BASE = { PRESERVE_CASE: false, USE_RESERVED_WORDS: true, PG_NUMERIC_TYPE: false, PG_INTEGER_TYPE: true, DEFAULT_NUMERIC: 'numeric', REPLACE_AS_BOOLEAN: '', DATA_TYPE: '', MODIFY_TYPE: '', DISABLE_COMMENT: false };

/** Saves BASE plus the given decisions over the project's saved settings (everything else unchanged). */
async function decide({ ora2pg = {}, lob = { blobAs: 'bytea' } } = {}) {
  const r = await call('PUT', `${P}/settings`, {
    ...saved,
    targetSchema: TARGET,
    ora2pg: { ...saved.ora2pg, ...BASE, ...ora2pg },
    lob,
    engine: { ...saved.engine, snapshot: 'off' },
  });
  expect(r.status).toBe(200);
}

/** Empty target schema (unless keep), then one run of these tables; returns the run's final state. */
async function migrate(tables, { keep = false } = {}) {
  if (!keep) await pg.query(`DROP SCHEMA IF EXISTS "${TARGET}" CASCADE`);
  const start = await call('POST', `${P}/runs`, { tables });
  expect(start.status).toBe(202);
  for (;;) {
    await new Promise((r) => setTimeout(r, 3000));
    const { data } = await call('GET', `${P}/runs/${start.data.runId}`);
    if (['COMPLETED', 'COMPLETED_WITH_ERRORS', 'FAILED', 'CANCELLED', 'INTERRUPTED'].includes(data.status)) return data;
  }
}

/** { column: type } of one target table, e.g. { qty: 'integer', unit_price: 'numeric(12,2)' }. */
async function types(table) {
  const { rows } = await pg.query(
    `SELECT a.attname AS col, format_type(a.atttypid, a.atttypmod) AS type
       FROM pg_attribute a JOIN pg_class c ON c.oid = a.attrelid JOIN pg_namespace n ON n.oid = c.relnamespace
      WHERE n.nspname = $1 AND c.relname = $2 AND a.attnum > 0 AND NOT a.attisdropped`, [TARGET, table]);
  return Object.fromEntries(rows.map((r) => [r.col, r.type]));
}

const one = async (sql) => Object.values((await pg.query(sql)).rows[0])[0];

const loaded = (run, name) => {
  const t = run.tables[name];
  expect(t.status).toBe('done');
  expect(t.pgRows).toBe(t.oracleRows);
  if (t.dataCheck) expect(t.dataCheck.ok).toBe(true);
};

maybe('Settings decisions change the PostgreSQL result', () => {
  beforeAll(async () => {
    const health = await call('GET', `${API}/api/health`).catch(() => null);
    if (!health || health.status !== 200) throw new Error(`The API is not running at ${API}`);
    saved = (await call('GET', `${P}/settings`)).data.settings;
    pg = new Client({ connectionString: PG_URL });
    await pg.connect();
  });

  afterAll(async () => {
    if (saved) await call('PUT', `${P}/settings`, saved);
    if (pg) {
      await pg.query(`DROP SCHEMA IF EXISTS "${TARGET}" CASCADE`).catch(() => {});
      await pg.end();
    }
  });

  test('defaults: lower-case names, reserved words kept, NUMBER sizes, DATE, CLOB and BLOB types, comments', async () => {
    await decide();
    const run = await migrate(['SPARE_PART', 'CUSTOMIZED_RANK', 'DOCUMENTS', 'SETTING']);
    for (const t of ['SPARE_PART', 'CUSTOMIZED_RANK', 'DOCUMENTS', 'SETTING']) loaded(run, t);

    expect(await types('spare_part')).toMatchObject({ part_id: 'bigint', qty: 'integer', unit_price: 'numeric(12,2)', total_value: 'numeric', in_stock: 'smallint', is_active: 'character(1)' });
    // OFFSET, POSITION and VALUE are reserved words in PostgreSQL: they keep their names.
    expect(Object.keys(await types('customized_rank'))).toEqual(expect.arrayContaining(['offset', 'position', 'value']));
    expect(await types('documents')).toMatchObject({ content: 'bytea', uploaded_at: 'timestamp(0) without time zone' }); // Oracle DATE has whole seconds
    expect(await types('setting')).toMatchObject({ value: 'text' });
    // Decimals of NUMBER without a size are kept (DEFAULT_NUMERIC numeric).
    expect(Number(await one(`SELECT count(*) FROM "${TARGET}".spare_part WHERE total_value <> trunc(total_value)`))).toBe(25371);
    expect(await one(`SELECT obj_description('"${TARGET}".spare_part'::regclass, 'pg_class')`)).toBeTruthy();
  });

  test('overrides: booleans, DATE as date, one column type, comments skipped', async () => {
    await decide({ ora2pg: {
      REPLACE_AS_BOOLEAN: 'SPARE_PART:IS_ACTIVE CUSTOMER_MASTER:IS_VIP',
      DATA_TYPE: 'DATE:date',
      MODIFY_TYPE: 'CUSTOMER_MASTER:CUSTOMER_CODE:varchar(20)',
      DISABLE_COMMENT: true,
    } });
    const run = await migrate(['SPARE_PART', 'CUSTOMER_MASTER', 'CUSTOMIZED_RANK']);
    for (const t of ['SPARE_PART', 'CUSTOMER_MASTER', 'CUSTOMIZED_RANK']) loaded(run, t);

    expect(await types('spare_part')).toMatchObject({ is_active: 'boolean' });
    expect(await types('customer_master')).toMatchObject({ is_vip: 'boolean', customer_code: 'character varying(20)', created_on: 'date' });
    // 'Y' became true and 'N' false: 26,667 Y and 3,333 N in Oracle.
    expect((await pg.query(`SELECT is_active, count(*)::int AS n FROM "${TARGET}".spare_part GROUP BY 1 ORDER BY 1`)).rows)
      .toEqual([{ is_active: false, n: 3333 }, { is_active: true, n: 26667 }]);
    expect(await one(`SELECT obj_description('"${TARGET}".spare_part'::regclass, 'pg_class')`)).toBeNull();
  });

  test('NUMBER mapping off: every NUMBER column becomes numeric', async () => {
    await decide({ ora2pg: { PG_NUMERIC_TYPE: false, PG_INTEGER_TYPE: false } });
    const run = await migrate(['SPARE_PART']);
    loaded(run, 'SPARE_PART');
    const t = await types('spare_part');
    for (const c of ['part_id', 'qty', 'in_stock', 'total_value']) expect(t[c]).toMatch(/^numeric/);
  });

  test('preserve case: table and column names keep Oracle upper case (calculated column TOTAL_VALUE too)', async () => {
    await decide({ ora2pg: { PRESERVE_CASE: true } });
    const run = await migrate(['SPARE_PART']);
    loaded(run, 'SPARE_PART');
    expect(Object.keys(await types('SPARE_PART'))).toEqual(expect.arrayContaining(['PART_ID', 'IS_ACTIVE']));
    expect(await types('spare_part')).toEqual({});
  });

  test('BLOB as large objects (oid): the documents load and match Oracle', async () => {
    await decide({ lob: { blobAs: 'oid' } });
    const run = await migrate(['DOCUMENTS']);
    loaded(run, 'DOCUMENTS');
    expect(await types('documents')).toMatchObject({ content: 'oid' });
    await pg.query(`SELECT lo_unlink(content) FROM "${TARGET}".documents WHERE content IS NOT NULL`);
  });

  test('a wrong boolean choice is caught, never loaded silently (IN_STOCK holds 0-9, not 0/1)', async () => {
    await decide({ ora2pg: { REPLACE_AS_BOOLEAN: 'SPARE_PART:IN_STOCK' } });
    const run = await migrate(['SPARE_PART']);
    const t = run.tables.SPARE_PART;
    const caught = t.status === 'failed' || (t.dataCheck && t.dataCheck.ok === false);
    expect(caught).toBe(true);
  });

  test('decimals rounded by a bigint mapping are caught (TOTAL_VALUE = QTY*UNIT_PRICE, a calculated NUMBER)', async () => {
    await decide({ ora2pg: { DEFAULT_NUMERIC: 'bigint' } });
    const run = await migrate(['SPARE_PART']);
    const t = run.tables.SPARE_PART;
    expect(t.status).toBe('failed');
    expect(t.error).toMatch(/Data check failed.*TOTAL_VALUE/);
  });

  test('numeric for NUMBER without precision: decimals kept, key columns still bigint', async () => {
    await decide();
    const run = await migrate(['CALENDAR_EXCEPTION', 'SPARE_PART']);
    loaded(run, 'CALENDAR_EXCEPTION');
    loaded(run, 'SPARE_PART');
    // EXCEPTION_ID is a primary key declared NUMBER (no precision): bigint, as agreed for IDs.
    expect(await types('calendar_exception')).toMatchObject({ exception_id: 'bigint' });
    expect(await types('spare_part')).toMatchObject({ total_value: 'numeric', unit_price: 'numeric(12,2)' });
  });

  test('a new run rebuilds a table whose type mapping changed; validation counts it in the custom target schema', async () => {
    await decide({ ora2pg: { DEFAULT_NUMERIC: 'bigint' } });
    const first = await migrate(['SPARE_PART']);
    expect(first.tables.SPARE_PART.status).toBe('failed');
    expect(await types('spare_part')).toMatchObject({ total_value: 'bigint' });

    await decide(); // back to numeric, the table stays in PostgreSQL
    const second = await migrate(['SPARE_PART'], { keep: true });
    loaded(second, 'SPARE_PART');
    expect(await types('spare_part')).toMatchObject({ total_value: 'numeric' });
    expect(second.events.map((e) => e.message).join('\n')).toMatch(/Table SPARE_PART is rebuilt/);
    // No scratch schema left behind.
    expect(Number(await one(`SELECT count(*) FROM pg_namespace WHERE nspname LIKE 'dma_check_%'`))).toBe(0);

    const v = await call('GET', `${P}/validation`);
    const row = v.data.rowCountCheck.find((r) => r[1] === 'spare_part');
    expect(row.slice(2, 5)).toEqual([30000, 30000, 'yes']);
  });

  test('a second run into the same schema reloads a table that a partitioned table points at (foreign key on every partition)', async () => {
    await decide();
    const first = await migrate(['STATION', 'PLAN_PE']);
    loaded(first, 'STATION');
    loaded(first, 'PLAN_PE');
    // PLAN_PE is partitioned and its foreign key to STATION is copied to each partition by PostgreSQL.
    const again = await migrate(['STATION', 'PLAN_PE'], { keep: true });
    loaded(again, 'STATION');
    loaded(again, 'PLAN_PE');
    expect(Number(await one(`SELECT count(*) FROM pg_constraint WHERE contype = 'f' AND conparentid = 0 AND conrelid = '"${TARGET}".plan_pe'::regclass`))).toBe(1);
  });
});
