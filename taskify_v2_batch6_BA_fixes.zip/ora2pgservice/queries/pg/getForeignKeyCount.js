'use strict';

const cacheService = require('../../utils/cache');
const logger = require('../../utils/logger');

/**
 * Retrieves the count of foreign keys in the specified schema from PostgreSQL.
 * It compares the live count against a cached value.
 * @param {object} connection - The active PostgreSQL client or connection from the pool.
 * @param {string} schemaName - The name of the database schema to query.
 * @returns {Promise<[object[], number, boolean]>} - Returns an array containing:
 * 1. The query result rows (e.g., [{ foreign_key_count: '5' }]),
 * 2. The cached foreign key count,
 * 3. A boolean indicating if the live count matches the cached value.
 */
async function getForeignKeyCount(connection, schemaName) {
  logger.info('getForeignKeyCount execution started');

  const queryText = `
    SELECT COUNT(*) AS foreign_key_count
    FROM pg_constraint con
    JOIN pg_namespace n ON n.oid = con.connamespace
    WHERE con.contype = 'f' AND con.conparentid = 0 AND n.nspname = $1;
  `;

  try {
    const { rows } = await connection.query(queryText, [(connection.pgSchema || schemaName.toLowerCase())]);

    const cachedForeignKeyCount = cacheService.get(`getForeignKeyCount:${schemaName}`);

    const isCountMatchingCache =
      Number(rows[0]?.foreign_key_count) === Number(cachedForeignKeyCount);

    logger.info(`getForeignKeyCount execution completed`);
    return [rows, cachedForeignKeyCount, isCountMatchingCache];
  } catch (error) {
    logger.error('getForeignKeyCount execution failed with exception', error);
    throw error;
  }
}

module.exports = { getForeignKeyCount };
