'use strict';

const cacheService = require('../../utils/cache');
const logger = require('../../utils/logger');

/**
 * Retrieves the count of primary keys using pg_catalog for accuracy.
 */
async function getPrimaryKeyCount(connection, schemaName) {
  logger.info('getPrimaryKeyCount execution started');

  // 'p' stands for Primary Key in pg_constraint
  const queryText = `
    SELECT COUNT(*) AS primary_key_count
    FROM pg_constraint con
    JOIN pg_namespace n ON n.oid = con.connamespace
    WHERE con.contype = 'p'
      AND con.conparentid = 0 -- partitions repeat their parent's key: counted once, like Oracle
      AND n.nspname = $1;
  `;

  try {
    const { rows } = await connection.query(queryText, [(connection.pgSchema || schemaName.toLowerCase())]);

    const cachedPrimaryKeyCount = cacheService.get(`getPrimaryKeyCount:${schemaName}`);

    const isCountMatchingCache =
      Number(rows[0]?.primary_key_count) === Number(cachedPrimaryKeyCount);

    logger.info('getPrimaryKeyCount execution completed');
    return [rows, cachedPrimaryKeyCount, isCountMatchingCache];
  } catch (error) {
    logger.error('getPrimaryKeyCount execution failed with exception', error);
    throw error;
  }
}

module.exports = { getPrimaryKeyCount };
