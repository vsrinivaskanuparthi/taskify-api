const logger = require('../../utils/logger');

async function runPrerequisiteAnalysis(connection, schemaName, migrationUser) {
    if (!connection || !schemaName) {
        // Fix: Throw a string message, not an object
        throw new Error("Database connection or Schema Name missing");
    }

    logger.info(`Prerequisite analysis started for schema: ${schemaName}`);

    try {
        // Parallel execution for better performance
        const [privilegeCheck, analyzeCheck, sessionCheck, flashbackCheck, typeCheck] = await Promise.all([
            checkPrivileges(connection, schemaName),
            checkLastAnalyzed(connection, schemaName),
            checkActiveSessions(connection, schemaName, migrationUser),
            checkFlashback(connection, schemaName),
            checkObjectTypes(connection, schemaName)
        ]);

        logger.info(`Prerequisite analysis completed for schema: ${schemaName}`);
        return [privilegeCheck, analyzeCheck, sessionCheck, flashbackCheck, typeCheck].filter(Boolean);

    } catch (error) {
        logger.error("Error during prerequisite analysis", error);
        // Fix: Re-throw the original error or a clear string message
        throw error;
    }
}

/** The migration user must see the schema's objects (DBA views) and be able to read its tables. */
async function checkPrivileges(connection, schemaName) {
    const result = await connection.execute(
        `SELECT COUNT(*), MIN(CASE WHEN object_type = 'TABLE' THEN object_name END)
           FROM dba_objects WHERE owner = :owner`, { owner: schemaName });
    const [count, table] = result.rows[0];
    let readable = !table;
    if (table) {
        try {
            await connection.execute(`SELECT 1 FROM "${schemaName}"."${table}" WHERE ROWNUM = 1`);
            readable = true;
        } catch { readable = false; }
    }
    const ok = count > 0 && readable;
    return {
        check: "permissions",
        response: ok,
        description: count === 0
            ? `No objects of ${schemaName} are visible: the migration user needs SELECT ANY DICTIONARY (or SELECT_CATALOG_ROLE) and the schema must not be empty.`
            : readable
                ? `Schema objects are visible and table data is readable (${count} objects).`
                : `Objects are visible but table data is not readable: grant SELECT ANY TABLE (or SELECT on each table) to the migration user.`
    };
}

/**
 * Columns of the schema's own object types (e.g. ADDRESS_T) can only be read by a user allowed to
 * use the type: without it ora2pg fails with OCI-21700 / ORA-24360 on those tables. Only reported
 * when the schema has such columns.
 */
async function checkObjectTypes(connection, schemaName) {
    // Two plain queries instead of LISTAGG(DISTINCT ...), which needs Oracle 19c (ORA-30482 before).
    const r = await connection.execute(
        `SELECT COUNT(DISTINCT c.table_name)
           FROM dba_tab_columns c JOIN dba_tables t ON t.owner = c.owner AND t.table_name = c.table_name
          WHERE c.owner = :owner AND c.data_type_owner = :owner AND t.temporary = 'N'`, { owner: schemaName });
    const tables = Number(r.rows[0][0]);
    if (!tables) return null;
    const ty = await connection.execute(
        `SELECT DISTINCT c.data_type
           FROM dba_tab_columns c JOIN dba_tables t ON t.owner = c.owner AND t.table_name = c.table_name
          WHERE c.owner = :owner AND c.data_type_owner = :owner AND t.temporary = 'N'
          ORDER BY c.data_type`, { owner: schemaName });
    const types = ty.rows.map((row) => row[0]).join(', ');
    const me = (await connection.execute(`SELECT USER FROM dual`)).rows[0][0];
    if (me === schemaName) return null;
    const anyType = (await connection.execute(`SELECT COUNT(*) FROM session_privs WHERE privilege = 'EXECUTE ANY TYPE'`)).rows[0][0] > 0;
    const missing = anyType ? 0 : (await connection.execute(
        `SELECT COUNT(DISTINCT c.data_type) FROM dba_tab_columns c
          WHERE c.owner = :owner AND c.data_type_owner = :owner
            AND NOT EXISTS (SELECT 1 FROM all_tab_privs p WHERE p.table_schema = :owner AND p.table_name = c.data_type AND p.privilege = 'EXECUTE')`,
        { owner: schemaName })).rows[0][0];
    return {
        check: "object types",
        response: missing === 0,
        description: missing === 0
            ? `${tables} tables use object types (${types}); the migration user can read them.`
            : `${tables} tables use object types (${types}) that the migration user may not use: their data load fails (OCI-21700). Ask the DBA: GRANT EXECUTE ANY TYPE TO ${me} (or EXECUTE on each type).`
    };
}

/**
 * ora2pg 25 reads data AS OF SCN. With FLASHBACK the run reads every table at one consistent SCN;
 * without it the engine falls back to current data, which is only safe while the application is stopped.
 */
async function checkFlashback(connection, schemaName) {
    try {
        const t = await connection.execute(
            `SELECT MIN(table_name) FROM dba_tables WHERE owner = :owner AND secondary = 'N'`, { owner: schemaName });
        const table = t.rows[0][0];
        if (table) {
            // AS OF SCN takes a literal, not a subquery (ORA-22818).
            const scn = (await connection.execute('SELECT current_scn FROM v$database')).rows[0][0];
            await connection.execute(`SELECT 1 FROM "${schemaName}"."${table}" AS OF SCN ${Number(scn)} WHERE ROWNUM = 1`);
        }
        return { check: "snapshot", response: true, description: "FLASHBACK works: all tables will be read at one consistent point in time (SCN)." };
    } catch (err) {
        return {
            check: "snapshot",
            response: false,
            description: `No consistent snapshot possible (${String(err.message).split('\n')[0]}). The load still works but reads current data: stop the application during the load, or grant FLASHBACK ANY TABLE to the migration user.`
        };
    }
}

async function checkLastAnalyzed(connection, schemaName) {
    // Real tables only: temporary tables, Oracle Text (DR$) and materialized view log tables never get statistics.
    const result = await connection.execute(
        `SELECT COUNT(*), LISTAGG(CASE WHEN rn <= 5 THEN table_name END, ', ') WITHIN GROUP (ORDER BY table_name)
           FROM (SELECT table_name, ROW_NUMBER() OVER (ORDER BY table_name) rn
                   FROM dba_tables
                  WHERE owner = :owner AND temporary = 'N' AND secondary = 'N'
                    AND table_name NOT LIKE 'DR$%' AND table_name NOT LIKE 'MLOG$%' AND table_name NOT LIKE 'RUPD$%' AND table_name NOT LIKE 'BIN$%'
                    AND table_name NOT IN (SELECT mview_name FROM dba_mviews WHERE owner = :owner)
                    AND (last_analyzed IS NULL OR last_analyzed < SYSDATE - 7))`,
        { owner: schemaName });
    const [stale, names] = result.rows[0];
    return {
        check: "analyze",
        response: stale === 0,
        description: stale === 0
            ? "Schema statistics are up to date (analysed within the last 7 days)."
            : `${stale} tables have missing or old statistics (${names}${stale > 5 ? ', …' : ''}): row estimates, time left and chunk plans will be off. Run EXEC DBMS_STATS.GATHER_SCHEMA_STATS('${schemaName}') first.`
    };
}

async function checkActiveSessions(connection, schemaName, migrationUser) {
    const query = `
        SELECT sid FROM (
            SELECT s.sid FROM v$locked_object l
            JOIN dba_objects o ON l.object_id = o.object_id
            JOIN v$session s ON l.session_id = s.sid
            WHERE o.owner = UPPER(:owner)
            UNION ALL
            SELECT sid FROM v$session
            WHERE username = UPPER(:owner)
            AND username NOT IN (UPPER(:migUser), 'SYS')
        ) WHERE ROWNUM <= 1
    `;

    // FIX: Using named object to bind :owner and :migUser correctly
    const result = await connection.execute(query, {
        owner: schemaName,
        migUser: migrationUser
    });

    const hasActiveSessions = result.rows.length > 0;

    return {
        check: "status",
        response: !hasActiveSessions,
        description: !hasActiveSessions
            ? "No active sessions or locks detected."
            : "Active sessions or locked objects detected. Killing sessions is recommended before migration."
    };
}

module.exports = { runPrerequisiteAnalysis };
