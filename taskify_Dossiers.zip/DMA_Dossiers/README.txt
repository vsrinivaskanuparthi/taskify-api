DMA v2 dossiers
- DMA_Architecture_Dossier_ARD.docx : high-level design (HLD)
- DMA_Software_Dossier_SD.docx      : low-level design (LLD)
- diagrams/      : every diagram as a high-resolution PNG (copy into any document)
- diagram-sources/ : the same diagrams as Mermaid text; edit and render again
  (e.g. paste into https://mermaid.live on a PC with internet, or any Mermaid tool)
