# DMA v2: batch 8, Oracle DB links (oracle_fdw)

Deploy after batch 7. No `.env` change, no new npm package.

## What was tested

A real `oracle_fdw` 2.9.0 test (PostgreSQL 16 + Oracle Instant Client 23), set up like a company server: the DBA installs the extension, and DMA's user is not a superuser.

Oracle link `ACMM_LINK` was mapped to `oracle_fdw`, then:
- **Remote tables:** read from PostgreSQL. ✅
- **Converted views using the link:** they return exactly what Oracle returns (180 / 50,000 / 3,000 rows). ✅
- **Application role:** `app_read` can read through the link. ✅
- **Re-applying the code, and a migration run with the code package:** both work. ✅

## What was fixed

| Problem | Now |
|---|---|
| A failed DB link showed a **green check** ("3 applied") | Red: "DB link failed", with the reason. The Live monitor shows it too |
| The error showed a server file path and no advice | Plain words plus what to do (wrong password / DBA grant missing / extension not installed / host not reachable) |
| "Used by 1 object" (wrong) | "Used by 3 objects (view operator, view customer, synonym)": view and code text is scanned |
| The mapping form was empty | Choosing oracle_fdw fills host, port, service, user and remote schema from Oracle's own link |
| No way to check a link before applying code | New **"Save and test"** button: connects for real, reads one row, keeps nothing |
| The test could say OK with a wrong password (oracle_fdw reuses open logins) | The test always logs in fresh |

A wrong password or host never breaks a working link: the whole link setup is one transaction, and the old link is kept.

## Your DBA must do this once, on the RHEL PostgreSQL server

1. Install the **Oracle Instant Client** (basic + sdk) and **oracle_fdw** for your PostgreSQL version. Packages or source: github.com/laurenz/oracle_fdw.
2. In the target database, as a superuser:
   ```sql
   CREATE EXTENSION oracle_fdw;
   GRANT USAGE ON FOREIGN DATA WRAPPER oracle_fdw TO <DMA's PostgreSQL user>;
   ```
3. **Network:** the **PostgreSQL server** (not the DMA server, not your PC) must reach each remote Oracle host and port (firewall).

Check with: `SELECT oracle_diag();` (it shows the oracle_fdw and Oracle client versions).

## Files

| | Files |
|---|---|
| `ora2pgservice/` | `services/code.js`, `services/migrate.js`, `queries/oracle/getDbLinks.js`, `controllers/codeController.js`, `routes/projectRoutes.js`, `tests/unit/dbLinks.test.js` (new), `tests/e2e/dblink.e2e.test.js` (new) |
| `ora2pgui/` | `src/pages/CodePage.tsx`, `src/pages/RunPage.tsx` |

## Deploy

1. Copy the folders.
2. `npm test` in `ora2pgservice`: it should end with **Tests: 81 passed**.
3. `npm run build` in `ora2pgui`.
4. On RHEL: `git pull`, then `pm2 restart ora2pg-service-prod`, then `pm2 restart ora2pg-worker-prod` (when no migration runs).
5. Copy `index.html` to nginx, then press Ctrl+F5.
6. Take a **new Snapshot** of projects that have DB links, so "used by" is counted the new way.

## Test on RHEL

- [ ] Code objects → DB link mapping → choose "Remote database stays on Oracle (oracle_fdw)": the fields are filled in. Check the host as seen from the PostgreSQL server.
- [ ] **Save and test** says "Connected: N remote tables and views…".
- [ ] With a wrong password, "Save and test" says "Wrong user or password".
- [ ] Apply your converted code: no red "DB link failed"; the views that use `link_<name>.<table>` return data.
