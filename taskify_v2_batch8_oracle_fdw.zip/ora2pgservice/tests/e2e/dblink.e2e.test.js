'use strict';

/**
 * End-to-end: an Oracle DB link that stays on Oracle becomes an oracle_fdw foreign server.
 * Needs a project whose PostgreSQL target has oracle_fdw installed by the DBA (CREATE EXTENSION
 * oracle_fdw; GRANT USAGE ON FOREIGN DATA WRAPPER oracle_fdw TO <DMA user>), with its snapshot
 * taken and CUSTOMER_MASTER migrated. Skipped unless DMA_E2E_FDW_PROJECT is set.
 *   DMA_E2E_FDW_PROJECT   e.g. FDW_TEST
 *   DMA_E2E_FDW_HOST/PORT the remote Oracle as the PostgreSQL server reaches it (default host.docker.internal:1522)
 *   ORACLE_REMOTE_PW      password of ACMM_REMOTE (dev-tools/testdb/credentials.env)
 * Test data (dev-tools/testdb): link ACMM_LINK → schema ACMM_REMOTE; views OPERATOR and CUSTOMER
 * and synonym SS10_THIRD read over it.
 */
const AdmZip = require('adm-zip');

const API = process.env.DMA_E2E_URL || 'http://localhost:5055';
const PROJECT = process.env.DMA_E2E_FDW_PROJECT;
const P = `${API}/api/projects/${PROJECT}`;
const maybe = PROJECT ? describe : describe.skip;
const LINK = 'ACMM_LINK';

jest.setTimeout(180000);

async function call(method, url, body, type = 'application/json') {
  const res = await fetch(url, { method, headers: body ? { 'Content-Type': type } : {}, body: body ? (Buffer.isBuffer(body) ? body : JSON.stringify(body)) : undefined });
  const text = await res.text();
  let data = null;
  try { data = JSON.parse(text); } catch { data = text; }
  return { status: res.status, data };
}
const mapping = (password) => ({ mappings: { [LINK]: {
  mode: 'oracle_fdw', host: process.env.DMA_E2E_FDW_HOST || 'host.docker.internal', port: process.env.DMA_E2E_FDW_PORT || '1522',
  dbname: 'FREEPDB1', remoteSchema: 'ACMM_REMOTE', user: 'ACMM_REMOTE', password, localSchema: 'link_acmm_link' } } });
const sql = async (target, q) => (await call('POST', `${P}/sql`, { target, sql: q })).data;
/** Applies the package and waits until its lastApply is newer than before. */
async function apply(id) {
  const before = (await call('GET', `${P}/code/packages/${id}`)).data.lastApply;
  expect((await call('POST', `${P}/code/packages/${id}/apply`, {})).status).toBeLessThan(300);
  for (;;) {
    await new Promise((r) => setTimeout(r, 2000));
    const m = (await call('GET', `${P}/code/packages/${id}`)).data;
    if (m.lastApply && (!before || m.lastApply.at !== before.at)) return m;
  }
}

maybe('DB links with oracle_fdw', () => {
  let pkg;

  test('the link is found with what uses it (views by their text, the synonym)', async () => {
    const { data } = await call('GET', `${P}/code`);
    const l = data.dbLinks.find((x) => x.name === LINK);
    expect(l.usedByNames).toEqual(expect.arrayContaining(['view OPERATOR', 'view CUSTOMER']));
    expect(l.synonyms).toContain('SS10_THIRD');
    expect(l.usedBy).toBe(3);
  });

  test('"Save and test": a wrong password is explained, the right one connects (nothing kept)', async () => {
    await call('PUT', `${P}/code/dblinks`, mapping('wrong-password'));
    const bad = (await call('POST', `${P}/code/dblinks/test`, { name: LINK })).data;
    expect(bad.ok).toBe(false);
    expect(bad.message).toMatch(/Wrong user or password/);
    await call('PUT', `${P}/code/dblinks`, mapping(process.env.ORACLE_REMOTE_PW));
    const ok = (await call('POST', `${P}/code/dblinks/test`, { name: LINK })).data;
    expect(ok).toMatchObject({ ok: true, tables: 4 });
  });

  test('converted code reading over the link is applied and returns what Oracle returns', async () => {
    const zip = new AdmZip();
    zip.addFile('views/operator.sql', Buffer.from('CREATE OR REPLACE VIEW operator AS SELECT operator_id, operator_name, role_code FROM link_acmm_link.operator_src WHERE active = 1;'));
    zip.addFile('views/customer.sql', Buffer.from('CREATE OR REPLACE VIEW customer AS SELECT c.customer_id, c.customer_name, r.country FROM customer_master c LEFT JOIN link_acmm_link.customer_src r ON r.customer_code = c.customer_code;'));
    zip.addFile('views/comac.sql', Buffer.from('CREATE OR REPLACE VIEW comac AS SELECT * FROM link_acmm_link.ss10_view_third;'));
    const up = await call('POST', `${P}/code/packages`, zip.toBuffer(), 'application/zip');
    expect(up.status).toBe(201);
    pkg = up.data.id;
    const m = await apply(pkg);
    expect(m.lastApply).toMatchObject({ dbLinks: 'ok', failed: 0 });

    for (const [q, oq] of [
      ['SELECT count(*) FROM operator', 'SELECT COUNT(*) FROM operator'],
      ['SELECT count(*), count(country) FROM customer', 'SELECT COUNT(*), COUNT(country) FROM customer'],
      ['SELECT count(*) FROM comac', 'SELECT COUNT(*) FROM comac'],
    ]) {
      const pg = await sql('postgres', q);
      const ora = await sql('oracle', oq);
      expect(pg.results[0].rows[0]).toEqual(ora.results[0].rows[0]);
    }
  });

  test('a failed link change is reported in plain words and the working link is kept', async () => {
    await call('PUT', `${P}/code/dblinks`, mapping('wrong-password'));
    const m = await apply(pkg);
    expect(m.lastApply.dbLinks).toMatch(/Wrong user or password.*previous DB link setup is kept/);
    expect(m.lastApply.dbLinks).not.toMatch(/psql:/);
    const pg = await sql('postgres', 'SELECT count(*) FROM operator');
    expect(Number(pg.results[0].rows[0][0])).toBeGreaterThan(0);
    await call('PUT', `${P}/code/dblinks`, mapping(process.env.ORACLE_REMOTE_PW)); // as it was
  });
});
