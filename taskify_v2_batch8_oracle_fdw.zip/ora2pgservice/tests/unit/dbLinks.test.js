'use strict';

// DB link errors in plain words: what went wrong and what to do (oracle_fdw / postgres_fdw).
const { dbLinkError } = require('../../services/code');

test.each([
  ['psql:/srv/p/.dblinks_1.sql:9: ERROR:  cannot authenticate connection to foreign Oracle server', /^cannot authenticate connection to foreign Oracle server\. Wrong user or password/],
  ['psql:/srv/p/.dblinks_1.sql:3: ERROR:  permission denied for foreign-data wrapper oracle_fdw', /GRANT USAGE ON FOREIGN DATA WRAPPER oracle_fdw TO <DMA user>/],
  ['ERROR:  permission denied to create extension "oracle_fdw"', /The extension is not installed in this PostgreSQL/],
  ['ERROR:  extension "oracle_fdw" is not available', /The DBA installs it on the PostgreSQL server/],
  ['ERROR:  cannot connect to foreign Oracle server', /cannot reach the remote database: check Host, Port and Service name/],
])('%s', (raw, expected) => {
  const msg = dbLinkError(raw);
  expect(msg).toMatch(expected);
  expect(msg).not.toMatch(/psql:|ERROR:/);
  expect(msg).toMatch(/previous DB link setup is kept unchanged\.$/);
});
