'use strict';

/**
 * Code objects (views, materialized views, functions, procedures, packages, triggers, types,
 * DB links, synonyms, grants) and the GenAI conversion round trip:
 *
 *  1. Export  ora2pg exports every code object type (one file per object where ora2pg supports
 *             it) into <project>/code/exports/<id>/ and zips it as
 *             <SCHEMA>_genai_candidates_<id>.zip together with CONVERSION_GUIDE.md.
 *  2. Upload  the converted files come back as a zip with the same folders
 *             (packages/, procedures/, functions/, views/ …). It is checked and extracted to
 *             <project>/code/packages/<id>/.
 *  3. Apply   during a migration run ("code" phase) or on demand. Files are applied with psql,
 *             each in its own transaction, in dependency order (types → DB links → functions →
 *             procedures → packages → views → materialized views → triggers → synonyms → grants).
 *             Objects that fail because something they need is not created yet are retried in
 *             further passes, so the order inside a folder does not matter.
 *
 * DB links: each Oracle DB link is mapped (Code objects page) to postgres_fdw (the remote
 * database is/was migrated to PostgreSQL), oracle_fdw (it stays on Oracle) or skipped. The engine
 * creates the server, user mapping and a local schema link_<name> with the remote tables imported,
 * so converted code replaces  table@LINK  with  link_<name>.table.
 */

const fs = require('fs');
const fsp = require('fs').promises;
const path = require('path');
const AdmZip = require('adm-zip');
const logger = require('../utils/logger');
const secrets = require('../utils/secrets');
const { CONSTANTS } = require('../utils/constants');
const { runWithProject } = require('../utils/context');
const { createRunLogger, executeAndLog } = require('../errorHandling/error');
const { buildConfig } = require('./config_modify');
const settingsSvc = require('./settings');
const store = require('./projectStore');
const events = require('./events');

// Folder name in the zip → ora2pg export type. The order is the apply order.
const FOLDERS = [
  { folder: 'types', type: 'TYPE', label: 'Types' },
  { folder: 'dblinks', type: 'DBLINK', label: 'DB links' },
  { folder: 'functions', type: 'FUNCTION', label: 'Functions' },
  { folder: 'procedures', type: 'PROCEDURE', label: 'Procedures' },
  { folder: 'packages', type: 'PACKAGE', label: 'Packages' },
  { folder: 'views', type: 'VIEW', label: 'Views' },
  { folder: 'mviews', type: 'MVIEW', label: 'Materialized views' },
  { folder: 'triggers', type: 'TRIGGER', label: 'Triggers' },
  { folder: 'synonyms', type: 'SYNONYM', label: 'Synonyms' },
  { folder: 'grants', type: 'GRANT', label: 'Grants' },
];
const ALIASES = {
  type: 'types', dblink: 'dblinks', db_links: 'dblinks', function: 'functions', procedure: 'procedures',
  package: 'packages', view: 'views', mview: 'mviews', materialized_views: 'mviews', trigger: 'triggers',
  synonym: 'synonyms', grant: 'grants',
};
const SQL_EXT = /\.(sql|psql|pgsql)$/i;

/**
 * ora2pg's package index file (packages.sql) includes the routine files with \i and absolute paths
 * of this server, and drops the package schema first. In the zip it keeps only what it really does:
 * create the package schema. The routines are separate files anyway. Other files are unchanged.
 */
async function zipText(file) {
  const text = await fsp.readFile(file, 'utf8');
  if (!/^\s*\\i\s/m.test(text)) return null;
  return text.split('\n').filter((l) => !/^\s*\\i\s/.test(l) && !/^\s*DROP\s+SCHEMA\b/i.test(l)).join('\n');
}

const codeDir = (projectName) => path.join(store.projectDir(projectName), 'code');
const exportsDir = (projectName) => path.join(codeDir(projectName), 'exports');
const packagesDir = (projectName) => path.join(codeDir(projectName), 'packages');
const stamp = () => new Date().toISOString().replace(/[-:]/g, '').replace(/\..+/, '').replace('T', '-');

const jobs = new Map(); // `${project}:export` / `${project}:apply` -> state (one of each at a time)

async function listDir(dir) {
  if (!fs.existsSync(dir)) return [];
  const out = [];
  for (const id of (await fsp.readdir(dir)).sort().reverse()) {
    const m = await store.readJson(path.join(dir, id, 'manifest.json'));
    if (m) out.push(m);
  }
  return out;
}

// ---------------------------------------------------------------- export

function exportStatus(projectName) {
  return jobs.get(`${projectName}:export`) || null;
}

/** Starts the ora2pg export of all code objects in the background (progress over SSE). */
async function startExport(projectName) {
  const key = `${projectName}:export`;
  if (jobs.has(key)) return jobs.get(key);
  const meta = await store.readMeta(projectName);
  if (!meta.selectedSchema) throw Object.assign(new Error('Select a schema first.'), { status: 400 });
  const oracle = store.oracleCredentials(meta);
  if (!oracle) throw Object.assign(new Error('Connect the Oracle source first.'), { status: 400 });

  const id = stamp();
  const schema = meta.selectedSchema;
  const dir = path.join(exportsDir(projectName), id);
  const state = {
    id, schema, status: 'RUNNING', startedAt: new Date().toISOString(),
    zipName: `${schema}_genai_candidates_${id}.zip`,
    steps: FOLDERS.map((f) => ({ folder: f.folder, label: f.label, status: 'pending', files: 0, objects: 0 })),
  };
  jobs.set(key, state);
  const emit = () => events.publish(projectName, 'codeExport', state);
  emit();

  runWithProject(projectName, async () => {
    const log = createRunLogger(dir);
    try {
      const settings = settingsSvc.resolve(meta);
      const conf = await buildConfig({
        outFile: path.join(dir, 'config', 'export.conf'),
        outputDir: path.join(dir, 'src'),
        oracle,
        schema,
        options: {
          pgSchema: settings.targetSchema || schema.toLowerCase(),
          directives: settingsSvc.ora2pgDirectives(settings),
          // One file per function / procedure / package / trigger: easier to convert one by one.
          extra: { FILE_PER_FUNCTION: 1 },
        },
      });
      // Three exports at a time.
      const queue = [...FOLDERS];
      const worker = async () => {
        while (queue.length) {
          const f = queue.shift();
          const step = state.steps.find((s) => s.folder === f.folder);
          step.status = 'running';
          emit();
          const out = path.join(dir, 'src', f.folder);
          await fsp.mkdir(out, { recursive: true });
          const res = await executeAndLog({
            cmd: CONSTANTS.ORA2PG_BIN,
            args: ['-p', '-t', f.type, '-c', conf, '-b', out, '-o', `${f.folder}.sql`],
            cwd: out,
            log,
            label: `Export ${f.type}`,
          });
          const files = await collectSqlFiles(out);
          step.files = files.length;
          step.objects = await countObjects(files);
          step.status = res.code === 0 ? 'done' : 'failed';
          if (res.code !== 0) step.error = res.errorTail.split('\n')[0];
          emit();
        }
      };
      await Promise.all([worker(), worker(), worker()]);

      // Zip: <folder>/<files>, plus the guide and a manifest of what is inside.
      const zip = new AdmZip();
      for (const f of FOLDERS) {
        for (const file of await collectSqlFiles(path.join(dir, 'src', f.folder))) {
          const zipDir = path.posix.join(f.folder, path.relative(path.join(dir, 'src', f.folder), path.dirname(file)).split(path.sep).join('/'));
          const cleaned = await zipText(file);
          if (cleaned !== null) zip.addFile(path.posix.join(zipDir, path.basename(file)), Buffer.from(cleaned));
          else zip.addLocalFile(file, zipDir);
        }
      }
      zip.addFile('CONVERSION_GUIDE.md', Buffer.from(conversionGuide(schema, meta, settings)));
      const manifest = {
        id, schema, zipName: state.zipName, createdAt: new Date().toISOString(),
        folders: state.steps.map(({ folder, label, files, objects, status, error }) => ({ folder, label, files, objects, status, error })),
      };
      zip.addFile('manifest.json', Buffer.from(JSON.stringify(manifest, null, 2)));
      zip.writeZip(path.join(dir, state.zipName));
      manifest.bytes = fs.statSync(path.join(dir, state.zipName)).size;
      await store.writeJsonAtomic(path.join(dir, 'manifest.json'), manifest);

      state.status = state.steps.some((s) => s.status === 'failed') ? 'COMPLETED_WITH_ERRORS' : 'COMPLETED';
      await store.updateMeta(projectName, (m) => ({ ...m, codeExportAt: manifest.createdAt })).catch(() => {});
      state.finishedAt = manifest.createdAt;
      state.bytes = manifest.bytes;
    } catch (err) {
      logger.error(`Code export failed: ${err.stack}`);
      state.status = 'FAILED';
      state.error = err.message;
    } finally {
      log.close();
      emit();
      setTimeout(() => jobs.delete(key), 1000);
    }
  });
  return state;
}

async function collectSqlFiles(dir) {
  const out = [];
  if (!fs.existsSync(dir)) return out;
  for (const e of await fsp.readdir(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) out.push(...await collectSqlFiles(p));
    else if (SQL_EXT.test(e.name) && fs.statSync(p).size > 0) {
      // Skip ora2pg's include-only master files (lines of \i …) when per-object files exist.
      const text = await fsp.readFile(p, 'utf8');
      const body = text.split('\n').filter((l) => l.trim() && !l.trim().startsWith('--') && !/^SET\s/i.test(l.trim()) && !l.trim().startsWith('\\set'));
      if (body.length && body.every((l) => l.trim().startsWith('\\i'))) continue;
      if (!body.length) continue;
      out.push(p);
    }
  }
  return out.sort();
}

async function countObjects(files) {
  let n = 0;
  for (const f of files) {
    const t = await fsp.readFile(f, 'utf8');
    n += (t.match(/^\s*CREATE\s/gim) || []).length;
  }
  return n;
}

function conversionGuide(schema, meta, settings) {
  const target = settings.targetSchema || schema.toLowerCase();
  const renames = (meta.columnRenames || []).map((c) => `${c.tableName}.${c.oldName} → ${c.name}`);
  const booleans = String(settings.ora2pg.REPLACE_AS_BOOLEAN || '').split(/\s+/).filter(Boolean);
  const links = Object.entries(meta.dbLinkMappings || {}).filter(([, m]) => m.mode !== 'skip');
  return `# ${schema}: code objects for conversion

Exported by ora2pg (PL/SQL already pre-converted where ora2pg could). Convert each file to
PostgreSQL (PL/pgSQL) and send the result back as a zip **with the same folders**:

\`\`\`
types/        functions/    procedures/   packages/
views/        mviews/       triggers/     synonyms/     grants/     dblinks/ (optional)
\`\`\`

Rules for the converted files
- One object per file is best; any file name ending in .sql works. Folders may contain sub-folders.
- Objects go into schema **${target}**. Unqualified names are fine (search_path is ${target}, public).
- Each file is applied in its own transaction. If it needs another object that is not created yet,
  it is retried after the others, so the order of files does not matter.
- Oracle packages: convert to a schema per package (e.g. pkg_name.proc) or prefixed functions;
  keep the same choice for every reference.
- Remote tables used through DB links (table@LINK) become foreign tables:
${links.length ? links.map(([name, m]) => `  - \`${name}\` → \`${m.localSchema}.<table>\` (${m.mode})`).join('\n') : '  - map the DB links on the Code objects page first; each LINK becomes schema link_<link>.'}
- Do not include CREATE SCHEMA / ALTER ... OWNER statements; leave grants to the grants/ folder.

Migration decisions (agreed${settings.decisions.agreedBy ? ` with ${settings.decisions.agreedBy}` : ': NOT YET AGREED'}): the tables already follow them, the code must too
- Object names: ${settings.ora2pg.PRESERVE_CASE ? 'Oracle UPPER case, always double-quoted ("EMPLOYEES")' : 'lower case, unquoted'}.
- Reserved-word columns (OFFSET, TYPE, VALUE, POSITION, PERCENT, HOUR, USER…): ${settings.ora2pg.USE_RESERVED_WORDS ? `keep the ORIGINAL name and double-quote it ("offset")${renames.length ? ', except the columns renamed below' : ''}. Never invent new names (no _val / _value suffix): the code must use the names the tables have.` : 'see the renames below.'}
${renames.length ? `- Column renames applied to the tables (use exactly these names):\n${renames.map((r) => `  - ${r}`).join('\n')}` : '- No column renames: use the Oracle column names.'}
- NUMBER: ${settings.ora2pg.PG_INTEGER_TYPE ? `NUMBER(p,0) → smallint/integer/bigint by precision, NUMBER without precision → ${settings.ora2pg.DEFAULT_NUMERIC}${settings.ora2pg.DEFAULT_NUMERIC === 'numeric' ? ' (primary and foreign key columns → bigint)' : ''}, decimals → ${settings.ora2pg.PG_NUMERIC_TYPE ? 'double precision' : 'numeric'}` : 'numeric everywhere'}. Function parameters and return types must use the SAME types as the columns they read/write (a numeric parameter does not match a bigint argument).
${booleans.length ? `- These columns are boolean: compare with true/false, never with 1/0:\n${booleans.map((b) => `  - ${b}`).join('\n')}` : '- No boolean columns: NUMBER(1) flags stay numbers (compare with 1/0).'}
- LOBs: CLOB → text, BLOB → ${settings.lob.blobAs}.
${settings.access.dualView ? '- A view `dual` exists in the target schema; `FROM dual` still works, but drop it where easy.' : '- There is no DUAL table: remove FROM dual (SELECT expr; is valid PostgreSQL).'}
`;
}

async function exportZipPath(projectName, id) {
  const m = await store.readJson(path.join(exportsDir(projectName), id, 'manifest.json'));
  if (!m) return null;
  return path.join(exportsDir(projectName), id, m.zipName);
}

// ---------------------------------------------------------------- upload

/**
 * Checks and extracts an uploaded zip of converted code. Accepts the folders above (also in
 * singular, any case) at the top level or inside one wrapping folder. Only .sql/.psql/.pgsql files
 * are used; anything else is listed as a warning. Entries that would escape the target folder
 * (absolute paths, "..") are rejected.
 */
async function uploadPackage(projectName, buffer, fileName) {
  let zip;
  try {
    zip = new AdmZip(buffer);
  } catch {
    throw Object.assign(new Error('The file is not a valid zip archive.'), { status: 400 });
  }
  const entries = zip.getEntries().filter((e) => !e.isDirectory && !/(^|\/)(__MACOSX|\.DS_Store)/.test(e.entryName));
  if (!entries.length) throw Object.assign(new Error('The zip is empty.'), { status: 400 });

  // A single wrapping folder (e.g. converted/packages/…) is allowed.
  const tops = new Set(entries.map((e) => e.entryName.split('/')[0]));
  const known = (n) => FOLDERS.some((f) => f.folder === n.toLowerCase()) || ALIASES[n.toLowerCase()];
  const strip = tops.size === 1 && !known([...tops][0]) && entries.every((e) => e.entryName.includes('/'));

  const id = stamp();
  const dir = path.join(packagesDir(projectName), id);
  const files = [];
  const warnings = [];
  for (const e of entries) {
    const parts = e.entryName.replace(/\\/g, '/').split('/').filter(Boolean).slice(strip ? 1 : 0);
    if (parts.some((p) => p === '..') || e.entryName.startsWith('/')) {
      throw Object.assign(new Error(`Unsafe path in zip: ${e.entryName}`), { status: 400 });
    }
    if (parts.length < 2) {
      if (!/^(manifest\.json|CONVERSION_GUIDE\.md|readme.*)$/i.test(parts[0] || '')) warnings.push(`${e.entryName}: not inside a known folder, ignored`);
      continue;
    }
    const folder = FOLDERS.find((f) => f.folder === parts[0].toLowerCase())?.folder || ALIASES[parts[0].toLowerCase()];
    if (!folder) { warnings.push(`${e.entryName}: unknown folder "${parts[0]}", ignored`); continue; }
    if (!SQL_EXT.test(parts[parts.length - 1])) { warnings.push(`${e.entryName}: not a .sql file, ignored`); continue; }
    const rel = path.join(folder, ...parts.slice(1));
    const target = path.join(dir, 'files', rel);
    if (!target.startsWith(path.join(dir, 'files') + path.sep)) throw Object.assign(new Error(`Unsafe path in zip: ${e.entryName}`), { status: 400 });
    await fsp.mkdir(path.dirname(target), { recursive: true });
    const data = e.getData();
    await fsp.writeFile(target, data);
    files.push({ folder, path: rel.split(path.sep).join('/'), bytes: data.length, status: 'pending' });
  }
  if (!files.length) {
    await fsp.rm(dir, { recursive: true, force: true });
    throw Object.assign(new Error(`No .sql files found in the expected folders (${FOLDERS.map((f) => f.folder).join(', ')}).`), { status: 400 });
  }
  // The original export uploaded by mistake: its manifest names a GenAI candidates zip of this tool.
  const exportManifest = entries.find((e) => /(^|\/)manifest\.json$/i.test(e.entryName));
  let notice = null;
  if (exportManifest) {
    try {
      const m = JSON.parse(exportManifest.getData().toString('utf8'));
      if (/_genai_candidates_/.test(m.zipName || '')) notice = (`This looks like the original export (${m.zipName}), not the converted code: its files are still Oracle PL/SQL and most will fail. Upload the zip your GenAI assistant returned.`);
    } catch { /* not ours */ }
  }
  const meta = await store.readMeta(projectName);
  const manifest = {
    id,
    fileName: String(fileName || 'converted.zip').slice(0, 200),
    schema: meta.selectedSchema,
    uploadedAt: new Date().toISOString(),
    folders: FOLDERS.map((f) => ({ folder: f.folder, label: f.label, files: files.filter((x) => x.folder === f.folder).length })).filter((f) => f.files),
    files,
    warnings: warnings.slice(0, 200),
    notice,
    lastApply: null,
  };
  await store.writeJsonAtomic(path.join(dir, 'manifest.json'), manifest);
  return manifest;
}

async function readPackage(projectName, id) {
  if (!/^[0-9-]+$/.test(id)) return null;
  return store.readJson(path.join(packagesDir(projectName), id, 'manifest.json'));
}

async function deletePackage(projectName, id) {
  if (!/^[0-9-]+$/.test(id)) return;
  await fsp.rm(path.join(packagesDir(projectName), id), { recursive: true, force: true });
}

// ---------------------------------------------------------------- DB links

const qi = (s) => `"${String(s).replace(/"/g, '""')}"`;
const ql = (s) => `'${String(s).replace(/'/g, "''")}'`;

/** SQL creating the FDW servers, user mappings and link_<name> schemas (passwords inside: 0600, deleted after use). */
function dbLinkSql(meta, appRoles = []) {
  const out = [];
  for (const [name, m] of Object.entries(meta.dbLinkMappings || {})) {
    if (!m || m.mode === 'skip') continue;
    const srv = `fdw_${name.toLowerCase().replace(/[^a-z0-9_]/g, '_')}`;
    const pwd = m.password ? secrets.decrypt(m.password) : '';
    if (m.mode === 'postgres_fdw') {
      out.push('CREATE EXTENSION IF NOT EXISTS postgres_fdw;');
      out.push(`DROP SERVER IF EXISTS ${qi(srv)} CASCADE;`);
      out.push(`CREATE SERVER ${qi(srv)} FOREIGN DATA WRAPPER postgres_fdw OPTIONS (host ${ql(m.host)}, port ${ql(m.port || '5432')}, dbname ${ql(m.dbname)});`);
    } else {
      out.push('CREATE EXTENSION IF NOT EXISTS oracle_fdw;');
      out.push(`DROP SERVER IF EXISTS ${qi(srv)} CASCADE;`);
      out.push(`CREATE SERVER ${qi(srv)} FOREIGN DATA WRAPPER oracle_fdw OPTIONS (dbserver ${ql(`//${m.host}:${m.port || '1521'}/${m.dbname}`)});`);
    }
    out.push(`CREATE USER MAPPING FOR CURRENT_USER SERVER ${qi(srv)} OPTIONS (user ${ql(m.user)}, password ${ql(pwd)});`);
    // The application's roles query the foreign tables too: they need USAGE on the server and their
    // own user mapping (missing in the Jaguar PoC: "permission denied for foreign server").
    for (const r of appRoles) {
      out.push(`GRANT USAGE ON FOREIGN SERVER ${qi(srv)} TO ${r};`);
      out.push(`CREATE USER MAPPING IF NOT EXISTS FOR ${r} SERVER ${qi(srv)} OPTIONS (user ${ql(m.user)}, password ${ql(pwd)});`);
    }
    out.push(`DROP SCHEMA IF EXISTS ${qi(m.localSchema)} CASCADE;`);
    out.push(`CREATE SCHEMA ${qi(m.localSchema)};`);
    out.push(`IMPORT FOREIGN SCHEMA ${qi(m.remoteSchema)} FROM SERVER ${qi(srv)} INTO ${qi(m.localSchema)};`);
    for (const r of appRoles) {
      out.push(`GRANT USAGE ON SCHEMA ${qi(m.localSchema)} TO ${r};`);
      out.push(`GRANT SELECT ON ALL TABLES IN SCHEMA ${qi(m.localSchema)} TO ${r};`);
    }
  }
  return out.join('\n');
}

/**
 * A DB link error in plain words: psql's file and line removed, plus what to do. The usual causes
 * on a company server: the DBA has not installed / granted the FDW extension, the PostgreSQL server
 * cannot reach the remote database, or the link's user or password is wrong.
 */
function dbLinkError(raw) {
  const msg = String(raw || 'failed').split('\n')[0].replace(/^psql:[^:]*:\d+:\s*/, '').replace(/^(ERROR|FATAL):\s*/, '').trim();
  const advice = [
    [/permission denied for foreign-data wrapper (\w+)/i, (m) => `The DBA must allow DMA's PostgreSQL user to use it: GRANT USAGE ON FOREIGN DATA WRAPPER ${m[1]} TO <DMA user>;`],
    [/permission denied to create extension|must be (owner|superuser)|extension "(oracle_fdw|postgres_fdw)" (is not available|does not exist)|could not open extension control file|could not load library/i,
      () => 'The extension is not installed in this PostgreSQL. The DBA installs it on the PostgreSQL server (for oracle_fdw also the Oracle Instant Client) and runs CREATE EXTENSION oracle_fdw; (or postgres_fdw) in the target database.'],
    [/cannot authenticate|ORA-01017|password authentication failed/i, () => "Wrong user or password for the remote database: check the link's User and Password."],
    [/cannot connect|ORA-12\d\d\d|could not connect|Connection refused|could not translate host name|timeout expired/i,
      () => "The PostgreSQL server cannot reach the remote database: check Host, Port and Service name as seen from the PostgreSQL server (not from the user's PC), and the firewall between them."],
    [/schema .* does not exist|ORA-00942|remote schema/i, () => 'The remote schema was not found: check Remote schema (Oracle names are usually UPPER case).'],
  ].map(([re, fn]) => { const m = re.exec(msg); return m ? fn(m) : null; }).find(Boolean);
  return `${msg}.${advice ? ` ${advice}` : ''} The previous DB link setup is kept unchanged.`;
}

/**
 * Tries one DB link mapping without keeping anything: creates the server, user mapping and imported
 * remote tables inside a transaction, reads one row through it, and rolls everything back.
 * Returns { ok, tables, message }.
 */
async function testDbLink(projectName, linkName) {
  const meta = await store.readMeta(projectName);
  const m = (meta.dbLinkMappings || {})[linkName];
  if (!m || m.mode === 'skip') return { ok: false, tables: 0, message: 'Choose how this link is created and save it first.' };
  const { ensurePostgresPool, getPostgresConnection } = require('../utils/postgreClient');
  await ensurePostgresPool(store.postgresCredentials(meta), projectName);
  const client = await getPostgresConnection(projectName);
  const sql = dbLinkSql({ dbLinkMappings: { [linkName]: m } }, settingsSvc.appRoles(settingsSvc.resolve(meta)));
  // oracle_fdw / postgres_fdw keep remote sessions open per PostgreSQL connection: closed first, so the
  // test really logs in with the saved user and password (a pooled connection may hold an older login).
  const closeRemote = () => client.query(m.mode === 'oracle_fdw' ? 'SELECT oracle_close_connections()' : 'SELECT postgres_fdw_disconnect_all()').catch(() => {});
  try {
    await closeRemote();
    await client.query('BEGIN');
    for (const statement of sql.split('\n').filter(Boolean)) await client.query(statement);
    const { rows } = await client.query(
      'SELECT foreign_table_name AS t FROM information_schema.foreign_tables WHERE foreign_table_schema = $1 ORDER BY 1', [m.localSchema]);
    if (rows.length) await client.query(`SELECT 1 FROM ${qi(m.localSchema)}.${qi(rows[0].t)} LIMIT 1`);
    return { ok: true, tables: rows.length, message: rows.length ? `Connected: ${rows.length} remote tables and views can be read (e.g. ${m.localSchema}.${rows[0].t}).` : 'Connected, but the remote schema has no tables or views.' };
  } catch (err) {
    return { ok: false, tables: 0, message: dbLinkError(err.message).replace(' The previous DB link setup is kept unchanged.', '') };
  } finally {
    await client.query('ROLLBACK').catch(() => {});
    await closeRemote();
    client.release();
  }
}

// ---------------------------------------------------------------- apply

/**
 * Applies a converted package (and the DB link mappings) to the target schema.
 * ctx: { pg, pgSchema, log, children, shouldStop, onProgress }
 * Returns { applied, failed: [{ path, error }], skipped }.
 */
async function applyPackage(projectName, id, ctx) {
  const manifest = await readPackage(projectName, id);
  if (!manifest) throw new Error(`Converted package ${id} not found.`);
  const dir = path.join(packagesDir(projectName), id, 'files');
  const meta = await store.readMeta(projectName);

  const env = {
    PGPASSWORD: ctx.pg.password,
    PGSSLMODE: CONSTANTS.PG_SSLMODE,
    PGOPTIONS: `-c search_path=${ctx.pgSchema},public`,
  };
  const psql = (args, label) => executeAndLog({
    cmd: CONSTANTS.PSQL_BIN,
    args: ['--host', ctx.pg.hostip, '--port', String(ctx.pg.port), '--dbname', ctx.pg.dbname, '--username', ctx.pg.username, '--no-psqlrc', '-v', 'ON_ERROR_STOP=1', '--single-transaction', ...args],
    env, log: ctx.log, children: ctx.children, label,
  });

  const result = { applied: 0, failed: [], dbLinks: null };

  // 1. DB link servers / foreign schemas, before any code that uses them.
  const settings = settingsSvc.resolve(meta);
  const linkSql = dbLinkSql(meta, settingsSvc.appRoles(settings));
  if (linkSql) {
    const f = path.join(packagesDir(projectName), id, `.dblinks_${process.pid}.sql`);
    await fsp.writeFile(f, linkSql, { mode: 0o600 });
    const r = await psql(['-f', f], 'Create DB link servers (FDW)');
    await fsp.unlink(f).catch(() => {});
    result.dbLinks = r.code === 0 ? 'ok' : dbLinkError(r.errorTail);
    if (r.code !== 0) ctx.log && ctx.log.error(`DB link mapping failed: ${result.dbLinks}`);
  }

  // 2. Files in folder order; failures are retried in later passes (dependencies).
  const order = (f) => FOLDERS.findIndex((x) => x.folder === f.folder);
  let pending = [...manifest.files].sort((a, b) => order(a) - order(b) || a.path.localeCompare(b.path));
  const errors = new Map();
  const total = pending.length;
  for (let pass = 1; pass <= 4 && pending.length; pass += 1) {
    const stillFailing = [];
    for (const file of pending) {
      if (ctx.shouldStop && ctx.shouldStop()) throw new Error('Stopped');
      const r = await psql(['-f', path.join(dir, file.path)], `Apply ${file.path}`);
      if (r.code === 0) {
        result.applied += 1;
        file.status = 'applied';
        file.error = null;
      } else {
        stillFailing.push(file);
        errors.set(file.path, (r.errorTail.split('\n').find((l) => /ERROR/.test(l)) || r.errorTail.split('\n')[0] || 'failed').trim());
      }
      if (ctx.onProgress) ctx.onProgress(result.applied, total, pass);
    }
    if (stillFailing.length === pending.length) break; // no progress: the rest needs fixing
    pending = stillFailing;
  }
  for (const f of pending) {
    f.error = errors.get(f.path);
    // Re-applying a package: objects that cannot be replaced (tables, materialized views) report
    // "already exists". They are listed as already present, not as failures.
    if (/already exists/i.test(f.error || '')) {
      f.status = 'exists';
      result.existing = (result.existing || 0) + 1;
      continue;
    }
    f.status = 'failed';
    result.failed.push({ path: f.path, error: f.error });
  }
  // 3. Grants for the application roles on what was just created (and the DUAL view if chosen).
  const access = settingsSvc.accessSql(settings, ctx.pgSchema);
  if (access.length) {
    const f = path.join(packagesDir(projectName), id, `.access_${process.pid}.sql`);
    await fsp.writeFile(f, access.map((q) => `${q};`).join('\n'), { mode: 0o600 });
    const r = await psql(['-f', f], 'Grant application access');
    await fsp.unlink(f).catch(() => {});
    if (r.code !== 0) ctx.log && ctx.log.error(`Application access grants failed: ${r.errorTail.split('\n')[0]}`);
  }
  if (!result.failed.length) await store.updateMeta(projectName, (m) => ({ ...m, codeAppliedAt: new Date().toISOString() })).catch(() => {});
  manifest.lastApply = { at: new Date().toISOString(), runId: ctx.runId || null, applied: result.applied, existing: result.existing || 0, failed: result.failed.length, dbLinks: result.dbLinks, target: ctx.pgSchema };
  await store.writeJsonAtomic(path.join(packagesDir(projectName), id, 'manifest.json'), manifest);
  return result;
}

/** Apply on demand (outside a migration run), in the background with live progress. */
async function startApply(projectName, id) {
  const key = `${projectName}:apply`;
  if (jobs.has(key)) throw Object.assign(new Error('Code is already being applied for this project.'), { status: 409 });
  const meta = await store.readMeta(projectName);
  const pg = store.postgresCredentials(meta);
  if (!pg) throw Object.assign(new Error('Connect the PostgreSQL target first.'), { status: 400 });
  if (!(await readPackage(projectName, id))) throw Object.assign(new Error('Package not found.'), { status: 404 });
  const settings = settingsSvc.resolve(meta);
  const pgSchema = settings.targetSchema || String(meta.selectedSchema || '').toLowerCase();

  const state = { id, status: 'RUNNING', startedAt: new Date().toISOString(), applied: 0, total: 0, pass: 1 };
  jobs.set(key, state);
  const emit = () => events.publish(projectName, 'codeApply', state);
  emit();
  runWithProject(projectName, async () => {
    const log = createRunLogger(path.join(packagesDir(projectName), id));
    try {
      const r = await applyPackage(projectName, id, {
        pg, pgSchema, log,
        onProgress: (applied, total, pass) => { Object.assign(state, { applied, total, pass }); emit(); },
      });
      Object.assign(state, { status: r.failed.length ? 'COMPLETED_WITH_ERRORS' : 'COMPLETED', failed: r.failed.length, dbLinks: r.dbLinks });
    } catch (err) {
      Object.assign(state, { status: 'FAILED', error: err.message });
    } finally {
      log.close();
      state.finishedAt = new Date().toISOString();
      emit();
      setTimeout(() => jobs.delete(key), 1000);
    }
  });
  return state;
}

module.exports = {
  FOLDERS,
  startExport,
  exportStatus,
  listExports: (p) => listDir(exportsDir(p)),
  exportZipPath,
  uploadPackage,
  listPackages: (p) => listDir(packagesDir(p)),
  readPackage,
  deletePackage,
  applyPackage,
  startApply,
  applyStatus: (p) => jobs.get(`${p}:apply`) || null,
  packageDir: (p, id) => path.join(packagesDir(p), id),
  testDbLink,
  dbLinkError,
};
