const logger = require("../../utils/logger");

/**
 * DB links the schema owns or can use (PUBLIC), with how many of its objects reference each one.
 * Used by the DB link mapping on the Code objects page.
 */
async function getDbLinks(connection, schemaName) {
  logger.info("getDbLinks execution started");
  const links = await connection.execute(
    `SELECT owner, db_link, username, host
       FROM dba_db_links
      WHERE owner IN (:owner, 'PUBLIC')
      ORDER BY owner, db_link`,
    { owner: schemaName }
  );
  const usage = await connection.execute(
    `SELECT referenced_link_name, COUNT(DISTINCT name)
       FROM dba_dependencies
      WHERE owner = :owner AND referenced_link_name IS NOT NULL
      GROUP BY referenced_link_name`,
    { owner: schemaName }
  );
  const used = new Map(usage.rows.map((r) => [String(r[0]).split('.')[0].toUpperCase(), Number(r[1])]));
  // Oracle records no dependency for views and SQL that read table@LINK: their text is searched too.
  const users = new Map(); // link → Set of object names
  const texts = [];
  const add = (rows) => rows.forEach(([obj, text]) => texts.push([obj, String(text || '')]));
  await connection.execute(`SELECT 'view ' || view_name, text FROM dba_views WHERE owner = :owner`, { owner: schemaName })
    .then((r) => add(r.rows)).catch(() => {});
  await connection.execute(`SELECT 'materialized view ' || mview_name, query FROM dba_mviews WHERE owner = :owner`, { owner: schemaName })
    .then((r) => add(r.rows)).catch(() => {});
  await connection.execute(`SELECT LOWER(type) || ' ' || name, text FROM dba_source WHERE owner = :owner AND INSTR(text, '@') > 0`, { owner: schemaName })
    .then((r) => add(r.rows)).catch(() => {});
  // Synonyms that point over a link (SYN → TABLE@LINK): ora2pg does not export them, the link mapping replaces them.
  const syn = await connection.execute(
    `SELECT db_link, synonym_name FROM dba_synonyms WHERE owner = :owner AND db_link IS NOT NULL`,
    { owner: schemaName }
  ).catch(() => ({ rows: [] }));
  const synonyms = new Map();
  for (const [link, name] of syn.rows) {
    const k = String(link).split('.')[0].toUpperCase();
    synonyms.set(k, [...(synonyms.get(k) || []), name]);
  }
  for (const [, name] of links.rows) {
    const short = String(name).split('.')[0];
    const re = new RegExp(`@\\s*"?${short.replace(/[$#]/g, '\\$&')}\\b`, 'i');
    users.set(short.toUpperCase(), new Set(texts.filter(([, t]) => re.test(t)).map(([o]) => o)));
  }
  return links.rows.map(([owner, name, username, host]) => ({
    owner,
    name,
    username,
    host,
    usedBy: Math.max(used.get(String(name).split('.')[0].toUpperCase()) || 0, (users.get(String(name).split('.')[0].toUpperCase()) || new Set()).size)
      + (synonyms.get(String(name).split('.')[0].toUpperCase()) || []).length,
    usedByNames: [...(users.get(String(name).split('.')[0].toUpperCase()) || [])].slice(0, 20),
    synonyms: synonyms.get(String(name).split('.')[0].toUpperCase()) || [],
  }));
}

module.exports = { getDbLinks };
